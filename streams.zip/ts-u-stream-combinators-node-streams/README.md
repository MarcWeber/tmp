test/test.ts actually contains draft of a benchmark and looks like IO is the bottleneck.
Interestingly this code performs better than
fs.creatReadableStream().pipe(fs.createWriteStream()) directly ?
