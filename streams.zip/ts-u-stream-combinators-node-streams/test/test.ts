import { async_pull_stream_to_writable, node_readable_to_push_stream } from "u-stream-combinators-node-streams";
import { } from "node:stream";
import fs from "fs";
import _ from "lodash";
import { run_tests_print } from 'u-testrunner';
import { push_to_pull } from "/tsmono/u-stream-combinators/transformers/async";
import { aps_buffered } from "/tsmono/u-stream-combinators/pull/async";

run_tests_print({
  'description': 'tests',
  'timeout' : 2000,
}, async (c) => {

    const tmp_dir = '/tmp'

    const bytes = _.range(0, 1024).map((x) => (""+x)[0]).join('')
    const more_bytes = _.range(0, 1024 * 100).map((x) => bytes).join("\n")

    const in_file = `${tmp_dir}/infile`
    const out_1 = `${tmp_dir}/out1`
    const out_2 = `${tmp_dir}/out2`
    const out_3 = `${tmp_dir}/out3`

    const node_test = async () => {
        const node_in = fs.createReadStream(in_file)
        const node_out = fs.createWriteStream(out_1)
        return new Promise((r,j) => {
            node_in.pipe(node_out).on('close', r)
        })
    }

    const stream_combinator_test = async (buffered: boolean) => {
        const node_in = fs.createReadStream(in_file)
        const node_out = fs.createWriteStream(out_2)
        let stream = push_to_pull(node_readable_to_push_stream(node_in))
        if (buffered)
                stream = aps_buffered(stream)
        await async_pull_stream_to_writable(
            stream,
            node_out
        )
    }

    fs.writeFileSync(in_file, more_bytes, 'utf8')

    console.log(await Promise.all([
            node_test().then(
                () => { console.log("node_ok")},
                (e) => `node failed ${e}`
            ),
            // why does sct always finish first?
            // is it even faster than the node implementation pipe() ?
            stream_combinator_test(false).then(
                () => { console.log("sct ok")},
                (e) => `sct failed ${e}`
            ),

            // why does sct always finish first?
            // is it even faster than the node implementation pipe() ?
            stream_combinator_test(true).then(
                () => { console.log("sct buffered ok")},
                (e) => `sct failed ${e}`
            ),
    ]))

    const s1 = fs.readFileSync(out_1, 'utf8')
    const s2 = fs.readFileSync(out_2, 'utf8')
    const s3 = fs.readFileSync(out_2, 'utf8')
    // c.describe('should be same').expect_deep_equal(s1, s2)
    console.log({len1: s1.length, len2: s2.length });

}).then(console.log, console.log)
