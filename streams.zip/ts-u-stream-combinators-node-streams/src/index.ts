// should be extra package
import {Readable, Writable} from "node:stream"
import { AddSink, PushSourceApiSignal, PushSourcePush } from "u-stream-combinators/push"
import { S_end } from "u-stream-combinators/symbols"
import { AsyncPullStream} from "u-stream-combinators/pull/async"
import { S_disconnect, S_pause, S_start } from "u-stream-combinators/symbols"
import { push_to_pull } from "./tsmono/u-stream-combinators/transformers/async"

export const node_readable_to_push_stream = <T>(readable: Readable): AddSink<T> => {
    // TODO: test

    let sink: PushSourcePush<T> | undefined= undefined
    let connected = false

    const addSink: AddSink<T>["addSink"] = (_sink) => {

        if (sink) throw Error('only one sink can be added!')

        sink = _sink

        return (signal: PushSourceApiSignal) => {

            if (signal == S_start) {
                if (connected){
                    readable.resume()
                } else {
                    readable.on('data',  (data) => _sink.push({value: data}) )
                    readable.on('end',   () => _sink.push(S_end) )
                    readable.on('close', () => _sink.push(S_end) )
                    readable.on('error', (e) => _sink.push({error: e}) )
                    connected = true;
                }
            }

            if (signal == S_pause){
                readable.pause()
            }

            if (signal == S_disconnect){
                readable.destroy()
            }
        }
    }

    return {
        addSink
    }
}

export const node_readable_to_pull_stream = <T>(readable: Readable): AsyncPullStream<T> => 
    push_to_pull(node_readable_to_push_stream(readable))

export const async_pull_stream_to_writable = async <T>(s: AsyncPullStream<T>, writeable: Writable) => {
    // TODO: test
    while (true){
        try {
            const v = await s()
            if (v == S_end){
                writeable.end()
                return 
            } else writeable.write(v)
            const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
        } catch (e) {
            writeable.emit('error', e)
        }
    }
}
