
// // export type SourceConnectable = {
// //     connectSource: (api: {
// //         pause(): void
// //         disconnect(): void // end()
// //     }) => void
// // }
// // // allow combining pushable streams
// // export type Pipeable<T>   = {
// //     pipe(  stream: PushStream<T> & SourceConnectable): void
// //     unpipe(stream: PushStream<T>): void
// // }

// // export type PushMultiplexerOptions = {
// //     autoend?: boolean // if no stream is left, auto end source ?
// // }

// // implemen like pull/index PushMultiplexer
// export class PushMultiplexer<T> {

//     private push_streams: PushStream<T>[]
//     private status: "ended" | "paused" | "running"

//     constructor(private source: Pipeable<T>, private o: PushMultiplexerOptions) {
//         this.push_streams = []
//         this.status = "paused"
//         this.source.pipe(this)
//     }

//     // make this private by passing interface ?
//     push (t: T): undefined | t_end {
//         const ending: PushStream<T>[] = []
//         for (let s of this.push_streams ) {
//             const r = s.push(t)
//             if (r == S_end) ending.push(s)
//         }
//         return this._unpipe(...ending)
//     }

//     end(){
//     }

//     start(){
//         this.source.start()
//         this.status = "running"
//     }

//     pause(){
//         this.status = "paused"
//         this.source.pause()
//     }

//     pipe(stream: PushStream<T>){
//         this.push_streams.push(stream)
//     }

//     _unpipe(...streams: PushStream<T>[]){
//         this.push_streams = this.push_streams.filter((x) => !streams.includes(x))
//         if (this.push_streams.length == 0 && this.o.autoend) {
//             this.source.unpipe(this)
//             this.source.end()
//             return S_end
//         }
//     }

//     unpipe(...streams: PushStream<T>[]){
//         this._unpipe(...streams)
//     }
// }



export class PromiseHandlers<T>{

    private rra: ResolveRejectArray<T> | undefined = undefined

    constructor() {
    }

    promise(){
        if (this.rra) throw Error('p_handlers set, called iterator without waiting for previous result')
        return new Promise((r,j) => { this.rra =[r,j] })
    }

    resolve(v:T){ this.rra![0](v); this.rra = undefined; }
    reject(e: any){ this.rra![1](e);  this.rra = undefined; }

}


// should be extra package
import {Readable, Writable} from "node:stream"
import { AddSink, PushSourceApiSignal, PushSourcePush } from "./push"

import { AsyncPullStream} from "./pull/async"
import { S_disconnect, S_pause, S_start, S_end, t_end } from "./symbols"

export const node_readable_to_push_stream = <T>(readable: Readable): AddSink<T> => {
    // TODO: test

    let sink: PushSourcePush<T> | undefined= undefined
    let connected = false

    const addSink: AddSink<T>["addSink"] = (_sink) => {

        if (sink) throw Error('only one sink can be added!')

        sink = _sink

        return (signal: PushSourceApiSignal) => {

            if (signal == S_start) {
                if (connected){
                    readable.resume()
                } else {
                    readable.on('data',  (data) => _sink.push({value: data}) )
                    readable.on('end',   () => _sink.push(S_end) )
                    readable.on('close', () => _sink.push(S_end) )
                    readable.on('error', (e) => _sink.push({error: e}) )
                    connected = true;
                }
            }

            if (signal == S_pause){
                readable.pause()
            }

            if (signal == S_disconnect){
                readable.destroy()
            }
        }
    }

    return {
        addSink
    }
}

export const async_pull_stream_to_writable = async <T>(s: AsyncPullStream<T>, writeable: Writable) => {
    // TODO: test
    while (true){
        try {
            const v = await s()
            writeable.write(v)
        } catch (e) {
            writeable.emit('error', e)
        }
    }
}
