import * as ps from "u-stream-combinators/pull";
import * as aps from "u-stream-combinators/pull/async";
import * as hs from "u-stream-combinators/push";

import {createLimiter} from "u-frequency-limiter";

import { run_tests_print } from 'u-testrunner';
import { S_disconnect, S_end, S_pause, S_start, t_end } from "/symbols";
import { map_concurrently, push_to_pull } from "/transformers/async";
import { Expectation } from "/tsmono/u-testrunner";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

export const push_stream_from_array = <T>(a: T[]): hs.AddSink<T> => {
    let intervalTimer: undefined | ReturnType<typeof setInterval> = undefined
    let connected = false
    let sink: hs.PushSourcePush<T> | undefined= undefined
    const stop = () => clearInterval(intervalTimer)
    const start = () => {
        intervalTimer = setInterval(() => {
            const v = a.shift()
            if (v == undefined) {
                sink!.push(S_end)
                stop()
            } else {
                sink!.push({value: v})
            }
        }, 30)
    }

    const addSink: hs.AddSink<T>["addSink"] = (_sink) => {
        if (connected) throw Error('x')
        sink = _sink
        connected = true
        return (signal: hs.PushSourceApiSignal) => {
            if (signal == S_start) start()
            if (signal == S_pause) stop()
            if (signal == S_disconnect) stop()
        }
    }
    return {
        addSink
    }
}

export const add_delay = <T>(stream: aps.AsyncPullStream<T>, delay: number): aps.AsyncPullStream<T> => {
    const getToken = createLimiter(() => delay)
    return (async (end?: t_end) => {
        await getToken()
        return stream(end)
    }) as aps.AsyncPullStream<T>
}

run_tests_print({
  'description': 'tests',
  'timeout' : 4000,
}, async (c) => {

    let tests: Record< string, (a:Expectation) => Promise<void>> = {

            test_push_to_pull_stream: async (a) => {
                const push_stream = push_stream_from_array([1,2,3])
                const pull_stream = push_to_pull(push_stream)
                a.expect_deep_equal(
                    [1,2,3],
                    await aps.aps_to_array(pull_stream)
                )
            },



            test_aps_zip: async (a) => {
                let stream1 = aps.aps_from_array([1,2,3]).next
                let stream2 = aps.aps_from_array(['A', 'B', "C"]).next
                const stream = aps.aps_zip({}, stream1, stream2)
                a.expect_deep_equal(
                    [[1,"A"], [2,"B"], [3, "C"]],
                    await aps.aps_to_array(stream)
                )
                c.todo('early = true /false cases')
            },

            test_buffered_stream_map: async (a) => {
            let stream = aps.aps_from_array([1,2,3]).next
            stream = add_delay(stream, 50)
            stream = aps.aps_buffered(stream)
            a.expect_deep_equal(
                [1,2,3],
                await aps.aps_to_array(stream)
            )
        },

        test_buffered_stream: async (a) => {
            let stream = aps.aps_from_array([1,2,3,4,5]).next
            stream = add_delay(stream, 50)
            stream = aps.aps_buffered(stream, { watermarks: {low_watermark: 1, high_watermark: 2 }})
            stream = add_delay(stream, 50)
            a.expect_deep_equal(
                [1,2,3,4,5],
                await aps.aps_to_array(stream)
            )
        },

        test_iterator_works_1: async (a) => {
            const reader = ps.from_array([1,2,3])
            a.expect_deep_equal(
                [1,2,3],
                ps.to_array(reader.next)
            )
        },

        // SYNC from_array + map
        
        test_iterator_with_map_works: async (a) => {
            const reader = ps.from_array([1,2,3])
            const mapped = ps.map(reader.next, (x) => x * 2)
            a.expect_deep_equal(
                [2,4,6],
                ps.to_array(mapped)
            )
        },

        // ASYNC from_array end
            test_iterator_works2: async (a) => {
            const reader = aps.aps_from_array([1,2,3])
            a.expect_deep_equal(
                [1,2,3],
                await aps.aps_to_array(reader.next)
            )
        },

        test_iterator_works2b: async (a) => {
            const reader = aps.aps_from_array([1,2,3], {done: false})
            reader.push(4,5,6)
            reader.done()
            a.expect_deep_equal(
                [1,2,3, 4,5,6],
                await aps.aps_to_array(reader.next)
            )
        },

        test_async_iterator_with_async_map: async (a) => {
            const reader = aps.aps_from_array([1,2,3], {done: false})
            const mapped = aps.aps_map(reader.next, async (x) => x * 2)
            reader.push(4,5,6)
            reader.done()
            a.expect_deep_equal(
                [2,4,6, 8, 10, 12],
                await aps.aps_to_array(mapped)
            )
        },

        // multiplexer
        test_multiplexer: async (a) => {
            a.expect_true(true)
            const a1 = c.describe('multiplexer arr 1')
            const a2 = c.describe('multiplexer arr 2')
            const reader = aps.aps_from_array([1,2,3])

            const mapped = aps.aps_map(reader.next, async (x) => x * 2)
            const m = aps.aps_multiplexer(mapped, {autoend: true})

            const s1 = m.source()
            const s2 = m.source()

            const [A1, A2] = await Promise.all([
                aps.aps_to_array(s1),
                aps.aps_to_array(s2)
            ])
            a1.expect_deep_equal( [2,4,6], A1)
            a2.expect_deep_equal( [2,4,6], A2)
        },


        test_async_queue: async (a) => {
            const reader1 = aps.aps_from_array([1,2,3])
            const reader2 = aps.aps_from_array([])
            const reader3 = aps.aps_from_array([1,2,3])
            const q = aps.aps_queue({streams: [reader1.next, reader2.next, reader3.next]})
            a.expect_deep_equal(
                await aps.aps_to_array(q.next),
                [1,2,3, 1,2,3]
            )
        },

         test_async_queue2: async (a) => {
            const reader = aps.aps_partition(aps.aps_from_array([1,2,3]).next, 2)
            a.expect_deep_equal(
                await aps.aps_to_array(reader),
               [[1,2],[3]]
            )
        },

        test_async_queue_done: async (a) => {
            const reader1 = aps.aps_from_array([1,2,3])
            const reader2 = aps.aps_from_array([])
            const reader3 = aps.aps_from_array([1,2,3])
            const q = aps.aps_queue({streams: [reader1.next], done: false});

            setTimeout(() => {
                    q.push(reader2.next, reader3.next)
                    q.done()
            }, 100)

            a.expect_deep_equal(
                await aps.aps_to_array(q.next),
                [1,2,3, 1,2,3]
            )
        },

            test_async_concurrency: async (a) => {
            a.expect_true(true)
            const a_ordered = c.describe('a_ordered')
            const a_any_order = c.describe('a_any_order')

            const r = (preserve_order: boolean) => 
                map_concurrently(
                    aps.aps_from_array([10,9,8,7,6,5,4,3,2,1]).next,
                        async (i) => {
                            await sleep(i * 30)
                            return i
                        },
                        {preserve_order, concurrency: 10}
                )

            // for await (const v of aps.aps_to_iter(r(true))) {
            //         console.log(`v ${v}`);
            // }

            a_any_order.expect_deep_equal(
                [1,2,3,4,5,6,7,8,9,10],
                await aps.aps_to_array(r(false))
            )

            a_ordered.expect_deep_equal(
                [10,9,8,7,6,5,4,3,2,1],
                await aps.aps_to_array(r(true))
            )
        }
    }

    // run a single test:
    // tests = { test_async_concurrency: tests.test_async_concurrency }
    await Promise.all(
        Object.entries(tests).map(([k,v]) => v(c.describe(k)))
    )

    c.todo('f.screateStreamReader & push_to_pull')
    c.todo('totally missing -> end of stream callback events')
    c.todo('test ending from recieving side!')

}).then(console.log, console.log)
