ts-u-stream-combinators
========================
Minimalistic streaming library using modern TS/JS features.
Eg the (Async)PullStream<T> is just a (async) function returning the value or
S_end. Call the function with (S_end) to indigate you don't need more items.

The only drawback is that you cannot cancel waiting for an item
unless switching to Bluebird promises, see ROADMAP.

features:
* backpressure
* propagating error by Exception
  Eg look at aps_zip how well this works in some cases - no code at all
* signal end top down / bottom up
* branch a stream into multiple listeners (multiplexer)
* allows to free resources on both sides: sources and sinks
* compared to node:stream allow to connect late. So you can pass
  around a stream without having to know about its source
  and everyting including freeing resources will just work.
  pipe() of node doesn't allow that. You can create your own
  glue code waiting for end/close whatever events, though
* allow turning push designs into pull designs.
  The push interface is much more complicated because it requires
  pausing the source !
* ending or open ended. Meaning you you can add items while the stream
  has been returned. See queue and aps_from_array implementation

Examples
========
See test/test.ts
Aborting:
const stream = ...

for await (const v of aps_to_iter(stream)) {
    if (cond) stream(S_end)
}

maybe a await asp_for_each(stream, async () => return S_end)
interface is nicer?

related
=======
ts-u-stream-combinators-node-streams. This implements piping to from node
Readable/Writable eg fs.creatReadStream and fs.createWriteStream

details
=======

Streams typicall look like this

source -> [ optional transformers ] -> sink

source: 
    push or pull implementation

transformers:
    Transform or filter stream

sink: 
    push or pull implementation

goals:
    - allow changing streams dynamically (eg audio)
      -> special case dynamic

    - don't loose data (thus sources should start sending data once the pipe is
      setup)
      -> special case static

    - be as simple as possible

pushing vs pulling

    push and pull streams can be identified at runtime by having a push/pull
    interface. So dynamically setting up pipes is possible

    - (async) pulling / iterator

      * don't have to be started, because starting is done by executing the
        function

      - passing throw 'exceptions' using throw .. catch
      - wrapping (mappping / filtering) an iterator happens to be a closure
      
      Pulling from a source which can 'stall' requires async functions of course
      cause gou have to await the next item

      start/pausing:
        You cannot get something out of a pull pipe without having constructed it
        So there is nothing to take care of

      backpressure:
        If source no data, will not return (consequence if you source doesn't have data is PullStreamAsync)
        If receiver doesn't want data stops asking

      Implementations: 
        See PullStream / PullStreamAsync


    - (async) pushing (here is next value, do something with it)
      * must be started/stopped to not loose data

      start/pausing:
        Pushing basically is multiplexing (push to one or many)
        If you push before pipe is complete you'll loose data
        So something to be pushed to needs to be able to start/pause


      backpressure:
        If source no data, will not return (consequence if you source doesn't have data is PullStreamAsync)
        If receiver doesn't want data stops asking

      Implementations: 

        See PushStream / Pipeable


- multiplexers:
  Eg have multiple consmuers
  puisng to multiple streams and attaching / detaching receivers can be
  implemented easily.

- adopters
  turning pushing into pulling or pulling into pushing

- transformers 
  * map
  * filter
  * chunking is a special case of transforming.
    Eg turm a Stream of T into T[]

- node like piping:

  pipe(
    source,
    transformer1,
    transformer2,
    sink
 )

  Typing for each number of items works well enough
    pipe(source, sink)
    pipe(source, t1, sink)
    pipe(source, t1, t2, sink)

  provide combine(transformer1, transformer2) in case the provided typings are
  not enough?

 Would this allow mixing push/pull streams ?

GOALS:
* allow to free resources (eg if a source captures node handle or file watching
  it should free if the recievers are not interested anymore)
* focus on success (but allow catching errors if you really have to)
* returned values are always valid or undefined
  If your values contain undefined wrap them because it's the most common case
* Back pressuring is implemented by not callaing the the stream
  function.
* async support by using async functions
* errors support by simply throwing throws
* end of iterator returns undefined
* upstream no elements -> function blocks and return once items
  are available. Of course this only works with async AsyncPullIterator
* eventually there are faster implementations because eg node-streams
  implemenatation uses many lambdas to encode error as function call
* allows iterating by to_iter and async_to_iter (or use while loop)
* allows freing resuorces in reader by ending stream with "end"
* support progress by wrapping in object ?
* multiple consumers can be implemented similar to node-streams



recipes:
========
file -> transformer -> file

push_to_pull(node_readable_to_push_stream(fs.createRedable(file)))
-> file not implemented yet

alternatives
============

The lines comparison might be unfair because I might be lacking
this amount of comments

This library:
700 lines
ts-u-stream-combinators-node-streams
139 lines 

node:streams: 
- when do the streams actually end?
- the contained type isn't typed
  There is a closed PR @ nodejs

https://github.com/poelstra/ts-stream
-> more complicated than required
(approx 2000 lines including tests)

There is a fork from Java streams
-> probably more complicated than requried
https://github.com/lordofdestiny/streams-ts
(2600 lines)

drawbacks
==========
Because Promises are used to stop a source you have to await
an item before you can send S_end.
Cancellable Bluebbird promises could be used

If you have start heavy computation request (database,ai)
then you can't abort easily

ROADMAP
========
Rewrite using Bluebird promises ?

TODO:
=====
events to find out when stream finished (onend or such) ?
Eventually extract the exception-in-values types into its own library
pipe like see above
Is the non async version useful enough to keep ?
Should iterator interface be used instead - it requires packing the values for
each step causing more GC stress in simple cases.

Would a class interface have been nicer ? Then you could be using
stream.forEach and have iter() interface attached to each class?
