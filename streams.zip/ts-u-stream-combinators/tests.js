"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/object-keys/isArguments.js
var require_isArguments = __commonJS({
  "node_modules/object-keys/isArguments.js"(exports2, module2) {
    "use strict";
    var toStr = Object.prototype.toString;
    module2.exports = function isArguments(value) {
      var str = toStr.call(value);
      var isArgs = str === "[object Arguments]";
      if (!isArgs) {
        isArgs = str !== "[object Array]" && value !== null && typeof value === "object" && typeof value.length === "number" && value.length >= 0 && toStr.call(value.callee) === "[object Function]";
      }
      return isArgs;
    };
  }
});

// node_modules/object-keys/implementation.js
var require_implementation = __commonJS({
  "node_modules/object-keys/implementation.js"(exports2, module2) {
    "use strict";
    var keysShim;
    if (!Object.keys) {
      has = Object.prototype.hasOwnProperty;
      toStr = Object.prototype.toString;
      isArgs = require_isArguments();
      isEnumerable = Object.prototype.propertyIsEnumerable;
      hasDontEnumBug = !isEnumerable.call({ toString: null }, "toString");
      hasProtoEnumBug = isEnumerable.call(function() {
      }, "prototype");
      dontEnums = [
        "toString",
        "toLocaleString",
        "valueOf",
        "hasOwnProperty",
        "isPrototypeOf",
        "propertyIsEnumerable",
        "constructor"
      ];
      equalsConstructorPrototype = function(o) {
        var ctor = o.constructor;
        return ctor && ctor.prototype === o;
      };
      excludedKeys = {
        $applicationCache: true,
        $console: true,
        $external: true,
        $frame: true,
        $frameElement: true,
        $frames: true,
        $innerHeight: true,
        $innerWidth: true,
        $onmozfullscreenchange: true,
        $onmozfullscreenerror: true,
        $outerHeight: true,
        $outerWidth: true,
        $pageXOffset: true,
        $pageYOffset: true,
        $parent: true,
        $scrollLeft: true,
        $scrollTop: true,
        $scrollX: true,
        $scrollY: true,
        $self: true,
        $webkitIndexedDB: true,
        $webkitStorageInfo: true,
        $window: true
      };
      hasAutomationEqualityBug = function() {
        if (typeof window === "undefined") {
          return false;
        }
        for (var k in window) {
          try {
            if (!excludedKeys["$" + k] && has.call(window, k) && window[k] !== null && typeof window[k] === "object") {
              try {
                equalsConstructorPrototype(window[k]);
              } catch (e) {
                return true;
              }
            }
          } catch (e) {
            return true;
          }
        }
        return false;
      }();
      equalsConstructorPrototypeIfNotBuggy = function(o) {
        if (typeof window === "undefined" || !hasAutomationEqualityBug) {
          return equalsConstructorPrototype(o);
        }
        try {
          return equalsConstructorPrototype(o);
        } catch (e) {
          return false;
        }
      };
      keysShim = function keys(object) {
        var isObject = object !== null && typeof object === "object";
        var isFunction = toStr.call(object) === "[object Function]";
        var isArguments = isArgs(object);
        var isString = isObject && toStr.call(object) === "[object String]";
        var theKeys = [];
        if (!isObject && !isFunction && !isArguments) {
          throw new TypeError("Object.keys called on a non-object");
        }
        var skipProto = hasProtoEnumBug && isFunction;
        if (isString && object.length > 0 && !has.call(object, 0)) {
          for (var i = 0; i < object.length; ++i) {
            theKeys.push(String(i));
          }
        }
        if (isArguments && object.length > 0) {
          for (var j = 0; j < object.length; ++j) {
            theKeys.push(String(j));
          }
        } else {
          for (var name in object) {
            if (!(skipProto && name === "prototype") && has.call(object, name)) {
              theKeys.push(String(name));
            }
          }
        }
        if (hasDontEnumBug) {
          var skipConstructor = equalsConstructorPrototypeIfNotBuggy(object);
          for (var k = 0; k < dontEnums.length; ++k) {
            if (!(skipConstructor && dontEnums[k] === "constructor") && has.call(object, dontEnums[k])) {
              theKeys.push(dontEnums[k]);
            }
          }
        }
        return theKeys;
      };
    }
    var has;
    var toStr;
    var isArgs;
    var isEnumerable;
    var hasDontEnumBug;
    var hasProtoEnumBug;
    var dontEnums;
    var equalsConstructorPrototype;
    var excludedKeys;
    var hasAutomationEqualityBug;
    var equalsConstructorPrototypeIfNotBuggy;
    module2.exports = keysShim;
  }
});

// node_modules/object-keys/index.js
var require_object_keys = __commonJS({
  "node_modules/object-keys/index.js"(exports2, module2) {
    "use strict";
    var slice = Array.prototype.slice;
    var isArgs = require_isArguments();
    var origKeys = Object.keys;
    var keysShim = origKeys ? function keys(o) {
      return origKeys(o);
    } : require_implementation();
    var originalKeys = Object.keys;
    keysShim.shim = function shimObjectKeys() {
      if (Object.keys) {
        var keysWorksWithArguments = function() {
          var args = Object.keys(arguments);
          return args && args.length === arguments.length;
        }(1, 2);
        if (!keysWorksWithArguments) {
          Object.keys = function keys(object) {
            if (isArgs(object)) {
              return originalKeys(slice.call(object));
            }
            return originalKeys(object);
          };
        }
      } else {
        Object.keys = keysShim;
      }
      return Object.keys || keysShim;
    };
    module2.exports = keysShim;
  }
});

// node_modules/es-errors/index.js
var require_es_errors = __commonJS({
  "node_modules/es-errors/index.js"(exports2, module2) {
    "use strict";
    module2.exports = Error;
  }
});

// node_modules/es-errors/eval.js
var require_eval = __commonJS({
  "node_modules/es-errors/eval.js"(exports2, module2) {
    "use strict";
    module2.exports = EvalError;
  }
});

// node_modules/es-errors/range.js
var require_range = __commonJS({
  "node_modules/es-errors/range.js"(exports2, module2) {
    "use strict";
    module2.exports = RangeError;
  }
});

// node_modules/es-errors/ref.js
var require_ref = __commonJS({
  "node_modules/es-errors/ref.js"(exports2, module2) {
    "use strict";
    module2.exports = ReferenceError;
  }
});

// node_modules/es-errors/syntax.js
var require_syntax = __commonJS({
  "node_modules/es-errors/syntax.js"(exports2, module2) {
    "use strict";
    module2.exports = SyntaxError;
  }
});

// node_modules/es-errors/type.js
var require_type = __commonJS({
  "node_modules/es-errors/type.js"(exports2, module2) {
    "use strict";
    module2.exports = TypeError;
  }
});

// node_modules/es-errors/uri.js
var require_uri = __commonJS({
  "node_modules/es-errors/uri.js"(exports2, module2) {
    "use strict";
    module2.exports = URIError;
  }
});

// node_modules/has-symbols/shams.js
var require_shams = __commonJS({
  "node_modules/has-symbols/shams.js"(exports2, module2) {
    "use strict";
    module2.exports = function hasSymbols() {
      if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
        return false;
      }
      if (typeof Symbol.iterator === "symbol") {
        return true;
      }
      var obj = {};
      var sym = Symbol("test");
      var symObj = Object(sym);
      if (typeof sym === "string") {
        return false;
      }
      if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
        return false;
      }
      if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
        return false;
      }
      var symVal = 42;
      obj[sym] = symVal;
      for (sym in obj) {
        return false;
      }
      if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
        return false;
      }
      if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
        return false;
      }
      var syms = Object.getOwnPropertySymbols(obj);
      if (syms.length !== 1 || syms[0] !== sym) {
        return false;
      }
      if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
        return false;
      }
      if (typeof Object.getOwnPropertyDescriptor === "function") {
        var descriptor = Object.getOwnPropertyDescriptor(obj, sym);
        if (descriptor.value !== symVal || descriptor.enumerable !== true) {
          return false;
        }
      }
      return true;
    };
  }
});

// node_modules/has-symbols/index.js
var require_has_symbols = __commonJS({
  "node_modules/has-symbols/index.js"(exports2, module2) {
    "use strict";
    var origSymbol = typeof Symbol !== "undefined" && Symbol;
    var hasSymbolSham = require_shams();
    module2.exports = function hasNativeSymbols() {
      if (typeof origSymbol !== "function") {
        return false;
      }
      if (typeof Symbol !== "function") {
        return false;
      }
      if (typeof origSymbol("foo") !== "symbol") {
        return false;
      }
      if (typeof Symbol("bar") !== "symbol") {
        return false;
      }
      return hasSymbolSham();
    };
  }
});

// node_modules/has-proto/index.js
var require_has_proto = __commonJS({
  "node_modules/has-proto/index.js"(exports2, module2) {
    "use strict";
    var test = {
      __proto__: null,
      foo: {}
    };
    var $Object = Object;
    module2.exports = function hasProto() {
      return { __proto__: test }.foo === test.foo && !(test instanceof $Object);
    };
  }
});

// node_modules/function-bind/implementation.js
var require_implementation2 = __commonJS({
  "node_modules/function-bind/implementation.js"(exports2, module2) {
    "use strict";
    var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
    var toStr = Object.prototype.toString;
    var max = Math.max;
    var funcType = "[object Function]";
    var concatty = function concatty2(a, b) {
      var arr = [];
      for (var i = 0; i < a.length; i += 1) {
        arr[i] = a[i];
      }
      for (var j = 0; j < b.length; j += 1) {
        arr[j + a.length] = b[j];
      }
      return arr;
    };
    var slicy = function slicy2(arrLike, offset) {
      var arr = [];
      for (var i = offset || 0, j = 0; i < arrLike.length; i += 1, j += 1) {
        arr[j] = arrLike[i];
      }
      return arr;
    };
    var joiny = function(arr, joiner) {
      var str = "";
      for (var i = 0; i < arr.length; i += 1) {
        str += arr[i];
        if (i + 1 < arr.length) {
          str += joiner;
        }
      }
      return str;
    };
    module2.exports = function bind(that) {
      var target = this;
      if (typeof target !== "function" || toStr.apply(target) !== funcType) {
        throw new TypeError(ERROR_MESSAGE + target);
      }
      var args = slicy(arguments, 1);
      var bound;
      var binder = function() {
        if (this instanceof bound) {
          var result = target.apply(
            this,
            concatty(args, arguments)
          );
          if (Object(result) === result) {
            return result;
          }
          return this;
        }
        return target.apply(
          that,
          concatty(args, arguments)
        );
      };
      var boundLength = max(0, target.length - args.length);
      var boundArgs = [];
      for (var i = 0; i < boundLength; i++) {
        boundArgs[i] = "$" + i;
      }
      bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
      if (target.prototype) {
        var Empty = function Empty2() {
        };
        Empty.prototype = target.prototype;
        bound.prototype = new Empty();
        Empty.prototype = null;
      }
      return bound;
    };
  }
});

// node_modules/function-bind/index.js
var require_function_bind = __commonJS({
  "node_modules/function-bind/index.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation2();
    module2.exports = Function.prototype.bind || implementation;
  }
});

// node_modules/hasown/index.js
var require_hasown = __commonJS({
  "node_modules/hasown/index.js"(exports2, module2) {
    "use strict";
    var call = Function.prototype.call;
    var $hasOwn = Object.prototype.hasOwnProperty;
    var bind = require_function_bind();
    module2.exports = bind.call(call, $hasOwn);
  }
});

// node_modules/get-intrinsic/index.js
var require_get_intrinsic = __commonJS({
  "node_modules/get-intrinsic/index.js"(exports2, module2) {
    "use strict";
    var undefined2;
    var $Error = require_es_errors();
    var $EvalError = require_eval();
    var $RangeError = require_range();
    var $ReferenceError = require_ref();
    var $SyntaxError = require_syntax();
    var $TypeError = require_type();
    var $URIError = require_uri();
    var $Function = Function;
    var getEvalledConstructor = function(expressionSyntax) {
      try {
        return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
      } catch (e) {
      }
    };
    var $gOPD = Object.getOwnPropertyDescriptor;
    if ($gOPD) {
      try {
        $gOPD({}, "");
      } catch (e) {
        $gOPD = null;
      }
    }
    var throwTypeError = function() {
      throw new $TypeError();
    };
    var ThrowTypeError = $gOPD ? function() {
      try {
        arguments.callee;
        return throwTypeError;
      } catch (calleeThrows) {
        try {
          return $gOPD(arguments, "callee").get;
        } catch (gOPDthrows) {
          return throwTypeError;
        }
      }
    }() : throwTypeError;
    var hasSymbols = require_has_symbols()();
    var hasProto = require_has_proto()();
    var getProto = Object.getPrototypeOf || (hasProto ? function(x) {
      return x.__proto__;
    } : null);
    var needsEval = {};
    var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined2 : getProto(Uint8Array);
    var INTRINSICS = {
      __proto__: null,
      "%AggregateError%": typeof AggregateError === "undefined" ? undefined2 : AggregateError,
      "%Array%": Array,
      "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined2 : ArrayBuffer,
      "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined2,
      "%AsyncFromSyncIteratorPrototype%": undefined2,
      "%AsyncFunction%": needsEval,
      "%AsyncGenerator%": needsEval,
      "%AsyncGeneratorFunction%": needsEval,
      "%AsyncIteratorPrototype%": needsEval,
      "%Atomics%": typeof Atomics === "undefined" ? undefined2 : Atomics,
      "%BigInt%": typeof BigInt === "undefined" ? undefined2 : BigInt,
      "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined2 : BigInt64Array,
      "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined2 : BigUint64Array,
      "%Boolean%": Boolean,
      "%DataView%": typeof DataView === "undefined" ? undefined2 : DataView,
      "%Date%": Date,
      "%decodeURI%": decodeURI,
      "%decodeURIComponent%": decodeURIComponent,
      "%encodeURI%": encodeURI,
      "%encodeURIComponent%": encodeURIComponent,
      "%Error%": $Error,
      "%eval%": eval,
      // eslint-disable-line no-eval
      "%EvalError%": $EvalError,
      "%Float32Array%": typeof Float32Array === "undefined" ? undefined2 : Float32Array,
      "%Float64Array%": typeof Float64Array === "undefined" ? undefined2 : Float64Array,
      "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined2 : FinalizationRegistry,
      "%Function%": $Function,
      "%GeneratorFunction%": needsEval,
      "%Int8Array%": typeof Int8Array === "undefined" ? undefined2 : Int8Array,
      "%Int16Array%": typeof Int16Array === "undefined" ? undefined2 : Int16Array,
      "%Int32Array%": typeof Int32Array === "undefined" ? undefined2 : Int32Array,
      "%isFinite%": isFinite,
      "%isNaN%": isNaN,
      "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined2,
      "%JSON%": typeof JSON === "object" ? JSON : undefined2,
      "%Map%": typeof Map === "undefined" ? undefined2 : Map,
      "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
      "%Math%": Math,
      "%Number%": Number,
      "%Object%": Object,
      "%parseFloat%": parseFloat,
      "%parseInt%": parseInt,
      "%Promise%": typeof Promise === "undefined" ? undefined2 : Promise,
      "%Proxy%": typeof Proxy === "undefined" ? undefined2 : Proxy,
      "%RangeError%": $RangeError,
      "%ReferenceError%": $ReferenceError,
      "%Reflect%": typeof Reflect === "undefined" ? undefined2 : Reflect,
      "%RegExp%": RegExp,
      "%Set%": typeof Set === "undefined" ? undefined2 : Set,
      "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
      "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined2 : SharedArrayBuffer,
      "%String%": String,
      "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined2,
      "%Symbol%": hasSymbols ? Symbol : undefined2,
      "%SyntaxError%": $SyntaxError,
      "%ThrowTypeError%": ThrowTypeError,
      "%TypedArray%": TypedArray,
      "%TypeError%": $TypeError,
      "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined2 : Uint8Array,
      "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined2 : Uint8ClampedArray,
      "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined2 : Uint16Array,
      "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined2 : Uint32Array,
      "%URIError%": $URIError,
      "%WeakMap%": typeof WeakMap === "undefined" ? undefined2 : WeakMap,
      "%WeakRef%": typeof WeakRef === "undefined" ? undefined2 : WeakRef,
      "%WeakSet%": typeof WeakSet === "undefined" ? undefined2 : WeakSet
    };
    if (getProto) {
      try {
        null.error;
      } catch (e) {
        errorProto = getProto(getProto(e));
        INTRINSICS["%Error.prototype%"] = errorProto;
      }
    }
    var errorProto;
    var doEval = function doEval2(name) {
      var value;
      if (name === "%AsyncFunction%") {
        value = getEvalledConstructor("async function () {}");
      } else if (name === "%GeneratorFunction%") {
        value = getEvalledConstructor("function* () {}");
      } else if (name === "%AsyncGeneratorFunction%") {
        value = getEvalledConstructor("async function* () {}");
      } else if (name === "%AsyncGenerator%") {
        var fn = doEval2("%AsyncGeneratorFunction%");
        if (fn) {
          value = fn.prototype;
        }
      } else if (name === "%AsyncIteratorPrototype%") {
        var gen = doEval2("%AsyncGenerator%");
        if (gen && getProto) {
          value = getProto(gen.prototype);
        }
      }
      INTRINSICS[name] = value;
      return value;
    };
    var LEGACY_ALIASES = {
      __proto__: null,
      "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
      "%ArrayPrototype%": ["Array", "prototype"],
      "%ArrayProto_entries%": ["Array", "prototype", "entries"],
      "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
      "%ArrayProto_keys%": ["Array", "prototype", "keys"],
      "%ArrayProto_values%": ["Array", "prototype", "values"],
      "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
      "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
      "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
      "%BooleanPrototype%": ["Boolean", "prototype"],
      "%DataViewPrototype%": ["DataView", "prototype"],
      "%DatePrototype%": ["Date", "prototype"],
      "%ErrorPrototype%": ["Error", "prototype"],
      "%EvalErrorPrototype%": ["EvalError", "prototype"],
      "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
      "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
      "%FunctionPrototype%": ["Function", "prototype"],
      "%Generator%": ["GeneratorFunction", "prototype"],
      "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
      "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
      "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
      "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
      "%JSONParse%": ["JSON", "parse"],
      "%JSONStringify%": ["JSON", "stringify"],
      "%MapPrototype%": ["Map", "prototype"],
      "%NumberPrototype%": ["Number", "prototype"],
      "%ObjectPrototype%": ["Object", "prototype"],
      "%ObjProto_toString%": ["Object", "prototype", "toString"],
      "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
      "%PromisePrototype%": ["Promise", "prototype"],
      "%PromiseProto_then%": ["Promise", "prototype", "then"],
      "%Promise_all%": ["Promise", "all"],
      "%Promise_reject%": ["Promise", "reject"],
      "%Promise_resolve%": ["Promise", "resolve"],
      "%RangeErrorPrototype%": ["RangeError", "prototype"],
      "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
      "%RegExpPrototype%": ["RegExp", "prototype"],
      "%SetPrototype%": ["Set", "prototype"],
      "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
      "%StringPrototype%": ["String", "prototype"],
      "%SymbolPrototype%": ["Symbol", "prototype"],
      "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
      "%TypedArrayPrototype%": ["TypedArray", "prototype"],
      "%TypeErrorPrototype%": ["TypeError", "prototype"],
      "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
      "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
      "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
      "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
      "%URIErrorPrototype%": ["URIError", "prototype"],
      "%WeakMapPrototype%": ["WeakMap", "prototype"],
      "%WeakSetPrototype%": ["WeakSet", "prototype"]
    };
    var bind = require_function_bind();
    var hasOwn = require_hasown();
    var $concat = bind.call(Function.call, Array.prototype.concat);
    var $spliceApply = bind.call(Function.apply, Array.prototype.splice);
    var $replace = bind.call(Function.call, String.prototype.replace);
    var $strSlice = bind.call(Function.call, String.prototype.slice);
    var $exec = bind.call(Function.call, RegExp.prototype.exec);
    var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
    var reEscapeChar = /\\(\\)?/g;
    var stringToPath = function stringToPath2(string) {
      var first = $strSlice(string, 0, 1);
      var last = $strSlice(string, -1);
      if (first === "%" && last !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
      } else if (last === "%" && first !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
      }
      var result = [];
      $replace(string, rePropName, function(match, number, quote, subString) {
        result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
      });
      return result;
    };
    var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
      var intrinsicName = name;
      var alias;
      if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
        alias = LEGACY_ALIASES[intrinsicName];
        intrinsicName = "%" + alias[0] + "%";
      }
      if (hasOwn(INTRINSICS, intrinsicName)) {
        var value = INTRINSICS[intrinsicName];
        if (value === needsEval) {
          value = doEval(intrinsicName);
        }
        if (typeof value === "undefined" && !allowMissing) {
          throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
        }
        return {
          alias,
          name: intrinsicName,
          value
        };
      }
      throw new $SyntaxError("intrinsic " + name + " does not exist!");
    };
    module2.exports = function GetIntrinsic(name, allowMissing) {
      if (typeof name !== "string" || name.length === 0) {
        throw new $TypeError("intrinsic name must be a non-empty string");
      }
      if (arguments.length > 1 && typeof allowMissing !== "boolean") {
        throw new $TypeError('"allowMissing" argument must be a boolean');
      }
      if ($exec(/^%?[^%]*%?$/, name) === null) {
        throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
      }
      var parts = stringToPath(name);
      var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
      var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
      var intrinsicRealName = intrinsic.name;
      var value = intrinsic.value;
      var skipFurtherCaching = false;
      var alias = intrinsic.alias;
      if (alias) {
        intrinsicBaseName = alias[0];
        $spliceApply(parts, $concat([0, 1], alias));
      }
      for (var i = 1, isOwn = true; i < parts.length; i += 1) {
        var part = parts[i];
        var first = $strSlice(part, 0, 1);
        var last = $strSlice(part, -1);
        if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
          throw new $SyntaxError("property names with quotes must have matching quotes");
        }
        if (part === "constructor" || !isOwn) {
          skipFurtherCaching = true;
        }
        intrinsicBaseName += "." + part;
        intrinsicRealName = "%" + intrinsicBaseName + "%";
        if (hasOwn(INTRINSICS, intrinsicRealName)) {
          value = INTRINSICS[intrinsicRealName];
        } else if (value != null) {
          if (!(part in value)) {
            if (!allowMissing) {
              throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
            }
            return void 0;
          }
          if ($gOPD && i + 1 >= parts.length) {
            var desc = $gOPD(value, part);
            isOwn = !!desc;
            if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
              value = desc.get;
            } else {
              value = value[part];
            }
          } else {
            isOwn = hasOwn(value, part);
            value = value[part];
          }
          if (isOwn && !skipFurtherCaching) {
            INTRINSICS[intrinsicRealName] = value;
          }
        }
      }
      return value;
    };
  }
});

// node_modules/es-define-property/index.js
var require_es_define_property = __commonJS({
  "node_modules/es-define-property/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var $defineProperty = GetIntrinsic("%Object.defineProperty%", true) || false;
    if ($defineProperty) {
      try {
        $defineProperty({}, "a", { value: 1 });
      } catch (e) {
        $defineProperty = false;
      }
    }
    module2.exports = $defineProperty;
  }
});

// node_modules/gopd/index.js
var require_gopd = __commonJS({
  "node_modules/gopd/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var $gOPD = GetIntrinsic("%Object.getOwnPropertyDescriptor%", true);
    if ($gOPD) {
      try {
        $gOPD([], "length");
      } catch (e) {
        $gOPD = null;
      }
    }
    module2.exports = $gOPD;
  }
});

// node_modules/define-data-property/index.js
var require_define_data_property = __commonJS({
  "node_modules/define-data-property/index.js"(exports2, module2) {
    "use strict";
    var $defineProperty = require_es_define_property();
    var $SyntaxError = require_syntax();
    var $TypeError = require_type();
    var gopd = require_gopd();
    module2.exports = function defineDataProperty(obj, property, value) {
      if (!obj || typeof obj !== "object" && typeof obj !== "function") {
        throw new $TypeError("`obj` must be an object or a function`");
      }
      if (typeof property !== "string" && typeof property !== "symbol") {
        throw new $TypeError("`property` must be a string or a symbol`");
      }
      if (arguments.length > 3 && typeof arguments[3] !== "boolean" && arguments[3] !== null) {
        throw new $TypeError("`nonEnumerable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 4 && typeof arguments[4] !== "boolean" && arguments[4] !== null) {
        throw new $TypeError("`nonWritable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 5 && typeof arguments[5] !== "boolean" && arguments[5] !== null) {
        throw new $TypeError("`nonConfigurable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 6 && typeof arguments[6] !== "boolean") {
        throw new $TypeError("`loose`, if provided, must be a boolean");
      }
      var nonEnumerable = arguments.length > 3 ? arguments[3] : null;
      var nonWritable = arguments.length > 4 ? arguments[4] : null;
      var nonConfigurable = arguments.length > 5 ? arguments[5] : null;
      var loose = arguments.length > 6 ? arguments[6] : false;
      var desc = !!gopd && gopd(obj, property);
      if ($defineProperty) {
        $defineProperty(obj, property, {
          configurable: nonConfigurable === null && desc ? desc.configurable : !nonConfigurable,
          enumerable: nonEnumerable === null && desc ? desc.enumerable : !nonEnumerable,
          value,
          writable: nonWritable === null && desc ? desc.writable : !nonWritable
        });
      } else if (loose || !nonEnumerable && !nonWritable && !nonConfigurable) {
        obj[property] = value;
      } else {
        throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
      }
    };
  }
});

// node_modules/has-property-descriptors/index.js
var require_has_property_descriptors = __commonJS({
  "node_modules/has-property-descriptors/index.js"(exports2, module2) {
    "use strict";
    var $defineProperty = require_es_define_property();
    var hasPropertyDescriptors = function hasPropertyDescriptors2() {
      return !!$defineProperty;
    };
    hasPropertyDescriptors.hasArrayLengthDefineBug = function hasArrayLengthDefineBug() {
      if (!$defineProperty) {
        return null;
      }
      try {
        return $defineProperty([], "length", { value: 1 }).length !== 1;
      } catch (e) {
        return true;
      }
    };
    module2.exports = hasPropertyDescriptors;
  }
});

// node_modules/define-properties/index.js
var require_define_properties = __commonJS({
  "node_modules/define-properties/index.js"(exports2, module2) {
    "use strict";
    var keys = require_object_keys();
    var hasSymbols = typeof Symbol === "function" && typeof Symbol("foo") === "symbol";
    var toStr = Object.prototype.toString;
    var concat = Array.prototype.concat;
    var defineDataProperty = require_define_data_property();
    var isFunction = function(fn) {
      return typeof fn === "function" && toStr.call(fn) === "[object Function]";
    };
    var supportsDescriptors = require_has_property_descriptors()();
    var defineProperty = function(object, name, value, predicate) {
      if (name in object) {
        if (predicate === true) {
          if (object[name] === value) {
            return;
          }
        } else if (!isFunction(predicate) || !predicate()) {
          return;
        }
      }
      if (supportsDescriptors) {
        defineDataProperty(object, name, value, true);
      } else {
        defineDataProperty(object, name, value);
      }
    };
    var defineProperties = function(object, map2) {
      var predicates = arguments.length > 2 ? arguments[2] : {};
      var props = keys(map2);
      if (hasSymbols) {
        props = concat.call(props, Object.getOwnPropertySymbols(map2));
      }
      for (var i = 0; i < props.length; i += 1) {
        defineProperty(object, props[i], map2[props[i]], predicates[props[i]]);
      }
    };
    defineProperties.supportsDescriptors = !!supportsDescriptors;
    module2.exports = defineProperties;
  }
});

// node_modules/set-function-length/index.js
var require_set_function_length = __commonJS({
  "node_modules/set-function-length/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var define = require_define_data_property();
    var hasDescriptors = require_has_property_descriptors()();
    var gOPD = require_gopd();
    var $TypeError = require_type();
    var $floor = GetIntrinsic("%Math.floor%");
    module2.exports = function setFunctionLength(fn, length) {
      if (typeof fn !== "function") {
        throw new $TypeError("`fn` is not a function");
      }
      if (typeof length !== "number" || length < 0 || length > 4294967295 || $floor(length) !== length) {
        throw new $TypeError("`length` must be a positive 32-bit integer");
      }
      var loose = arguments.length > 2 && !!arguments[2];
      var functionLengthIsConfigurable = true;
      var functionLengthIsWritable = true;
      if ("length" in fn && gOPD) {
        var desc = gOPD(fn, "length");
        if (desc && !desc.configurable) {
          functionLengthIsConfigurable = false;
        }
        if (desc && !desc.writable) {
          functionLengthIsWritable = false;
        }
      }
      if (functionLengthIsConfigurable || functionLengthIsWritable || !loose) {
        if (hasDescriptors) {
          define(
            /** @type {Parameters<define>[0]} */
            fn,
            "length",
            length,
            true,
            true
          );
        } else {
          define(
            /** @type {Parameters<define>[0]} */
            fn,
            "length",
            length
          );
        }
      }
      return fn;
    };
  }
});

// node_modules/call-bind/index.js
var require_call_bind = __commonJS({
  "node_modules/call-bind/index.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    var GetIntrinsic = require_get_intrinsic();
    var setFunctionLength = require_set_function_length();
    var $TypeError = require_type();
    var $apply = GetIntrinsic("%Function.prototype.apply%");
    var $call = GetIntrinsic("%Function.prototype.call%");
    var $reflectApply = GetIntrinsic("%Reflect.apply%", true) || bind.call($call, $apply);
    var $defineProperty = require_es_define_property();
    var $max = GetIntrinsic("%Math.max%");
    module2.exports = function callBind(originalFunction) {
      if (typeof originalFunction !== "function") {
        throw new $TypeError("a function is required");
      }
      var func = $reflectApply(bind, $call, arguments);
      return setFunctionLength(
        func,
        1 + $max(0, originalFunction.length - (arguments.length - 1)),
        true
      );
    };
    var applyBind = function applyBind2() {
      return $reflectApply(bind, $apply, arguments);
    };
    if ($defineProperty) {
      $defineProperty(module2.exports, "apply", { value: applyBind });
    } else {
      module2.exports.apply = applyBind;
    }
  }
});

// node_modules/call-bind/callBound.js
var require_callBound = __commonJS({
  "node_modules/call-bind/callBound.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var callBind = require_call_bind();
    var $indexOf = callBind(GetIntrinsic("String.prototype.indexOf"));
    module2.exports = function callBoundIntrinsic(name, allowMissing) {
      var intrinsic = GetIntrinsic(name, !!allowMissing);
      if (typeof intrinsic === "function" && $indexOf(name, ".prototype.") > -1) {
        return callBind(intrinsic);
      }
      return intrinsic;
    };
  }
});

// node_modules/object.assign/implementation.js
var require_implementation3 = __commonJS({
  "node_modules/object.assign/implementation.js"(exports2, module2) {
    "use strict";
    var objectKeys = require_object_keys();
    var hasSymbols = require_shams()();
    var callBound = require_callBound();
    var toObject = Object;
    var $push = callBound("Array.prototype.push");
    var $propIsEnumerable = callBound("Object.prototype.propertyIsEnumerable");
    var originalGetSymbols = hasSymbols ? Object.getOwnPropertySymbols : null;
    module2.exports = function assign(target, source1) {
      if (target == null) {
        throw new TypeError("target must be an object");
      }
      var to = toObject(target);
      if (arguments.length === 1) {
        return to;
      }
      for (var s = 1; s < arguments.length; ++s) {
        var from = toObject(arguments[s]);
        var keys = objectKeys(from);
        var getSymbols = hasSymbols && (Object.getOwnPropertySymbols || originalGetSymbols);
        if (getSymbols) {
          var syms = getSymbols(from);
          for (var j = 0; j < syms.length; ++j) {
            var key = syms[j];
            if ($propIsEnumerable(from, key)) {
              $push(keys, key);
            }
          }
        }
        for (var i = 0; i < keys.length; ++i) {
          var nextKey = keys[i];
          if ($propIsEnumerable(from, nextKey)) {
            var propValue = from[nextKey];
            to[nextKey] = propValue;
          }
        }
      }
      return to;
    };
  }
});

// node_modules/object.assign/polyfill.js
var require_polyfill = __commonJS({
  "node_modules/object.assign/polyfill.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation3();
    var lacksProperEnumerationOrder = function() {
      if (!Object.assign) {
        return false;
      }
      var str = "abcdefghijklmnopqrst";
      var letters = str.split("");
      var map2 = {};
      for (var i = 0; i < letters.length; ++i) {
        map2[letters[i]] = letters[i];
      }
      var obj = Object.assign({}, map2);
      var actual = "";
      for (var k in obj) {
        actual += k;
      }
      return str !== actual;
    };
    var assignHasPendingExceptions = function() {
      if (!Object.assign || !Object.preventExtensions) {
        return false;
      }
      var thrower = Object.preventExtensions({ 1: 2 });
      try {
        Object.assign(thrower, "xy");
      } catch (e) {
        return thrower[1] === "y";
      }
      return false;
    };
    module2.exports = function getPolyfill() {
      if (!Object.assign) {
        return implementation;
      }
      if (lacksProperEnumerationOrder()) {
        return implementation;
      }
      if (assignHasPendingExceptions()) {
        return implementation;
      }
      return Object.assign;
    };
  }
});

// node_modules/object.assign/shim.js
var require_shim = __commonJS({
  "node_modules/object.assign/shim.js"(exports2, module2) {
    "use strict";
    var define = require_define_properties();
    var getPolyfill = require_polyfill();
    module2.exports = function shimAssign() {
      var polyfill = getPolyfill();
      define(
        Object,
        { assign: polyfill },
        { assign: function() {
          return Object.assign !== polyfill;
        } }
      );
      return polyfill;
    };
  }
});

// node_modules/object.assign/index.js
var require_object = __commonJS({
  "node_modules/object.assign/index.js"(exports2, module2) {
    "use strict";
    var defineProperties = require_define_properties();
    var callBind = require_call_bind();
    var implementation = require_implementation3();
    var getPolyfill = require_polyfill();
    var shim = require_shim();
    var polyfill = callBind.apply(getPolyfill());
    var bound = function assign(target, source1) {
      return polyfill(Object, arguments);
    };
    defineProperties(bound, {
      getPolyfill,
      implementation,
      shim
    });
    module2.exports = bound;
  }
});

// node_modules/functions-have-names/index.js
var require_functions_have_names = __commonJS({
  "node_modules/functions-have-names/index.js"(exports2, module2) {
    "use strict";
    var functionsHaveNames = function functionsHaveNames2() {
      return typeof function f() {
      }.name === "string";
    };
    var gOPD = Object.getOwnPropertyDescriptor;
    if (gOPD) {
      try {
        gOPD([], "length");
      } catch (e) {
        gOPD = null;
      }
    }
    functionsHaveNames.functionsHaveConfigurableNames = function functionsHaveConfigurableNames() {
      if (!functionsHaveNames() || !gOPD) {
        return false;
      }
      var desc = gOPD(function() {
      }, "name");
      return !!desc && !!desc.configurable;
    };
    var $bind = Function.prototype.bind;
    functionsHaveNames.boundFunctionsHaveNames = function boundFunctionsHaveNames() {
      return functionsHaveNames() && typeof $bind === "function" && function f() {
      }.bind().name !== "";
    };
    module2.exports = functionsHaveNames;
  }
});

// node_modules/set-function-name/index.js
var require_set_function_name = __commonJS({
  "node_modules/set-function-name/index.js"(exports2, module2) {
    "use strict";
    var define = require_define_data_property();
    var hasDescriptors = require_has_property_descriptors()();
    var functionsHaveConfigurableNames = require_functions_have_names().functionsHaveConfigurableNames();
    var $TypeError = require_type();
    module2.exports = function setFunctionName(fn, name) {
      if (typeof fn !== "function") {
        throw new $TypeError("`fn` is not a function");
      }
      var loose = arguments.length > 2 && !!arguments[2];
      if (!loose || functionsHaveConfigurableNames) {
        if (hasDescriptors) {
          define(
            /** @type {Parameters<define>[0]} */
            fn,
            "name",
            name,
            true,
            true
          );
        } else {
          define(
            /** @type {Parameters<define>[0]} */
            fn,
            "name",
            name
          );
        }
      }
      return fn;
    };
  }
});

// node_modules/regexp.prototype.flags/implementation.js
var require_implementation4 = __commonJS({
  "node_modules/regexp.prototype.flags/implementation.js"(exports2, module2) {
    "use strict";
    var setFunctionName = require_set_function_name();
    var $TypeError = require_type();
    var $Object = Object;
    module2.exports = setFunctionName(function flags() {
      if (this == null || this !== $Object(this)) {
        throw new $TypeError("RegExp.prototype.flags getter called on non-object");
      }
      var result = "";
      if (this.hasIndices) {
        result += "d";
      }
      if (this.global) {
        result += "g";
      }
      if (this.ignoreCase) {
        result += "i";
      }
      if (this.multiline) {
        result += "m";
      }
      if (this.dotAll) {
        result += "s";
      }
      if (this.unicode) {
        result += "u";
      }
      if (this.unicodeSets) {
        result += "v";
      }
      if (this.sticky) {
        result += "y";
      }
      return result;
    }, "get flags", true);
  }
});

// node_modules/regexp.prototype.flags/polyfill.js
var require_polyfill2 = __commonJS({
  "node_modules/regexp.prototype.flags/polyfill.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation4();
    var supportsDescriptors = require_define_properties().supportsDescriptors;
    var $gOPD = Object.getOwnPropertyDescriptor;
    module2.exports = function getPolyfill() {
      if (supportsDescriptors && /a/mig.flags === "gim") {
        var descriptor = $gOPD(RegExp.prototype, "flags");
        if (descriptor && typeof descriptor.get === "function" && "dotAll" in RegExp.prototype && "hasIndices" in RegExp.prototype) {
          var calls = "";
          var o = {};
          Object.defineProperty(o, "hasIndices", {
            get: function() {
              calls += "d";
            }
          });
          Object.defineProperty(o, "sticky", {
            get: function() {
              calls += "y";
            }
          });
          descriptor.get.call(o);
          if (calls === "dy") {
            return descriptor.get;
          }
        }
      }
      return implementation;
    };
  }
});

// node_modules/regexp.prototype.flags/shim.js
var require_shim2 = __commonJS({
  "node_modules/regexp.prototype.flags/shim.js"(exports2, module2) {
    "use strict";
    var supportsDescriptors = require_define_properties().supportsDescriptors;
    var getPolyfill = require_polyfill2();
    var gOPD = Object.getOwnPropertyDescriptor;
    var defineProperty = Object.defineProperty;
    var TypeErr = TypeError;
    var getProto = Object.getPrototypeOf;
    var regex = /a/;
    module2.exports = function shimFlags() {
      if (!supportsDescriptors || !getProto) {
        throw new TypeErr("RegExp.prototype.flags requires a true ES5 environment that supports property descriptors");
      }
      var polyfill = getPolyfill();
      var proto = getProto(regex);
      var descriptor = gOPD(proto, "flags");
      if (!descriptor || descriptor.get !== polyfill) {
        defineProperty(proto, "flags", {
          configurable: true,
          enumerable: false,
          get: polyfill
        });
      }
      return polyfill;
    };
  }
});

// node_modules/regexp.prototype.flags/index.js
var require_regexp_prototype = __commonJS({
  "node_modules/regexp.prototype.flags/index.js"(exports2, module2) {
    "use strict";
    var define = require_define_properties();
    var callBind = require_call_bind();
    var implementation = require_implementation4();
    var getPolyfill = require_polyfill2();
    var shim = require_shim2();
    var flagsBound = callBind(getPolyfill());
    define(flagsBound, {
      getPolyfill,
      implementation,
      shim
    });
    module2.exports = flagsBound;
  }
});

// node_modules/es-get-iterator/node.js
var require_node = __commonJS({
  "node_modules/es-get-iterator/node.js"(exports2, module2) {
    "use strict";
    var $iterator = Symbol.iterator;
    module2.exports = function getIterator(iterable) {
      if (iterable != null && typeof iterable[$iterator] !== "undefined") {
        return iterable[$iterator]();
      }
    };
  }
});

// node_modules/object-inspect/util.inspect.js
var require_util_inspect = __commonJS({
  "node_modules/object-inspect/util.inspect.js"(exports2, module2) {
    module2.exports = require("util").inspect;
  }
});

// node_modules/object-inspect/index.js
var require_object_inspect = __commonJS({
  "node_modules/object-inspect/index.js"(exports2, module2) {
    var hasMap = typeof Map === "function" && Map.prototype;
    var mapSizeDescriptor = Object.getOwnPropertyDescriptor && hasMap ? Object.getOwnPropertyDescriptor(Map.prototype, "size") : null;
    var mapSize = hasMap && mapSizeDescriptor && typeof mapSizeDescriptor.get === "function" ? mapSizeDescriptor.get : null;
    var mapForEach = hasMap && Map.prototype.forEach;
    var hasSet = typeof Set === "function" && Set.prototype;
    var setSizeDescriptor = Object.getOwnPropertyDescriptor && hasSet ? Object.getOwnPropertyDescriptor(Set.prototype, "size") : null;
    var setSize = hasSet && setSizeDescriptor && typeof setSizeDescriptor.get === "function" ? setSizeDescriptor.get : null;
    var setForEach = hasSet && Set.prototype.forEach;
    var hasWeakMap = typeof WeakMap === "function" && WeakMap.prototype;
    var weakMapHas = hasWeakMap ? WeakMap.prototype.has : null;
    var hasWeakSet = typeof WeakSet === "function" && WeakSet.prototype;
    var weakSetHas = hasWeakSet ? WeakSet.prototype.has : null;
    var hasWeakRef = typeof WeakRef === "function" && WeakRef.prototype;
    var weakRefDeref = hasWeakRef ? WeakRef.prototype.deref : null;
    var booleanValueOf = Boolean.prototype.valueOf;
    var objectToString = Object.prototype.toString;
    var functionToString = Function.prototype.toString;
    var $match = String.prototype.match;
    var $slice = String.prototype.slice;
    var $replace = String.prototype.replace;
    var $toUpperCase = String.prototype.toUpperCase;
    var $toLowerCase = String.prototype.toLowerCase;
    var $test = RegExp.prototype.test;
    var $concat = Array.prototype.concat;
    var $join = Array.prototype.join;
    var $arrSlice = Array.prototype.slice;
    var $floor = Math.floor;
    var bigIntValueOf = typeof BigInt === "function" ? BigInt.prototype.valueOf : null;
    var gOPS = Object.getOwnPropertySymbols;
    var symToString = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? Symbol.prototype.toString : null;
    var hasShammedSymbols = typeof Symbol === "function" && typeof Symbol.iterator === "object";
    var toStringTag = typeof Symbol === "function" && Symbol.toStringTag && (typeof Symbol.toStringTag === hasShammedSymbols ? "object" : "symbol") ? Symbol.toStringTag : null;
    var isEnumerable = Object.prototype.propertyIsEnumerable;
    var gPO = (typeof Reflect === "function" ? Reflect.getPrototypeOf : Object.getPrototypeOf) || ([].__proto__ === Array.prototype ? function(O) {
      return O.__proto__;
    } : null);
    function addNumericSeparator(num, str) {
      if (num === Infinity || num === -Infinity || num !== num || num && num > -1e3 && num < 1e3 || $test.call(/e/, str)) {
        return str;
      }
      var sepRegex = /[0-9](?=(?:[0-9]{3})+(?![0-9]))/g;
      if (typeof num === "number") {
        var int = num < 0 ? -$floor(-num) : $floor(num);
        if (int !== num) {
          var intStr = String(int);
          var dec = $slice.call(str, intStr.length + 1);
          return $replace.call(intStr, sepRegex, "$&_") + "." + $replace.call($replace.call(dec, /([0-9]{3})/g, "$&_"), /_$/, "");
        }
      }
      return $replace.call(str, sepRegex, "$&_");
    }
    var utilInspect = require_util_inspect();
    var inspectCustom = utilInspect.custom;
    var inspectSymbol = isSymbol(inspectCustom) ? inspectCustom : null;
    module2.exports = function inspect_(obj, options, depth, seen) {
      var opts = options || {};
      if (has(opts, "quoteStyle") && (opts.quoteStyle !== "single" && opts.quoteStyle !== "double")) {
        throw new TypeError('option "quoteStyle" must be "single" or "double"');
      }
      if (has(opts, "maxStringLength") && (typeof opts.maxStringLength === "number" ? opts.maxStringLength < 0 && opts.maxStringLength !== Infinity : opts.maxStringLength !== null)) {
        throw new TypeError('option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`');
      }
      var customInspect = has(opts, "customInspect") ? opts.customInspect : true;
      if (typeof customInspect !== "boolean" && customInspect !== "symbol") {
        throw new TypeError("option \"customInspect\", if provided, must be `true`, `false`, or `'symbol'`");
      }
      if (has(opts, "indent") && opts.indent !== null && opts.indent !== "	" && !(parseInt(opts.indent, 10) === opts.indent && opts.indent > 0)) {
        throw new TypeError('option "indent" must be "\\t", an integer > 0, or `null`');
      }
      if (has(opts, "numericSeparator") && typeof opts.numericSeparator !== "boolean") {
        throw new TypeError('option "numericSeparator", if provided, must be `true` or `false`');
      }
      var numericSeparator = opts.numericSeparator;
      if (typeof obj === "undefined") {
        return "undefined";
      }
      if (obj === null) {
        return "null";
      }
      if (typeof obj === "boolean") {
        return obj ? "true" : "false";
      }
      if (typeof obj === "string") {
        return inspectString(obj, opts);
      }
      if (typeof obj === "number") {
        if (obj === 0) {
          return Infinity / obj > 0 ? "0" : "-0";
        }
        var str = String(obj);
        return numericSeparator ? addNumericSeparator(obj, str) : str;
      }
      if (typeof obj === "bigint") {
        var bigIntStr = String(obj) + "n";
        return numericSeparator ? addNumericSeparator(obj, bigIntStr) : bigIntStr;
      }
      var maxDepth = typeof opts.depth === "undefined" ? 5 : opts.depth;
      if (typeof depth === "undefined") {
        depth = 0;
      }
      if (depth >= maxDepth && maxDepth > 0 && typeof obj === "object") {
        return isArray(obj) ? "[Array]" : "[Object]";
      }
      var indent = getIndent(opts, depth);
      if (typeof seen === "undefined") {
        seen = [];
      } else if (indexOf(seen, obj) >= 0) {
        return "[Circular]";
      }
      function inspect(value, from, noIndent) {
        if (from) {
          seen = $arrSlice.call(seen);
          seen.push(from);
        }
        if (noIndent) {
          var newOpts = {
            depth: opts.depth
          };
          if (has(opts, "quoteStyle")) {
            newOpts.quoteStyle = opts.quoteStyle;
          }
          return inspect_(value, newOpts, depth + 1, seen);
        }
        return inspect_(value, opts, depth + 1, seen);
      }
      if (typeof obj === "function" && !isRegExp(obj)) {
        var name = nameOf(obj);
        var keys = arrObjKeys(obj, inspect);
        return "[Function" + (name ? ": " + name : " (anonymous)") + "]" + (keys.length > 0 ? " { " + $join.call(keys, ", ") + " }" : "");
      }
      if (isSymbol(obj)) {
        var symString = hasShammedSymbols ? $replace.call(String(obj), /^(Symbol\(.*\))_[^)]*$/, "$1") : symToString.call(obj);
        return typeof obj === "object" && !hasShammedSymbols ? markBoxed(symString) : symString;
      }
      if (isElement(obj)) {
        var s = "<" + $toLowerCase.call(String(obj.nodeName));
        var attrs = obj.attributes || [];
        for (var i = 0; i < attrs.length; i++) {
          s += " " + attrs[i].name + "=" + wrapQuotes(quote(attrs[i].value), "double", opts);
        }
        s += ">";
        if (obj.childNodes && obj.childNodes.length) {
          s += "...";
        }
        s += "</" + $toLowerCase.call(String(obj.nodeName)) + ">";
        return s;
      }
      if (isArray(obj)) {
        if (obj.length === 0) {
          return "[]";
        }
        var xs = arrObjKeys(obj, inspect);
        if (indent && !singleLineValues(xs)) {
          return "[" + indentedJoin(xs, indent) + "]";
        }
        return "[ " + $join.call(xs, ", ") + " ]";
      }
      if (isError(obj)) {
        var parts = arrObjKeys(obj, inspect);
        if (!("cause" in Error.prototype) && "cause" in obj && !isEnumerable.call(obj, "cause")) {
          return "{ [" + String(obj) + "] " + $join.call($concat.call("[cause]: " + inspect(obj.cause), parts), ", ") + " }";
        }
        if (parts.length === 0) {
          return "[" + String(obj) + "]";
        }
        return "{ [" + String(obj) + "] " + $join.call(parts, ", ") + " }";
      }
      if (typeof obj === "object" && customInspect) {
        if (inspectSymbol && typeof obj[inspectSymbol] === "function" && utilInspect) {
          return utilInspect(obj, { depth: maxDepth - depth });
        } else if (customInspect !== "symbol" && typeof obj.inspect === "function") {
          return obj.inspect();
        }
      }
      if (isMap(obj)) {
        var mapParts = [];
        if (mapForEach) {
          mapForEach.call(obj, function(value, key) {
            mapParts.push(inspect(key, obj, true) + " => " + inspect(value, obj));
          });
        }
        return collectionOf("Map", mapSize.call(obj), mapParts, indent);
      }
      if (isSet(obj)) {
        var setParts = [];
        if (setForEach) {
          setForEach.call(obj, function(value) {
            setParts.push(inspect(value, obj));
          });
        }
        return collectionOf("Set", setSize.call(obj), setParts, indent);
      }
      if (isWeakMap(obj)) {
        return weakCollectionOf("WeakMap");
      }
      if (isWeakSet(obj)) {
        return weakCollectionOf("WeakSet");
      }
      if (isWeakRef(obj)) {
        return weakCollectionOf("WeakRef");
      }
      if (isNumber(obj)) {
        return markBoxed(inspect(Number(obj)));
      }
      if (isBigInt(obj)) {
        return markBoxed(inspect(bigIntValueOf.call(obj)));
      }
      if (isBoolean(obj)) {
        return markBoxed(booleanValueOf.call(obj));
      }
      if (isString(obj)) {
        return markBoxed(inspect(String(obj)));
      }
      if (typeof window !== "undefined" && obj === window) {
        return "{ [object Window] }";
      }
      if (typeof globalThis !== "undefined" && obj === globalThis || typeof global !== "undefined" && obj === global) {
        return "{ [object globalThis] }";
      }
      if (!isDate(obj) && !isRegExp(obj)) {
        var ys = arrObjKeys(obj, inspect);
        var isPlainObject = gPO ? gPO(obj) === Object.prototype : obj instanceof Object || obj.constructor === Object;
        var protoTag = obj instanceof Object ? "" : "null prototype";
        var stringTag = !isPlainObject && toStringTag && Object(obj) === obj && toStringTag in obj ? $slice.call(toStr(obj), 8, -1) : protoTag ? "Object" : "";
        var constructorTag = isPlainObject || typeof obj.constructor !== "function" ? "" : obj.constructor.name ? obj.constructor.name + " " : "";
        var tag = constructorTag + (stringTag || protoTag ? "[" + $join.call($concat.call([], stringTag || [], protoTag || []), ": ") + "] " : "");
        if (ys.length === 0) {
          return tag + "{}";
        }
        if (indent) {
          return tag + "{" + indentedJoin(ys, indent) + "}";
        }
        return tag + "{ " + $join.call(ys, ", ") + " }";
      }
      return String(obj);
    };
    function wrapQuotes(s, defaultStyle, opts) {
      var quoteChar = (opts.quoteStyle || defaultStyle) === "double" ? '"' : "'";
      return quoteChar + s + quoteChar;
    }
    function quote(s) {
      return $replace.call(String(s), /"/g, "&quot;");
    }
    function isArray(obj) {
      return toStr(obj) === "[object Array]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isDate(obj) {
      return toStr(obj) === "[object Date]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isRegExp(obj) {
      return toStr(obj) === "[object RegExp]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isError(obj) {
      return toStr(obj) === "[object Error]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isString(obj) {
      return toStr(obj) === "[object String]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isNumber(obj) {
      return toStr(obj) === "[object Number]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isBoolean(obj) {
      return toStr(obj) === "[object Boolean]" && (!toStringTag || !(typeof obj === "object" && toStringTag in obj));
    }
    function isSymbol(obj) {
      if (hasShammedSymbols) {
        return obj && typeof obj === "object" && obj instanceof Symbol;
      }
      if (typeof obj === "symbol") {
        return true;
      }
      if (!obj || typeof obj !== "object" || !symToString) {
        return false;
      }
      try {
        symToString.call(obj);
        return true;
      } catch (e) {
      }
      return false;
    }
    function isBigInt(obj) {
      if (!obj || typeof obj !== "object" || !bigIntValueOf) {
        return false;
      }
      try {
        bigIntValueOf.call(obj);
        return true;
      } catch (e) {
      }
      return false;
    }
    var hasOwn = Object.prototype.hasOwnProperty || function(key) {
      return key in this;
    };
    function has(obj, key) {
      return hasOwn.call(obj, key);
    }
    function toStr(obj) {
      return objectToString.call(obj);
    }
    function nameOf(f) {
      if (f.name) {
        return f.name;
      }
      var m = $match.call(functionToString.call(f), /^function\s*([\w$]+)/);
      if (m) {
        return m[1];
      }
      return null;
    }
    function indexOf(xs, x) {
      if (xs.indexOf) {
        return xs.indexOf(x);
      }
      for (var i = 0, l = xs.length; i < l; i++) {
        if (xs[i] === x) {
          return i;
        }
      }
      return -1;
    }
    function isMap(x) {
      if (!mapSize || !x || typeof x !== "object") {
        return false;
      }
      try {
        mapSize.call(x);
        try {
          setSize.call(x);
        } catch (s) {
          return true;
        }
        return x instanceof Map;
      } catch (e) {
      }
      return false;
    }
    function isWeakMap(x) {
      if (!weakMapHas || !x || typeof x !== "object") {
        return false;
      }
      try {
        weakMapHas.call(x, weakMapHas);
        try {
          weakSetHas.call(x, weakSetHas);
        } catch (s) {
          return true;
        }
        return x instanceof WeakMap;
      } catch (e) {
      }
      return false;
    }
    function isWeakRef(x) {
      if (!weakRefDeref || !x || typeof x !== "object") {
        return false;
      }
      try {
        weakRefDeref.call(x);
        return true;
      } catch (e) {
      }
      return false;
    }
    function isSet(x) {
      if (!setSize || !x || typeof x !== "object") {
        return false;
      }
      try {
        setSize.call(x);
        try {
          mapSize.call(x);
        } catch (m) {
          return true;
        }
        return x instanceof Set;
      } catch (e) {
      }
      return false;
    }
    function isWeakSet(x) {
      if (!weakSetHas || !x || typeof x !== "object") {
        return false;
      }
      try {
        weakSetHas.call(x, weakSetHas);
        try {
          weakMapHas.call(x, weakMapHas);
        } catch (s) {
          return true;
        }
        return x instanceof WeakSet;
      } catch (e) {
      }
      return false;
    }
    function isElement(x) {
      if (!x || typeof x !== "object") {
        return false;
      }
      if (typeof HTMLElement !== "undefined" && x instanceof HTMLElement) {
        return true;
      }
      return typeof x.nodeName === "string" && typeof x.getAttribute === "function";
    }
    function inspectString(str, opts) {
      if (str.length > opts.maxStringLength) {
        var remaining = str.length - opts.maxStringLength;
        var trailer = "... " + remaining + " more character" + (remaining > 1 ? "s" : "");
        return inspectString($slice.call(str, 0, opts.maxStringLength), opts) + trailer;
      }
      var s = $replace.call($replace.call(str, /(['\\])/g, "\\$1"), /[\x00-\x1f]/g, lowbyte);
      return wrapQuotes(s, "single", opts);
    }
    function lowbyte(c) {
      var n = c.charCodeAt(0);
      var x = {
        8: "b",
        9: "t",
        10: "n",
        12: "f",
        13: "r"
      }[n];
      if (x) {
        return "\\" + x;
      }
      return "\\x" + (n < 16 ? "0" : "") + $toUpperCase.call(n.toString(16));
    }
    function markBoxed(str) {
      return "Object(" + str + ")";
    }
    function weakCollectionOf(type) {
      return type + " { ? }";
    }
    function collectionOf(type, size, entries, indent) {
      var joinedEntries = indent ? indentedJoin(entries, indent) : $join.call(entries, ", ");
      return type + " (" + size + ") {" + joinedEntries + "}";
    }
    function singleLineValues(xs) {
      for (var i = 0; i < xs.length; i++) {
        if (indexOf(xs[i], "\n") >= 0) {
          return false;
        }
      }
      return true;
    }
    function getIndent(opts, depth) {
      var baseIndent;
      if (opts.indent === "	") {
        baseIndent = "	";
      } else if (typeof opts.indent === "number" && opts.indent > 0) {
        baseIndent = $join.call(Array(opts.indent + 1), " ");
      } else {
        return null;
      }
      return {
        base: baseIndent,
        prev: $join.call(Array(depth + 1), baseIndent)
      };
    }
    function indentedJoin(xs, indent) {
      if (xs.length === 0) {
        return "";
      }
      var lineJoiner = "\n" + indent.prev + indent.base;
      return lineJoiner + $join.call(xs, "," + lineJoiner) + "\n" + indent.prev;
    }
    function arrObjKeys(obj, inspect) {
      var isArr = isArray(obj);
      var xs = [];
      if (isArr) {
        xs.length = obj.length;
        for (var i = 0; i < obj.length; i++) {
          xs[i] = has(obj, i) ? inspect(obj[i], obj) : "";
        }
      }
      var syms = typeof gOPS === "function" ? gOPS(obj) : [];
      var symMap;
      if (hasShammedSymbols) {
        symMap = {};
        for (var k = 0; k < syms.length; k++) {
          symMap["$" + syms[k]] = syms[k];
        }
      }
      for (var key in obj) {
        if (!has(obj, key)) {
          continue;
        }
        if (isArr && String(Number(key)) === key && key < obj.length) {
          continue;
        }
        if (hasShammedSymbols && symMap["$" + key] instanceof Symbol) {
          continue;
        } else if ($test.call(/[^\w$]/, key)) {
          xs.push(inspect(key, obj) + ": " + inspect(obj[key], obj));
        } else {
          xs.push(key + ": " + inspect(obj[key], obj));
        }
      }
      if (typeof gOPS === "function") {
        for (var j = 0; j < syms.length; j++) {
          if (isEnumerable.call(obj, syms[j])) {
            xs.push("[" + inspect(syms[j]) + "]: " + inspect(obj[syms[j]], obj));
          }
        }
      }
      return xs;
    }
  }
});

// node_modules/side-channel/index.js
var require_side_channel = __commonJS({
  "node_modules/side-channel/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var callBound = require_callBound();
    var inspect = require_object_inspect();
    var $TypeError = require_type();
    var $WeakMap = GetIntrinsic("%WeakMap%", true);
    var $Map = GetIntrinsic("%Map%", true);
    var $weakMapGet = callBound("WeakMap.prototype.get", true);
    var $weakMapSet = callBound("WeakMap.prototype.set", true);
    var $weakMapHas = callBound("WeakMap.prototype.has", true);
    var $mapGet = callBound("Map.prototype.get", true);
    var $mapSet = callBound("Map.prototype.set", true);
    var $mapHas = callBound("Map.prototype.has", true);
    var listGetNode = function(list, key) {
      var prev = list;
      var curr;
      for (; (curr = prev.next) !== null; prev = curr) {
        if (curr.key === key) {
          prev.next = curr.next;
          curr.next = /** @type {NonNullable<typeof list.next>} */
          list.next;
          list.next = curr;
          return curr;
        }
      }
    };
    var listGet = function(objects, key) {
      var node = listGetNode(objects, key);
      return node && node.value;
    };
    var listSet = function(objects, key, value) {
      var node = listGetNode(objects, key);
      if (node) {
        node.value = value;
      } else {
        objects.next = /** @type {import('.').ListNode<typeof value>} */
        {
          // eslint-disable-line no-param-reassign, no-extra-parens
          key,
          next: objects.next,
          value
        };
      }
    };
    var listHas = function(objects, key) {
      return !!listGetNode(objects, key);
    };
    module2.exports = function getSideChannel() {
      var $wm;
      var $m;
      var $o;
      var channel = {
        assert: function(key) {
          if (!channel.has(key)) {
            throw new $TypeError("Side channel does not contain " + inspect(key));
          }
        },
        get: function(key) {
          if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
            if ($wm) {
              return $weakMapGet($wm, key);
            }
          } else if ($Map) {
            if ($m) {
              return $mapGet($m, key);
            }
          } else {
            if ($o) {
              return listGet($o, key);
            }
          }
        },
        has: function(key) {
          if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
            if ($wm) {
              return $weakMapHas($wm, key);
            }
          } else if ($Map) {
            if ($m) {
              return $mapHas($m, key);
            }
          } else {
            if ($o) {
              return listHas($o, key);
            }
          }
          return false;
        },
        set: function(key, value) {
          if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
            if (!$wm) {
              $wm = new $WeakMap();
            }
            $weakMapSet($wm, key, value);
          } else if ($Map) {
            if (!$m) {
              $m = new $Map();
            }
            $mapSet($m, key, value);
          } else {
            if (!$o) {
              $o = { key: {}, next: null };
            }
            listSet($o, key, value);
          }
        }
      };
      return channel;
    };
  }
});

// node_modules/object-is/implementation.js
var require_implementation5 = __commonJS({
  "node_modules/object-is/implementation.js"(exports2, module2) {
    "use strict";
    var numberIsNaN = function(value) {
      return value !== value;
    };
    module2.exports = function is(a, b) {
      if (a === 0 && b === 0) {
        return 1 / a === 1 / b;
      }
      if (a === b) {
        return true;
      }
      if (numberIsNaN(a) && numberIsNaN(b)) {
        return true;
      }
      return false;
    };
  }
});

// node_modules/object-is/polyfill.js
var require_polyfill3 = __commonJS({
  "node_modules/object-is/polyfill.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation5();
    module2.exports = function getPolyfill() {
      return typeof Object.is === "function" ? Object.is : implementation;
    };
  }
});

// node_modules/object-is/shim.js
var require_shim3 = __commonJS({
  "node_modules/object-is/shim.js"(exports2, module2) {
    "use strict";
    var getPolyfill = require_polyfill3();
    var define = require_define_properties();
    module2.exports = function shimObjectIs() {
      var polyfill = getPolyfill();
      define(Object, { is: polyfill }, {
        is: function testObjectIs() {
          return Object.is !== polyfill;
        }
      });
      return polyfill;
    };
  }
});

// node_modules/object-is/index.js
var require_object_is = __commonJS({
  "node_modules/object-is/index.js"(exports2, module2) {
    "use strict";
    var define = require_define_properties();
    var callBind = require_call_bind();
    var implementation = require_implementation5();
    var getPolyfill = require_polyfill3();
    var shim = require_shim3();
    var polyfill = callBind(getPolyfill(), Object);
    define(polyfill, {
      getPolyfill,
      implementation,
      shim
    });
    module2.exports = polyfill;
  }
});

// node_modules/has-tostringtag/shams.js
var require_shams2 = __commonJS({
  "node_modules/has-tostringtag/shams.js"(exports2, module2) {
    "use strict";
    var hasSymbols = require_shams();
    module2.exports = function hasToStringTagShams() {
      return hasSymbols() && !!Symbol.toStringTag;
    };
  }
});

// node_modules/is-arguments/index.js
var require_is_arguments = __commonJS({
  "node_modules/is-arguments/index.js"(exports2, module2) {
    "use strict";
    var hasToStringTag = require_shams2()();
    var callBound = require_callBound();
    var $toString = callBound("Object.prototype.toString");
    var isStandardArguments = function isArguments(value) {
      if (hasToStringTag && value && typeof value === "object" && Symbol.toStringTag in value) {
        return false;
      }
      return $toString(value) === "[object Arguments]";
    };
    var isLegacyArguments = function isArguments(value) {
      if (isStandardArguments(value)) {
        return true;
      }
      return value !== null && typeof value === "object" && typeof value.length === "number" && value.length >= 0 && $toString(value) !== "[object Array]" && $toString(value.callee) === "[object Function]";
    };
    var supportsStandardArguments = function() {
      return isStandardArguments(arguments);
    }();
    isStandardArguments.isLegacyArguments = isLegacyArguments;
    module2.exports = supportsStandardArguments ? isStandardArguments : isLegacyArguments;
  }
});

// node_modules/isarray/index.js
var require_isarray = __commonJS({
  "node_modules/isarray/index.js"(exports2, module2) {
    var toString = {}.toString;
    module2.exports = Array.isArray || function(arr) {
      return toString.call(arr) == "[object Array]";
    };
  }
});

// node_modules/is-array-buffer/index.js
var require_is_array_buffer = __commonJS({
  "node_modules/is-array-buffer/index.js"(exports2, module2) {
    "use strict";
    var callBind = require_call_bind();
    var callBound = require_callBound();
    var GetIntrinsic = require_get_intrinsic();
    var $ArrayBuffer = GetIntrinsic("%ArrayBuffer%", true);
    var $byteLength = callBound("ArrayBuffer.prototype.byteLength", true);
    var $toString = callBound("Object.prototype.toString");
    var abSlice = !!$ArrayBuffer && !$byteLength && new $ArrayBuffer(0).slice;
    var $abSlice = !!abSlice && callBind(abSlice);
    module2.exports = $byteLength || $abSlice ? function isArrayBuffer(obj) {
      if (!obj || typeof obj !== "object") {
        return false;
      }
      try {
        if ($byteLength) {
          $byteLength(obj);
        } else {
          $abSlice(obj, 0);
        }
        return true;
      } catch (e) {
        return false;
      }
    } : $ArrayBuffer ? function isArrayBuffer(obj) {
      return $toString(obj) === "[object ArrayBuffer]";
    } : function isArrayBuffer(obj) {
      return false;
    };
  }
});

// node_modules/is-date-object/index.js
var require_is_date_object = __commonJS({
  "node_modules/is-date-object/index.js"(exports2, module2) {
    "use strict";
    var getDay = Date.prototype.getDay;
    var tryDateObject = function tryDateGetDayCall(value) {
      try {
        getDay.call(value);
        return true;
      } catch (e) {
        return false;
      }
    };
    var toStr = Object.prototype.toString;
    var dateClass = "[object Date]";
    var hasToStringTag = require_shams2()();
    module2.exports = function isDateObject(value) {
      if (typeof value !== "object" || value === null) {
        return false;
      }
      return hasToStringTag ? tryDateObject(value) : toStr.call(value) === dateClass;
    };
  }
});

// node_modules/is-regex/index.js
var require_is_regex = __commonJS({
  "node_modules/is-regex/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_callBound();
    var hasToStringTag = require_shams2()();
    var has;
    var $exec;
    var isRegexMarker;
    var badStringifier;
    if (hasToStringTag) {
      has = callBound("Object.prototype.hasOwnProperty");
      $exec = callBound("RegExp.prototype.exec");
      isRegexMarker = {};
      throwRegexMarker = function() {
        throw isRegexMarker;
      };
      badStringifier = {
        toString: throwRegexMarker,
        valueOf: throwRegexMarker
      };
      if (typeof Symbol.toPrimitive === "symbol") {
        badStringifier[Symbol.toPrimitive] = throwRegexMarker;
      }
    }
    var throwRegexMarker;
    var $toString = callBound("Object.prototype.toString");
    var gOPD = Object.getOwnPropertyDescriptor;
    var regexClass = "[object RegExp]";
    module2.exports = hasToStringTag ? function isRegex(value) {
      if (!value || typeof value !== "object") {
        return false;
      }
      var descriptor = gOPD(value, "lastIndex");
      var hasLastIndexDataProperty = descriptor && has(descriptor, "value");
      if (!hasLastIndexDataProperty) {
        return false;
      }
      try {
        $exec(value, badStringifier);
      } catch (e) {
        return e === isRegexMarker;
      }
    } : function isRegex(value) {
      if (!value || typeof value !== "object" && typeof value !== "function") {
        return false;
      }
      return $toString(value) === regexClass;
    };
  }
});

// node_modules/is-shared-array-buffer/index.js
var require_is_shared_array_buffer = __commonJS({
  "node_modules/is-shared-array-buffer/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_callBound();
    var $byteLength = callBound("SharedArrayBuffer.prototype.byteLength", true);
    module2.exports = $byteLength ? function isSharedArrayBuffer(obj) {
      if (!obj || typeof obj !== "object") {
        return false;
      }
      try {
        $byteLength(obj);
        return true;
      } catch (e) {
        return false;
      }
    } : function isSharedArrayBuffer(obj) {
      return false;
    };
  }
});

// node_modules/is-string/index.js
var require_is_string = __commonJS({
  "node_modules/is-string/index.js"(exports2, module2) {
    "use strict";
    var strValue = String.prototype.valueOf;
    var tryStringObject = function tryStringObject2(value) {
      try {
        strValue.call(value);
        return true;
      } catch (e) {
        return false;
      }
    };
    var toStr = Object.prototype.toString;
    var strClass = "[object String]";
    var hasToStringTag = require_shams2()();
    module2.exports = function isString(value) {
      if (typeof value === "string") {
        return true;
      }
      if (typeof value !== "object") {
        return false;
      }
      return hasToStringTag ? tryStringObject(value) : toStr.call(value) === strClass;
    };
  }
});

// node_modules/is-number-object/index.js
var require_is_number_object = __commonJS({
  "node_modules/is-number-object/index.js"(exports2, module2) {
    "use strict";
    var numToStr = Number.prototype.toString;
    var tryNumberObject = function tryNumberObject2(value) {
      try {
        numToStr.call(value);
        return true;
      } catch (e) {
        return false;
      }
    };
    var toStr = Object.prototype.toString;
    var numClass = "[object Number]";
    var hasToStringTag = require_shams2()();
    module2.exports = function isNumberObject(value) {
      if (typeof value === "number") {
        return true;
      }
      if (typeof value !== "object") {
        return false;
      }
      return hasToStringTag ? tryNumberObject(value) : toStr.call(value) === numClass;
    };
  }
});

// node_modules/is-boolean-object/index.js
var require_is_boolean_object = __commonJS({
  "node_modules/is-boolean-object/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_callBound();
    var $boolToStr = callBound("Boolean.prototype.toString");
    var $toString = callBound("Object.prototype.toString");
    var tryBooleanObject = function booleanBrandCheck(value) {
      try {
        $boolToStr(value);
        return true;
      } catch (e) {
        return false;
      }
    };
    var boolClass = "[object Boolean]";
    var hasToStringTag = require_shams2()();
    module2.exports = function isBoolean(value) {
      if (typeof value === "boolean") {
        return true;
      }
      if (value === null || typeof value !== "object") {
        return false;
      }
      return hasToStringTag && Symbol.toStringTag in value ? tryBooleanObject(value) : $toString(value) === boolClass;
    };
  }
});

// node_modules/is-symbol/index.js
var require_is_symbol = __commonJS({
  "node_modules/is-symbol/index.js"(exports2, module2) {
    "use strict";
    var toStr = Object.prototype.toString;
    var hasSymbols = require_has_symbols()();
    if (hasSymbols) {
      symToStr = Symbol.prototype.toString;
      symStringRegex = /^Symbol\(.*\)$/;
      isSymbolObject = function isRealSymbolObject(value) {
        if (typeof value.valueOf() !== "symbol") {
          return false;
        }
        return symStringRegex.test(symToStr.call(value));
      };
      module2.exports = function isSymbol(value) {
        if (typeof value === "symbol") {
          return true;
        }
        if (toStr.call(value) !== "[object Symbol]") {
          return false;
        }
        try {
          return isSymbolObject(value);
        } catch (e) {
          return false;
        }
      };
    } else {
      module2.exports = function isSymbol(value) {
        return false;
      };
    }
    var symToStr;
    var symStringRegex;
    var isSymbolObject;
  }
});

// node_modules/has-bigints/index.js
var require_has_bigints = __commonJS({
  "node_modules/has-bigints/index.js"(exports2, module2) {
    "use strict";
    var $BigInt = typeof BigInt !== "undefined" && BigInt;
    module2.exports = function hasNativeBigInts() {
      return typeof $BigInt === "function" && typeof BigInt === "function" && typeof $BigInt(42) === "bigint" && typeof BigInt(42) === "bigint";
    };
  }
});

// node_modules/is-bigint/index.js
var require_is_bigint = __commonJS({
  "node_modules/is-bigint/index.js"(exports2, module2) {
    "use strict";
    var hasBigInts = require_has_bigints()();
    if (hasBigInts) {
      bigIntValueOf = BigInt.prototype.valueOf;
      tryBigInt = function tryBigIntObject(value) {
        try {
          bigIntValueOf.call(value);
          return true;
        } catch (e) {
        }
        return false;
      };
      module2.exports = function isBigInt(value) {
        if (value === null || typeof value === "undefined" || typeof value === "boolean" || typeof value === "string" || typeof value === "number" || typeof value === "symbol" || typeof value === "function") {
          return false;
        }
        if (typeof value === "bigint") {
          return true;
        }
        return tryBigInt(value);
      };
    } else {
      module2.exports = function isBigInt(value) {
        return false;
      };
    }
    var bigIntValueOf;
    var tryBigInt;
  }
});

// node_modules/which-boxed-primitive/index.js
var require_which_boxed_primitive = __commonJS({
  "node_modules/which-boxed-primitive/index.js"(exports2, module2) {
    "use strict";
    var isString = require_is_string();
    var isNumber = require_is_number_object();
    var isBoolean = require_is_boolean_object();
    var isSymbol = require_is_symbol();
    var isBigInt = require_is_bigint();
    module2.exports = function whichBoxedPrimitive(value) {
      if (value == null || typeof value !== "object" && typeof value !== "function") {
        return null;
      }
      if (isString(value)) {
        return "String";
      }
      if (isNumber(value)) {
        return "Number";
      }
      if (isBoolean(value)) {
        return "Boolean";
      }
      if (isSymbol(value)) {
        return "Symbol";
      }
      if (isBigInt(value)) {
        return "BigInt";
      }
    };
  }
});

// node_modules/is-map/index.js
var require_is_map = __commonJS({
  "node_modules/is-map/index.js"(exports2, module2) {
    "use strict";
    var $Map = typeof Map === "function" && Map.prototype ? Map : null;
    var $Set = typeof Set === "function" && Set.prototype ? Set : null;
    var exported;
    if (!$Map) {
      exported = function isMap(x) {
        return false;
      };
    }
    var $mapHas = $Map ? Map.prototype.has : null;
    var $setHas = $Set ? Set.prototype.has : null;
    if (!exported && !$mapHas) {
      exported = function isMap(x) {
        return false;
      };
    }
    module2.exports = exported || function isMap(x) {
      if (!x || typeof x !== "object") {
        return false;
      }
      try {
        $mapHas.call(x);
        if ($setHas) {
          try {
            $setHas.call(x);
          } catch (e) {
            return true;
          }
        }
        return x instanceof $Map;
      } catch (e) {
      }
      return false;
    };
  }
});

// node_modules/is-set/index.js
var require_is_set = __commonJS({
  "node_modules/is-set/index.js"(exports2, module2) {
    "use strict";
    var $Map = typeof Map === "function" && Map.prototype ? Map : null;
    var $Set = typeof Set === "function" && Set.prototype ? Set : null;
    var exported;
    if (!$Set) {
      exported = function isSet(x) {
        return false;
      };
    }
    var $mapHas = $Map ? Map.prototype.has : null;
    var $setHas = $Set ? Set.prototype.has : null;
    if (!exported && !$setHas) {
      exported = function isSet(x) {
        return false;
      };
    }
    module2.exports = exported || function isSet(x) {
      if (!x || typeof x !== "object") {
        return false;
      }
      try {
        $setHas.call(x);
        if ($mapHas) {
          try {
            $mapHas.call(x);
          } catch (e) {
            return true;
          }
        }
        return x instanceof $Set;
      } catch (e) {
      }
      return false;
    };
  }
});

// node_modules/is-weakmap/index.js
var require_is_weakmap = __commonJS({
  "node_modules/is-weakmap/index.js"(exports2, module2) {
    "use strict";
    var $WeakMap = typeof WeakMap === "function" && WeakMap.prototype ? WeakMap : null;
    var $WeakSet = typeof WeakSet === "function" && WeakSet.prototype ? WeakSet : null;
    var exported;
    if (!$WeakMap) {
      exported = function isWeakMap(x) {
        return false;
      };
    }
    var $mapHas = $WeakMap ? $WeakMap.prototype.has : null;
    var $setHas = $WeakSet ? $WeakSet.prototype.has : null;
    if (!exported && !$mapHas) {
      exported = function isWeakMap(x) {
        return false;
      };
    }
    module2.exports = exported || function isWeakMap(x) {
      if (!x || typeof x !== "object") {
        return false;
      }
      try {
        $mapHas.call(x, $mapHas);
        if ($setHas) {
          try {
            $setHas.call(x, $setHas);
          } catch (e) {
            return true;
          }
        }
        return x instanceof $WeakMap;
      } catch (e) {
      }
      return false;
    };
  }
});

// node_modules/is-weakset/index.js
var require_is_weakset = __commonJS({
  "node_modules/is-weakset/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var callBound = require_callBound();
    var $WeakSet = GetIntrinsic("%WeakSet%", true);
    var $setHas = callBound("WeakSet.prototype.has", true);
    if ($setHas) {
      $mapHas = callBound("WeakMap.prototype.has", true);
      module2.exports = function isWeakSet(x) {
        if (!x || typeof x !== "object") {
          return false;
        }
        try {
          $setHas(x, $setHas);
          if ($mapHas) {
            try {
              $mapHas(x, $mapHas);
            } catch (e) {
              return true;
            }
          }
          return x instanceof $WeakSet;
        } catch (e) {
        }
        return false;
      };
    } else {
      module2.exports = function isWeakSet(x) {
        return false;
      };
    }
    var $mapHas;
  }
});

// node_modules/which-collection/index.js
var require_which_collection = __commonJS({
  "node_modules/which-collection/index.js"(exports2, module2) {
    "use strict";
    var isMap = require_is_map();
    var isSet = require_is_set();
    var isWeakMap = require_is_weakmap();
    var isWeakSet = require_is_weakset();
    module2.exports = function whichCollection(value) {
      if (value && typeof value === "object") {
        if (isMap(value)) {
          return "Map";
        }
        if (isSet(value)) {
          return "Set";
        }
        if (isWeakMap(value)) {
          return "WeakMap";
        }
        if (isWeakSet(value)) {
          return "WeakSet";
        }
      }
      return false;
    };
  }
});

// node_modules/is-callable/index.js
var require_is_callable = __commonJS({
  "node_modules/is-callable/index.js"(exports2, module2) {
    "use strict";
    var fnToStr = Function.prototype.toString;
    var reflectApply = typeof Reflect === "object" && Reflect !== null && Reflect.apply;
    var badArrayLike;
    var isCallableMarker;
    if (typeof reflectApply === "function" && typeof Object.defineProperty === "function") {
      try {
        badArrayLike = Object.defineProperty({}, "length", {
          get: function() {
            throw isCallableMarker;
          }
        });
        isCallableMarker = {};
        reflectApply(function() {
          throw 42;
        }, null, badArrayLike);
      } catch (_) {
        if (_ !== isCallableMarker) {
          reflectApply = null;
        }
      }
    } else {
      reflectApply = null;
    }
    var constructorRegex = /^\s*class\b/;
    var isES6ClassFn = function isES6ClassFunction(value) {
      try {
        var fnStr = fnToStr.call(value);
        return constructorRegex.test(fnStr);
      } catch (e) {
        return false;
      }
    };
    var tryFunctionObject = function tryFunctionToStr(value) {
      try {
        if (isES6ClassFn(value)) {
          return false;
        }
        fnToStr.call(value);
        return true;
      } catch (e) {
        return false;
      }
    };
    var toStr = Object.prototype.toString;
    var objectClass = "[object Object]";
    var fnClass = "[object Function]";
    var genClass = "[object GeneratorFunction]";
    var ddaClass = "[object HTMLAllCollection]";
    var ddaClass2 = "[object HTML document.all class]";
    var ddaClass3 = "[object HTMLCollection]";
    var hasToStringTag = typeof Symbol === "function" && !!Symbol.toStringTag;
    var isIE68 = !(0 in [,]);
    var isDDA = function isDocumentDotAll() {
      return false;
    };
    if (typeof document === "object") {
      all = document.all;
      if (toStr.call(all) === toStr.call(document.all)) {
        isDDA = function isDocumentDotAll(value) {
          if ((isIE68 || !value) && (typeof value === "undefined" || typeof value === "object")) {
            try {
              var str = toStr.call(value);
              return (str === ddaClass || str === ddaClass2 || str === ddaClass3 || str === objectClass) && value("") == null;
            } catch (e) {
            }
          }
          return false;
        };
      }
    }
    var all;
    module2.exports = reflectApply ? function isCallable(value) {
      if (isDDA(value)) {
        return true;
      }
      if (!value) {
        return false;
      }
      if (typeof value !== "function" && typeof value !== "object") {
        return false;
      }
      try {
        reflectApply(value, null, badArrayLike);
      } catch (e) {
        if (e !== isCallableMarker) {
          return false;
        }
      }
      return !isES6ClassFn(value) && tryFunctionObject(value);
    } : function isCallable(value) {
      if (isDDA(value)) {
        return true;
      }
      if (!value) {
        return false;
      }
      if (typeof value !== "function" && typeof value !== "object") {
        return false;
      }
      if (hasToStringTag) {
        return tryFunctionObject(value);
      }
      if (isES6ClassFn(value)) {
        return false;
      }
      var strClass = toStr.call(value);
      if (strClass !== fnClass && strClass !== genClass && !/^\[object HTML/.test(strClass)) {
        return false;
      }
      return tryFunctionObject(value);
    };
  }
});

// node_modules/for-each/index.js
var require_for_each = __commonJS({
  "node_modules/for-each/index.js"(exports2, module2) {
    "use strict";
    var isCallable = require_is_callable();
    var toStr = Object.prototype.toString;
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var forEachArray = function forEachArray2(array, iterator, receiver) {
      for (var i = 0, len = array.length; i < len; i++) {
        if (hasOwnProperty.call(array, i)) {
          if (receiver == null) {
            iterator(array[i], i, array);
          } else {
            iterator.call(receiver, array[i], i, array);
          }
        }
      }
    };
    var forEachString = function forEachString2(string, iterator, receiver) {
      for (var i = 0, len = string.length; i < len; i++) {
        if (receiver == null) {
          iterator(string.charAt(i), i, string);
        } else {
          iterator.call(receiver, string.charAt(i), i, string);
        }
      }
    };
    var forEachObject = function forEachObject2(object, iterator, receiver) {
      for (var k in object) {
        if (hasOwnProperty.call(object, k)) {
          if (receiver == null) {
            iterator(object[k], k, object);
          } else {
            iterator.call(receiver, object[k], k, object);
          }
        }
      }
    };
    var forEach = function forEach2(list, iterator, thisArg) {
      if (!isCallable(iterator)) {
        throw new TypeError("iterator must be a function");
      }
      var receiver;
      if (arguments.length >= 3) {
        receiver = thisArg;
      }
      if (toStr.call(list) === "[object Array]") {
        forEachArray(list, iterator, receiver);
      } else if (typeof list === "string") {
        forEachString(list, iterator, receiver);
      } else {
        forEachObject(list, iterator, receiver);
      }
    };
    module2.exports = forEach;
  }
});

// node_modules/possible-typed-array-names/index.js
var require_possible_typed_array_names = __commonJS({
  "node_modules/possible-typed-array-names/index.js"(exports2, module2) {
    "use strict";
    module2.exports = [
      "Float32Array",
      "Float64Array",
      "Int8Array",
      "Int16Array",
      "Int32Array",
      "Uint8Array",
      "Uint8ClampedArray",
      "Uint16Array",
      "Uint32Array",
      "BigInt64Array",
      "BigUint64Array"
    ];
  }
});

// node_modules/available-typed-arrays/index.js
var require_available_typed_arrays = __commonJS({
  "node_modules/available-typed-arrays/index.js"(exports2, module2) {
    "use strict";
    var possibleNames = require_possible_typed_array_names();
    var g = typeof globalThis === "undefined" ? global : globalThis;
    module2.exports = function availableTypedArrays() {
      var out = [];
      for (var i = 0; i < possibleNames.length; i++) {
        if (typeof g[possibleNames[i]] === "function") {
          out[out.length] = possibleNames[i];
        }
      }
      return out;
    };
  }
});

// node_modules/which-typed-array/index.js
var require_which_typed_array = __commonJS({
  "node_modules/which-typed-array/index.js"(exports2, module2) {
    "use strict";
    var forEach = require_for_each();
    var availableTypedArrays = require_available_typed_arrays();
    var callBind = require_call_bind();
    var callBound = require_callBound();
    var gOPD = require_gopd();
    var $toString = callBound("Object.prototype.toString");
    var hasToStringTag = require_shams2()();
    var g = typeof globalThis === "undefined" ? global : globalThis;
    var typedArrays = availableTypedArrays();
    var $slice = callBound("String.prototype.slice");
    var getPrototypeOf = Object.getPrototypeOf;
    var $indexOf = callBound("Array.prototype.indexOf", true) || function indexOf(array, value) {
      for (var i = 0; i < array.length; i += 1) {
        if (array[i] === value) {
          return i;
        }
      }
      return -1;
    };
    var cache = { __proto__: null };
    if (hasToStringTag && gOPD && getPrototypeOf) {
      forEach(typedArrays, function(typedArray) {
        var arr = new g[typedArray]();
        if (Symbol.toStringTag in arr) {
          var proto = getPrototypeOf(arr);
          var descriptor = gOPD(proto, Symbol.toStringTag);
          if (!descriptor) {
            var superProto = getPrototypeOf(proto);
            descriptor = gOPD(superProto, Symbol.toStringTag);
          }
          cache["$" + typedArray] = callBind(descriptor.get);
        }
      });
    } else {
      forEach(typedArrays, function(typedArray) {
        var arr = new g[typedArray]();
        var fn = arr.slice || arr.set;
        if (fn) {
          cache["$" + typedArray] = callBind(fn);
        }
      });
    }
    var tryTypedArrays = function tryAllTypedArrays(value) {
      var found = false;
      forEach(
        // eslint-disable-next-line no-extra-parens
        /** @type {Record<`\$${TypedArrayName}`, Getter>} */
        /** @type {any} */
        cache,
        /** @type {(getter: Getter, name: `\$${import('.').TypedArrayName}`) => void} */
        function(getter, typedArray) {
          if (!found) {
            try {
              if ("$" + getter(value) === typedArray) {
                found = $slice(typedArray, 1);
              }
            } catch (e) {
            }
          }
        }
      );
      return found;
    };
    var trySlices = function tryAllSlices(value) {
      var found = false;
      forEach(
        // eslint-disable-next-line no-extra-parens
        /** @type {Record<`\$${TypedArrayName}`, Getter>} */
        /** @type {any} */
        cache,
        /** @type {(getter: typeof cache, name: `\$${import('.').TypedArrayName}`) => void} */
        function(getter, name) {
          if (!found) {
            try {
              getter(value);
              found = $slice(name, 1);
            } catch (e) {
            }
          }
        }
      );
      return found;
    };
    module2.exports = function whichTypedArray(value) {
      if (!value || typeof value !== "object") {
        return false;
      }
      if (!hasToStringTag) {
        var tag = $slice($toString(value), 8, -1);
        if ($indexOf(typedArrays, tag) > -1) {
          return tag;
        }
        if (tag !== "Object") {
          return false;
        }
        return trySlices(value);
      }
      if (!gOPD) {
        return null;
      }
      return tryTypedArrays(value);
    };
  }
});

// node_modules/array-buffer-byte-length/index.js
var require_array_buffer_byte_length = __commonJS({
  "node_modules/array-buffer-byte-length/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_callBound();
    var $byteLength = callBound("ArrayBuffer.prototype.byteLength", true);
    var isArrayBuffer = require_is_array_buffer();
    module2.exports = function byteLength(ab) {
      if (!isArrayBuffer(ab)) {
        return NaN;
      }
      return $byteLength ? $byteLength(ab) : ab.byteLength;
    };
  }
});

// node_modules/deep-equal/index.js
var require_deep_equal = __commonJS({
  "node_modules/deep-equal/index.js"(exports2, module2) {
    "use strict";
    var assign = require_object();
    var callBound = require_callBound();
    var flags = require_regexp_prototype();
    var GetIntrinsic = require_get_intrinsic();
    var getIterator = require_node();
    var getSideChannel = require_side_channel();
    var is = require_object_is();
    var isArguments = require_is_arguments();
    var isArray = require_isarray();
    var isArrayBuffer = require_is_array_buffer();
    var isDate = require_is_date_object();
    var isRegex = require_is_regex();
    var isSharedArrayBuffer = require_is_shared_array_buffer();
    var objectKeys = require_object_keys();
    var whichBoxedPrimitive = require_which_boxed_primitive();
    var whichCollection = require_which_collection();
    var whichTypedArray = require_which_typed_array();
    var byteLength = require_array_buffer_byte_length();
    var sabByteLength = callBound("SharedArrayBuffer.prototype.byteLength", true);
    var $getTime = callBound("Date.prototype.getTime");
    var gPO = Object.getPrototypeOf;
    var $objToString = callBound("Object.prototype.toString");
    var $Set = GetIntrinsic("%Set%", true);
    var $mapHas = callBound("Map.prototype.has", true);
    var $mapGet = callBound("Map.prototype.get", true);
    var $mapSize = callBound("Map.prototype.size", true);
    var $setAdd = callBound("Set.prototype.add", true);
    var $setDelete = callBound("Set.prototype.delete", true);
    var $setHas = callBound("Set.prototype.has", true);
    var $setSize = callBound("Set.prototype.size", true);
    function setHasEqualElement(set, val1, opts, channel) {
      var i = getIterator(set);
      var result;
      while ((result = i.next()) && !result.done) {
        if (internalDeepEqual(val1, result.value, opts, channel)) {
          $setDelete(set, result.value);
          return true;
        }
      }
      return false;
    }
    function findLooseMatchingPrimitives(prim) {
      if (typeof prim === "undefined") {
        return null;
      }
      if (typeof prim === "object") {
        return void 0;
      }
      if (typeof prim === "symbol") {
        return false;
      }
      if (typeof prim === "string" || typeof prim === "number") {
        return +prim === +prim;
      }
      return true;
    }
    function mapMightHaveLoosePrim(a, b, prim, item, opts, channel) {
      var altValue = findLooseMatchingPrimitives(prim);
      if (altValue != null) {
        return altValue;
      }
      var curB = $mapGet(b, altValue);
      var looseOpts = assign({}, opts, { strict: false });
      if (typeof curB === "undefined" && !$mapHas(b, altValue) || !internalDeepEqual(item, curB, looseOpts, channel)) {
        return false;
      }
      return !$mapHas(a, altValue) && internalDeepEqual(item, curB, looseOpts, channel);
    }
    function setMightHaveLoosePrim(a, b, prim) {
      var altValue = findLooseMatchingPrimitives(prim);
      if (altValue != null) {
        return altValue;
      }
      return $setHas(b, altValue) && !$setHas(a, altValue);
    }
    function mapHasEqualEntry(set, map2, key1, item1, opts, channel) {
      var i = getIterator(set);
      var result;
      var key2;
      while ((result = i.next()) && !result.done) {
        key2 = result.value;
        if (
          // eslint-disable-next-line no-use-before-define
          internalDeepEqual(key1, key2, opts, channel) && internalDeepEqual(item1, $mapGet(map2, key2), opts, channel)
        ) {
          $setDelete(set, key2);
          return true;
        }
      }
      return false;
    }
    function internalDeepEqual(actual, expected, options, channel) {
      var opts = options || {};
      if (opts.strict ? is(actual, expected) : actual === expected) {
        return true;
      }
      var actualBoxed = whichBoxedPrimitive(actual);
      var expectedBoxed = whichBoxedPrimitive(expected);
      if (actualBoxed !== expectedBoxed) {
        return false;
      }
      if (!actual || !expected || typeof actual !== "object" && typeof expected !== "object") {
        return opts.strict ? is(actual, expected) : actual == expected;
      }
      var hasActual = channel.has(actual);
      var hasExpected = channel.has(expected);
      var sentinel;
      if (hasActual && hasExpected) {
        if (channel.get(actual) === channel.get(expected)) {
          return true;
        }
      } else {
        sentinel = {};
      }
      if (!hasActual) {
        channel.set(actual, sentinel);
      }
      if (!hasExpected) {
        channel.set(expected, sentinel);
      }
      return objEquiv(actual, expected, opts, channel);
    }
    function isBuffer(x) {
      if (!x || typeof x !== "object" || typeof x.length !== "number") {
        return false;
      }
      if (typeof x.copy !== "function" || typeof x.slice !== "function") {
        return false;
      }
      if (x.length > 0 && typeof x[0] !== "number") {
        return false;
      }
      return !!(x.constructor && x.constructor.isBuffer && x.constructor.isBuffer(x));
    }
    function setEquiv(a, b, opts, channel) {
      if ($setSize(a) !== $setSize(b)) {
        return false;
      }
      var iA = getIterator(a);
      var iB = getIterator(b);
      var resultA;
      var resultB;
      var set;
      while ((resultA = iA.next()) && !resultA.done) {
        if (resultA.value && typeof resultA.value === "object") {
          if (!set) {
            set = new $Set();
          }
          $setAdd(set, resultA.value);
        } else if (!$setHas(b, resultA.value)) {
          if (opts.strict) {
            return false;
          }
          if (!setMightHaveLoosePrim(a, b, resultA.value)) {
            return false;
          }
          if (!set) {
            set = new $Set();
          }
          $setAdd(set, resultA.value);
        }
      }
      if (set) {
        while ((resultB = iB.next()) && !resultB.done) {
          if (resultB.value && typeof resultB.value === "object") {
            if (!setHasEqualElement(set, resultB.value, opts.strict, channel)) {
              return false;
            }
          } else if (!opts.strict && !$setHas(a, resultB.value) && !setHasEqualElement(set, resultB.value, opts.strict, channel)) {
            return false;
          }
        }
        return $setSize(set) === 0;
      }
      return true;
    }
    function mapEquiv(a, b, opts, channel) {
      if ($mapSize(a) !== $mapSize(b)) {
        return false;
      }
      var iA = getIterator(a);
      var iB = getIterator(b);
      var resultA;
      var resultB;
      var set;
      var key;
      var item1;
      var item2;
      while ((resultA = iA.next()) && !resultA.done) {
        key = resultA.value[0];
        item1 = resultA.value[1];
        if (key && typeof key === "object") {
          if (!set) {
            set = new $Set();
          }
          $setAdd(set, key);
        } else {
          item2 = $mapGet(b, key);
          if (typeof item2 === "undefined" && !$mapHas(b, key) || !internalDeepEqual(item1, item2, opts, channel)) {
            if (opts.strict) {
              return false;
            }
            if (!mapMightHaveLoosePrim(a, b, key, item1, opts, channel)) {
              return false;
            }
            if (!set) {
              set = new $Set();
            }
            $setAdd(set, key);
          }
        }
      }
      if (set) {
        while ((resultB = iB.next()) && !resultB.done) {
          key = resultB.value[0];
          item2 = resultB.value[1];
          if (key && typeof key === "object") {
            if (!mapHasEqualEntry(set, a, key, item2, opts, channel)) {
              return false;
            }
          } else if (!opts.strict && (!a.has(key) || !internalDeepEqual($mapGet(a, key), item2, opts, channel)) && !mapHasEqualEntry(set, a, key, item2, assign({}, opts, { strict: false }), channel)) {
            return false;
          }
        }
        return $setSize(set) === 0;
      }
      return true;
    }
    function objEquiv(a, b, opts, channel) {
      var i, key;
      if (typeof a !== typeof b) {
        return false;
      }
      if (a == null || b == null) {
        return false;
      }
      if ($objToString(a) !== $objToString(b)) {
        return false;
      }
      if (isArguments(a) !== isArguments(b)) {
        return false;
      }
      var aIsArray = isArray(a);
      var bIsArray = isArray(b);
      if (aIsArray !== bIsArray) {
        return false;
      }
      var aIsError = a instanceof Error;
      var bIsError = b instanceof Error;
      if (aIsError !== bIsError) {
        return false;
      }
      if (aIsError || bIsError) {
        if (a.name !== b.name || a.message !== b.message) {
          return false;
        }
      }
      var aIsRegex = isRegex(a);
      var bIsRegex = isRegex(b);
      if (aIsRegex !== bIsRegex) {
        return false;
      }
      if ((aIsRegex || bIsRegex) && (a.source !== b.source || flags(a) !== flags(b))) {
        return false;
      }
      var aIsDate = isDate(a);
      var bIsDate = isDate(b);
      if (aIsDate !== bIsDate) {
        return false;
      }
      if (aIsDate || bIsDate) {
        if ($getTime(a) !== $getTime(b)) {
          return false;
        }
      }
      if (opts.strict && gPO && gPO(a) !== gPO(b)) {
        return false;
      }
      var aWhich = whichTypedArray(a);
      var bWhich = whichTypedArray(b);
      if (aWhich !== bWhich) {
        return false;
      }
      if (aWhich || bWhich) {
        if (a.length !== b.length) {
          return false;
        }
        for (i = 0; i < a.length; i++) {
          if (a[i] !== b[i]) {
            return false;
          }
        }
        return true;
      }
      var aIsBuffer = isBuffer(a);
      var bIsBuffer = isBuffer(b);
      if (aIsBuffer !== bIsBuffer) {
        return false;
      }
      if (aIsBuffer || bIsBuffer) {
        if (a.length !== b.length) {
          return false;
        }
        for (i = 0; i < a.length; i++) {
          if (a[i] !== b[i]) {
            return false;
          }
        }
        return true;
      }
      var aIsArrayBuffer = isArrayBuffer(a);
      var bIsArrayBuffer = isArrayBuffer(b);
      if (aIsArrayBuffer !== bIsArrayBuffer) {
        return false;
      }
      if (aIsArrayBuffer || bIsArrayBuffer) {
        if (byteLength(a) !== byteLength(b)) {
          return false;
        }
        return typeof Uint8Array === "function" && internalDeepEqual(new Uint8Array(a), new Uint8Array(b), opts, channel);
      }
      var aIsSAB = isSharedArrayBuffer(a);
      var bIsSAB = isSharedArrayBuffer(b);
      if (aIsSAB !== bIsSAB) {
        return false;
      }
      if (aIsSAB || bIsSAB) {
        if (sabByteLength(a) !== sabByteLength(b)) {
          return false;
        }
        return typeof Uint8Array === "function" && internalDeepEqual(new Uint8Array(a), new Uint8Array(b), opts, channel);
      }
      if (typeof a !== typeof b) {
        return false;
      }
      var ka = objectKeys(a);
      var kb = objectKeys(b);
      if (ka.length !== kb.length) {
        return false;
      }
      ka.sort();
      kb.sort();
      for (i = ka.length - 1; i >= 0; i--) {
        if (ka[i] != kb[i]) {
          return false;
        }
      }
      for (i = ka.length - 1; i >= 0; i--) {
        key = ka[i];
        if (!internalDeepEqual(a[key], b[key], opts, channel)) {
          return false;
        }
      }
      var aCollection = whichCollection(a);
      var bCollection = whichCollection(b);
      if (aCollection !== bCollection) {
        return false;
      }
      if (aCollection === "Set" || bCollection === "Set") {
        return setEquiv(a, b, opts, channel);
      }
      if (aCollection === "Map") {
        return mapEquiv(a, b, opts, channel);
      }
      return true;
    }
    module2.exports = function deepEqual(a, b, opts) {
      return internalDeepEqual(a, b, opts, getSideChannel());
    };
  }
});

// test/tests.ts
var tests_exports = {};
__export(tests_exports, {
  add_delay: () => add_delay,
  push_stream_from_array: () => push_stream_from_array
});
module.exports = __toCommonJS(tests_exports);

// src/symbols.ts
var S_end = Symbol("end");
var S_running = Symbol("running");
var S_ending = Symbol("ending");
var S_paused = Symbol("paused");
var S_pausing = Symbol("pausing");
var S_pause = Symbol("pause");
var S_start = Symbol("start");
var S_disconnect = Symbol("disconnect");
var S_paused_internal = Symbol("paused_external");

// src/pull/index.ts
var eofi = Symbol("end-of-function-iterator");
var from_array = (buffer = []) => {
  const push = (...i) => buffer.push(...i);
  const next = (end) => {
    if (end == S_end)
      return S_end;
    return buffer.length == 0 ? S_end : buffer.shift();
  };
  return {
    push,
    // you can push, append replace whatever you want
    next
  };
};
var map = (i, map2) => (e) => {
  if (e == S_end)
    return i(S_end);
  else {
    const v = i(e);
    return v === S_end ? S_end : map2(v);
  }
};
var _to_iter = (x) => ({ done: x === S_end, value: x });
var to_iter = (i) => {
  return {
    [Symbol.iterator]: () => ({
      next: () => _to_iter(i(void 0))
    })
  };
};
var to_array = (i) => {
  const r = [];
  while (true) {
    const v = i();
    if (v == S_end)
      break;
    else
      r.push(v);
  }
  for (const v of to_iter(i)) {
    r.push(v);
  }
  return r;
};

// src/internal.ts
var vee_to_p_handler = (v, p_handlers) => {
  if (v === S_end)
    p_handlers[0](S_end);
  else if ("value" in v)
    p_handlers[0](v.value);
  else
    p_handlers[1](v.error);
};
var vee_to_value = (v) => {
  if (v === S_end)
    return S_end;
  else if ("value" in v)
    return v.value;
  else
    throw v.error;
};
var promise_to_vee = async (p) => {
  try {
    const v = await p;
    if (v === S_end)
      return S_end;
    return { value: v };
  } catch (e) {
    return { error: e };
  }
};
var watermarks = (hl) => {
  const w = hl.watermarks;
  if (!w)
    return { low_watermark: 20, high_watermark: 100 };
  return typeof w == "number" ? { low_watermark: w, high_watermark: w * 10 } : w;
};

// src/pull/async.ts
var aps_from_array = (buffer = [], o = {}) => {
  let ending = false;
  let _buffer = buffer;
  let p_handlers = void 0;
  let done = o.done ?? true;
  let complete = false;
  const push = (...i) => {
    if (p_handlers) {
      p_handlers[0](i.shift());
      p_handlers = void 0;
    }
    buffer.push(...i);
  };
  const next = async () => new Promise((r, j) => {
    if (!_buffer) {
      return S_end;
    }
    if (_buffer.length == 0) {
      if (p_handlers)
        throw Error("p_handlers set, called iterator without waiting for previous result");
      if (done)
        r(S_end);
      else
        p_handlers = [r, j];
    } else {
      r(_buffer.shift());
    }
  });
  const end = () => {
    if (!_buffer)
      return;
    ending = true;
    if (_buffer.length == 0)
      _buffer = void 0;
    if (p_handlers)
      p_handlers[0](S_end);
  };
  return {
    push,
    // you can push, append replace whatever you want
    end,
    next,
    done: () => done = true
  };
};
var aps_map = (i, map2) => async (e) => {
  if (e == S_end) {
    await i(S_end);
    return S_end;
  }
  const v = await i();
  return v == S_end ? S_end : await map2(v);
};
var aps_to_iter = (i) => ({
  [Symbol.asyncIterator]: () => ({
    next: async () => _to_iter(await i(void 0))
  })
});
var aps_to_array = async (i) => {
  const r = [];
  for await (const v of aps_to_iter(i)) {
    r.push(v);
  }
  return r;
};
var aps_multiplexer = (s, o = { autoend: true }) => {
  let _complete = false;
  let _ending = false;
  const sources = [];
  const end = () => {
    _ending = true;
    s(S_end);
  };
  const try_end = () => {
    if (!sources.find((x) => x) && o.autoend) {
      end();
    }
  };
  const try_fill = async () => {
    if (_complete) {
    } else {
      if (!sources.find((x) => x && !x.waiting)) {
        const f = await s().then(
          (v) => (x) => x[0](v),
          (v) => (x) => x[1](v)
        );
        for (let v of sources) {
          if (v) {
            f(v.waiting);
            v.waiting = void 0;
          }
        }
      }
    }
  };
  const complete = () => {
    _complete = true;
    try_fill();
  };
  return {
    end,
    complete,
    // starts asking if all targets started asking
    source: () => {
      const id = sources.length;
      sources.push({ waiting: void 0 });
      const stream = (o2) => {
        if (o2 == S_end) {
          sources[id] = void 0;
          try_end();
        }
        if (_ending)
          return S_end;
        if (sources[id]?.waiting)
          throw Error("you failed awaiting previous Promise");
        return new Promise((r, j) => {
          sources[id].waiting = [r, j];
          try_fill();
        });
      };
      return stream;
    }
  };
};
var aps_queue = (o) => {
  const streams = o.streams;
  let done = o.done ?? true;
  let p_handlers = void 0;
  let trying_next = void 0;
  const try_next = async () => {
    while (true) {
      if (streams.length == 0) {
        if (done) {
          p_handlers[0](S_end);
          p_handlers = void 0;
        }
        return;
      }
      try {
        const v = await streams[0]();
        if (v == S_end) {
          streams.shift();
        } else {
          p_handlers[0](v);
          p_handlers = void 0;
          return;
        }
      } catch (e) {
        p_handlers[1](e);
        p_handlers = void 0;
        return;
      }
    }
  };
  const push = async (..._streams) => {
    if (trying_next)
      await trying_next;
    streams.push(..._streams);
    if (p_handlers) {
      trying_next = try_next();
    }
  };
  const next = async (end) => {
    if (end == S_end) {
      for (let s of streams) {
        s(S_end);
      }
    }
    if (p_handlers)
      throw Error("p_handlers set, called iterator without waiting for previous result");
    const p = new Promise((r, j) => p_handlers = [r, j]);
    trying_next = try_next();
    return p;
  };
  return {
    push,
    next,
    done: () => {
      done = true;
    }
  };
};
var aps_buffered = (stream, o = {}) => {
  const { low_watermark, high_watermark } = watermarks(o);
  const buffer = [];
  let p_handlers = void 0;
  let running = false;
  const run2 = async () => {
    if (running)
      return;
    running = true;
    try {
      while (buffer.length < high_watermark) {
        const v = await promise_to_vee(stream());
        if (p_handlers) {
          vee_to_p_handler(v, p_handlers);
          p_handlers = void 0;
        } else
          buffer.push(v);
        if (v == S_end)
          break;
      }
    } finally {
      running = false;
    }
  };
  return async (end) => {
    if (end == S_end) {
      stream(S_end);
      return S_end;
    }
    if (buffer.length > 0) {
      const r = buffer.shift();
      if (buffer.length < low_watermark)
        run2();
      return vee_to_value(r);
    } else {
      const p = new Promise((r, j) => {
        p_handlers = [r, j];
      });
      run2();
      return p;
    }
  };
};
var aps_zip = (o, ...streams) => {
  const end_all = () => Promise.all(streams.map((x) => x(S_end)));
  const c = streams.length;
  return async (end) => {
    const values = await Promise.all(streams.map((x) => x()));
    const count_ends = values.filter((x) => x === S_end).length;
    if (count_ends > 0 && (o.end_on_first_end ?? true)) {
      end_all();
      return S_end;
    } else if (count_ends == c) {
      end_all();
      return S_end;
    }
    return values;
  };
};
var aps_partition = (stream, count) => {
  let ending = false;
  return async (end) => {
    if (end)
      return stream(S_end);
    if (ending)
      return S_end;
    const a = [];
    for (var i = 0; i < count; i++) {
      const v = await stream();
      if (v == S_end) {
        ending = true;
        break;
      } else
        a.push(v);
    }
    return a;
  };
};

// src/tsmono/u-frequency-limiter/index.ts
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var createLimiter = (ms_fun) => {
  let last = void 0;
  return async () => {
    const wait = ms_fun();
    const n = (/* @__PURE__ */ new Date()).getTime();
    if (!last) {
      last = n;
      return;
    }
    const sleep_ms = wait - (n - last);
    if (sleep_ms > 0)
      await sleep(sleep_ms);
    last = n + sleep_ms;
    return;
  };
};

// src/tsmono/u-testrunner/index.ts
var import_deep_equal = __toESM(require_deep_equal());

// src/tsmono/u-exception-to-string/index.ts
var exception_to_str = (e) => {
  if (typeof e == "object") {
    if ("stack" in e) {
      return e.stack;
    } else {
      const r = [];
      for (const [k, v] of Object.entries(e)) {
        r.push(`${JSON.stringify(k)}: ${JSON.stringify(v)}`);
      }
      return r.join("\n");
    }
  } else if (e && e.trace) {
    return `${e}
${e.trace}`;
  }
  return JSON.stringify(e);
};

// src/tsmono/u-testrunner/index.ts
var tests_result = () => ({
  failed: [],
  todo: [],
  passed: [],
  timedout: []
  // gets populated at end of run()
});
var tests_state = () => ({
  _nr: 0,
  running: {},
  result: tests_result()
});
var tests_failed = (result) => result.failed.length > 0 || result.timedout.length > 0;
var result_to_string = (tr) => {
  let r = [];
  r.push(`passed: ${tr.passed.length}`);
  const add = (label, list) => {
    if (list.length > 0) {
      r.push(`=== ${label}
`);
    }
  };
  tr.failed.forEach((v, i) => {
    r.push(`failed: ${v.label}`);
    r = [" ", ...r, ...exception_to_str(v.failure).split("\n")];
  });
  tr.todo.forEach((v, i) => {
    r.push(`todo: ${v}`);
  });
  (tr.timedout ?? []).forEach((v, i) => {
    r.push(`timedout: ${v}`);
  });
  return r;
};
var print_tests_results = (result, description) => {
  if (tests_failed(result))
    console.log(`=== :-( tests failed ${description}`, result_to_string(result));
  else
    console.log(`=== :-) tests passed ${description}`, result_to_string(result));
};
var run_tests_print = async (c, f) => {
  console.log(`== ${c.description}`);
  print_tests_results(await run(c, f));
};
var run = (cfg, f, o) => {
  const finallies = [];
  const state = o?.state ?? tests_state();
  let timer;
  return new Promise((resolve, reject) => {
    const end_run = (why) => {
      clearTimeout(timer);
      state.result.timedout = Object.values(state.running).map((x) => x.label);
      resolve(state.result);
      finallies.forEach((z) => z());
    };
    const track = (label) => {
      const next = state._nr++;
      state.running[next] = {
        promise: void 0,
        label
      };
      return (p) => {
        state.running[next].promise = p;
        const done = () => {
          delete state.running[next];
          if (Object.keys(state.running).length === 0) {
            end_run("no more running");
          }
        };
        p.then(
          (x) => {
            state.result.passed.push(`ok: ${label}`);
            done();
          },
          (x) => {
            const e_str = exception_to_str(x);
            state.result.failed.push({ label, failure: e_str });
            done();
          }
        );
      };
    };
    const step = cfg.report_period || cfg.timeout;
    const print_and_restart = (timeout, first) => {
      if (cfg.report_state && !first) {
        cfg.report_state(state);
      }
      if (timeout === 0) {
        end_run("ending run due to timeout");
      } else {
        timer = setTimeout(() => {
          print_and_restart(timeout - step);
        }, step);
      }
    };
    timer = setTimeout(() => {
      print_and_restart(cfg.timeout, true);
    }, 0);
    const describe = (label) => {
      const d = {};
      d.promise = new Promise((r, j) => {
        if (cfg.abort_on_failure) {
          const j_o = j;
          j = (e) => {
            j_o(e);
            throw Error(`${e}`);
          };
        }
        const assert_true = (b, reason) => {
          if (b) {
            r();
          } else {
            j(reason || "no reason given");
          }
        };
        const expect_all_true = (...b) => {
          const errs = [];
          for (var i = 0, len = b.length; i < len; i++) {
            if (!b[i])
              errs.push(`argument ${i + 1} failed`);
          }
          if (errs.length > 0)
            j(errs.join(",\n"));
          r();
        };
        const _expect_exception = (e, expect_exception) => {
          if (expect_exception) {
            if (expect_exception instanceof RegExp) {
              if (e.toString().match(expect_exception))
                r();
              else
                j({
                  error: `Expected exception to match given regex ${expect_exception}`,
                  exception: e
                });
            } else {
              try {
                expect_exception(e);
                r();
              } catch (e2) {
                j({
                  "error": "exception while looking at expected exception",
                  "exception": e2
                });
              }
            }
          } else
            r();
        };
        d.resolve = r;
        d.todo = () => {
          r();
          state.result.todo.push(label);
        };
        d.fail = j;
        d.expect_true = assert_true;
        d.expect_all_true = expect_all_true;
        d.expect_exception = (f2, expect_exception) => {
          try {
            f2();
            j(`exception expected`);
          } catch (e) {
            _expect_exception(e, expect_exception);
          }
        };
        d.expect_failing_promise = (f2, expect_exception) => {
          const p = f2();
          return p.then(
            () => j(`exception expected matching ${expect_exception?.toString()}`),
            (e) => {
              debugger;
              _expect_exception(e, expect_exception);
            }
          );
        };
        d.expect_resolving_promise = (p) => p.then(r, j);
        d.expect_deep_equal = (a, b, strict) => {
          assert_true((0, import_deep_equal.default)(a, b, { strict: !!strict }), `a to deep equal b
a:${JSON.stringify(a)}
b:${JSON.stringify(b)}`);
        };
      });
      track(`${label}`)(d.promise);
      return d;
    };
    const promise = (p, label) => {
      const stack = new Error().stack;
      return track(label ? label : stack.toString())(p);
    };
    promise(
      f({
        promise,
        describe,
        state,
        todo: (s) => describe(s).todo(),
        finally: (z) => {
          finallies.push(z);
        }
      }),
      "test function runs without exception and returns within timeout"
    );
  });
};

// src/transformers/async.ts
var push_to_pull = (push, o = {}) => {
  const { low_watermark, high_watermark } = watermarks(o);
  const items = [];
  let status = S_paused;
  let waiting;
  const api = push.addSink({
    push: (t) => {
      if (waiting) {
        if (t == S_end) {
          waiting[0](S_end);
          status = S_ending;
        } else if ("value" in t) {
          waiting[0](t.value);
        } else if ("error" in t) {
          waiting[1](t.error);
        }
        waiting = void 0;
      } else {
        items.push(t);
        if (items.length > high_watermark)
          api(S_pause);
      }
    }
  });
  return (end) => {
    if (end == S_end) {
      api(S_disconnect);
      return S_end;
    }
    if (items.length == 0) {
      if (status == S_paused) {
        api(S_start);
        status = S_running;
      }
    } else if (items.length > 0) {
      const x = items.shift();
      if (items.length < low_watermark) {
        api(S_start);
        status = S_running;
      }
      if (x == S_end)
        return S_end;
      else if ("value" in x)
        return x.value;
      else
        throw x.error;
    }
    if (status == S_ending)
      return S_end;
    return new Promise((r, j) => {
      waiting = [r, j];
    });
  };
};
var pull_to_push_concurrently = (stream, o) => {
  console.log(`warning pull_to_push_concurrently not well tested`);
  let sink = void 0;
  let running = 0;
  let ending = false;
  let order = Promise.resolve(void 0);
  let status = S_paused;
  let p = Promise.resolve(null);
  let restart;
  const run2 = async () => {
    if ([S_running, S_ending].includes(status))
      return;
    status = S_running;
    while (status === S_running && running < o.concurrency) {
      const p_ = promise_to_vee(stream(void 0));
      running += 1;
      if (o.preserve_order) {
        order = order.then(async () => {
          const res = await p_;
          running -= 1;
          if (res == S_end) {
            ending = true;
          }
          sink.push(res);
          restart();
        });
      } else {
        p_.then((res) => {
          running -= 1;
          if (res == S_end)
            ending = true;
          else
            sink.push(res);
          if (running == 0 && ending)
            sink.push(S_end);
          restart();
        });
      }
    }
    if (status === S_pausing)
      status = S_paused;
    else
      status = S_paused_internal;
  };
  restart = () => {
    if (ending)
      return;
    if ([S_paused, S_pausing, S_ending].includes(status))
      return;
    if (running < o.concurrency) {
      if (status == S_paused_internal)
        run2();
    }
  };
  const addSink = (_sink) => {
    if (sink)
      throw Error("only one sink can be added!");
    sink = _sink;
    return (signal) => {
      if (signal == S_start) {
        if (status == S_pausing)
          status = S_running;
        else if (status == S_paused) {
          status = S_paused_internal;
          restart();
        }
      }
      if (signal == S_pause)
        status = S_pausing;
      if (signal == S_disconnect) {
        status = S_ending;
        stream(S_end);
      }
    };
  };
  return {
    addSink
  };
};
var map_concurrently = (stream, map2, o) => push_to_pull(
  pull_to_push_concurrently(aps_map(stream, map2), o),
  {
    watermarks: o.watermarks ?? 0
    /* will accept pushin anyway, default to don't requset more than required */
  }
);

// test/tests.ts
var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
var push_stream_from_array = (a) => {
  let intervalTimer = void 0;
  let connected = false;
  let sink = void 0;
  const stop = () => clearInterval(intervalTimer);
  const start = () => {
    intervalTimer = setInterval(() => {
      const v = a.shift();
      if (v == void 0) {
        sink.push(S_end);
        stop();
      } else {
        sink.push({ value: v });
      }
    }, 30);
  };
  const addSink = (_sink) => {
    if (connected)
      throw Error("x");
    sink = _sink;
    connected = true;
    return (signal) => {
      if (signal == S_start)
        start();
      if (signal == S_pause)
        stop();
      if (signal == S_disconnect)
        stop();
    };
  };
  return {
    addSink
  };
};
var add_delay = (stream, delay) => {
  const getToken = createLimiter(() => delay);
  return async (end) => {
    await getToken();
    return stream(end);
  };
};
run_tests_print({
  "description": "tests",
  "timeout": 4e3
}, async (c) => {
  let tests = {
    test_push_to_pull_stream: async (a) => {
      const push_stream = push_stream_from_array([1, 2, 3]);
      const pull_stream = push_to_pull(push_stream);
      a.expect_deep_equal(
        [1, 2, 3],
        await aps_to_array(pull_stream)
      );
    },
    test_aps_zip: async (a) => {
      let stream1 = aps_from_array([1, 2, 3]).next;
      let stream2 = aps_from_array(["A", "B", "C"]).next;
      const stream = aps_zip({}, stream1, stream2);
      a.expect_deep_equal(
        [[1, "A"], [2, "B"], [3, "C"]],
        await aps_to_array(stream)
      );
      c.todo("early = true /false cases");
    },
    test_buffered_stream_map: async (a) => {
      let stream = aps_from_array([1, 2, 3]).next;
      stream = add_delay(stream, 50);
      stream = aps_buffered(stream);
      a.expect_deep_equal(
        [1, 2, 3],
        await aps_to_array(stream)
      );
    },
    test_buffered_stream: async (a) => {
      let stream = aps_from_array([1, 2, 3, 4, 5]).next;
      stream = add_delay(stream, 50);
      stream = aps_buffered(stream, { watermarks: { low_watermark: 1, high_watermark: 2 } });
      stream = add_delay(stream, 50);
      a.expect_deep_equal(
        [1, 2, 3, 4, 5],
        await aps_to_array(stream)
      );
    },
    test_iterator_works_1: async (a) => {
      const reader = from_array([1, 2, 3]);
      a.expect_deep_equal(
        [1, 2, 3],
        to_array(reader.next)
      );
    },
    // SYNC from_array + map
    test_iterator_with_map_works: async (a) => {
      const reader = from_array([1, 2, 3]);
      const mapped = map(reader.next, (x) => x * 2);
      a.expect_deep_equal(
        [2, 4, 6],
        to_array(mapped)
      );
    },
    // ASYNC from_array end
    test_iterator_works2: async (a) => {
      const reader = aps_from_array([1, 2, 3]);
      a.expect_deep_equal(
        [1, 2, 3],
        await aps_to_array(reader.next)
      );
    },
    test_iterator_works2b: async (a) => {
      const reader = aps_from_array([1, 2, 3], { done: false });
      reader.push(4, 5, 6);
      reader.done();
      a.expect_deep_equal(
        [1, 2, 3, 4, 5, 6],
        await aps_to_array(reader.next)
      );
    },
    test_async_iterator_with_async_map: async (a) => {
      const reader = aps_from_array([1, 2, 3], { done: false });
      const mapped = aps_map(reader.next, async (x) => x * 2);
      reader.push(4, 5, 6);
      reader.done();
      a.expect_deep_equal(
        [2, 4, 6, 8, 10, 12],
        await aps_to_array(mapped)
      );
    },
    // multiplexer
    test_multiplexer: async (a) => {
      a.expect_true(true);
      const a1 = c.describe("multiplexer arr 1");
      const a2 = c.describe("multiplexer arr 2");
      const reader = aps_from_array([1, 2, 3]);
      const mapped = aps_map(reader.next, async (x) => x * 2);
      const m = aps_multiplexer(mapped, { autoend: true });
      const s1 = m.source();
      const s2 = m.source();
      const [A1, A2] = await Promise.all([
        aps_to_array(s1),
        aps_to_array(s2)
      ]);
      a1.expect_deep_equal([2, 4, 6], A1);
      a2.expect_deep_equal([2, 4, 6], A2);
    },
    test_async_queue: async (a) => {
      const reader1 = aps_from_array([1, 2, 3]);
      const reader2 = aps_from_array([]);
      const reader3 = aps_from_array([1, 2, 3]);
      const q = aps_queue({ streams: [reader1.next, reader2.next, reader3.next] });
      a.expect_deep_equal(
        await aps_to_array(q.next),
        [1, 2, 3, 1, 2, 3]
      );
    },
    test_async_queue2: async (a) => {
      const reader = aps_partition(aps_from_array([1, 2, 3]).next, 2);
      a.expect_deep_equal(
        await aps_to_array(reader),
        [[1, 2], [3]]
      );
    },
    test_async_queue_done: async (a) => {
      const reader1 = aps_from_array([1, 2, 3]);
      const reader2 = aps_from_array([]);
      const reader3 = aps_from_array([1, 2, 3]);
      const q = aps_queue({ streams: [reader1.next], done: false });
      setTimeout(() => {
        q.push(reader2.next, reader3.next);
        q.done();
      }, 100);
      a.expect_deep_equal(
        await aps_to_array(q.next),
        [1, 2, 3, 1, 2, 3]
      );
    },
    test_async_concurrency: async (a) => {
      a.expect_true(true);
      const a_ordered = c.describe("a_ordered");
      const a_any_order = c.describe("a_any_order");
      const r = (preserve_order) => map_concurrently(
        aps_from_array([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]).next,
        async (i) => {
          await sleep2(i * 30);
          return i;
        },
        { preserve_order, concurrency: 10 }
      );
      a_any_order.expect_deep_equal(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        await aps_to_array(r(false))
      );
      a_ordered.expect_deep_equal(
        [10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        await aps_to_array(r(true))
      );
    }
  };
  await Promise.all(
    Object.entries(tests).map(([k, v]) => v(c.describe(k)))
  );
  c.todo("f.screateStreamReader & push_to_pull");
  c.todo("totally missing -> end of stream callback events");
  c.todo("test ending from recieving side!");
}).then(console.log, console.log);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  add_delay,
  push_stream_from_array
});
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibm9kZV9tb2R1bGVzL29iamVjdC1rZXlzL2lzQXJndW1lbnRzLmpzIiwgIm5vZGVfbW9kdWxlcy9vYmplY3Qta2V5cy9pbXBsZW1lbnRhdGlvbi5qcyIsICJub2RlX21vZHVsZXMvb2JqZWN0LWtleXMvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2VzLWVycm9ycy9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvZXMtZXJyb3JzL2V2YWwuanMiLCAibm9kZV9tb2R1bGVzL2VzLWVycm9ycy9yYW5nZS5qcyIsICJub2RlX21vZHVsZXMvZXMtZXJyb3JzL3JlZi5qcyIsICJub2RlX21vZHVsZXMvZXMtZXJyb3JzL3N5bnRheC5qcyIsICJub2RlX21vZHVsZXMvZXMtZXJyb3JzL3R5cGUuanMiLCAibm9kZV9tb2R1bGVzL2VzLWVycm9ycy91cmkuanMiLCAibm9kZV9tb2R1bGVzL2hhcy1zeW1ib2xzL3NoYW1zLmpzIiwgIm5vZGVfbW9kdWxlcy9oYXMtc3ltYm9scy9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvaGFzLXByb3RvL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9mdW5jdGlvbi1iaW5kL2ltcGxlbWVudGF0aW9uLmpzIiwgIm5vZGVfbW9kdWxlcy9mdW5jdGlvbi1iaW5kL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9oYXNvd24vaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2dldC1pbnRyaW5zaWMvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2VzLWRlZmluZS1wcm9wZXJ0eS9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvZ29wZC9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvZGVmaW5lLWRhdGEtcHJvcGVydHkvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2hhcy1wcm9wZXJ0eS1kZXNjcmlwdG9ycy9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvZGVmaW5lLXByb3BlcnRpZXMvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL3NldC1mdW5jdGlvbi1sZW5ndGgvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2NhbGwtYmluZC9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvY2FsbC1iaW5kL2NhbGxCb3VuZC5qcyIsICJub2RlX21vZHVsZXMvb2JqZWN0LmFzc2lnbi9pbXBsZW1lbnRhdGlvbi5qcyIsICJub2RlX21vZHVsZXMvb2JqZWN0LmFzc2lnbi9wb2x5ZmlsbC5qcyIsICJub2RlX21vZHVsZXMvb2JqZWN0LmFzc2lnbi9zaGltLmpzIiwgIm5vZGVfbW9kdWxlcy9vYmplY3QuYXNzaWduL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9mdW5jdGlvbnMtaGF2ZS1uYW1lcy9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvc2V0LWZ1bmN0aW9uLW5hbWUvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL3JlZ2V4cC5wcm90b3R5cGUuZmxhZ3MvaW1wbGVtZW50YXRpb24uanMiLCAibm9kZV9tb2R1bGVzL3JlZ2V4cC5wcm90b3R5cGUuZmxhZ3MvcG9seWZpbGwuanMiLCAibm9kZV9tb2R1bGVzL3JlZ2V4cC5wcm90b3R5cGUuZmxhZ3Mvc2hpbS5qcyIsICJub2RlX21vZHVsZXMvcmVnZXhwLnByb3RvdHlwZS5mbGFncy9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvZXMtZ2V0LWl0ZXJhdG9yL25vZGUuanMiLCAibm9kZV9tb2R1bGVzL29iamVjdC1pbnNwZWN0L3V0aWwuaW5zcGVjdC5qcyIsICJub2RlX21vZHVsZXMvb2JqZWN0LWluc3BlY3QvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL3NpZGUtY2hhbm5lbC9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvb2JqZWN0LWlzL2ltcGxlbWVudGF0aW9uLmpzIiwgIm5vZGVfbW9kdWxlcy9vYmplY3QtaXMvcG9seWZpbGwuanMiLCAibm9kZV9tb2R1bGVzL29iamVjdC1pcy9zaGltLmpzIiwgIm5vZGVfbW9kdWxlcy9vYmplY3QtaXMvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2hhcy10b3N0cmluZ3RhZy9zaGFtcy5qcyIsICJub2RlX21vZHVsZXMvaXMtYXJndW1lbnRzL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pc2FycmF5L2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy1hcnJheS1idWZmZXIvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2lzLWRhdGUtb2JqZWN0L2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy1yZWdleC9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvaXMtc2hhcmVkLWFycmF5LWJ1ZmZlci9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvaXMtc3RyaW5nL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy1udW1iZXItb2JqZWN0L2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy1ib29sZWFuLW9iamVjdC9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvaXMtc3ltYm9sL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9oYXMtYmlnaW50cy9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvaXMtYmlnaW50L2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy93aGljaC1ib3hlZC1wcmltaXRpdmUvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL2lzLW1hcC9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvaXMtc2V0L2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy13ZWFrbWFwL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy13ZWFrc2V0L2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy93aGljaC1jb2xsZWN0aW9uL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9pcy1jYWxsYWJsZS9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvZm9yLWVhY2gvaW5kZXguanMiLCAibm9kZV9tb2R1bGVzL3Bvc3NpYmxlLXR5cGVkLWFycmF5LW5hbWVzL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9hdmFpbGFibGUtdHlwZWQtYXJyYXlzL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy93aGljaC10eXBlZC1hcnJheS9pbmRleC5qcyIsICJub2RlX21vZHVsZXMvYXJyYXktYnVmZmVyLWJ5dGUtbGVuZ3RoL2luZGV4LmpzIiwgIm5vZGVfbW9kdWxlcy9kZWVwLWVxdWFsL2luZGV4LmpzIiwgInRlc3QvdGVzdHMudHMiLCAic3JjL3N5bWJvbHMudHMiLCAic3JjL3B1bGwvaW5kZXgudHMiLCAic3JjL2ludGVybmFsLnRzIiwgInNyYy9wdWxsL2FzeW5jLnRzIiwgInNyYy90c21vbm8vdS1mcmVxdWVuY3ktbGltaXRlci9pbmRleC50cyIsICJzcmMvdHNtb25vL3UtdGVzdHJ1bm5lci9pbmRleC50cyIsICJzcmMvdHNtb25vL3UtZXhjZXB0aW9uLXRvLXN0cmluZy9pbmRleC50cyIsICJzcmMvdHJhbnNmb3JtZXJzL2FzeW5jLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIndXNlIHN0cmljdCc7XG5cbnZhciB0b1N0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNBcmd1bWVudHModmFsdWUpIHtcblx0dmFyIHN0ciA9IHRvU3RyLmNhbGwodmFsdWUpO1xuXHR2YXIgaXNBcmdzID0gc3RyID09PSAnW29iamVjdCBBcmd1bWVudHNdJztcblx0aWYgKCFpc0FyZ3MpIHtcblx0XHRpc0FyZ3MgPSBzdHIgIT09ICdbb2JqZWN0IEFycmF5XScgJiZcblx0XHRcdHZhbHVlICE9PSBudWxsICYmXG5cdFx0XHR0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmXG5cdFx0XHR0eXBlb2YgdmFsdWUubGVuZ3RoID09PSAnbnVtYmVyJyAmJlxuXHRcdFx0dmFsdWUubGVuZ3RoID49IDAgJiZcblx0XHRcdHRvU3RyLmNhbGwodmFsdWUuY2FsbGVlKSA9PT0gJ1tvYmplY3QgRnVuY3Rpb25dJztcblx0fVxuXHRyZXR1cm4gaXNBcmdzO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBrZXlzU2hpbTtcbmlmICghT2JqZWN0LmtleXMpIHtcblx0Ly8gbW9kaWZpZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vZXMtc2hpbXMvZXM1LXNoaW1cblx0dmFyIGhhcyA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5cdHZhciB0b1N0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG5cdHZhciBpc0FyZ3MgPSByZXF1aXJlKCcuL2lzQXJndW1lbnRzJyk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZ2xvYmFsLXJlcXVpcmVcblx0dmFyIGlzRW51bWVyYWJsZSA9IE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGU7XG5cdHZhciBoYXNEb250RW51bUJ1ZyA9ICFpc0VudW1lcmFibGUuY2FsbCh7IHRvU3RyaW5nOiBudWxsIH0sICd0b1N0cmluZycpO1xuXHR2YXIgaGFzUHJvdG9FbnVtQnVnID0gaXNFbnVtZXJhYmxlLmNhbGwoZnVuY3Rpb24gKCkge30sICdwcm90b3R5cGUnKTtcblx0dmFyIGRvbnRFbnVtcyA9IFtcblx0XHQndG9TdHJpbmcnLFxuXHRcdCd0b0xvY2FsZVN0cmluZycsXG5cdFx0J3ZhbHVlT2YnLFxuXHRcdCdoYXNPd25Qcm9wZXJ0eScsXG5cdFx0J2lzUHJvdG90eXBlT2YnLFxuXHRcdCdwcm9wZXJ0eUlzRW51bWVyYWJsZScsXG5cdFx0J2NvbnN0cnVjdG9yJ1xuXHRdO1xuXHR2YXIgZXF1YWxzQ29uc3RydWN0b3JQcm90b3R5cGUgPSBmdW5jdGlvbiAobykge1xuXHRcdHZhciBjdG9yID0gby5jb25zdHJ1Y3Rvcjtcblx0XHRyZXR1cm4gY3RvciAmJiBjdG9yLnByb3RvdHlwZSA9PT0gbztcblx0fTtcblx0dmFyIGV4Y2x1ZGVkS2V5cyA9IHtcblx0XHQkYXBwbGljYXRpb25DYWNoZTogdHJ1ZSxcblx0XHQkY29uc29sZTogdHJ1ZSxcblx0XHQkZXh0ZXJuYWw6IHRydWUsXG5cdFx0JGZyYW1lOiB0cnVlLFxuXHRcdCRmcmFtZUVsZW1lbnQ6IHRydWUsXG5cdFx0JGZyYW1lczogdHJ1ZSxcblx0XHQkaW5uZXJIZWlnaHQ6IHRydWUsXG5cdFx0JGlubmVyV2lkdGg6IHRydWUsXG5cdFx0JG9ubW96ZnVsbHNjcmVlbmNoYW5nZTogdHJ1ZSxcblx0XHQkb25tb3pmdWxsc2NyZWVuZXJyb3I6IHRydWUsXG5cdFx0JG91dGVySGVpZ2h0OiB0cnVlLFxuXHRcdCRvdXRlcldpZHRoOiB0cnVlLFxuXHRcdCRwYWdlWE9mZnNldDogdHJ1ZSxcblx0XHQkcGFnZVlPZmZzZXQ6IHRydWUsXG5cdFx0JHBhcmVudDogdHJ1ZSxcblx0XHQkc2Nyb2xsTGVmdDogdHJ1ZSxcblx0XHQkc2Nyb2xsVG9wOiB0cnVlLFxuXHRcdCRzY3JvbGxYOiB0cnVlLFxuXHRcdCRzY3JvbGxZOiB0cnVlLFxuXHRcdCRzZWxmOiB0cnVlLFxuXHRcdCR3ZWJraXRJbmRleGVkREI6IHRydWUsXG5cdFx0JHdlYmtpdFN0b3JhZ2VJbmZvOiB0cnVlLFxuXHRcdCR3aW5kb3c6IHRydWVcblx0fTtcblx0dmFyIGhhc0F1dG9tYXRpb25FcXVhbGl0eUJ1ZyA9IChmdW5jdGlvbiAoKSB7XG5cdFx0LyogZ2xvYmFsIHdpbmRvdyAqL1xuXHRcdGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgeyByZXR1cm4gZmFsc2U7IH1cblx0XHRmb3IgKHZhciBrIGluIHdpbmRvdykge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0aWYgKCFleGNsdWRlZEtleXNbJyQnICsga10gJiYgaGFzLmNhbGwod2luZG93LCBrKSAmJiB3aW5kb3dba10gIT09IG51bGwgJiYgdHlwZW9mIHdpbmRvd1trXSA9PT0gJ29iamVjdCcpIHtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0ZXF1YWxzQ29uc3RydWN0b3JQcm90b3R5cGUod2luZG93W2tdKTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBmYWxzZTtcblx0fSgpKTtcblx0dmFyIGVxdWFsc0NvbnN0cnVjdG9yUHJvdG90eXBlSWZOb3RCdWdneSA9IGZ1bmN0aW9uIChvKSB7XG5cdFx0LyogZ2xvYmFsIHdpbmRvdyAqL1xuXHRcdGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyB8fCAhaGFzQXV0b21hdGlvbkVxdWFsaXR5QnVnKSB7XG5cdFx0XHRyZXR1cm4gZXF1YWxzQ29uc3RydWN0b3JQcm90b3R5cGUobyk7XG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHRyZXR1cm4gZXF1YWxzQ29uc3RydWN0b3JQcm90b3R5cGUobyk7XG5cdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fTtcblxuXHRrZXlzU2hpbSA9IGZ1bmN0aW9uIGtleXMob2JqZWN0KSB7XG5cdFx0dmFyIGlzT2JqZWN0ID0gb2JqZWN0ICE9PSBudWxsICYmIHR5cGVvZiBvYmplY3QgPT09ICdvYmplY3QnO1xuXHRcdHZhciBpc0Z1bmN0aW9uID0gdG9TdHIuY2FsbChvYmplY3QpID09PSAnW29iamVjdCBGdW5jdGlvbl0nO1xuXHRcdHZhciBpc0FyZ3VtZW50cyA9IGlzQXJncyhvYmplY3QpO1xuXHRcdHZhciBpc1N0cmluZyA9IGlzT2JqZWN0ICYmIHRvU3RyLmNhbGwob2JqZWN0KSA9PT0gJ1tvYmplY3QgU3RyaW5nXSc7XG5cdFx0dmFyIHRoZUtleXMgPSBbXTtcblxuXHRcdGlmICghaXNPYmplY3QgJiYgIWlzRnVuY3Rpb24gJiYgIWlzQXJndW1lbnRzKSB7XG5cdFx0XHR0aHJvdyBuZXcgVHlwZUVycm9yKCdPYmplY3Qua2V5cyBjYWxsZWQgb24gYSBub24tb2JqZWN0Jyk7XG5cdFx0fVxuXG5cdFx0dmFyIHNraXBQcm90byA9IGhhc1Byb3RvRW51bUJ1ZyAmJiBpc0Z1bmN0aW9uO1xuXHRcdGlmIChpc1N0cmluZyAmJiBvYmplY3QubGVuZ3RoID4gMCAmJiAhaGFzLmNhbGwob2JqZWN0LCAwKSkge1xuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBvYmplY3QubGVuZ3RoOyArK2kpIHtcblx0XHRcdFx0dGhlS2V5cy5wdXNoKFN0cmluZyhpKSk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKGlzQXJndW1lbnRzICYmIG9iamVjdC5sZW5ndGggPiAwKSB7XG5cdFx0XHRmb3IgKHZhciBqID0gMDsgaiA8IG9iamVjdC5sZW5ndGg7ICsraikge1xuXHRcdFx0XHR0aGVLZXlzLnB1c2goU3RyaW5nKGopKTtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0Zm9yICh2YXIgbmFtZSBpbiBvYmplY3QpIHtcblx0XHRcdFx0aWYgKCEoc2tpcFByb3RvICYmIG5hbWUgPT09ICdwcm90b3R5cGUnKSAmJiBoYXMuY2FsbChvYmplY3QsIG5hbWUpKSB7XG5cdFx0XHRcdFx0dGhlS2V5cy5wdXNoKFN0cmluZyhuYW1lKSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZiAoaGFzRG9udEVudW1CdWcpIHtcblx0XHRcdHZhciBza2lwQ29uc3RydWN0b3IgPSBlcXVhbHNDb25zdHJ1Y3RvclByb3RvdHlwZUlmTm90QnVnZ3kob2JqZWN0KTtcblxuXHRcdFx0Zm9yICh2YXIgayA9IDA7IGsgPCBkb250RW51bXMubGVuZ3RoOyArK2spIHtcblx0XHRcdFx0aWYgKCEoc2tpcENvbnN0cnVjdG9yICYmIGRvbnRFbnVtc1trXSA9PT0gJ2NvbnN0cnVjdG9yJykgJiYgaGFzLmNhbGwob2JqZWN0LCBkb250RW51bXNba10pKSB7XG5cdFx0XHRcdFx0dGhlS2V5cy5wdXNoKGRvbnRFbnVtc1trXSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHRoZUtleXM7XG5cdH07XG59XG5tb2R1bGUuZXhwb3J0cyA9IGtleXNTaGltO1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIHNsaWNlID0gQXJyYXkucHJvdG90eXBlLnNsaWNlO1xudmFyIGlzQXJncyA9IHJlcXVpcmUoJy4vaXNBcmd1bWVudHMnKTtcblxudmFyIG9yaWdLZXlzID0gT2JqZWN0LmtleXM7XG52YXIga2V5c1NoaW0gPSBvcmlnS2V5cyA/IGZ1bmN0aW9uIGtleXMobykgeyByZXR1cm4gb3JpZ0tleXMobyk7IH0gOiByZXF1aXJlKCcuL2ltcGxlbWVudGF0aW9uJyk7XG5cbnZhciBvcmlnaW5hbEtleXMgPSBPYmplY3Qua2V5cztcblxua2V5c1NoaW0uc2hpbSA9IGZ1bmN0aW9uIHNoaW1PYmplY3RLZXlzKCkge1xuXHRpZiAoT2JqZWN0LmtleXMpIHtcblx0XHR2YXIga2V5c1dvcmtzV2l0aEFyZ3VtZW50cyA9IChmdW5jdGlvbiAoKSB7XG5cdFx0XHQvLyBTYWZhcmkgNS4wIGJ1Z1xuXHRcdFx0dmFyIGFyZ3MgPSBPYmplY3Qua2V5cyhhcmd1bWVudHMpO1xuXHRcdFx0cmV0dXJuIGFyZ3MgJiYgYXJncy5sZW5ndGggPT09IGFyZ3VtZW50cy5sZW5ndGg7XG5cdFx0fSgxLCAyKSk7XG5cdFx0aWYgKCFrZXlzV29ya3NXaXRoQXJndW1lbnRzKSB7XG5cdFx0XHRPYmplY3Qua2V5cyA9IGZ1bmN0aW9uIGtleXMob2JqZWN0KSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZnVuYy1uYW1lLW1hdGNoaW5nXG5cdFx0XHRcdGlmIChpc0FyZ3Mob2JqZWN0KSkge1xuXHRcdFx0XHRcdHJldHVybiBvcmlnaW5hbEtleXMoc2xpY2UuY2FsbChvYmplY3QpKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gb3JpZ2luYWxLZXlzKG9iamVjdCk7XG5cdFx0XHR9O1xuXHRcdH1cblx0fSBlbHNlIHtcblx0XHRPYmplY3Qua2V5cyA9IGtleXNTaGltO1xuXHR9XG5cdHJldHVybiBPYmplY3Qua2V5cyB8fCBrZXlzU2hpbTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0ga2V5c1NoaW07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBFcnJvcjtcbiIsICIndXNlIHN0cmljdCc7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuL2V2YWwnKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gRXZhbEVycm9yO1xuIiwgIid1c2Ugc3RyaWN0JztcblxuLyoqIEB0eXBlIHtpbXBvcnQoJy4vcmFuZ2UnKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gUmFuZ2VFcnJvcjtcbiIsICIndXNlIHN0cmljdCc7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuL3JlZicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBSZWZlcmVuY2VFcnJvcjtcbiIsICIndXNlIHN0cmljdCc7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuL3N5bnRheCcpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBTeW50YXhFcnJvcjtcbiIsICIndXNlIHN0cmljdCc7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuL3R5cGUnKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gVHlwZUVycm9yO1xuIiwgIid1c2Ugc3RyaWN0JztcblxuLyoqIEB0eXBlIHtpbXBvcnQoJy4vdXJpJyl9ICovXG5tb2R1bGUuZXhwb3J0cyA9IFVSSUVycm9yO1xuIiwgIid1c2Ugc3RyaWN0JztcblxuLyogZXNsaW50IGNvbXBsZXhpdHk6IFsyLCAxOF0sIG1heC1zdGF0ZW1lbnRzOiBbMiwgMzNdICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGhhc1N5bWJvbHMoKSB7XG5cdGlmICh0eXBlb2YgU3ltYm9sICE9PSAnZnVuY3Rpb24nIHx8IHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzICE9PSAnZnVuY3Rpb24nKSB7IHJldHVybiBmYWxzZTsgfVxuXHRpZiAodHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gJ3N5bWJvbCcpIHsgcmV0dXJuIHRydWU7IH1cblxuXHR2YXIgb2JqID0ge307XG5cdHZhciBzeW0gPSBTeW1ib2woJ3Rlc3QnKTtcblx0dmFyIHN5bU9iaiA9IE9iamVjdChzeW0pO1xuXHRpZiAodHlwZW9mIHN5bSA9PT0gJ3N0cmluZycpIHsgcmV0dXJuIGZhbHNlOyB9XG5cblx0aWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChzeW0pICE9PSAnW29iamVjdCBTeW1ib2xdJykgeyByZXR1cm4gZmFsc2U7IH1cblx0aWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChzeW1PYmopICE9PSAnW29iamVjdCBTeW1ib2xdJykgeyByZXR1cm4gZmFsc2U7IH1cblxuXHQvLyB0ZW1wIGRpc2FibGVkIHBlciBodHRwczovL2dpdGh1Yi5jb20vbGpoYXJiL29iamVjdC5hc3NpZ24vaXNzdWVzLzE3XG5cdC8vIGlmIChzeW0gaW5zdGFuY2VvZiBTeW1ib2wpIHsgcmV0dXJuIGZhbHNlOyB9XG5cdC8vIHRlbXAgZGlzYWJsZWQgcGVyIGh0dHBzOi8vZ2l0aHViLmNvbS9XZWJSZWZsZWN0aW9uL2dldC1vd24tcHJvcGVydHktc3ltYm9scy9pc3N1ZXMvNFxuXHQvLyBpZiAoIShzeW1PYmogaW5zdGFuY2VvZiBTeW1ib2wpKSB7IHJldHVybiBmYWxzZTsgfVxuXG5cdC8vIGlmICh0eXBlb2YgU3ltYm9sLnByb3RvdHlwZS50b1N0cmluZyAhPT0gJ2Z1bmN0aW9uJykgeyByZXR1cm4gZmFsc2U7IH1cblx0Ly8gaWYgKFN0cmluZyhzeW0pICE9PSBTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoc3ltKSkgeyByZXR1cm4gZmFsc2U7IH1cblxuXHR2YXIgc3ltVmFsID0gNDI7XG5cdG9ialtzeW1dID0gc3ltVmFsO1xuXHRmb3IgKHN5bSBpbiBvYmopIHsgcmV0dXJuIGZhbHNlOyB9IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcmVzdHJpY3RlZC1zeW50YXgsIG5vLXVucmVhY2hhYmxlLWxvb3Bcblx0aWYgKHR5cGVvZiBPYmplY3Qua2V5cyA9PT0gJ2Z1bmN0aW9uJyAmJiBPYmplY3Qua2V5cyhvYmopLmxlbmd0aCAhPT0gMCkgeyByZXR1cm4gZmFsc2U7IH1cblxuXHRpZiAodHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzID09PSAnZnVuY3Rpb24nICYmIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG9iaikubGVuZ3RoICE9PSAwKSB7IHJldHVybiBmYWxzZTsgfVxuXG5cdHZhciBzeW1zID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhvYmopO1xuXHRpZiAoc3ltcy5sZW5ndGggIT09IDEgfHwgc3ltc1swXSAhPT0gc3ltKSB7IHJldHVybiBmYWxzZTsgfVxuXG5cdGlmICghT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKG9iaiwgc3ltKSkgeyByZXR1cm4gZmFsc2U7IH1cblxuXHRpZiAodHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPT09ICdmdW5jdGlvbicpIHtcblx0XHR2YXIgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqLCBzeW0pO1xuXHRcdGlmIChkZXNjcmlwdG9yLnZhbHVlICE9PSBzeW1WYWwgfHwgZGVzY3JpcHRvci5lbnVtZXJhYmxlICE9PSB0cnVlKSB7IHJldHVybiBmYWxzZTsgfVxuXHR9XG5cblx0cmV0dXJuIHRydWU7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIG9yaWdTeW1ib2wgPSB0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2w7XG52YXIgaGFzU3ltYm9sU2hhbSA9IHJlcXVpcmUoJy4vc2hhbXMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBoYXNOYXRpdmVTeW1ib2xzKCkge1xuXHRpZiAodHlwZW9mIG9yaWdTeW1ib2wgIT09ICdmdW5jdGlvbicpIHsgcmV0dXJuIGZhbHNlOyB9XG5cdGlmICh0eXBlb2YgU3ltYm9sICE9PSAnZnVuY3Rpb24nKSB7IHJldHVybiBmYWxzZTsgfVxuXHRpZiAodHlwZW9mIG9yaWdTeW1ib2woJ2ZvbycpICE9PSAnc3ltYm9sJykgeyByZXR1cm4gZmFsc2U7IH1cblx0aWYgKHR5cGVvZiBTeW1ib2woJ2JhcicpICE9PSAnc3ltYm9sJykgeyByZXR1cm4gZmFsc2U7IH1cblxuXHRyZXR1cm4gaGFzU3ltYm9sU2hhbSgpO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciB0ZXN0ID0ge1xuXHRfX3Byb3RvX186IG51bGwsXG5cdGZvbzoge31cbn07XG5cbnZhciAkT2JqZWN0ID0gT2JqZWN0O1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBoYXNQcm90bygpIHtcblx0Ly8gQHRzLWV4cGVjdC1lcnJvcjogVFMgZXJyb3JzIG9uIGFuIGluaGVyaXRlZCBwcm9wZXJ0eSBmb3Igc29tZSByZWFzb25cblx0cmV0dXJuIHsgX19wcm90b19fOiB0ZXN0IH0uZm9vID09PSB0ZXN0LmZvb1xuXHRcdCYmICEodGVzdCBpbnN0YW5jZW9mICRPYmplY3QpO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbi8qIGVzbGludCBuby1pbnZhbGlkLXRoaXM6IDEgKi9cblxudmFyIEVSUk9SX01FU1NBR0UgPSAnRnVuY3Rpb24ucHJvdG90eXBlLmJpbmQgY2FsbGVkIG9uIGluY29tcGF0aWJsZSAnO1xudmFyIHRvU3RyID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbnZhciBtYXggPSBNYXRoLm1heDtcbnZhciBmdW5jVHlwZSA9ICdbb2JqZWN0IEZ1bmN0aW9uXSc7XG5cbnZhciBjb25jYXR0eSA9IGZ1bmN0aW9uIGNvbmNhdHR5KGEsIGIpIHtcbiAgICB2YXIgYXJyID0gW107XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGEubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgYXJyW2ldID0gYVtpXTtcbiAgICB9XG4gICAgZm9yICh2YXIgaiA9IDA7IGogPCBiLmxlbmd0aDsgaiArPSAxKSB7XG4gICAgICAgIGFycltqICsgYS5sZW5ndGhdID0gYltqXTtcbiAgICB9XG5cbiAgICByZXR1cm4gYXJyO1xufTtcblxudmFyIHNsaWN5ID0gZnVuY3Rpb24gc2xpY3koYXJyTGlrZSwgb2Zmc2V0KSB7XG4gICAgdmFyIGFyciA9IFtdO1xuICAgIGZvciAodmFyIGkgPSBvZmZzZXQgfHwgMCwgaiA9IDA7IGkgPCBhcnJMaWtlLmxlbmd0aDsgaSArPSAxLCBqICs9IDEpIHtcbiAgICAgICAgYXJyW2pdID0gYXJyTGlrZVtpXTtcbiAgICB9XG4gICAgcmV0dXJuIGFycjtcbn07XG5cbnZhciBqb2lueSA9IGZ1bmN0aW9uIChhcnIsIGpvaW5lcikge1xuICAgIHZhciBzdHIgPSAnJztcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBzdHIgKz0gYXJyW2ldO1xuICAgICAgICBpZiAoaSArIDEgPCBhcnIubGVuZ3RoKSB7XG4gICAgICAgICAgICBzdHIgKz0gam9pbmVyO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdHI7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGJpbmQodGhhdCkge1xuICAgIHZhciB0YXJnZXQgPSB0aGlzO1xuICAgIGlmICh0eXBlb2YgdGFyZ2V0ICE9PSAnZnVuY3Rpb24nIHx8IHRvU3RyLmFwcGx5KHRhcmdldCkgIT09IGZ1bmNUeXBlKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoRVJST1JfTUVTU0FHRSArIHRhcmdldCk7XG4gICAgfVxuICAgIHZhciBhcmdzID0gc2xpY3koYXJndW1lbnRzLCAxKTtcblxuICAgIHZhciBib3VuZDtcbiAgICB2YXIgYmluZGVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcyBpbnN0YW5jZW9mIGJvdW5kKSB7XG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gdGFyZ2V0LmFwcGx5KFxuICAgICAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICAgICAgY29uY2F0dHkoYXJncywgYXJndW1lbnRzKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGlmIChPYmplY3QocmVzdWx0KSA9PT0gcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0YXJnZXQuYXBwbHkoXG4gICAgICAgICAgICB0aGF0LFxuICAgICAgICAgICAgY29uY2F0dHkoYXJncywgYXJndW1lbnRzKVxuICAgICAgICApO1xuXG4gICAgfTtcblxuICAgIHZhciBib3VuZExlbmd0aCA9IG1heCgwLCB0YXJnZXQubGVuZ3RoIC0gYXJncy5sZW5ndGgpO1xuICAgIHZhciBib3VuZEFyZ3MgPSBbXTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJvdW5kTGVuZ3RoOyBpKyspIHtcbiAgICAgICAgYm91bmRBcmdzW2ldID0gJyQnICsgaTtcbiAgICB9XG5cbiAgICBib3VuZCA9IEZ1bmN0aW9uKCdiaW5kZXInLCAncmV0dXJuIGZ1bmN0aW9uICgnICsgam9pbnkoYm91bmRBcmdzLCAnLCcpICsgJyl7IHJldHVybiBiaW5kZXIuYXBwbHkodGhpcyxhcmd1bWVudHMpOyB9JykoYmluZGVyKTtcblxuICAgIGlmICh0YXJnZXQucHJvdG90eXBlKSB7XG4gICAgICAgIHZhciBFbXB0eSA9IGZ1bmN0aW9uIEVtcHR5KCkge307XG4gICAgICAgIEVtcHR5LnByb3RvdHlwZSA9IHRhcmdldC5wcm90b3R5cGU7XG4gICAgICAgIGJvdW5kLnByb3RvdHlwZSA9IG5ldyBFbXB0eSgpO1xuICAgICAgICBFbXB0eS5wcm90b3R5cGUgPSBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiBib3VuZDtcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgaW1wbGVtZW50YXRpb24gPSByZXF1aXJlKCcuL2ltcGxlbWVudGF0aW9uJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gRnVuY3Rpb24ucHJvdG90eXBlLmJpbmQgfHwgaW1wbGVtZW50YXRpb247XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgY2FsbCA9IEZ1bmN0aW9uLnByb3RvdHlwZS5jYWxsO1xudmFyICRoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xudmFyIGJpbmQgPSByZXF1aXJlKCdmdW5jdGlvbi1iaW5kJyk7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5tb2R1bGUuZXhwb3J0cyA9IGJpbmQuY2FsbChjYWxsLCAkaGFzT3duKTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciB1bmRlZmluZWQ7XG5cbnZhciAkRXJyb3IgPSByZXF1aXJlKCdlcy1lcnJvcnMnKTtcbnZhciAkRXZhbEVycm9yID0gcmVxdWlyZSgnZXMtZXJyb3JzL2V2YWwnKTtcbnZhciAkUmFuZ2VFcnJvciA9IHJlcXVpcmUoJ2VzLWVycm9ycy9yYW5nZScpO1xudmFyICRSZWZlcmVuY2VFcnJvciA9IHJlcXVpcmUoJ2VzLWVycm9ycy9yZWYnKTtcbnZhciAkU3ludGF4RXJyb3IgPSByZXF1aXJlKCdlcy1lcnJvcnMvc3ludGF4Jyk7XG52YXIgJFR5cGVFcnJvciA9IHJlcXVpcmUoJ2VzLWVycm9ycy90eXBlJyk7XG52YXIgJFVSSUVycm9yID0gcmVxdWlyZSgnZXMtZXJyb3JzL3VyaScpO1xuXG52YXIgJEZ1bmN0aW9uID0gRnVuY3Rpb247XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxudmFyIGdldEV2YWxsZWRDb25zdHJ1Y3RvciA9IGZ1bmN0aW9uIChleHByZXNzaW9uU3ludGF4KSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuICRGdW5jdGlvbignXCJ1c2Ugc3RyaWN0XCI7IHJldHVybiAoJyArIGV4cHJlc3Npb25TeW50YXggKyAnKS5jb25zdHJ1Y3RvcjsnKSgpO1xuXHR9IGNhdGNoIChlKSB7fVxufTtcblxudmFyICRnT1BEID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbmlmICgkZ09QRCkge1xuXHR0cnkge1xuXHRcdCRnT1BEKHt9LCAnJyk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHQkZ09QRCA9IG51bGw7IC8vIHRoaXMgaXMgSUUgOCwgd2hpY2ggaGFzIGEgYnJva2VuIGdPUERcblx0fVxufVxuXG52YXIgdGhyb3dUeXBlRXJyb3IgPSBmdW5jdGlvbiAoKSB7XG5cdHRocm93IG5ldyAkVHlwZUVycm9yKCk7XG59O1xudmFyIFRocm93VHlwZUVycm9yID0gJGdPUERcblx0PyAoZnVuY3Rpb24gKCkge1xuXHRcdHRyeSB7XG5cdFx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLWV4cHJlc3Npb25zLCBuby1jYWxsZXIsIG5vLXJlc3RyaWN0ZWQtcHJvcGVydGllc1xuXHRcdFx0YXJndW1lbnRzLmNhbGxlZTsgLy8gSUUgOCBkb2VzIG5vdCB0aHJvdyBoZXJlXG5cdFx0XHRyZXR1cm4gdGhyb3dUeXBlRXJyb3I7XG5cdFx0fSBjYXRjaCAoY2FsbGVlVGhyb3dzKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHQvLyBJRSA4IHRocm93cyBvbiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGFyZ3VtZW50cywgJycpXG5cdFx0XHRcdHJldHVybiAkZ09QRChhcmd1bWVudHMsICdjYWxsZWUnKS5nZXQ7XG5cdFx0XHR9IGNhdGNoIChnT1BEdGhyb3dzKSB7XG5cdFx0XHRcdHJldHVybiB0aHJvd1R5cGVFcnJvcjtcblx0XHRcdH1cblx0XHR9XG5cdH0oKSlcblx0OiB0aHJvd1R5cGVFcnJvcjtcblxudmFyIGhhc1N5bWJvbHMgPSByZXF1aXJlKCdoYXMtc3ltYm9scycpKCk7XG52YXIgaGFzUHJvdG8gPSByZXF1aXJlKCdoYXMtcHJvdG8nKSgpO1xuXG52YXIgZ2V0UHJvdG8gPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YgfHwgKFxuXHRoYXNQcm90b1xuXHRcdD8gZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHguX19wcm90b19fOyB9IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcHJvdG9cblx0XHQ6IG51bGxcbik7XG5cbnZhciBuZWVkc0V2YWwgPSB7fTtcblxudmFyIFR5cGVkQXJyYXkgPSB0eXBlb2YgVWludDhBcnJheSA9PT0gJ3VuZGVmaW5lZCcgfHwgIWdldFByb3RvID8gdW5kZWZpbmVkIDogZ2V0UHJvdG8oVWludDhBcnJheSk7XG5cbnZhciBJTlRSSU5TSUNTID0ge1xuXHRfX3Byb3RvX186IG51bGwsXG5cdCclQWdncmVnYXRlRXJyb3IlJzogdHlwZW9mIEFnZ3JlZ2F0ZUVycm9yID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IEFnZ3JlZ2F0ZUVycm9yLFxuXHQnJUFycmF5JSc6IEFycmF5LFxuXHQnJUFycmF5QnVmZmVyJSc6IHR5cGVvZiBBcnJheUJ1ZmZlciA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBBcnJheUJ1ZmZlcixcblx0JyVBcnJheUl0ZXJhdG9yUHJvdG90eXBlJSc6IGhhc1N5bWJvbHMgJiYgZ2V0UHJvdG8gPyBnZXRQcm90byhbXVtTeW1ib2wuaXRlcmF0b3JdKCkpIDogdW5kZWZpbmVkLFxuXHQnJUFzeW5jRnJvbVN5bmNJdGVyYXRvclByb3RvdHlwZSUnOiB1bmRlZmluZWQsXG5cdCclQXN5bmNGdW5jdGlvbiUnOiBuZWVkc0V2YWwsXG5cdCclQXN5bmNHZW5lcmF0b3IlJzogbmVlZHNFdmFsLFxuXHQnJUFzeW5jR2VuZXJhdG9yRnVuY3Rpb24lJzogbmVlZHNFdmFsLFxuXHQnJUFzeW5jSXRlcmF0b3JQcm90b3R5cGUlJzogbmVlZHNFdmFsLFxuXHQnJUF0b21pY3MlJzogdHlwZW9mIEF0b21pY3MgPT09ICd1bmRlZmluZWQnID8gdW5kZWZpbmVkIDogQXRvbWljcyxcblx0JyVCaWdJbnQlJzogdHlwZW9mIEJpZ0ludCA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBCaWdJbnQsXG5cdCclQmlnSW50NjRBcnJheSUnOiB0eXBlb2YgQmlnSW50NjRBcnJheSA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBCaWdJbnQ2NEFycmF5LFxuXHQnJUJpZ1VpbnQ2NEFycmF5JSc6IHR5cGVvZiBCaWdVaW50NjRBcnJheSA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBCaWdVaW50NjRBcnJheSxcblx0JyVCb29sZWFuJSc6IEJvb2xlYW4sXG5cdCclRGF0YVZpZXclJzogdHlwZW9mIERhdGFWaWV3ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IERhdGFWaWV3LFxuXHQnJURhdGUlJzogRGF0ZSxcblx0JyVkZWNvZGVVUkklJzogZGVjb2RlVVJJLFxuXHQnJWRlY29kZVVSSUNvbXBvbmVudCUnOiBkZWNvZGVVUklDb21wb25lbnQsXG5cdCclZW5jb2RlVVJJJSc6IGVuY29kZVVSSSxcblx0JyVlbmNvZGVVUklDb21wb25lbnQlJzogZW5jb2RlVVJJQ29tcG9uZW50LFxuXHQnJUVycm9yJSc6ICRFcnJvcixcblx0JyVldmFsJSc6IGV2YWwsIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tZXZhbFxuXHQnJUV2YWxFcnJvciUnOiAkRXZhbEVycm9yLFxuXHQnJUZsb2F0MzJBcnJheSUnOiB0eXBlb2YgRmxvYXQzMkFycmF5ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IEZsb2F0MzJBcnJheSxcblx0JyVGbG9hdDY0QXJyYXklJzogdHlwZW9mIEZsb2F0NjRBcnJheSA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBGbG9hdDY0QXJyYXksXG5cdCclRmluYWxpemF0aW9uUmVnaXN0cnklJzogdHlwZW9mIEZpbmFsaXphdGlvblJlZ2lzdHJ5ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IEZpbmFsaXphdGlvblJlZ2lzdHJ5LFxuXHQnJUZ1bmN0aW9uJSc6ICRGdW5jdGlvbixcblx0JyVHZW5lcmF0b3JGdW5jdGlvbiUnOiBuZWVkc0V2YWwsXG5cdCclSW50OEFycmF5JSc6IHR5cGVvZiBJbnQ4QXJyYXkgPT09ICd1bmRlZmluZWQnID8gdW5kZWZpbmVkIDogSW50OEFycmF5LFxuXHQnJUludDE2QXJyYXklJzogdHlwZW9mIEludDE2QXJyYXkgPT09ICd1bmRlZmluZWQnID8gdW5kZWZpbmVkIDogSW50MTZBcnJheSxcblx0JyVJbnQzMkFycmF5JSc6IHR5cGVvZiBJbnQzMkFycmF5ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IEludDMyQXJyYXksXG5cdCclaXNGaW5pdGUlJzogaXNGaW5pdGUsXG5cdCclaXNOYU4lJzogaXNOYU4sXG5cdCclSXRlcmF0b3JQcm90b3R5cGUlJzogaGFzU3ltYm9scyAmJiBnZXRQcm90byA/IGdldFByb3RvKGdldFByb3RvKFtdW1N5bWJvbC5pdGVyYXRvcl0oKSkpIDogdW5kZWZpbmVkLFxuXHQnJUpTT04lJzogdHlwZW9mIEpTT04gPT09ICdvYmplY3QnID8gSlNPTiA6IHVuZGVmaW5lZCxcblx0JyVNYXAlJzogdHlwZW9mIE1hcCA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBNYXAsXG5cdCclTWFwSXRlcmF0b3JQcm90b3R5cGUlJzogdHlwZW9mIE1hcCA9PT0gJ3VuZGVmaW5lZCcgfHwgIWhhc1N5bWJvbHMgfHwgIWdldFByb3RvID8gdW5kZWZpbmVkIDogZ2V0UHJvdG8obmV3IE1hcCgpW1N5bWJvbC5pdGVyYXRvcl0oKSksXG5cdCclTWF0aCUnOiBNYXRoLFxuXHQnJU51bWJlciUnOiBOdW1iZXIsXG5cdCclT2JqZWN0JSc6IE9iamVjdCxcblx0JyVwYXJzZUZsb2F0JSc6IHBhcnNlRmxvYXQsXG5cdCclcGFyc2VJbnQlJzogcGFyc2VJbnQsXG5cdCclUHJvbWlzZSUnOiB0eXBlb2YgUHJvbWlzZSA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBQcm9taXNlLFxuXHQnJVByb3h5JSc6IHR5cGVvZiBQcm94eSA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBQcm94eSxcblx0JyVSYW5nZUVycm9yJSc6ICRSYW5nZUVycm9yLFxuXHQnJVJlZmVyZW5jZUVycm9yJSc6ICRSZWZlcmVuY2VFcnJvcixcblx0JyVSZWZsZWN0JSc6IHR5cGVvZiBSZWZsZWN0ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IFJlZmxlY3QsXG5cdCclUmVnRXhwJSc6IFJlZ0V4cCxcblx0JyVTZXQlJzogdHlwZW9mIFNldCA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBTZXQsXG5cdCclU2V0SXRlcmF0b3JQcm90b3R5cGUlJzogdHlwZW9mIFNldCA9PT0gJ3VuZGVmaW5lZCcgfHwgIWhhc1N5bWJvbHMgfHwgIWdldFByb3RvID8gdW5kZWZpbmVkIDogZ2V0UHJvdG8obmV3IFNldCgpW1N5bWJvbC5pdGVyYXRvcl0oKSksXG5cdCclU2hhcmVkQXJyYXlCdWZmZXIlJzogdHlwZW9mIFNoYXJlZEFycmF5QnVmZmVyID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IFNoYXJlZEFycmF5QnVmZmVyLFxuXHQnJVN0cmluZyUnOiBTdHJpbmcsXG5cdCclU3RyaW5nSXRlcmF0b3JQcm90b3R5cGUlJzogaGFzU3ltYm9scyAmJiBnZXRQcm90byA/IGdldFByb3RvKCcnW1N5bWJvbC5pdGVyYXRvcl0oKSkgOiB1bmRlZmluZWQsXG5cdCclU3ltYm9sJSc6IGhhc1N5bWJvbHMgPyBTeW1ib2wgOiB1bmRlZmluZWQsXG5cdCclU3ludGF4RXJyb3IlJzogJFN5bnRheEVycm9yLFxuXHQnJVRocm93VHlwZUVycm9yJSc6IFRocm93VHlwZUVycm9yLFxuXHQnJVR5cGVkQXJyYXklJzogVHlwZWRBcnJheSxcblx0JyVUeXBlRXJyb3IlJzogJFR5cGVFcnJvcixcblx0JyVVaW50OEFycmF5JSc6IHR5cGVvZiBVaW50OEFycmF5ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IFVpbnQ4QXJyYXksXG5cdCclVWludDhDbGFtcGVkQXJyYXklJzogdHlwZW9mIFVpbnQ4Q2xhbXBlZEFycmF5ID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IFVpbnQ4Q2xhbXBlZEFycmF5LFxuXHQnJVVpbnQxNkFycmF5JSc6IHR5cGVvZiBVaW50MTZBcnJheSA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBVaW50MTZBcnJheSxcblx0JyVVaW50MzJBcnJheSUnOiB0eXBlb2YgVWludDMyQXJyYXkgPT09ICd1bmRlZmluZWQnID8gdW5kZWZpbmVkIDogVWludDMyQXJyYXksXG5cdCclVVJJRXJyb3IlJzogJFVSSUVycm9yLFxuXHQnJVdlYWtNYXAlJzogdHlwZW9mIFdlYWtNYXAgPT09ICd1bmRlZmluZWQnID8gdW5kZWZpbmVkIDogV2Vha01hcCxcblx0JyVXZWFrUmVmJSc6IHR5cGVvZiBXZWFrUmVmID09PSAndW5kZWZpbmVkJyA/IHVuZGVmaW5lZCA6IFdlYWtSZWYsXG5cdCclV2Vha1NldCUnOiB0eXBlb2YgV2Vha1NldCA9PT0gJ3VuZGVmaW5lZCcgPyB1bmRlZmluZWQgOiBXZWFrU2V0XG59O1xuXG5pZiAoZ2V0UHJvdG8pIHtcblx0dHJ5IHtcblx0XHRudWxsLmVycm9yOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVudXNlZC1leHByZXNzaW9uc1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0Ly8gaHR0cHM6Ly9naXRodWIuY29tL3RjMzkvcHJvcG9zYWwtc2hhZG93cmVhbG0vcHVsbC8zODQjaXNzdWVjb21tZW50LTEzNjQyNjQyMjlcblx0XHR2YXIgZXJyb3JQcm90byA9IGdldFByb3RvKGdldFByb3RvKGUpKTtcblx0XHRJTlRSSU5TSUNTWyclRXJyb3IucHJvdG90eXBlJSddID0gZXJyb3JQcm90bztcblx0fVxufVxuXG52YXIgZG9FdmFsID0gZnVuY3Rpb24gZG9FdmFsKG5hbWUpIHtcblx0dmFyIHZhbHVlO1xuXHRpZiAobmFtZSA9PT0gJyVBc3luY0Z1bmN0aW9uJScpIHtcblx0XHR2YWx1ZSA9IGdldEV2YWxsZWRDb25zdHJ1Y3RvcignYXN5bmMgZnVuY3Rpb24gKCkge30nKTtcblx0fSBlbHNlIGlmIChuYW1lID09PSAnJUdlbmVyYXRvckZ1bmN0aW9uJScpIHtcblx0XHR2YWx1ZSA9IGdldEV2YWxsZWRDb25zdHJ1Y3RvcignZnVuY3Rpb24qICgpIHt9Jyk7XG5cdH0gZWxzZSBpZiAobmFtZSA9PT0gJyVBc3luY0dlbmVyYXRvckZ1bmN0aW9uJScpIHtcblx0XHR2YWx1ZSA9IGdldEV2YWxsZWRDb25zdHJ1Y3RvcignYXN5bmMgZnVuY3Rpb24qICgpIHt9Jyk7XG5cdH0gZWxzZSBpZiAobmFtZSA9PT0gJyVBc3luY0dlbmVyYXRvciUnKSB7XG5cdFx0dmFyIGZuID0gZG9FdmFsKCclQXN5bmNHZW5lcmF0b3JGdW5jdGlvbiUnKTtcblx0XHRpZiAoZm4pIHtcblx0XHRcdHZhbHVlID0gZm4ucHJvdG90eXBlO1xuXHRcdH1cblx0fSBlbHNlIGlmIChuYW1lID09PSAnJUFzeW5jSXRlcmF0b3JQcm90b3R5cGUlJykge1xuXHRcdHZhciBnZW4gPSBkb0V2YWwoJyVBc3luY0dlbmVyYXRvciUnKTtcblx0XHRpZiAoZ2VuICYmIGdldFByb3RvKSB7XG5cdFx0XHR2YWx1ZSA9IGdldFByb3RvKGdlbi5wcm90b3R5cGUpO1xuXHRcdH1cblx0fVxuXG5cdElOVFJJTlNJQ1NbbmFtZV0gPSB2YWx1ZTtcblxuXHRyZXR1cm4gdmFsdWU7XG59O1xuXG52YXIgTEVHQUNZX0FMSUFTRVMgPSB7XG5cdF9fcHJvdG9fXzogbnVsbCxcblx0JyVBcnJheUJ1ZmZlclByb3RvdHlwZSUnOiBbJ0FycmF5QnVmZmVyJywgJ3Byb3RvdHlwZSddLFxuXHQnJUFycmF5UHJvdG90eXBlJSc6IFsnQXJyYXknLCAncHJvdG90eXBlJ10sXG5cdCclQXJyYXlQcm90b19lbnRyaWVzJSc6IFsnQXJyYXknLCAncHJvdG90eXBlJywgJ2VudHJpZXMnXSxcblx0JyVBcnJheVByb3RvX2ZvckVhY2glJzogWydBcnJheScsICdwcm90b3R5cGUnLCAnZm9yRWFjaCddLFxuXHQnJUFycmF5UHJvdG9fa2V5cyUnOiBbJ0FycmF5JywgJ3Byb3RvdHlwZScsICdrZXlzJ10sXG5cdCclQXJyYXlQcm90b192YWx1ZXMlJzogWydBcnJheScsICdwcm90b3R5cGUnLCAndmFsdWVzJ10sXG5cdCclQXN5bmNGdW5jdGlvblByb3RvdHlwZSUnOiBbJ0FzeW5jRnVuY3Rpb24nLCAncHJvdG90eXBlJ10sXG5cdCclQXN5bmNHZW5lcmF0b3IlJzogWydBc3luY0dlbmVyYXRvckZ1bmN0aW9uJywgJ3Byb3RvdHlwZSddLFxuXHQnJUFzeW5jR2VuZXJhdG9yUHJvdG90eXBlJSc6IFsnQXN5bmNHZW5lcmF0b3JGdW5jdGlvbicsICdwcm90b3R5cGUnLCAncHJvdG90eXBlJ10sXG5cdCclQm9vbGVhblByb3RvdHlwZSUnOiBbJ0Jvb2xlYW4nLCAncHJvdG90eXBlJ10sXG5cdCclRGF0YVZpZXdQcm90b3R5cGUlJzogWydEYXRhVmlldycsICdwcm90b3R5cGUnXSxcblx0JyVEYXRlUHJvdG90eXBlJSc6IFsnRGF0ZScsICdwcm90b3R5cGUnXSxcblx0JyVFcnJvclByb3RvdHlwZSUnOiBbJ0Vycm9yJywgJ3Byb3RvdHlwZSddLFxuXHQnJUV2YWxFcnJvclByb3RvdHlwZSUnOiBbJ0V2YWxFcnJvcicsICdwcm90b3R5cGUnXSxcblx0JyVGbG9hdDMyQXJyYXlQcm90b3R5cGUlJzogWydGbG9hdDMyQXJyYXknLCAncHJvdG90eXBlJ10sXG5cdCclRmxvYXQ2NEFycmF5UHJvdG90eXBlJSc6IFsnRmxvYXQ2NEFycmF5JywgJ3Byb3RvdHlwZSddLFxuXHQnJUZ1bmN0aW9uUHJvdG90eXBlJSc6IFsnRnVuY3Rpb24nLCAncHJvdG90eXBlJ10sXG5cdCclR2VuZXJhdG9yJSc6IFsnR2VuZXJhdG9yRnVuY3Rpb24nLCAncHJvdG90eXBlJ10sXG5cdCclR2VuZXJhdG9yUHJvdG90eXBlJSc6IFsnR2VuZXJhdG9yRnVuY3Rpb24nLCAncHJvdG90eXBlJywgJ3Byb3RvdHlwZSddLFxuXHQnJUludDhBcnJheVByb3RvdHlwZSUnOiBbJ0ludDhBcnJheScsICdwcm90b3R5cGUnXSxcblx0JyVJbnQxNkFycmF5UHJvdG90eXBlJSc6IFsnSW50MTZBcnJheScsICdwcm90b3R5cGUnXSxcblx0JyVJbnQzMkFycmF5UHJvdG90eXBlJSc6IFsnSW50MzJBcnJheScsICdwcm90b3R5cGUnXSxcblx0JyVKU09OUGFyc2UlJzogWydKU09OJywgJ3BhcnNlJ10sXG5cdCclSlNPTlN0cmluZ2lmeSUnOiBbJ0pTT04nLCAnc3RyaW5naWZ5J10sXG5cdCclTWFwUHJvdG90eXBlJSc6IFsnTWFwJywgJ3Byb3RvdHlwZSddLFxuXHQnJU51bWJlclByb3RvdHlwZSUnOiBbJ051bWJlcicsICdwcm90b3R5cGUnXSxcblx0JyVPYmplY3RQcm90b3R5cGUlJzogWydPYmplY3QnLCAncHJvdG90eXBlJ10sXG5cdCclT2JqUHJvdG9fdG9TdHJpbmclJzogWydPYmplY3QnLCAncHJvdG90eXBlJywgJ3RvU3RyaW5nJ10sXG5cdCclT2JqUHJvdG9fdmFsdWVPZiUnOiBbJ09iamVjdCcsICdwcm90b3R5cGUnLCAndmFsdWVPZiddLFxuXHQnJVByb21pc2VQcm90b3R5cGUlJzogWydQcm9taXNlJywgJ3Byb3RvdHlwZSddLFxuXHQnJVByb21pc2VQcm90b190aGVuJSc6IFsnUHJvbWlzZScsICdwcm90b3R5cGUnLCAndGhlbiddLFxuXHQnJVByb21pc2VfYWxsJSc6IFsnUHJvbWlzZScsICdhbGwnXSxcblx0JyVQcm9taXNlX3JlamVjdCUnOiBbJ1Byb21pc2UnLCAncmVqZWN0J10sXG5cdCclUHJvbWlzZV9yZXNvbHZlJSc6IFsnUHJvbWlzZScsICdyZXNvbHZlJ10sXG5cdCclUmFuZ2VFcnJvclByb3RvdHlwZSUnOiBbJ1JhbmdlRXJyb3InLCAncHJvdG90eXBlJ10sXG5cdCclUmVmZXJlbmNlRXJyb3JQcm90b3R5cGUlJzogWydSZWZlcmVuY2VFcnJvcicsICdwcm90b3R5cGUnXSxcblx0JyVSZWdFeHBQcm90b3R5cGUlJzogWydSZWdFeHAnLCAncHJvdG90eXBlJ10sXG5cdCclU2V0UHJvdG90eXBlJSc6IFsnU2V0JywgJ3Byb3RvdHlwZSddLFxuXHQnJVNoYXJlZEFycmF5QnVmZmVyUHJvdG90eXBlJSc6IFsnU2hhcmVkQXJyYXlCdWZmZXInLCAncHJvdG90eXBlJ10sXG5cdCclU3RyaW5nUHJvdG90eXBlJSc6IFsnU3RyaW5nJywgJ3Byb3RvdHlwZSddLFxuXHQnJVN5bWJvbFByb3RvdHlwZSUnOiBbJ1N5bWJvbCcsICdwcm90b3R5cGUnXSxcblx0JyVTeW50YXhFcnJvclByb3RvdHlwZSUnOiBbJ1N5bnRheEVycm9yJywgJ3Byb3RvdHlwZSddLFxuXHQnJVR5cGVkQXJyYXlQcm90b3R5cGUlJzogWydUeXBlZEFycmF5JywgJ3Byb3RvdHlwZSddLFxuXHQnJVR5cGVFcnJvclByb3RvdHlwZSUnOiBbJ1R5cGVFcnJvcicsICdwcm90b3R5cGUnXSxcblx0JyVVaW50OEFycmF5UHJvdG90eXBlJSc6IFsnVWludDhBcnJheScsICdwcm90b3R5cGUnXSxcblx0JyVVaW50OENsYW1wZWRBcnJheVByb3RvdHlwZSUnOiBbJ1VpbnQ4Q2xhbXBlZEFycmF5JywgJ3Byb3RvdHlwZSddLFxuXHQnJVVpbnQxNkFycmF5UHJvdG90eXBlJSc6IFsnVWludDE2QXJyYXknLCAncHJvdG90eXBlJ10sXG5cdCclVWludDMyQXJyYXlQcm90b3R5cGUlJzogWydVaW50MzJBcnJheScsICdwcm90b3R5cGUnXSxcblx0JyVVUklFcnJvclByb3RvdHlwZSUnOiBbJ1VSSUVycm9yJywgJ3Byb3RvdHlwZSddLFxuXHQnJVdlYWtNYXBQcm90b3R5cGUlJzogWydXZWFrTWFwJywgJ3Byb3RvdHlwZSddLFxuXHQnJVdlYWtTZXRQcm90b3R5cGUlJzogWydXZWFrU2V0JywgJ3Byb3RvdHlwZSddXG59O1xuXG52YXIgYmluZCA9IHJlcXVpcmUoJ2Z1bmN0aW9uLWJpbmQnKTtcbnZhciBoYXNPd24gPSByZXF1aXJlKCdoYXNvd24nKTtcbnZhciAkY29uY2F0ID0gYmluZC5jYWxsKEZ1bmN0aW9uLmNhbGwsIEFycmF5LnByb3RvdHlwZS5jb25jYXQpO1xudmFyICRzcGxpY2VBcHBseSA9IGJpbmQuY2FsbChGdW5jdGlvbi5hcHBseSwgQXJyYXkucHJvdG90eXBlLnNwbGljZSk7XG52YXIgJHJlcGxhY2UgPSBiaW5kLmNhbGwoRnVuY3Rpb24uY2FsbCwgU3RyaW5nLnByb3RvdHlwZS5yZXBsYWNlKTtcbnZhciAkc3RyU2xpY2UgPSBiaW5kLmNhbGwoRnVuY3Rpb24uY2FsbCwgU3RyaW5nLnByb3RvdHlwZS5zbGljZSk7XG52YXIgJGV4ZWMgPSBiaW5kLmNhbGwoRnVuY3Rpb24uY2FsbCwgUmVnRXhwLnByb3RvdHlwZS5leGVjKTtcblxuLyogYWRhcHRlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9sb2Rhc2gvbG9kYXNoL2Jsb2IvNC4xNy4xNS9kaXN0L2xvZGFzaC5qcyNMNjczNS1MNjc0NCAqL1xudmFyIHJlUHJvcE5hbWUgPSAvW14lLltcXF1dK3xcXFsoPzooLT9cXGQrKD86XFwuXFxkKyk/KXwoW1wiJ10pKCg/Oig/IVxcMilbXlxcXFxdfFxcXFwuKSo/KVxcMilcXF18KD89KD86XFwufFxcW1xcXSkoPzpcXC58XFxbXFxdfCUkKSkvZztcbnZhciByZUVzY2FwZUNoYXIgPSAvXFxcXChcXFxcKT8vZzsgLyoqIFVzZWQgdG8gbWF0Y2ggYmFja3NsYXNoZXMgaW4gcHJvcGVydHkgcGF0aHMuICovXG52YXIgc3RyaW5nVG9QYXRoID0gZnVuY3Rpb24gc3RyaW5nVG9QYXRoKHN0cmluZykge1xuXHR2YXIgZmlyc3QgPSAkc3RyU2xpY2Uoc3RyaW5nLCAwLCAxKTtcblx0dmFyIGxhc3QgPSAkc3RyU2xpY2Uoc3RyaW5nLCAtMSk7XG5cdGlmIChmaXJzdCA9PT0gJyUnICYmIGxhc3QgIT09ICclJykge1xuXHRcdHRocm93IG5ldyAkU3ludGF4RXJyb3IoJ2ludmFsaWQgaW50cmluc2ljIHN5bnRheCwgZXhwZWN0ZWQgY2xvc2luZyBgJWAnKTtcblx0fSBlbHNlIGlmIChsYXN0ID09PSAnJScgJiYgZmlyc3QgIT09ICclJykge1xuXHRcdHRocm93IG5ldyAkU3ludGF4RXJyb3IoJ2ludmFsaWQgaW50cmluc2ljIHN5bnRheCwgZXhwZWN0ZWQgb3BlbmluZyBgJWAnKTtcblx0fVxuXHR2YXIgcmVzdWx0ID0gW107XG5cdCRyZXBsYWNlKHN0cmluZywgcmVQcm9wTmFtZSwgZnVuY3Rpb24gKG1hdGNoLCBudW1iZXIsIHF1b3RlLCBzdWJTdHJpbmcpIHtcblx0XHRyZXN1bHRbcmVzdWx0Lmxlbmd0aF0gPSBxdW90ZSA/ICRyZXBsYWNlKHN1YlN0cmluZywgcmVFc2NhcGVDaGFyLCAnJDEnKSA6IG51bWJlciB8fCBtYXRjaDtcblx0fSk7XG5cdHJldHVybiByZXN1bHQ7XG59O1xuLyogZW5kIGFkYXB0YXRpb24gKi9cblxudmFyIGdldEJhc2VJbnRyaW5zaWMgPSBmdW5jdGlvbiBnZXRCYXNlSW50cmluc2ljKG5hbWUsIGFsbG93TWlzc2luZykge1xuXHR2YXIgaW50cmluc2ljTmFtZSA9IG5hbWU7XG5cdHZhciBhbGlhcztcblx0aWYgKGhhc093bihMRUdBQ1lfQUxJQVNFUywgaW50cmluc2ljTmFtZSkpIHtcblx0XHRhbGlhcyA9IExFR0FDWV9BTElBU0VTW2ludHJpbnNpY05hbWVdO1xuXHRcdGludHJpbnNpY05hbWUgPSAnJScgKyBhbGlhc1swXSArICclJztcblx0fVxuXG5cdGlmIChoYXNPd24oSU5UUklOU0lDUywgaW50cmluc2ljTmFtZSkpIHtcblx0XHR2YXIgdmFsdWUgPSBJTlRSSU5TSUNTW2ludHJpbnNpY05hbWVdO1xuXHRcdGlmICh2YWx1ZSA9PT0gbmVlZHNFdmFsKSB7XG5cdFx0XHR2YWx1ZSA9IGRvRXZhbChpbnRyaW5zaWNOYW1lKTtcblx0XHR9XG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcgJiYgIWFsbG93TWlzc2luZykge1xuXHRcdFx0dGhyb3cgbmV3ICRUeXBlRXJyb3IoJ2ludHJpbnNpYyAnICsgbmFtZSArICcgZXhpc3RzLCBidXQgaXMgbm90IGF2YWlsYWJsZS4gUGxlYXNlIGZpbGUgYW4gaXNzdWUhJyk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHtcblx0XHRcdGFsaWFzOiBhbGlhcyxcblx0XHRcdG5hbWU6IGludHJpbnNpY05hbWUsXG5cdFx0XHR2YWx1ZTogdmFsdWVcblx0XHR9O1xuXHR9XG5cblx0dGhyb3cgbmV3ICRTeW50YXhFcnJvcignaW50cmluc2ljICcgKyBuYW1lICsgJyBkb2VzIG5vdCBleGlzdCEnKTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gR2V0SW50cmluc2ljKG5hbWUsIGFsbG93TWlzc2luZykge1xuXHRpZiAodHlwZW9mIG5hbWUgIT09ICdzdHJpbmcnIHx8IG5hbWUubGVuZ3RoID09PSAwKSB7XG5cdFx0dGhyb3cgbmV3ICRUeXBlRXJyb3IoJ2ludHJpbnNpYyBuYW1lIG11c3QgYmUgYSBub24tZW1wdHkgc3RyaW5nJyk7XG5cdH1cblx0aWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIHR5cGVvZiBhbGxvd01pc3NpbmcgIT09ICdib29sZWFuJykge1xuXHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdcImFsbG93TWlzc2luZ1wiIGFyZ3VtZW50IG11c3QgYmUgYSBib29sZWFuJyk7XG5cdH1cblxuXHRpZiAoJGV4ZWMoL14lP1teJV0qJT8kLywgbmFtZSkgPT09IG51bGwpIHtcblx0XHR0aHJvdyBuZXcgJFN5bnRheEVycm9yKCdgJWAgbWF5IG5vdCBiZSBwcmVzZW50IGFueXdoZXJlIGJ1dCBhdCB0aGUgYmVnaW5uaW5nIGFuZCBlbmQgb2YgdGhlIGludHJpbnNpYyBuYW1lJyk7XG5cdH1cblx0dmFyIHBhcnRzID0gc3RyaW5nVG9QYXRoKG5hbWUpO1xuXHR2YXIgaW50cmluc2ljQmFzZU5hbWUgPSBwYXJ0cy5sZW5ndGggPiAwID8gcGFydHNbMF0gOiAnJztcblxuXHR2YXIgaW50cmluc2ljID0gZ2V0QmFzZUludHJpbnNpYygnJScgKyBpbnRyaW5zaWNCYXNlTmFtZSArICclJywgYWxsb3dNaXNzaW5nKTtcblx0dmFyIGludHJpbnNpY1JlYWxOYW1lID0gaW50cmluc2ljLm5hbWU7XG5cdHZhciB2YWx1ZSA9IGludHJpbnNpYy52YWx1ZTtcblx0dmFyIHNraXBGdXJ0aGVyQ2FjaGluZyA9IGZhbHNlO1xuXG5cdHZhciBhbGlhcyA9IGludHJpbnNpYy5hbGlhcztcblx0aWYgKGFsaWFzKSB7XG5cdFx0aW50cmluc2ljQmFzZU5hbWUgPSBhbGlhc1swXTtcblx0XHQkc3BsaWNlQXBwbHkocGFydHMsICRjb25jYXQoWzAsIDFdLCBhbGlhcykpO1xuXHR9XG5cblx0Zm9yICh2YXIgaSA9IDEsIGlzT3duID0gdHJ1ZTsgaSA8IHBhcnRzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0dmFyIHBhcnQgPSBwYXJ0c1tpXTtcblx0XHR2YXIgZmlyc3QgPSAkc3RyU2xpY2UocGFydCwgMCwgMSk7XG5cdFx0dmFyIGxhc3QgPSAkc3RyU2xpY2UocGFydCwgLTEpO1xuXHRcdGlmIChcblx0XHRcdChcblx0XHRcdFx0KGZpcnN0ID09PSAnXCInIHx8IGZpcnN0ID09PSBcIidcIiB8fCBmaXJzdCA9PT0gJ2AnKVxuXHRcdFx0XHR8fCAobGFzdCA9PT0gJ1wiJyB8fCBsYXN0ID09PSBcIidcIiB8fCBsYXN0ID09PSAnYCcpXG5cdFx0XHQpXG5cdFx0XHQmJiBmaXJzdCAhPT0gbGFzdFxuXHRcdCkge1xuXHRcdFx0dGhyb3cgbmV3ICRTeW50YXhFcnJvcigncHJvcGVydHkgbmFtZXMgd2l0aCBxdW90ZXMgbXVzdCBoYXZlIG1hdGNoaW5nIHF1b3RlcycpO1xuXHRcdH1cblx0XHRpZiAocGFydCA9PT0gJ2NvbnN0cnVjdG9yJyB8fCAhaXNPd24pIHtcblx0XHRcdHNraXBGdXJ0aGVyQ2FjaGluZyA9IHRydWU7XG5cdFx0fVxuXG5cdFx0aW50cmluc2ljQmFzZU5hbWUgKz0gJy4nICsgcGFydDtcblx0XHRpbnRyaW5zaWNSZWFsTmFtZSA9ICclJyArIGludHJpbnNpY0Jhc2VOYW1lICsgJyUnO1xuXG5cdFx0aWYgKGhhc093bihJTlRSSU5TSUNTLCBpbnRyaW5zaWNSZWFsTmFtZSkpIHtcblx0XHRcdHZhbHVlID0gSU5UUklOU0lDU1tpbnRyaW5zaWNSZWFsTmFtZV07XG5cdFx0fSBlbHNlIGlmICh2YWx1ZSAhPSBudWxsKSB7XG5cdFx0XHRpZiAoIShwYXJ0IGluIHZhbHVlKSkge1xuXHRcdFx0XHRpZiAoIWFsbG93TWlzc2luZykge1xuXHRcdFx0XHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdiYXNlIGludHJpbnNpYyBmb3IgJyArIG5hbWUgKyAnIGV4aXN0cywgYnV0IHRoZSBwcm9wZXJ0eSBpcyBub3QgYXZhaWxhYmxlLicpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiB2b2lkIHVuZGVmaW5lZDtcblx0XHRcdH1cblx0XHRcdGlmICgkZ09QRCAmJiAoaSArIDEpID49IHBhcnRzLmxlbmd0aCkge1xuXHRcdFx0XHR2YXIgZGVzYyA9ICRnT1BEKHZhbHVlLCBwYXJ0KTtcblx0XHRcdFx0aXNPd24gPSAhIWRlc2M7XG5cblx0XHRcdFx0Ly8gQnkgY29udmVudGlvbiwgd2hlbiBhIGRhdGEgcHJvcGVydHkgaXMgY29udmVydGVkIHRvIGFuIGFjY2Vzc29yXG5cdFx0XHRcdC8vIHByb3BlcnR5IHRvIGVtdWxhdGUgYSBkYXRhIHByb3BlcnR5IHRoYXQgZG9lcyBub3Qgc3VmZmVyIGZyb21cblx0XHRcdFx0Ly8gdGhlIG92ZXJyaWRlIG1pc3Rha2UsIHRoYXQgYWNjZXNzb3IncyBnZXR0ZXIgaXMgbWFya2VkIHdpdGhcblx0XHRcdFx0Ly8gYW4gYG9yaWdpbmFsVmFsdWVgIHByb3BlcnR5LiBIZXJlLCB3aGVuIHdlIGRldGVjdCB0aGlzLCB3ZVxuXHRcdFx0XHQvLyB1cGhvbGQgdGhlIGlsbHVzaW9uIGJ5IHByZXRlbmRpbmcgdG8gc2VlIHRoYXQgb3JpZ2luYWwgZGF0YVxuXHRcdFx0XHQvLyBwcm9wZXJ0eSwgaS5lLiwgcmV0dXJuaW5nIHRoZSB2YWx1ZSByYXRoZXIgdGhhbiB0aGUgZ2V0dGVyXG5cdFx0XHRcdC8vIGl0c2VsZi5cblx0XHRcdFx0aWYgKGlzT3duICYmICdnZXQnIGluIGRlc2MgJiYgISgnb3JpZ2luYWxWYWx1ZScgaW4gZGVzYy5nZXQpKSB7XG5cdFx0XHRcdFx0dmFsdWUgPSBkZXNjLmdldDtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHR2YWx1ZSA9IHZhbHVlW3BhcnRdO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRpc093biA9IGhhc093bih2YWx1ZSwgcGFydCk7XG5cdFx0XHRcdHZhbHVlID0gdmFsdWVbcGFydF07XG5cdFx0XHR9XG5cblx0XHRcdGlmIChpc093biAmJiAhc2tpcEZ1cnRoZXJDYWNoaW5nKSB7XG5cdFx0XHRcdElOVFJJTlNJQ1NbaW50cmluc2ljUmVhbE5hbWVdID0gdmFsdWU7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdHJldHVybiB2YWx1ZTtcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgR2V0SW50cmluc2ljID0gcmVxdWlyZSgnZ2V0LWludHJpbnNpYycpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xudmFyICRkZWZpbmVQcm9wZXJ0eSA9IEdldEludHJpbnNpYygnJU9iamVjdC5kZWZpbmVQcm9wZXJ0eSUnLCB0cnVlKSB8fCBmYWxzZTtcbmlmICgkZGVmaW5lUHJvcGVydHkpIHtcblx0dHJ5IHtcblx0XHQkZGVmaW5lUHJvcGVydHkoe30sICdhJywgeyB2YWx1ZTogMSB9KTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdC8vIElFIDggaGFzIGEgYnJva2VuIGRlZmluZVByb3BlcnR5XG5cdFx0JGRlZmluZVByb3BlcnR5ID0gZmFsc2U7XG5cdH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSAkZGVmaW5lUHJvcGVydHk7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgR2V0SW50cmluc2ljID0gcmVxdWlyZSgnZ2V0LWludHJpbnNpYycpO1xuXG52YXIgJGdPUEQgPSBHZXRJbnRyaW5zaWMoJyVPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yJScsIHRydWUpO1xuXG5pZiAoJGdPUEQpIHtcblx0dHJ5IHtcblx0XHQkZ09QRChbXSwgJ2xlbmd0aCcpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0Ly8gSUUgOCBoYXMgYSBicm9rZW4gZ09QRFxuXHRcdCRnT1BEID0gbnVsbDtcblx0fVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9ICRnT1BEO1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyICRkZWZpbmVQcm9wZXJ0eSA9IHJlcXVpcmUoJ2VzLWRlZmluZS1wcm9wZXJ0eScpO1xuXG52YXIgJFN5bnRheEVycm9yID0gcmVxdWlyZSgnZXMtZXJyb3JzL3N5bnRheCcpO1xudmFyICRUeXBlRXJyb3IgPSByZXF1aXJlKCdlcy1lcnJvcnMvdHlwZScpO1xuXG52YXIgZ29wZCA9IHJlcXVpcmUoJ2dvcGQnKTtcblxuLyoqIEB0eXBlIHtpbXBvcnQoJy4nKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZGVmaW5lRGF0YVByb3BlcnR5KFxuXHRvYmosXG5cdHByb3BlcnR5LFxuXHR2YWx1ZVxuKSB7XG5cdGlmICghb2JqIHx8ICh0eXBlb2Ygb2JqICE9PSAnb2JqZWN0JyAmJiB0eXBlb2Ygb2JqICE9PSAnZnVuY3Rpb24nKSkge1xuXHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdgb2JqYCBtdXN0IGJlIGFuIG9iamVjdCBvciBhIGZ1bmN0aW9uYCcpO1xuXHR9XG5cdGlmICh0eXBlb2YgcHJvcGVydHkgIT09ICdzdHJpbmcnICYmIHR5cGVvZiBwcm9wZXJ0eSAhPT0gJ3N5bWJvbCcpIHtcblx0XHR0aHJvdyBuZXcgJFR5cGVFcnJvcignYHByb3BlcnR5YCBtdXN0IGJlIGEgc3RyaW5nIG9yIGEgc3ltYm9sYCcpO1xuXHR9XG5cdGlmIChhcmd1bWVudHMubGVuZ3RoID4gMyAmJiB0eXBlb2YgYXJndW1lbnRzWzNdICE9PSAnYm9vbGVhbicgJiYgYXJndW1lbnRzWzNdICE9PSBudWxsKSB7XG5cdFx0dGhyb3cgbmV3ICRUeXBlRXJyb3IoJ2Bub25FbnVtZXJhYmxlYCwgaWYgcHJvdmlkZWQsIG11c3QgYmUgYSBib29sZWFuIG9yIG51bGwnKTtcblx0fVxuXHRpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDQgJiYgdHlwZW9mIGFyZ3VtZW50c1s0XSAhPT0gJ2Jvb2xlYW4nICYmIGFyZ3VtZW50c1s0XSAhPT0gbnVsbCkge1xuXHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdgbm9uV3JpdGFibGVgLCBpZiBwcm92aWRlZCwgbXVzdCBiZSBhIGJvb2xlYW4gb3IgbnVsbCcpO1xuXHR9XG5cdGlmIChhcmd1bWVudHMubGVuZ3RoID4gNSAmJiB0eXBlb2YgYXJndW1lbnRzWzVdICE9PSAnYm9vbGVhbicgJiYgYXJndW1lbnRzWzVdICE9PSBudWxsKSB7XG5cdFx0dGhyb3cgbmV3ICRUeXBlRXJyb3IoJ2Bub25Db25maWd1cmFibGVgLCBpZiBwcm92aWRlZCwgbXVzdCBiZSBhIGJvb2xlYW4gb3IgbnVsbCcpO1xuXHR9XG5cdGlmIChhcmd1bWVudHMubGVuZ3RoID4gNiAmJiB0eXBlb2YgYXJndW1lbnRzWzZdICE9PSAnYm9vbGVhbicpIHtcblx0XHR0aHJvdyBuZXcgJFR5cGVFcnJvcignYGxvb3NlYCwgaWYgcHJvdmlkZWQsIG11c3QgYmUgYSBib29sZWFuJyk7XG5cdH1cblxuXHR2YXIgbm9uRW51bWVyYWJsZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAzID8gYXJndW1lbnRzWzNdIDogbnVsbDtcblx0dmFyIG5vbldyaXRhYmxlID0gYXJndW1lbnRzLmxlbmd0aCA+IDQgPyBhcmd1bWVudHNbNF0gOiBudWxsO1xuXHR2YXIgbm9uQ29uZmlndXJhYmxlID0gYXJndW1lbnRzLmxlbmd0aCA+IDUgPyBhcmd1bWVudHNbNV0gOiBudWxsO1xuXHR2YXIgbG9vc2UgPSBhcmd1bWVudHMubGVuZ3RoID4gNiA/IGFyZ3VtZW50c1s2XSA6IGZhbHNlO1xuXG5cdC8qIEB0eXBlIHtmYWxzZSB8IFR5cGVkUHJvcGVydHlEZXNjcmlwdG9yPHVua25vd24+fSAqL1xuXHR2YXIgZGVzYyA9ICEhZ29wZCAmJiBnb3BkKG9iaiwgcHJvcGVydHkpO1xuXG5cdGlmICgkZGVmaW5lUHJvcGVydHkpIHtcblx0XHQkZGVmaW5lUHJvcGVydHkob2JqLCBwcm9wZXJ0eSwge1xuXHRcdFx0Y29uZmlndXJhYmxlOiBub25Db25maWd1cmFibGUgPT09IG51bGwgJiYgZGVzYyA/IGRlc2MuY29uZmlndXJhYmxlIDogIW5vbkNvbmZpZ3VyYWJsZSxcblx0XHRcdGVudW1lcmFibGU6IG5vbkVudW1lcmFibGUgPT09IG51bGwgJiYgZGVzYyA/IGRlc2MuZW51bWVyYWJsZSA6ICFub25FbnVtZXJhYmxlLFxuXHRcdFx0dmFsdWU6IHZhbHVlLFxuXHRcdFx0d3JpdGFibGU6IG5vbldyaXRhYmxlID09PSBudWxsICYmIGRlc2MgPyBkZXNjLndyaXRhYmxlIDogIW5vbldyaXRhYmxlXG5cdFx0fSk7XG5cdH0gZWxzZSBpZiAobG9vc2UgfHwgKCFub25FbnVtZXJhYmxlICYmICFub25Xcml0YWJsZSAmJiAhbm9uQ29uZmlndXJhYmxlKSkge1xuXHRcdC8vIG11c3QgZmFsbCBiYWNrIHRvIFtbU2V0XV0sIGFuZCB3YXMgbm90IGV4cGxpY2l0bHkgYXNrZWQgdG8gbWFrZSBub24tZW51bWVyYWJsZSwgbm9uLXdyaXRhYmxlLCBvciBub24tY29uZmlndXJhYmxlXG5cdFx0b2JqW3Byb3BlcnR5XSA9IHZhbHVlOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG5cdH0gZWxzZSB7XG5cdFx0dGhyb3cgbmV3ICRTeW50YXhFcnJvcignVGhpcyBlbnZpcm9ubWVudCBkb2VzIG5vdCBzdXBwb3J0IGRlZmluaW5nIGEgcHJvcGVydHkgYXMgbm9uLWNvbmZpZ3VyYWJsZSwgbm9uLXdyaXRhYmxlLCBvciBub24tZW51bWVyYWJsZS4nKTtcblx0fVxufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciAkZGVmaW5lUHJvcGVydHkgPSByZXF1aXJlKCdlcy1kZWZpbmUtcHJvcGVydHknKTtcblxudmFyIGhhc1Byb3BlcnR5RGVzY3JpcHRvcnMgPSBmdW5jdGlvbiBoYXNQcm9wZXJ0eURlc2NyaXB0b3JzKCkge1xuXHRyZXR1cm4gISEkZGVmaW5lUHJvcGVydHk7XG59O1xuXG5oYXNQcm9wZXJ0eURlc2NyaXB0b3JzLmhhc0FycmF5TGVuZ3RoRGVmaW5lQnVnID0gZnVuY3Rpb24gaGFzQXJyYXlMZW5ndGhEZWZpbmVCdWcoKSB7XG5cdC8vIG5vZGUgdjAuNiBoYXMgYSBidWcgd2hlcmUgYXJyYXkgbGVuZ3RocyBjYW4gYmUgU2V0IGJ1dCBub3QgRGVmaW5lZFxuXHRpZiAoISRkZWZpbmVQcm9wZXJ0eSkge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdHRyeSB7XG5cdFx0cmV0dXJuICRkZWZpbmVQcm9wZXJ0eShbXSwgJ2xlbmd0aCcsIHsgdmFsdWU6IDEgfSkubGVuZ3RoICE9PSAxO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0Ly8gSW4gRmlyZWZveCA0LTIyLCBkZWZpbmluZyBsZW5ndGggb24gYW4gYXJyYXkgdGhyb3dzIGFuIGV4Y2VwdGlvbi5cblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxufTtcblxubW9kdWxlLmV4cG9ydHMgPSBoYXNQcm9wZXJ0eURlc2NyaXB0b3JzO1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGtleXMgPSByZXF1aXJlKCdvYmplY3Qta2V5cycpO1xudmFyIGhhc1N5bWJvbHMgPSB0eXBlb2YgU3ltYm9sID09PSAnZnVuY3Rpb24nICYmIHR5cGVvZiBTeW1ib2woJ2ZvbycpID09PSAnc3ltYm9sJztcblxudmFyIHRvU3RyID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbnZhciBjb25jYXQgPSBBcnJheS5wcm90b3R5cGUuY29uY2F0O1xudmFyIGRlZmluZURhdGFQcm9wZXJ0eSA9IHJlcXVpcmUoJ2RlZmluZS1kYXRhLXByb3BlcnR5Jyk7XG5cbnZhciBpc0Z1bmN0aW9uID0gZnVuY3Rpb24gKGZuKSB7XG5cdHJldHVybiB0eXBlb2YgZm4gPT09ICdmdW5jdGlvbicgJiYgdG9TdHIuY2FsbChmbikgPT09ICdbb2JqZWN0IEZ1bmN0aW9uXSc7XG59O1xuXG52YXIgc3VwcG9ydHNEZXNjcmlwdG9ycyA9IHJlcXVpcmUoJ2hhcy1wcm9wZXJ0eS1kZXNjcmlwdG9ycycpKCk7XG5cbnZhciBkZWZpbmVQcm9wZXJ0eSA9IGZ1bmN0aW9uIChvYmplY3QsIG5hbWUsIHZhbHVlLCBwcmVkaWNhdGUpIHtcblx0aWYgKG5hbWUgaW4gb2JqZWN0KSB7XG5cdFx0aWYgKHByZWRpY2F0ZSA9PT0gdHJ1ZSkge1xuXHRcdFx0aWYgKG9iamVjdFtuYW1lXSA9PT0gdmFsdWUpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAoIWlzRnVuY3Rpb24ocHJlZGljYXRlKSB8fCAhcHJlZGljYXRlKCkpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdH1cblxuXHRpZiAoc3VwcG9ydHNEZXNjcmlwdG9ycykge1xuXHRcdGRlZmluZURhdGFQcm9wZXJ0eShvYmplY3QsIG5hbWUsIHZhbHVlLCB0cnVlKTtcblx0fSBlbHNlIHtcblx0XHRkZWZpbmVEYXRhUHJvcGVydHkob2JqZWN0LCBuYW1lLCB2YWx1ZSk7XG5cdH1cbn07XG5cbnZhciBkZWZpbmVQcm9wZXJ0aWVzID0gZnVuY3Rpb24gKG9iamVjdCwgbWFwKSB7XG5cdHZhciBwcmVkaWNhdGVzID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgPyBhcmd1bWVudHNbMl0gOiB7fTtcblx0dmFyIHByb3BzID0ga2V5cyhtYXApO1xuXHRpZiAoaGFzU3ltYm9scykge1xuXHRcdHByb3BzID0gY29uY2F0LmNhbGwocHJvcHMsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMobWFwKSk7XG5cdH1cblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBwcm9wcy5sZW5ndGg7IGkgKz0gMSkge1xuXHRcdGRlZmluZVByb3BlcnR5KG9iamVjdCwgcHJvcHNbaV0sIG1hcFtwcm9wc1tpXV0sIHByZWRpY2F0ZXNbcHJvcHNbaV1dKTtcblx0fVxufTtcblxuZGVmaW5lUHJvcGVydGllcy5zdXBwb3J0c0Rlc2NyaXB0b3JzID0gISFzdXBwb3J0c0Rlc2NyaXB0b3JzO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGRlZmluZVByb3BlcnRpZXM7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgR2V0SW50cmluc2ljID0gcmVxdWlyZSgnZ2V0LWludHJpbnNpYycpO1xudmFyIGRlZmluZSA9IHJlcXVpcmUoJ2RlZmluZS1kYXRhLXByb3BlcnR5Jyk7XG52YXIgaGFzRGVzY3JpcHRvcnMgPSByZXF1aXJlKCdoYXMtcHJvcGVydHktZGVzY3JpcHRvcnMnKSgpO1xudmFyIGdPUEQgPSByZXF1aXJlKCdnb3BkJyk7XG5cbnZhciAkVHlwZUVycm9yID0gcmVxdWlyZSgnZXMtZXJyb3JzL3R5cGUnKTtcbnZhciAkZmxvb3IgPSBHZXRJbnRyaW5zaWMoJyVNYXRoLmZsb29yJScpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBzZXRGdW5jdGlvbkxlbmd0aChmbiwgbGVuZ3RoKSB7XG5cdGlmICh0eXBlb2YgZm4gIT09ICdmdW5jdGlvbicpIHtcblx0XHR0aHJvdyBuZXcgJFR5cGVFcnJvcignYGZuYCBpcyBub3QgYSBmdW5jdGlvbicpO1xuXHR9XG5cdGlmICh0eXBlb2YgbGVuZ3RoICE9PSAnbnVtYmVyJyB8fCBsZW5ndGggPCAwIHx8IGxlbmd0aCA+IDB4RkZGRkZGRkYgfHwgJGZsb29yKGxlbmd0aCkgIT09IGxlbmd0aCkge1xuXHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdgbGVuZ3RoYCBtdXN0IGJlIGEgcG9zaXRpdmUgMzItYml0IGludGVnZXInKTtcblx0fVxuXG5cdHZhciBsb29zZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmICEhYXJndW1lbnRzWzJdO1xuXG5cdHZhciBmdW5jdGlvbkxlbmd0aElzQ29uZmlndXJhYmxlID0gdHJ1ZTtcblx0dmFyIGZ1bmN0aW9uTGVuZ3RoSXNXcml0YWJsZSA9IHRydWU7XG5cdGlmICgnbGVuZ3RoJyBpbiBmbiAmJiBnT1BEKSB7XG5cdFx0dmFyIGRlc2MgPSBnT1BEKGZuLCAnbGVuZ3RoJyk7XG5cdFx0aWYgKGRlc2MgJiYgIWRlc2MuY29uZmlndXJhYmxlKSB7XG5cdFx0XHRmdW5jdGlvbkxlbmd0aElzQ29uZmlndXJhYmxlID0gZmFsc2U7XG5cdFx0fVxuXHRcdGlmIChkZXNjICYmICFkZXNjLndyaXRhYmxlKSB7XG5cdFx0XHRmdW5jdGlvbkxlbmd0aElzV3JpdGFibGUgPSBmYWxzZTtcblx0XHR9XG5cdH1cblxuXHRpZiAoZnVuY3Rpb25MZW5ndGhJc0NvbmZpZ3VyYWJsZSB8fCBmdW5jdGlvbkxlbmd0aElzV3JpdGFibGUgfHwgIWxvb3NlKSB7XG5cdFx0aWYgKGhhc0Rlc2NyaXB0b3JzKSB7XG5cdFx0XHRkZWZpbmUoLyoqIEB0eXBlIHtQYXJhbWV0ZXJzPGRlZmluZT5bMF19ICovIChmbiksICdsZW5ndGgnLCBsZW5ndGgsIHRydWUsIHRydWUpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRkZWZpbmUoLyoqIEB0eXBlIHtQYXJhbWV0ZXJzPGRlZmluZT5bMF19ICovIChmbiksICdsZW5ndGgnLCBsZW5ndGgpO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gZm47XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGJpbmQgPSByZXF1aXJlKCdmdW5jdGlvbi1iaW5kJyk7XG52YXIgR2V0SW50cmluc2ljID0gcmVxdWlyZSgnZ2V0LWludHJpbnNpYycpO1xudmFyIHNldEZ1bmN0aW9uTGVuZ3RoID0gcmVxdWlyZSgnc2V0LWZ1bmN0aW9uLWxlbmd0aCcpO1xuXG52YXIgJFR5cGVFcnJvciA9IHJlcXVpcmUoJ2VzLWVycm9ycy90eXBlJyk7XG52YXIgJGFwcGx5ID0gR2V0SW50cmluc2ljKCclRnVuY3Rpb24ucHJvdG90eXBlLmFwcGx5JScpO1xudmFyICRjYWxsID0gR2V0SW50cmluc2ljKCclRnVuY3Rpb24ucHJvdG90eXBlLmNhbGwlJyk7XG52YXIgJHJlZmxlY3RBcHBseSA9IEdldEludHJpbnNpYygnJVJlZmxlY3QuYXBwbHklJywgdHJ1ZSkgfHwgYmluZC5jYWxsKCRjYWxsLCAkYXBwbHkpO1xuXG52YXIgJGRlZmluZVByb3BlcnR5ID0gcmVxdWlyZSgnZXMtZGVmaW5lLXByb3BlcnR5Jyk7XG52YXIgJG1heCA9IEdldEludHJpbnNpYygnJU1hdGgubWF4JScpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGNhbGxCaW5kKG9yaWdpbmFsRnVuY3Rpb24pIHtcblx0aWYgKHR5cGVvZiBvcmlnaW5hbEZ1bmN0aW9uICE9PSAnZnVuY3Rpb24nKSB7XG5cdFx0dGhyb3cgbmV3ICRUeXBlRXJyb3IoJ2EgZnVuY3Rpb24gaXMgcmVxdWlyZWQnKTtcblx0fVxuXHR2YXIgZnVuYyA9ICRyZWZsZWN0QXBwbHkoYmluZCwgJGNhbGwsIGFyZ3VtZW50cyk7XG5cdHJldHVybiBzZXRGdW5jdGlvbkxlbmd0aChcblx0XHRmdW5jLFxuXHRcdDEgKyAkbWF4KDAsIG9yaWdpbmFsRnVuY3Rpb24ubGVuZ3RoIC0gKGFyZ3VtZW50cy5sZW5ndGggLSAxKSksXG5cdFx0dHJ1ZVxuXHQpO1xufTtcblxudmFyIGFwcGx5QmluZCA9IGZ1bmN0aW9uIGFwcGx5QmluZCgpIHtcblx0cmV0dXJuICRyZWZsZWN0QXBwbHkoYmluZCwgJGFwcGx5LCBhcmd1bWVudHMpO1xufTtcblxuaWYgKCRkZWZpbmVQcm9wZXJ0eSkge1xuXHQkZGVmaW5lUHJvcGVydHkobW9kdWxlLmV4cG9ydHMsICdhcHBseScsIHsgdmFsdWU6IGFwcGx5QmluZCB9KTtcbn0gZWxzZSB7XG5cdG1vZHVsZS5leHBvcnRzLmFwcGx5ID0gYXBwbHlCaW5kO1xufVxuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIEdldEludHJpbnNpYyA9IHJlcXVpcmUoJ2dldC1pbnRyaW5zaWMnKTtcblxudmFyIGNhbGxCaW5kID0gcmVxdWlyZSgnLi8nKTtcblxudmFyICRpbmRleE9mID0gY2FsbEJpbmQoR2V0SW50cmluc2ljKCdTdHJpbmcucHJvdG90eXBlLmluZGV4T2YnKSk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gY2FsbEJvdW5kSW50cmluc2ljKG5hbWUsIGFsbG93TWlzc2luZykge1xuXHR2YXIgaW50cmluc2ljID0gR2V0SW50cmluc2ljKG5hbWUsICEhYWxsb3dNaXNzaW5nKTtcblx0aWYgKHR5cGVvZiBpbnRyaW5zaWMgPT09ICdmdW5jdGlvbicgJiYgJGluZGV4T2YobmFtZSwgJy5wcm90b3R5cGUuJykgPiAtMSkge1xuXHRcdHJldHVybiBjYWxsQmluZChpbnRyaW5zaWMpO1xuXHR9XG5cdHJldHVybiBpbnRyaW5zaWM7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxuLy8gbW9kaWZpZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vZXMtc2hpbXMvZXM2LXNoaW1cbnZhciBvYmplY3RLZXlzID0gcmVxdWlyZSgnb2JqZWN0LWtleXMnKTtcbnZhciBoYXNTeW1ib2xzID0gcmVxdWlyZSgnaGFzLXN5bWJvbHMvc2hhbXMnKSgpO1xudmFyIGNhbGxCb3VuZCA9IHJlcXVpcmUoJ2NhbGwtYmluZC9jYWxsQm91bmQnKTtcbnZhciB0b09iamVjdCA9IE9iamVjdDtcbnZhciAkcHVzaCA9IGNhbGxCb3VuZCgnQXJyYXkucHJvdG90eXBlLnB1c2gnKTtcbnZhciAkcHJvcElzRW51bWVyYWJsZSA9IGNhbGxCb3VuZCgnT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZScpO1xudmFyIG9yaWdpbmFsR2V0U3ltYm9scyA9IGhhc1N5bWJvbHMgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzIDogbnVsbDtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVudXNlZC12YXJzXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGFzc2lnbih0YXJnZXQsIHNvdXJjZTEpIHtcblx0aWYgKHRhcmdldCA9PSBudWxsKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoJ3RhcmdldCBtdXN0IGJlIGFuIG9iamVjdCcpOyB9XG5cdHZhciB0byA9IHRvT2JqZWN0KHRhcmdldCk7IC8vIHN0ZXAgMVxuXHRpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMSkge1xuXHRcdHJldHVybiB0bzsgLy8gc3RlcCAyXG5cdH1cblx0Zm9yICh2YXIgcyA9IDE7IHMgPCBhcmd1bWVudHMubGVuZ3RoOyArK3MpIHtcblx0XHR2YXIgZnJvbSA9IHRvT2JqZWN0KGFyZ3VtZW50c1tzXSk7IC8vIHN0ZXAgMy5hLmlcblxuXHRcdC8vIHN0ZXAgMy5hLmlpOlxuXHRcdHZhciBrZXlzID0gb2JqZWN0S2V5cyhmcm9tKTtcblx0XHR2YXIgZ2V0U3ltYm9scyA9IGhhc1N5bWJvbHMgJiYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgfHwgb3JpZ2luYWxHZXRTeW1ib2xzKTtcblx0XHRpZiAoZ2V0U3ltYm9scykge1xuXHRcdFx0dmFyIHN5bXMgPSBnZXRTeW1ib2xzKGZyb20pO1xuXHRcdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBzeW1zLmxlbmd0aDsgKytqKSB7XG5cdFx0XHRcdHZhciBrZXkgPSBzeW1zW2pdO1xuXHRcdFx0XHRpZiAoJHByb3BJc0VudW1lcmFibGUoZnJvbSwga2V5KSkge1xuXHRcdFx0XHRcdCRwdXNoKGtleXMsIGtleSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBzdGVwIDMuYS5paWk6XG5cdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgKytpKSB7XG5cdFx0XHR2YXIgbmV4dEtleSA9IGtleXNbaV07XG5cdFx0XHRpZiAoJHByb3BJc0VudW1lcmFibGUoZnJvbSwgbmV4dEtleSkpIHsgLy8gc3RlcCAzLmEuaWlpLjJcblx0XHRcdFx0dmFyIHByb3BWYWx1ZSA9IGZyb21bbmV4dEtleV07IC8vIHN0ZXAgMy5hLmlpaS4yLmFcblx0XHRcdFx0dG9bbmV4dEtleV0gPSBwcm9wVmFsdWU7IC8vIHN0ZXAgMy5hLmlpaS4yLmJcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gdG87IC8vIHN0ZXAgNFxufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBpbXBsZW1lbnRhdGlvbiA9IHJlcXVpcmUoJy4vaW1wbGVtZW50YXRpb24nKTtcblxudmFyIGxhY2tzUHJvcGVyRW51bWVyYXRpb25PcmRlciA9IGZ1bmN0aW9uICgpIHtcblx0aWYgKCFPYmplY3QuYXNzaWduKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdC8qXG5cdCAqIHY4LCBzcGVjaWZpY2FsbHkgaW4gbm9kZSA0LngsIGhhcyBhIGJ1ZyB3aXRoIGluY29ycmVjdCBwcm9wZXJ0eSBlbnVtZXJhdGlvbiBvcmRlclxuXHQgKiBub3RlOiB0aGlzIGRvZXMgbm90IGRldGVjdCB0aGUgYnVnIHVubGVzcyB0aGVyZSdzIDIwIGNoYXJhY3RlcnNcblx0ICovXG5cdHZhciBzdHIgPSAnYWJjZGVmZ2hpamtsbW5vcHFyc3QnO1xuXHR2YXIgbGV0dGVycyA9IHN0ci5zcGxpdCgnJyk7XG5cdHZhciBtYXAgPSB7fTtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBsZXR0ZXJzLmxlbmd0aDsgKytpKSB7XG5cdFx0bWFwW2xldHRlcnNbaV1dID0gbGV0dGVyc1tpXTtcblx0fVxuXHR2YXIgb2JqID0gT2JqZWN0LmFzc2lnbih7fSwgbWFwKTtcblx0dmFyIGFjdHVhbCA9ICcnO1xuXHRmb3IgKHZhciBrIGluIG9iaikge1xuXHRcdGFjdHVhbCArPSBrO1xuXHR9XG5cdHJldHVybiBzdHIgIT09IGFjdHVhbDtcbn07XG5cbnZhciBhc3NpZ25IYXNQZW5kaW5nRXhjZXB0aW9ucyA9IGZ1bmN0aW9uICgpIHtcblx0aWYgKCFPYmplY3QuYXNzaWduIHx8ICFPYmplY3QucHJldmVudEV4dGVuc2lvbnMpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0Lypcblx0ICogRmlyZWZveCAzNyBzdGlsbCBoYXMgXCJwZW5kaW5nIGV4Y2VwdGlvblwiIGxvZ2ljIGluIGl0cyBPYmplY3QuYXNzaWduIGltcGxlbWVudGF0aW9uLFxuXHQgKiB3aGljaCBpcyA3MiUgc2xvd2VyIHRoYW4gb3VyIHNoaW0sIGFuZCBGaXJlZm94IDQwJ3MgbmF0aXZlIGltcGxlbWVudGF0aW9uLlxuXHQgKi9cblx0dmFyIHRocm93ZXIgPSBPYmplY3QucHJldmVudEV4dGVuc2lvbnMoeyAxOiAyIH0pO1xuXHR0cnkge1xuXHRcdE9iamVjdC5hc3NpZ24odGhyb3dlciwgJ3h5Jyk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRyZXR1cm4gdGhyb3dlclsxXSA9PT0gJ3knO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZ2V0UG9seWZpbGwoKSB7XG5cdGlmICghT2JqZWN0LmFzc2lnbikge1xuXHRcdHJldHVybiBpbXBsZW1lbnRhdGlvbjtcblx0fVxuXHRpZiAobGFja3NQcm9wZXJFbnVtZXJhdGlvbk9yZGVyKCkpIHtcblx0XHRyZXR1cm4gaW1wbGVtZW50YXRpb247XG5cdH1cblx0aWYgKGFzc2lnbkhhc1BlbmRpbmdFeGNlcHRpb25zKCkpIHtcblx0XHRyZXR1cm4gaW1wbGVtZW50YXRpb247XG5cdH1cblx0cmV0dXJuIE9iamVjdC5hc3NpZ247XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGRlZmluZSA9IHJlcXVpcmUoJ2RlZmluZS1wcm9wZXJ0aWVzJyk7XG52YXIgZ2V0UG9seWZpbGwgPSByZXF1aXJlKCcuL3BvbHlmaWxsJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gc2hpbUFzc2lnbigpIHtcblx0dmFyIHBvbHlmaWxsID0gZ2V0UG9seWZpbGwoKTtcblx0ZGVmaW5lKFxuXHRcdE9iamVjdCxcblx0XHR7IGFzc2lnbjogcG9seWZpbGwgfSxcblx0XHR7IGFzc2lnbjogZnVuY3Rpb24gKCkgeyByZXR1cm4gT2JqZWN0LmFzc2lnbiAhPT0gcG9seWZpbGw7IH0gfVxuXHQpO1xuXHRyZXR1cm4gcG9seWZpbGw7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGRlZmluZVByb3BlcnRpZXMgPSByZXF1aXJlKCdkZWZpbmUtcHJvcGVydGllcycpO1xudmFyIGNhbGxCaW5kID0gcmVxdWlyZSgnY2FsbC1iaW5kJyk7XG5cbnZhciBpbXBsZW1lbnRhdGlvbiA9IHJlcXVpcmUoJy4vaW1wbGVtZW50YXRpb24nKTtcbnZhciBnZXRQb2x5ZmlsbCA9IHJlcXVpcmUoJy4vcG9seWZpbGwnKTtcbnZhciBzaGltID0gcmVxdWlyZSgnLi9zaGltJyk7XG5cbnZhciBwb2x5ZmlsbCA9IGNhbGxCaW5kLmFwcGx5KGdldFBvbHlmaWxsKCkpO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVudXNlZC12YXJzXG52YXIgYm91bmQgPSBmdW5jdGlvbiBhc3NpZ24odGFyZ2V0LCBzb3VyY2UxKSB7XG5cdHJldHVybiBwb2x5ZmlsbChPYmplY3QsIGFyZ3VtZW50cyk7XG59O1xuXG5kZWZpbmVQcm9wZXJ0aWVzKGJvdW5kLCB7XG5cdGdldFBvbHlmaWxsOiBnZXRQb2x5ZmlsbCxcblx0aW1wbGVtZW50YXRpb246IGltcGxlbWVudGF0aW9uLFxuXHRzaGltOiBzaGltXG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSBib3VuZDtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBmdW5jdGlvbnNIYXZlTmFtZXMgPSBmdW5jdGlvbiBmdW5jdGlvbnNIYXZlTmFtZXMoKSB7XG5cdHJldHVybiB0eXBlb2YgZnVuY3Rpb24gZigpIHt9Lm5hbWUgPT09ICdzdHJpbmcnO1xufTtcblxudmFyIGdPUEQgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuaWYgKGdPUEQpIHtcblx0dHJ5IHtcblx0XHRnT1BEKFtdLCAnbGVuZ3RoJyk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHQvLyBJRSA4IGhhcyBhIGJyb2tlbiBnT1BEXG5cdFx0Z09QRCA9IG51bGw7XG5cdH1cbn1cblxuZnVuY3Rpb25zSGF2ZU5hbWVzLmZ1bmN0aW9uc0hhdmVDb25maWd1cmFibGVOYW1lcyA9IGZ1bmN0aW9uIGZ1bmN0aW9uc0hhdmVDb25maWd1cmFibGVOYW1lcygpIHtcblx0aWYgKCFmdW5jdGlvbnNIYXZlTmFtZXMoKSB8fCAhZ09QRCkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHR2YXIgZGVzYyA9IGdPUEQoZnVuY3Rpb24gKCkge30sICduYW1lJyk7XG5cdHJldHVybiAhIWRlc2MgJiYgISFkZXNjLmNvbmZpZ3VyYWJsZTtcbn07XG5cbnZhciAkYmluZCA9IEZ1bmN0aW9uLnByb3RvdHlwZS5iaW5kO1xuXG5mdW5jdGlvbnNIYXZlTmFtZXMuYm91bmRGdW5jdGlvbnNIYXZlTmFtZXMgPSBmdW5jdGlvbiBib3VuZEZ1bmN0aW9uc0hhdmVOYW1lcygpIHtcblx0cmV0dXJuIGZ1bmN0aW9uc0hhdmVOYW1lcygpICYmIHR5cGVvZiAkYmluZCA9PT0gJ2Z1bmN0aW9uJyAmJiBmdW5jdGlvbiBmKCkge30uYmluZCgpLm5hbWUgIT09ICcnO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbnNIYXZlTmFtZXM7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgZGVmaW5lID0gcmVxdWlyZSgnZGVmaW5lLWRhdGEtcHJvcGVydHknKTtcbnZhciBoYXNEZXNjcmlwdG9ycyA9IHJlcXVpcmUoJ2hhcy1wcm9wZXJ0eS1kZXNjcmlwdG9ycycpKCk7XG52YXIgZnVuY3Rpb25zSGF2ZUNvbmZpZ3VyYWJsZU5hbWVzID0gcmVxdWlyZSgnZnVuY3Rpb25zLWhhdmUtbmFtZXMnKS5mdW5jdGlvbnNIYXZlQ29uZmlndXJhYmxlTmFtZXMoKTtcblxudmFyICRUeXBlRXJyb3IgPSByZXF1aXJlKCdlcy1lcnJvcnMvdHlwZScpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBzZXRGdW5jdGlvbk5hbWUoZm4sIG5hbWUpIHtcblx0aWYgKHR5cGVvZiBmbiAhPT0gJ2Z1bmN0aW9uJykge1xuXHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdgZm5gIGlzIG5vdCBhIGZ1bmN0aW9uJyk7XG5cdH1cblx0dmFyIGxvb3NlID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgISFhcmd1bWVudHNbMl07XG5cdGlmICghbG9vc2UgfHwgZnVuY3Rpb25zSGF2ZUNvbmZpZ3VyYWJsZU5hbWVzKSB7XG5cdFx0aWYgKGhhc0Rlc2NyaXB0b3JzKSB7XG5cdFx0XHRkZWZpbmUoLyoqIEB0eXBlIHtQYXJhbWV0ZXJzPGRlZmluZT5bMF19ICovIChmbiksICduYW1lJywgbmFtZSwgdHJ1ZSwgdHJ1ZSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdGRlZmluZSgvKiogQHR5cGUge1BhcmFtZXRlcnM8ZGVmaW5lPlswXX0gKi8gKGZuKSwgJ25hbWUnLCBuYW1lKTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIGZuO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBzZXRGdW5jdGlvbk5hbWUgPSByZXF1aXJlKCdzZXQtZnVuY3Rpb24tbmFtZScpO1xudmFyICRUeXBlRXJyb3IgPSByZXF1aXJlKCdlcy1lcnJvcnMvdHlwZScpO1xuXG52YXIgJE9iamVjdCA9IE9iamVjdDtcblxubW9kdWxlLmV4cG9ydHMgPSBzZXRGdW5jdGlvbk5hbWUoZnVuY3Rpb24gZmxhZ3MoKSB7XG5cdGlmICh0aGlzID09IG51bGwgfHwgdGhpcyAhPT0gJE9iamVjdCh0aGlzKSkge1xuXHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdSZWdFeHAucHJvdG90eXBlLmZsYWdzIGdldHRlciBjYWxsZWQgb24gbm9uLW9iamVjdCcpO1xuXHR9XG5cdHZhciByZXN1bHQgPSAnJztcblx0aWYgKHRoaXMuaGFzSW5kaWNlcykge1xuXHRcdHJlc3VsdCArPSAnZCc7XG5cdH1cblx0aWYgKHRoaXMuZ2xvYmFsKSB7XG5cdFx0cmVzdWx0ICs9ICdnJztcblx0fVxuXHRpZiAodGhpcy5pZ25vcmVDYXNlKSB7XG5cdFx0cmVzdWx0ICs9ICdpJztcblx0fVxuXHRpZiAodGhpcy5tdWx0aWxpbmUpIHtcblx0XHRyZXN1bHQgKz0gJ20nO1xuXHR9XG5cdGlmICh0aGlzLmRvdEFsbCkge1xuXHRcdHJlc3VsdCArPSAncyc7XG5cdH1cblx0aWYgKHRoaXMudW5pY29kZSkge1xuXHRcdHJlc3VsdCArPSAndSc7XG5cdH1cblx0aWYgKHRoaXMudW5pY29kZVNldHMpIHtcblx0XHRyZXN1bHQgKz0gJ3YnO1xuXHR9XG5cdGlmICh0aGlzLnN0aWNreSkge1xuXHRcdHJlc3VsdCArPSAneSc7XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn0sICdnZXQgZmxhZ3MnLCB0cnVlKTtcblxuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGltcGxlbWVudGF0aW9uID0gcmVxdWlyZSgnLi9pbXBsZW1lbnRhdGlvbicpO1xuXG52YXIgc3VwcG9ydHNEZXNjcmlwdG9ycyA9IHJlcXVpcmUoJ2RlZmluZS1wcm9wZXJ0aWVzJykuc3VwcG9ydHNEZXNjcmlwdG9ycztcbnZhciAkZ09QRCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZ2V0UG9seWZpbGwoKSB7XG5cdGlmIChzdXBwb3J0c0Rlc2NyaXB0b3JzICYmICgvYS9taWcpLmZsYWdzID09PSAnZ2ltJykge1xuXHRcdHZhciBkZXNjcmlwdG9yID0gJGdPUEQoUmVnRXhwLnByb3RvdHlwZSwgJ2ZsYWdzJyk7XG5cdFx0aWYgKFxuXHRcdFx0ZGVzY3JpcHRvclxuXHRcdFx0JiYgdHlwZW9mIGRlc2NyaXB0b3IuZ2V0ID09PSAnZnVuY3Rpb24nXG5cdFx0XHQmJiAnZG90QWxsJyBpbiBSZWdFeHAucHJvdG90eXBlXG5cdFx0XHQmJiAnaGFzSW5kaWNlcycgaW4gUmVnRXhwLnByb3RvdHlwZVxuXHRcdCkge1xuXHRcdFx0LyogZXNsaW50IGdldHRlci1yZXR1cm46IDAgKi9cblx0XHRcdHZhciBjYWxscyA9ICcnO1xuXHRcdFx0dmFyIG8gPSB7fTtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCAnaGFzSW5kaWNlcycsIHtcblx0XHRcdFx0Z2V0OiBmdW5jdGlvbiAoKSB7XG5cdFx0XHRcdFx0Y2FsbHMgKz0gJ2QnO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCAnc3RpY2t5Jywge1xuXHRcdFx0XHRnZXQ6IGZ1bmN0aW9uICgpIHtcblx0XHRcdFx0XHRjYWxscyArPSAneSc7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXG5cdFx0XHRkZXNjcmlwdG9yLmdldC5jYWxsKG8pO1xuXG5cdFx0XHRpZiAoY2FsbHMgPT09ICdkeScpIHtcblx0XHRcdFx0cmV0dXJuIGRlc2NyaXB0b3IuZ2V0O1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRyZXR1cm4gaW1wbGVtZW50YXRpb247XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIHN1cHBvcnRzRGVzY3JpcHRvcnMgPSByZXF1aXJlKCdkZWZpbmUtcHJvcGVydGllcycpLnN1cHBvcnRzRGVzY3JpcHRvcnM7XG52YXIgZ2V0UG9seWZpbGwgPSByZXF1aXJlKCcuL3BvbHlmaWxsJyk7XG52YXIgZ09QRCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgZGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgVHlwZUVyciA9IFR5cGVFcnJvcjtcbnZhciBnZXRQcm90byA9IE9iamVjdC5nZXRQcm90b3R5cGVPZjtcbnZhciByZWdleCA9IC9hLztcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBzaGltRmxhZ3MoKSB7XG5cdGlmICghc3VwcG9ydHNEZXNjcmlwdG9ycyB8fCAhZ2V0UHJvdG8pIHtcblx0XHR0aHJvdyBuZXcgVHlwZUVycignUmVnRXhwLnByb3RvdHlwZS5mbGFncyByZXF1aXJlcyBhIHRydWUgRVM1IGVudmlyb25tZW50IHRoYXQgc3VwcG9ydHMgcHJvcGVydHkgZGVzY3JpcHRvcnMnKTtcblx0fVxuXHR2YXIgcG9seWZpbGwgPSBnZXRQb2x5ZmlsbCgpO1xuXHR2YXIgcHJvdG8gPSBnZXRQcm90byhyZWdleCk7XG5cdHZhciBkZXNjcmlwdG9yID0gZ09QRChwcm90bywgJ2ZsYWdzJyk7XG5cdGlmICghZGVzY3JpcHRvciB8fCBkZXNjcmlwdG9yLmdldCAhPT0gcG9seWZpbGwpIHtcblx0XHRkZWZpbmVQcm9wZXJ0eShwcm90bywgJ2ZsYWdzJywge1xuXHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdFx0ZW51bWVyYWJsZTogZmFsc2UsXG5cdFx0XHRnZXQ6IHBvbHlmaWxsXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHBvbHlmaWxsO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBkZWZpbmUgPSByZXF1aXJlKCdkZWZpbmUtcHJvcGVydGllcycpO1xudmFyIGNhbGxCaW5kID0gcmVxdWlyZSgnY2FsbC1iaW5kJyk7XG5cbnZhciBpbXBsZW1lbnRhdGlvbiA9IHJlcXVpcmUoJy4vaW1wbGVtZW50YXRpb24nKTtcbnZhciBnZXRQb2x5ZmlsbCA9IHJlcXVpcmUoJy4vcG9seWZpbGwnKTtcbnZhciBzaGltID0gcmVxdWlyZSgnLi9zaGltJyk7XG5cbnZhciBmbGFnc0JvdW5kID0gY2FsbEJpbmQoZ2V0UG9seWZpbGwoKSk7XG5cbmRlZmluZShmbGFnc0JvdW5kLCB7XG5cdGdldFBvbHlmaWxsOiBnZXRQb2x5ZmlsbCxcblx0aW1wbGVtZW50YXRpb246IGltcGxlbWVudGF0aW9uLFxuXHRzaGltOiBzaGltXG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSBmbGFnc0JvdW5kO1xuIiwgIid1c2Ugc3RyaWN0JztcblxuLy8gdGhpcyBzaG91bGQgb25seSBydW4gaW4gbm9kZSA+PSAxMy4yLCBzbyBpdFxuLy8gZG9lcyBub3QgbmVlZCBhbnkgb2YgdGhlIGludGVuc2UgZmFsbGJhY2tzIHRoYXQgb2xkIG5vZGUvYnJvd3NlcnMgZG9cblxudmFyICRpdGVyYXRvciA9IFN5bWJvbC5pdGVyYXRvcjtcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZ2V0SXRlcmF0b3IoaXRlcmFibGUpIHtcblx0Ly8gYWx0ZXJuYXRpdmVseSwgYGl0ZXJhYmxlWyRpdGVyYXRvcl0/LigpYFxuXHRpZiAoaXRlcmFibGUgIT0gbnVsbCAmJiB0eXBlb2YgaXRlcmFibGVbJGl0ZXJhdG9yXSAhPT0gJ3VuZGVmaW5lZCcpIHtcblx0XHRyZXR1cm4gaXRlcmFibGVbJGl0ZXJhdG9yXSgpO1xuXHR9XG59O1xuIiwgIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgndXRpbCcpLmluc3BlY3Q7XG4iLCAidmFyIGhhc01hcCA9IHR5cGVvZiBNYXAgPT09ICdmdW5jdGlvbicgJiYgTWFwLnByb3RvdHlwZTtcbnZhciBtYXBTaXplRGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgJiYgaGFzTWFwID8gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihNYXAucHJvdG90eXBlLCAnc2l6ZScpIDogbnVsbDtcbnZhciBtYXBTaXplID0gaGFzTWFwICYmIG1hcFNpemVEZXNjcmlwdG9yICYmIHR5cGVvZiBtYXBTaXplRGVzY3JpcHRvci5nZXQgPT09ICdmdW5jdGlvbicgPyBtYXBTaXplRGVzY3JpcHRvci5nZXQgOiBudWxsO1xudmFyIG1hcEZvckVhY2ggPSBoYXNNYXAgJiYgTWFwLnByb3RvdHlwZS5mb3JFYWNoO1xudmFyIGhhc1NldCA9IHR5cGVvZiBTZXQgPT09ICdmdW5jdGlvbicgJiYgU2V0LnByb3RvdHlwZTtcbnZhciBzZXRTaXplRGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgJiYgaGFzU2V0ID8gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihTZXQucHJvdG90eXBlLCAnc2l6ZScpIDogbnVsbDtcbnZhciBzZXRTaXplID0gaGFzU2V0ICYmIHNldFNpemVEZXNjcmlwdG9yICYmIHR5cGVvZiBzZXRTaXplRGVzY3JpcHRvci5nZXQgPT09ICdmdW5jdGlvbicgPyBzZXRTaXplRGVzY3JpcHRvci5nZXQgOiBudWxsO1xudmFyIHNldEZvckVhY2ggPSBoYXNTZXQgJiYgU2V0LnByb3RvdHlwZS5mb3JFYWNoO1xudmFyIGhhc1dlYWtNYXAgPSB0eXBlb2YgV2Vha01hcCA9PT0gJ2Z1bmN0aW9uJyAmJiBXZWFrTWFwLnByb3RvdHlwZTtcbnZhciB3ZWFrTWFwSGFzID0gaGFzV2Vha01hcCA/IFdlYWtNYXAucHJvdG90eXBlLmhhcyA6IG51bGw7XG52YXIgaGFzV2Vha1NldCA9IHR5cGVvZiBXZWFrU2V0ID09PSAnZnVuY3Rpb24nICYmIFdlYWtTZXQucHJvdG90eXBlO1xudmFyIHdlYWtTZXRIYXMgPSBoYXNXZWFrU2V0ID8gV2Vha1NldC5wcm90b3R5cGUuaGFzIDogbnVsbDtcbnZhciBoYXNXZWFrUmVmID0gdHlwZW9mIFdlYWtSZWYgPT09ICdmdW5jdGlvbicgJiYgV2Vha1JlZi5wcm90b3R5cGU7XG52YXIgd2Vha1JlZkRlcmVmID0gaGFzV2Vha1JlZiA/IFdlYWtSZWYucHJvdG90eXBlLmRlcmVmIDogbnVsbDtcbnZhciBib29sZWFuVmFsdWVPZiA9IEJvb2xlYW4ucHJvdG90eXBlLnZhbHVlT2Y7XG52YXIgb2JqZWN0VG9TdHJpbmcgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xudmFyIGZ1bmN0aW9uVG9TdHJpbmcgPSBGdW5jdGlvbi5wcm90b3R5cGUudG9TdHJpbmc7XG52YXIgJG1hdGNoID0gU3RyaW5nLnByb3RvdHlwZS5tYXRjaDtcbnZhciAkc2xpY2UgPSBTdHJpbmcucHJvdG90eXBlLnNsaWNlO1xudmFyICRyZXBsYWNlID0gU3RyaW5nLnByb3RvdHlwZS5yZXBsYWNlO1xudmFyICR0b1VwcGVyQ2FzZSA9IFN0cmluZy5wcm90b3R5cGUudG9VcHBlckNhc2U7XG52YXIgJHRvTG93ZXJDYXNlID0gU3RyaW5nLnByb3RvdHlwZS50b0xvd2VyQ2FzZTtcbnZhciAkdGVzdCA9IFJlZ0V4cC5wcm90b3R5cGUudGVzdDtcbnZhciAkY29uY2F0ID0gQXJyYXkucHJvdG90eXBlLmNvbmNhdDtcbnZhciAkam9pbiA9IEFycmF5LnByb3RvdHlwZS5qb2luO1xudmFyICRhcnJTbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcbnZhciAkZmxvb3IgPSBNYXRoLmZsb29yO1xudmFyIGJpZ0ludFZhbHVlT2YgPSB0eXBlb2YgQmlnSW50ID09PSAnZnVuY3Rpb24nID8gQmlnSW50LnByb3RvdHlwZS52YWx1ZU9mIDogbnVsbDtcbnZhciBnT1BTID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scztcbnZhciBzeW1Ub1N0cmluZyA9IHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicgJiYgdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gJ3N5bWJvbCcgPyBTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nIDogbnVsbDtcbnZhciBoYXNTaGFtbWVkU3ltYm9scyA9IHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicgJiYgdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gJ29iamVjdCc7XG4vLyBpZSwgYGhhcy10b3N0cmluZ3RhZy9zaGFtc1xudmFyIHRvU3RyaW5nVGFnID0gdHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcgJiYgKHR5cGVvZiBTeW1ib2wudG9TdHJpbmdUYWcgPT09IGhhc1NoYW1tZWRTeW1ib2xzID8gJ29iamVjdCcgOiAnc3ltYm9sJylcbiAgICA/IFN5bWJvbC50b1N0cmluZ1RhZ1xuICAgIDogbnVsbDtcbnZhciBpc0VudW1lcmFibGUgPSBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlO1xuXG52YXIgZ1BPID0gKHR5cGVvZiBSZWZsZWN0ID09PSAnZnVuY3Rpb24nID8gUmVmbGVjdC5nZXRQcm90b3R5cGVPZiA6IE9iamVjdC5nZXRQcm90b3R5cGVPZikgfHwgKFxuICAgIFtdLl9fcHJvdG9fXyA9PT0gQXJyYXkucHJvdG90eXBlIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcHJvdG9cbiAgICAgICAgPyBmdW5jdGlvbiAoTykge1xuICAgICAgICAgICAgcmV0dXJuIE8uX19wcm90b19fOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXByb3RvXG4gICAgICAgIH1cbiAgICAgICAgOiBudWxsXG4pO1xuXG5mdW5jdGlvbiBhZGROdW1lcmljU2VwYXJhdG9yKG51bSwgc3RyKSB7XG4gICAgaWYgKFxuICAgICAgICBudW0gPT09IEluZmluaXR5XG4gICAgICAgIHx8IG51bSA9PT0gLUluZmluaXR5XG4gICAgICAgIHx8IG51bSAhPT0gbnVtXG4gICAgICAgIHx8IChudW0gJiYgbnVtID4gLTEwMDAgJiYgbnVtIDwgMTAwMClcbiAgICAgICAgfHwgJHRlc3QuY2FsbCgvZS8sIHN0cilcbiAgICApIHtcbiAgICAgICAgcmV0dXJuIHN0cjtcbiAgICB9XG4gICAgdmFyIHNlcFJlZ2V4ID0gL1swLTldKD89KD86WzAtOV17M30pKyg/IVswLTldKSkvZztcbiAgICBpZiAodHlwZW9mIG51bSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgdmFyIGludCA9IG51bSA8IDAgPyAtJGZsb29yKC1udW0pIDogJGZsb29yKG51bSk7IC8vIHRydW5jKG51bSlcbiAgICAgICAgaWYgKGludCAhPT0gbnVtKSB7XG4gICAgICAgICAgICB2YXIgaW50U3RyID0gU3RyaW5nKGludCk7XG4gICAgICAgICAgICB2YXIgZGVjID0gJHNsaWNlLmNhbGwoc3RyLCBpbnRTdHIubGVuZ3RoICsgMSk7XG4gICAgICAgICAgICByZXR1cm4gJHJlcGxhY2UuY2FsbChpbnRTdHIsIHNlcFJlZ2V4LCAnJCZfJykgKyAnLicgKyAkcmVwbGFjZS5jYWxsKCRyZXBsYWNlLmNhbGwoZGVjLCAvKFswLTldezN9KS9nLCAnJCZfJyksIC9fJC8sICcnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gJHJlcGxhY2UuY2FsbChzdHIsIHNlcFJlZ2V4LCAnJCZfJyk7XG59XG5cbnZhciB1dGlsSW5zcGVjdCA9IHJlcXVpcmUoJy4vdXRpbC5pbnNwZWN0Jyk7XG52YXIgaW5zcGVjdEN1c3RvbSA9IHV0aWxJbnNwZWN0LmN1c3RvbTtcbnZhciBpbnNwZWN0U3ltYm9sID0gaXNTeW1ib2woaW5zcGVjdEN1c3RvbSkgPyBpbnNwZWN0Q3VzdG9tIDogbnVsbDtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbnNwZWN0XyhvYmosIG9wdGlvbnMsIGRlcHRoLCBzZWVuKSB7XG4gICAgdmFyIG9wdHMgPSBvcHRpb25zIHx8IHt9O1xuXG4gICAgaWYgKGhhcyhvcHRzLCAncXVvdGVTdHlsZScpICYmIChvcHRzLnF1b3RlU3R5bGUgIT09ICdzaW5nbGUnICYmIG9wdHMucXVvdGVTdHlsZSAhPT0gJ2RvdWJsZScpKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ29wdGlvbiBcInF1b3RlU3R5bGVcIiBtdXN0IGJlIFwic2luZ2xlXCIgb3IgXCJkb3VibGVcIicpO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICAgIGhhcyhvcHRzLCAnbWF4U3RyaW5nTGVuZ3RoJykgJiYgKHR5cGVvZiBvcHRzLm1heFN0cmluZ0xlbmd0aCA9PT0gJ251bWJlcidcbiAgICAgICAgICAgID8gb3B0cy5tYXhTdHJpbmdMZW5ndGggPCAwICYmIG9wdHMubWF4U3RyaW5nTGVuZ3RoICE9PSBJbmZpbml0eVxuICAgICAgICAgICAgOiBvcHRzLm1heFN0cmluZ0xlbmd0aCAhPT0gbnVsbFxuICAgICAgICApXG4gICAgKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ29wdGlvbiBcIm1heFN0cmluZ0xlbmd0aFwiLCBpZiBwcm92aWRlZCwgbXVzdCBiZSBhIHBvc2l0aXZlIGludGVnZXIsIEluZmluaXR5LCBvciBgbnVsbGAnKTtcbiAgICB9XG4gICAgdmFyIGN1c3RvbUluc3BlY3QgPSBoYXMob3B0cywgJ2N1c3RvbUluc3BlY3QnKSA/IG9wdHMuY3VzdG9tSW5zcGVjdCA6IHRydWU7XG4gICAgaWYgKHR5cGVvZiBjdXN0b21JbnNwZWN0ICE9PSAnYm9vbGVhbicgJiYgY3VzdG9tSW5zcGVjdCAhPT0gJ3N5bWJvbCcpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignb3B0aW9uIFwiY3VzdG9tSW5zcGVjdFwiLCBpZiBwcm92aWRlZCwgbXVzdCBiZSBgdHJ1ZWAsIGBmYWxzZWAsIG9yIGBcXCdzeW1ib2xcXCdgJyk7XG4gICAgfVxuXG4gICAgaWYgKFxuICAgICAgICBoYXMob3B0cywgJ2luZGVudCcpXG4gICAgICAgICYmIG9wdHMuaW5kZW50ICE9PSBudWxsXG4gICAgICAgICYmIG9wdHMuaW5kZW50ICE9PSAnXFx0J1xuICAgICAgICAmJiAhKHBhcnNlSW50KG9wdHMuaW5kZW50LCAxMCkgPT09IG9wdHMuaW5kZW50ICYmIG9wdHMuaW5kZW50ID4gMClcbiAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignb3B0aW9uIFwiaW5kZW50XCIgbXVzdCBiZSBcIlxcXFx0XCIsIGFuIGludGVnZXIgPiAwLCBvciBgbnVsbGAnKTtcbiAgICB9XG4gICAgaWYgKGhhcyhvcHRzLCAnbnVtZXJpY1NlcGFyYXRvcicpICYmIHR5cGVvZiBvcHRzLm51bWVyaWNTZXBhcmF0b3IgIT09ICdib29sZWFuJykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdvcHRpb24gXCJudW1lcmljU2VwYXJhdG9yXCIsIGlmIHByb3ZpZGVkLCBtdXN0IGJlIGB0cnVlYCBvciBgZmFsc2VgJyk7XG4gICAgfVxuICAgIHZhciBudW1lcmljU2VwYXJhdG9yID0gb3B0cy5udW1lcmljU2VwYXJhdG9yO1xuXG4gICAgaWYgKHR5cGVvZiBvYmogPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHJldHVybiAndW5kZWZpbmVkJztcbiAgICB9XG4gICAgaWYgKG9iaiA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gJ251bGwnO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG9iaiA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiBvYmogPyAndHJ1ZScgOiAnZmFsc2UnO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2Ygb2JqID09PSAnc3RyaW5nJykge1xuICAgICAgICByZXR1cm4gaW5zcGVjdFN0cmluZyhvYmosIG9wdHMpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG9iaiA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgaWYgKG9iaiA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIEluZmluaXR5IC8gb2JqID4gMCA/ICcwJyA6ICctMCc7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHN0ciA9IFN0cmluZyhvYmopO1xuICAgICAgICByZXR1cm4gbnVtZXJpY1NlcGFyYXRvciA/IGFkZE51bWVyaWNTZXBhcmF0b3Iob2JqLCBzdHIpIDogc3RyO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG9iaiA9PT0gJ2JpZ2ludCcpIHtcbiAgICAgICAgdmFyIGJpZ0ludFN0ciA9IFN0cmluZyhvYmopICsgJ24nO1xuICAgICAgICByZXR1cm4gbnVtZXJpY1NlcGFyYXRvciA/IGFkZE51bWVyaWNTZXBhcmF0b3Iob2JqLCBiaWdJbnRTdHIpIDogYmlnSW50U3RyO1xuICAgIH1cblxuICAgIHZhciBtYXhEZXB0aCA9IHR5cGVvZiBvcHRzLmRlcHRoID09PSAndW5kZWZpbmVkJyA/IDUgOiBvcHRzLmRlcHRoO1xuICAgIGlmICh0eXBlb2YgZGVwdGggPT09ICd1bmRlZmluZWQnKSB7IGRlcHRoID0gMDsgfVxuICAgIGlmIChkZXB0aCA+PSBtYXhEZXB0aCAmJiBtYXhEZXB0aCA+IDAgJiYgdHlwZW9mIG9iaiA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIGlzQXJyYXkob2JqKSA/ICdbQXJyYXldJyA6ICdbT2JqZWN0XSc7XG4gICAgfVxuXG4gICAgdmFyIGluZGVudCA9IGdldEluZGVudChvcHRzLCBkZXB0aCk7XG5cbiAgICBpZiAodHlwZW9mIHNlZW4gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHNlZW4gPSBbXTtcbiAgICB9IGVsc2UgaWYgKGluZGV4T2Yoc2Vlbiwgb2JqKSA+PSAwKSB7XG4gICAgICAgIHJldHVybiAnW0NpcmN1bGFyXSc7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gaW5zcGVjdCh2YWx1ZSwgZnJvbSwgbm9JbmRlbnQpIHtcbiAgICAgICAgaWYgKGZyb20pIHtcbiAgICAgICAgICAgIHNlZW4gPSAkYXJyU2xpY2UuY2FsbChzZWVuKTtcbiAgICAgICAgICAgIHNlZW4ucHVzaChmcm9tKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobm9JbmRlbnQpIHtcbiAgICAgICAgICAgIHZhciBuZXdPcHRzID0ge1xuICAgICAgICAgICAgICAgIGRlcHRoOiBvcHRzLmRlcHRoXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKGhhcyhvcHRzLCAncXVvdGVTdHlsZScpKSB7XG4gICAgICAgICAgICAgICAgbmV3T3B0cy5xdW90ZVN0eWxlID0gb3B0cy5xdW90ZVN0eWxlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGluc3BlY3RfKHZhbHVlLCBuZXdPcHRzLCBkZXB0aCArIDEsIHNlZW4pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpbnNwZWN0Xyh2YWx1ZSwgb3B0cywgZGVwdGggKyAxLCBzZWVuKTtcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIG9iaiA9PT0gJ2Z1bmN0aW9uJyAmJiAhaXNSZWdFeHAob2JqKSkgeyAvLyBpbiBvbGRlciBlbmdpbmVzLCByZWdleGVzIGFyZSBjYWxsYWJsZVxuICAgICAgICB2YXIgbmFtZSA9IG5hbWVPZihvYmopO1xuICAgICAgICB2YXIga2V5cyA9IGFyck9iaktleXMob2JqLCBpbnNwZWN0KTtcbiAgICAgICAgcmV0dXJuICdbRnVuY3Rpb24nICsgKG5hbWUgPyAnOiAnICsgbmFtZSA6ICcgKGFub255bW91cyknKSArICddJyArIChrZXlzLmxlbmd0aCA+IDAgPyAnIHsgJyArICRqb2luLmNhbGwoa2V5cywgJywgJykgKyAnIH0nIDogJycpO1xuICAgIH1cbiAgICBpZiAoaXNTeW1ib2wob2JqKSkge1xuICAgICAgICB2YXIgc3ltU3RyaW5nID0gaGFzU2hhbW1lZFN5bWJvbHMgPyAkcmVwbGFjZS5jYWxsKFN0cmluZyhvYmopLCAvXihTeW1ib2xcXCguKlxcKSlfW14pXSokLywgJyQxJykgOiBzeW1Ub1N0cmluZy5jYWxsKG9iaik7XG4gICAgICAgIHJldHVybiB0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiAhaGFzU2hhbW1lZFN5bWJvbHMgPyBtYXJrQm94ZWQoc3ltU3RyaW5nKSA6IHN5bVN0cmluZztcbiAgICB9XG4gICAgaWYgKGlzRWxlbWVudChvYmopKSB7XG4gICAgICAgIHZhciBzID0gJzwnICsgJHRvTG93ZXJDYXNlLmNhbGwoU3RyaW5nKG9iai5ub2RlTmFtZSkpO1xuICAgICAgICB2YXIgYXR0cnMgPSBvYmouYXR0cmlidXRlcyB8fCBbXTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhdHRycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcyArPSAnICcgKyBhdHRyc1tpXS5uYW1lICsgJz0nICsgd3JhcFF1b3RlcyhxdW90ZShhdHRyc1tpXS52YWx1ZSksICdkb3VibGUnLCBvcHRzKTtcbiAgICAgICAgfVxuICAgICAgICBzICs9ICc+JztcbiAgICAgICAgaWYgKG9iai5jaGlsZE5vZGVzICYmIG9iai5jaGlsZE5vZGVzLmxlbmd0aCkgeyBzICs9ICcuLi4nOyB9XG4gICAgICAgIHMgKz0gJzwvJyArICR0b0xvd2VyQ2FzZS5jYWxsKFN0cmluZyhvYmoubm9kZU5hbWUpKSArICc+JztcbiAgICAgICAgcmV0dXJuIHM7XG4gICAgfVxuICAgIGlmIChpc0FycmF5KG9iaikpIHtcbiAgICAgICAgaWYgKG9iai5sZW5ndGggPT09IDApIHsgcmV0dXJuICdbXSc7IH1cbiAgICAgICAgdmFyIHhzID0gYXJyT2JqS2V5cyhvYmosIGluc3BlY3QpO1xuICAgICAgICBpZiAoaW5kZW50ICYmICFzaW5nbGVMaW5lVmFsdWVzKHhzKSkge1xuICAgICAgICAgICAgcmV0dXJuICdbJyArIGluZGVudGVkSm9pbih4cywgaW5kZW50KSArICddJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gJ1sgJyArICRqb2luLmNhbGwoeHMsICcsICcpICsgJyBdJztcbiAgICB9XG4gICAgaWYgKGlzRXJyb3Iob2JqKSkge1xuICAgICAgICB2YXIgcGFydHMgPSBhcnJPYmpLZXlzKG9iaiwgaW5zcGVjdCk7XG4gICAgICAgIGlmICghKCdjYXVzZScgaW4gRXJyb3IucHJvdG90eXBlKSAmJiAnY2F1c2UnIGluIG9iaiAmJiAhaXNFbnVtZXJhYmxlLmNhbGwob2JqLCAnY2F1c2UnKSkge1xuICAgICAgICAgICAgcmV0dXJuICd7IFsnICsgU3RyaW5nKG9iaikgKyAnXSAnICsgJGpvaW4uY2FsbCgkY29uY2F0LmNhbGwoJ1tjYXVzZV06ICcgKyBpbnNwZWN0KG9iai5jYXVzZSksIHBhcnRzKSwgJywgJykgKyAnIH0nO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwYXJ0cy5sZW5ndGggPT09IDApIHsgcmV0dXJuICdbJyArIFN0cmluZyhvYmopICsgJ10nOyB9XG4gICAgICAgIHJldHVybiAneyBbJyArIFN0cmluZyhvYmopICsgJ10gJyArICRqb2luLmNhbGwocGFydHMsICcsICcpICsgJyB9JztcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBvYmogPT09ICdvYmplY3QnICYmIGN1c3RvbUluc3BlY3QpIHtcbiAgICAgICAgaWYgKGluc3BlY3RTeW1ib2wgJiYgdHlwZW9mIG9ialtpbnNwZWN0U3ltYm9sXSA9PT0gJ2Z1bmN0aW9uJyAmJiB1dGlsSW5zcGVjdCkge1xuICAgICAgICAgICAgcmV0dXJuIHV0aWxJbnNwZWN0KG9iaiwgeyBkZXB0aDogbWF4RGVwdGggLSBkZXB0aCB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChjdXN0b21JbnNwZWN0ICE9PSAnc3ltYm9sJyAmJiB0eXBlb2Ygb2JqLmluc3BlY3QgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHJldHVybiBvYmouaW5zcGVjdCgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChpc01hcChvYmopKSB7XG4gICAgICAgIHZhciBtYXBQYXJ0cyA9IFtdO1xuICAgICAgICBpZiAobWFwRm9yRWFjaCkge1xuICAgICAgICAgICAgbWFwRm9yRWFjaC5jYWxsKG9iaiwgZnVuY3Rpb24gKHZhbHVlLCBrZXkpIHtcbiAgICAgICAgICAgICAgICBtYXBQYXJ0cy5wdXNoKGluc3BlY3Qoa2V5LCBvYmosIHRydWUpICsgJyA9PiAnICsgaW5zcGVjdCh2YWx1ZSwgb2JqKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29sbGVjdGlvbk9mKCdNYXAnLCBtYXBTaXplLmNhbGwob2JqKSwgbWFwUGFydHMsIGluZGVudCk7XG4gICAgfVxuICAgIGlmIChpc1NldChvYmopKSB7XG4gICAgICAgIHZhciBzZXRQYXJ0cyA9IFtdO1xuICAgICAgICBpZiAoc2V0Rm9yRWFjaCkge1xuICAgICAgICAgICAgc2V0Rm9yRWFjaC5jYWxsKG9iaiwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgc2V0UGFydHMucHVzaChpbnNwZWN0KHZhbHVlLCBvYmopKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb2xsZWN0aW9uT2YoJ1NldCcsIHNldFNpemUuY2FsbChvYmopLCBzZXRQYXJ0cywgaW5kZW50KTtcbiAgICB9XG4gICAgaWYgKGlzV2Vha01hcChvYmopKSB7XG4gICAgICAgIHJldHVybiB3ZWFrQ29sbGVjdGlvbk9mKCdXZWFrTWFwJyk7XG4gICAgfVxuICAgIGlmIChpc1dlYWtTZXQob2JqKSkge1xuICAgICAgICByZXR1cm4gd2Vha0NvbGxlY3Rpb25PZignV2Vha1NldCcpO1xuICAgIH1cbiAgICBpZiAoaXNXZWFrUmVmKG9iaikpIHtcbiAgICAgICAgcmV0dXJuIHdlYWtDb2xsZWN0aW9uT2YoJ1dlYWtSZWYnKTtcbiAgICB9XG4gICAgaWYgKGlzTnVtYmVyKG9iaikpIHtcbiAgICAgICAgcmV0dXJuIG1hcmtCb3hlZChpbnNwZWN0KE51bWJlcihvYmopKSk7XG4gICAgfVxuICAgIGlmIChpc0JpZ0ludChvYmopKSB7XG4gICAgICAgIHJldHVybiBtYXJrQm94ZWQoaW5zcGVjdChiaWdJbnRWYWx1ZU9mLmNhbGwob2JqKSkpO1xuICAgIH1cbiAgICBpZiAoaXNCb29sZWFuKG9iaikpIHtcbiAgICAgICAgcmV0dXJuIG1hcmtCb3hlZChib29sZWFuVmFsdWVPZi5jYWxsKG9iaikpO1xuICAgIH1cbiAgICBpZiAoaXNTdHJpbmcob2JqKSkge1xuICAgICAgICByZXR1cm4gbWFya0JveGVkKGluc3BlY3QoU3RyaW5nKG9iaikpKTtcbiAgICB9XG4gICAgLy8gbm90ZTogaW4gSUUgOCwgc29tZXRpbWVzIGBnbG9iYWwgIT09IHdpbmRvd2AgYnV0IGJvdGggYXJlIHRoZSBwcm90b3R5cGVzIG9mIGVhY2ggb3RoZXJcbiAgICAvKiBlc2xpbnQtZW52IGJyb3dzZXIgKi9cbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgb2JqID09PSB3aW5kb3cpIHtcbiAgICAgICAgcmV0dXJuICd7IFtvYmplY3QgV2luZG93XSB9JztcbiAgICB9XG4gICAgaWYgKFxuICAgICAgICAodHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnICYmIG9iaiA9PT0gZ2xvYmFsVGhpcylcbiAgICAgICAgfHwgKHR5cGVvZiBnbG9iYWwgIT09ICd1bmRlZmluZWQnICYmIG9iaiA9PT0gZ2xvYmFsKVxuICAgICkge1xuICAgICAgICByZXR1cm4gJ3sgW29iamVjdCBnbG9iYWxUaGlzXSB9JztcbiAgICB9XG4gICAgaWYgKCFpc0RhdGUob2JqKSAmJiAhaXNSZWdFeHAob2JqKSkge1xuICAgICAgICB2YXIgeXMgPSBhcnJPYmpLZXlzKG9iaiwgaW5zcGVjdCk7XG4gICAgICAgIHZhciBpc1BsYWluT2JqZWN0ID0gZ1BPID8gZ1BPKG9iaikgPT09IE9iamVjdC5wcm90b3R5cGUgOiBvYmogaW5zdGFuY2VvZiBPYmplY3QgfHwgb2JqLmNvbnN0cnVjdG9yID09PSBPYmplY3Q7XG4gICAgICAgIHZhciBwcm90b1RhZyA9IG9iaiBpbnN0YW5jZW9mIE9iamVjdCA/ICcnIDogJ251bGwgcHJvdG90eXBlJztcbiAgICAgICAgdmFyIHN0cmluZ1RhZyA9ICFpc1BsYWluT2JqZWN0ICYmIHRvU3RyaW5nVGFnICYmIE9iamVjdChvYmopID09PSBvYmogJiYgdG9TdHJpbmdUYWcgaW4gb2JqID8gJHNsaWNlLmNhbGwodG9TdHIob2JqKSwgOCwgLTEpIDogcHJvdG9UYWcgPyAnT2JqZWN0JyA6ICcnO1xuICAgICAgICB2YXIgY29uc3RydWN0b3JUYWcgPSBpc1BsYWluT2JqZWN0IHx8IHR5cGVvZiBvYmouY29uc3RydWN0b3IgIT09ICdmdW5jdGlvbicgPyAnJyA6IG9iai5jb25zdHJ1Y3Rvci5uYW1lID8gb2JqLmNvbnN0cnVjdG9yLm5hbWUgKyAnICcgOiAnJztcbiAgICAgICAgdmFyIHRhZyA9IGNvbnN0cnVjdG9yVGFnICsgKHN0cmluZ1RhZyB8fCBwcm90b1RhZyA/ICdbJyArICRqb2luLmNhbGwoJGNvbmNhdC5jYWxsKFtdLCBzdHJpbmdUYWcgfHwgW10sIHByb3RvVGFnIHx8IFtdKSwgJzogJykgKyAnXSAnIDogJycpO1xuICAgICAgICBpZiAoeXMubGVuZ3RoID09PSAwKSB7IHJldHVybiB0YWcgKyAne30nOyB9XG4gICAgICAgIGlmIChpbmRlbnQpIHtcbiAgICAgICAgICAgIHJldHVybiB0YWcgKyAneycgKyBpbmRlbnRlZEpvaW4oeXMsIGluZGVudCkgKyAnfSc7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRhZyArICd7ICcgKyAkam9pbi5jYWxsKHlzLCAnLCAnKSArICcgfSc7XG4gICAgfVxuICAgIHJldHVybiBTdHJpbmcob2JqKTtcbn07XG5cbmZ1bmN0aW9uIHdyYXBRdW90ZXMocywgZGVmYXVsdFN0eWxlLCBvcHRzKSB7XG4gICAgdmFyIHF1b3RlQ2hhciA9IChvcHRzLnF1b3RlU3R5bGUgfHwgZGVmYXVsdFN0eWxlKSA9PT0gJ2RvdWJsZScgPyAnXCInIDogXCInXCI7XG4gICAgcmV0dXJuIHF1b3RlQ2hhciArIHMgKyBxdW90ZUNoYXI7XG59XG5cbmZ1bmN0aW9uIHF1b3RlKHMpIHtcbiAgICByZXR1cm4gJHJlcGxhY2UuY2FsbChTdHJpbmcocyksIC9cIi9nLCAnJnF1b3Q7Jyk7XG59XG5cbmZ1bmN0aW9uIGlzQXJyYXkob2JqKSB7IHJldHVybiB0b1N0cihvYmopID09PSAnW29iamVjdCBBcnJheV0nICYmICghdG9TdHJpbmdUYWcgfHwgISh0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiB0b1N0cmluZ1RhZyBpbiBvYmopKTsgfVxuZnVuY3Rpb24gaXNEYXRlKG9iaikgeyByZXR1cm4gdG9TdHIob2JqKSA9PT0gJ1tvYmplY3QgRGF0ZV0nICYmICghdG9TdHJpbmdUYWcgfHwgISh0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiB0b1N0cmluZ1RhZyBpbiBvYmopKTsgfVxuZnVuY3Rpb24gaXNSZWdFeHAob2JqKSB7IHJldHVybiB0b1N0cihvYmopID09PSAnW29iamVjdCBSZWdFeHBdJyAmJiAoIXRvU3RyaW5nVGFnIHx8ICEodHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgJiYgdG9TdHJpbmdUYWcgaW4gb2JqKSk7IH1cbmZ1bmN0aW9uIGlzRXJyb3Iob2JqKSB7IHJldHVybiB0b1N0cihvYmopID09PSAnW29iamVjdCBFcnJvcl0nICYmICghdG9TdHJpbmdUYWcgfHwgISh0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiB0b1N0cmluZ1RhZyBpbiBvYmopKTsgfVxuZnVuY3Rpb24gaXNTdHJpbmcob2JqKSB7IHJldHVybiB0b1N0cihvYmopID09PSAnW29iamVjdCBTdHJpbmddJyAmJiAoIXRvU3RyaW5nVGFnIHx8ICEodHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgJiYgdG9TdHJpbmdUYWcgaW4gb2JqKSk7IH1cbmZ1bmN0aW9uIGlzTnVtYmVyKG9iaikgeyByZXR1cm4gdG9TdHIob2JqKSA9PT0gJ1tvYmplY3QgTnVtYmVyXScgJiYgKCF0b1N0cmluZ1RhZyB8fCAhKHR5cGVvZiBvYmogPT09ICdvYmplY3QnICYmIHRvU3RyaW5nVGFnIGluIG9iaikpOyB9XG5mdW5jdGlvbiBpc0Jvb2xlYW4ob2JqKSB7IHJldHVybiB0b1N0cihvYmopID09PSAnW29iamVjdCBCb29sZWFuXScgJiYgKCF0b1N0cmluZ1RhZyB8fCAhKHR5cGVvZiBvYmogPT09ICdvYmplY3QnICYmIHRvU3RyaW5nVGFnIGluIG9iaikpOyB9XG5cbi8vIFN5bWJvbCBhbmQgQmlnSW50IGRvIGhhdmUgU3ltYm9sLnRvU3RyaW5nVGFnIGJ5IHNwZWMsIHNvIHRoYXQgY2FuJ3QgYmUgdXNlZCB0byBlbGltaW5hdGUgZmFsc2UgcG9zaXRpdmVzXG5mdW5jdGlvbiBpc1N5bWJvbChvYmopIHtcbiAgICBpZiAoaGFzU2hhbW1lZFN5bWJvbHMpIHtcbiAgICAgICAgcmV0dXJuIG9iaiAmJiB0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiBvYmogaW5zdGFuY2VvZiBTeW1ib2w7XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygb2JqID09PSAnc3ltYm9sJykge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKCFvYmogfHwgdHlwZW9mIG9iaiAhPT0gJ29iamVjdCcgfHwgIXN5bVRvU3RyaW5nKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgc3ltVG9TdHJpbmcuY2FsbChvYmopO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlKSB7fVxuICAgIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gaXNCaWdJbnQob2JqKSB7XG4gICAgaWYgKCFvYmogfHwgdHlwZW9mIG9iaiAhPT0gJ29iamVjdCcgfHwgIWJpZ0ludFZhbHVlT2YpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICBiaWdJbnRWYWx1ZU9mLmNhbGwob2JqKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBjYXRjaCAoZSkge31cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbnZhciBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5IHx8IGZ1bmN0aW9uIChrZXkpIHsgcmV0dXJuIGtleSBpbiB0aGlzOyB9O1xuZnVuY3Rpb24gaGFzKG9iaiwga2V5KSB7XG4gICAgcmV0dXJuIGhhc093bi5jYWxsKG9iaiwga2V5KTtcbn1cblxuZnVuY3Rpb24gdG9TdHIob2JqKSB7XG4gICAgcmV0dXJuIG9iamVjdFRvU3RyaW5nLmNhbGwob2JqKTtcbn1cblxuZnVuY3Rpb24gbmFtZU9mKGYpIHtcbiAgICBpZiAoZi5uYW1lKSB7IHJldHVybiBmLm5hbWU7IH1cbiAgICB2YXIgbSA9ICRtYXRjaC5jYWxsKGZ1bmN0aW9uVG9TdHJpbmcuY2FsbChmKSwgL15mdW5jdGlvblxccyooW1xcdyRdKykvKTtcbiAgICBpZiAobSkgeyByZXR1cm4gbVsxXTsgfVxuICAgIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBpbmRleE9mKHhzLCB4KSB7XG4gICAgaWYgKHhzLmluZGV4T2YpIHsgcmV0dXJuIHhzLmluZGV4T2YoeCk7IH1cbiAgICBmb3IgKHZhciBpID0gMCwgbCA9IHhzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICBpZiAoeHNbaV0gPT09IHgpIHsgcmV0dXJuIGk7IH1cbiAgICB9XG4gICAgcmV0dXJuIC0xO1xufVxuXG5mdW5jdGlvbiBpc01hcCh4KSB7XG4gICAgaWYgKCFtYXBTaXplIHx8ICF4IHx8IHR5cGVvZiB4ICE9PSAnb2JqZWN0Jykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIG1hcFNpemUuY2FsbCh4KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHNldFNpemUuY2FsbCh4KTtcbiAgICAgICAgfSBjYXRjaCAocykge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHggaW5zdGFuY2VvZiBNYXA7IC8vIGNvcmUtanMgd29ya2Fyb3VuZCwgcHJlLXYyLjUuMFxuICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuXG5mdW5jdGlvbiBpc1dlYWtNYXAoeCkge1xuICAgIGlmICghd2Vha01hcEhhcyB8fCAheCB8fCB0eXBlb2YgeCAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICB3ZWFrTWFwSGFzLmNhbGwoeCwgd2Vha01hcEhhcyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB3ZWFrU2V0SGFzLmNhbGwoeCwgd2Vha1NldEhhcyk7XG4gICAgICAgIH0gY2F0Y2ggKHMpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB4IGluc3RhbmNlb2YgV2Vha01hcDsgLy8gY29yZS1qcyB3b3JrYXJvdW5kLCBwcmUtdjIuNS4wXG4gICAgfSBjYXRjaCAoZSkge31cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIGlzV2Vha1JlZih4KSB7XG4gICAgaWYgKCF3ZWFrUmVmRGVyZWYgfHwgIXggfHwgdHlwZW9mIHggIT09ICdvYmplY3QnKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgd2Vha1JlZkRlcmVmLmNhbGwoeCk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuXG5mdW5jdGlvbiBpc1NldCh4KSB7XG4gICAgaWYgKCFzZXRTaXplIHx8ICF4IHx8IHR5cGVvZiB4ICE9PSAnb2JqZWN0Jykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHNldFNpemUuY2FsbCh4KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIG1hcFNpemUuY2FsbCh4KTtcbiAgICAgICAgfSBjYXRjaCAobSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHggaW5zdGFuY2VvZiBTZXQ7IC8vIGNvcmUtanMgd29ya2Fyb3VuZCwgcHJlLXYyLjUuMFxuICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuXG5mdW5jdGlvbiBpc1dlYWtTZXQoeCkge1xuICAgIGlmICghd2Vha1NldEhhcyB8fCAheCB8fCB0eXBlb2YgeCAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICB3ZWFrU2V0SGFzLmNhbGwoeCwgd2Vha1NldEhhcyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB3ZWFrTWFwSGFzLmNhbGwoeCwgd2Vha01hcEhhcyk7XG4gICAgICAgIH0gY2F0Y2ggKHMpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB4IGluc3RhbmNlb2YgV2Vha1NldDsgLy8gY29yZS1qcyB3b3JrYXJvdW5kLCBwcmUtdjIuNS4wXG4gICAgfSBjYXRjaCAoZSkge31cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIGlzRWxlbWVudCh4KSB7XG4gICAgaWYgKCF4IHx8IHR5cGVvZiB4ICE9PSAnb2JqZWN0JykgeyByZXR1cm4gZmFsc2U7IH1cbiAgICBpZiAodHlwZW9mIEhUTUxFbGVtZW50ICE9PSAndW5kZWZpbmVkJyAmJiB4IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiB0eXBlb2YgeC5ub2RlTmFtZSA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIHguZ2V0QXR0cmlidXRlID09PSAnZnVuY3Rpb24nO1xufVxuXG5mdW5jdGlvbiBpbnNwZWN0U3RyaW5nKHN0ciwgb3B0cykge1xuICAgIGlmIChzdHIubGVuZ3RoID4gb3B0cy5tYXhTdHJpbmdMZW5ndGgpIHtcbiAgICAgICAgdmFyIHJlbWFpbmluZyA9IHN0ci5sZW5ndGggLSBvcHRzLm1heFN0cmluZ0xlbmd0aDtcbiAgICAgICAgdmFyIHRyYWlsZXIgPSAnLi4uICcgKyByZW1haW5pbmcgKyAnIG1vcmUgY2hhcmFjdGVyJyArIChyZW1haW5pbmcgPiAxID8gJ3MnIDogJycpO1xuICAgICAgICByZXR1cm4gaW5zcGVjdFN0cmluZygkc2xpY2UuY2FsbChzdHIsIDAsIG9wdHMubWF4U3RyaW5nTGVuZ3RoKSwgb3B0cykgKyB0cmFpbGVyO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29udHJvbC1yZWdleFxuICAgIHZhciBzID0gJHJlcGxhY2UuY2FsbCgkcmVwbGFjZS5jYWxsKHN0ciwgLyhbJ1xcXFxdKS9nLCAnXFxcXCQxJyksIC9bXFx4MDAtXFx4MWZdL2csIGxvd2J5dGUpO1xuICAgIHJldHVybiB3cmFwUXVvdGVzKHMsICdzaW5nbGUnLCBvcHRzKTtcbn1cblxuZnVuY3Rpb24gbG93Ynl0ZShjKSB7XG4gICAgdmFyIG4gPSBjLmNoYXJDb2RlQXQoMCk7XG4gICAgdmFyIHggPSB7XG4gICAgICAgIDg6ICdiJyxcbiAgICAgICAgOTogJ3QnLFxuICAgICAgICAxMDogJ24nLFxuICAgICAgICAxMjogJ2YnLFxuICAgICAgICAxMzogJ3InXG4gICAgfVtuXTtcbiAgICBpZiAoeCkgeyByZXR1cm4gJ1xcXFwnICsgeDsgfVxuICAgIHJldHVybiAnXFxcXHgnICsgKG4gPCAweDEwID8gJzAnIDogJycpICsgJHRvVXBwZXJDYXNlLmNhbGwobi50b1N0cmluZygxNikpO1xufVxuXG5mdW5jdGlvbiBtYXJrQm94ZWQoc3RyKSB7XG4gICAgcmV0dXJuICdPYmplY3QoJyArIHN0ciArICcpJztcbn1cblxuZnVuY3Rpb24gd2Vha0NvbGxlY3Rpb25PZih0eXBlKSB7XG4gICAgcmV0dXJuIHR5cGUgKyAnIHsgPyB9Jztcbn1cblxuZnVuY3Rpb24gY29sbGVjdGlvbk9mKHR5cGUsIHNpemUsIGVudHJpZXMsIGluZGVudCkge1xuICAgIHZhciBqb2luZWRFbnRyaWVzID0gaW5kZW50ID8gaW5kZW50ZWRKb2luKGVudHJpZXMsIGluZGVudCkgOiAkam9pbi5jYWxsKGVudHJpZXMsICcsICcpO1xuICAgIHJldHVybiB0eXBlICsgJyAoJyArIHNpemUgKyAnKSB7JyArIGpvaW5lZEVudHJpZXMgKyAnfSc7XG59XG5cbmZ1bmN0aW9uIHNpbmdsZUxpbmVWYWx1ZXMoeHMpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHhzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmIChpbmRleE9mKHhzW2ldLCAnXFxuJykgPj0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiBnZXRJbmRlbnQob3B0cywgZGVwdGgpIHtcbiAgICB2YXIgYmFzZUluZGVudDtcbiAgICBpZiAob3B0cy5pbmRlbnQgPT09ICdcXHQnKSB7XG4gICAgICAgIGJhc2VJbmRlbnQgPSAnXFx0JztcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBvcHRzLmluZGVudCA9PT0gJ251bWJlcicgJiYgb3B0cy5pbmRlbnQgPiAwKSB7XG4gICAgICAgIGJhc2VJbmRlbnQgPSAkam9pbi5jYWxsKEFycmF5KG9wdHMuaW5kZW50ICsgMSksICcgJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGJhc2U6IGJhc2VJbmRlbnQsXG4gICAgICAgIHByZXY6ICRqb2luLmNhbGwoQXJyYXkoZGVwdGggKyAxKSwgYmFzZUluZGVudClcbiAgICB9O1xufVxuXG5mdW5jdGlvbiBpbmRlbnRlZEpvaW4oeHMsIGluZGVudCkge1xuICAgIGlmICh4cy5sZW5ndGggPT09IDApIHsgcmV0dXJuICcnOyB9XG4gICAgdmFyIGxpbmVKb2luZXIgPSAnXFxuJyArIGluZGVudC5wcmV2ICsgaW5kZW50LmJhc2U7XG4gICAgcmV0dXJuIGxpbmVKb2luZXIgKyAkam9pbi5jYWxsKHhzLCAnLCcgKyBsaW5lSm9pbmVyKSArICdcXG4nICsgaW5kZW50LnByZXY7XG59XG5cbmZ1bmN0aW9uIGFyck9iaktleXMob2JqLCBpbnNwZWN0KSB7XG4gICAgdmFyIGlzQXJyID0gaXNBcnJheShvYmopO1xuICAgIHZhciB4cyA9IFtdO1xuICAgIGlmIChpc0Fycikge1xuICAgICAgICB4cy5sZW5ndGggPSBvYmoubGVuZ3RoO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9iai5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgeHNbaV0gPSBoYXMob2JqLCBpKSA/IGluc3BlY3Qob2JqW2ldLCBvYmopIDogJyc7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdmFyIHN5bXMgPSB0eXBlb2YgZ09QUyA9PT0gJ2Z1bmN0aW9uJyA/IGdPUFMob2JqKSA6IFtdO1xuICAgIHZhciBzeW1NYXA7XG4gICAgaWYgKGhhc1NoYW1tZWRTeW1ib2xzKSB7XG4gICAgICAgIHN5bU1hcCA9IHt9O1xuICAgICAgICBmb3IgKHZhciBrID0gMDsgayA8IHN5bXMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgICAgIHN5bU1hcFsnJCcgKyBzeW1zW2tdXSA9IHN5bXNba107XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcmVzdHJpY3RlZC1zeW50YXhcbiAgICAgICAgaWYgKCFoYXMob2JqLCBrZXkpKSB7IGNvbnRpbnVlOyB9IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcmVzdHJpY3RlZC1zeW50YXgsIG5vLWNvbnRpbnVlXG4gICAgICAgIGlmIChpc0FyciAmJiBTdHJpbmcoTnVtYmVyKGtleSkpID09PSBrZXkgJiYga2V5IDwgb2JqLmxlbmd0aCkgeyBjb250aW51ZTsgfSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXJlc3RyaWN0ZWQtc3ludGF4LCBuby1jb250aW51ZVxuICAgICAgICBpZiAoaGFzU2hhbW1lZFN5bWJvbHMgJiYgc3ltTWFwWyckJyArIGtleV0gaW5zdGFuY2VvZiBTeW1ib2wpIHtcbiAgICAgICAgICAgIC8vIHRoaXMgaXMgdG8gcHJldmVudCBzaGFtbWVkIFN5bWJvbHMsIHdoaWNoIGFyZSBzdG9yZWQgYXMgc3RyaW5ncywgZnJvbSBiZWluZyBpbmNsdWRlZCBpbiB0aGUgc3RyaW5nIGtleSBzZWN0aW9uXG4gICAgICAgICAgICBjb250aW51ZTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1yZXN0cmljdGVkLXN5bnRheCwgbm8tY29udGludWVcbiAgICAgICAgfSBlbHNlIGlmICgkdGVzdC5jYWxsKC9bXlxcdyRdLywga2V5KSkge1xuICAgICAgICAgICAgeHMucHVzaChpbnNwZWN0KGtleSwgb2JqKSArICc6ICcgKyBpbnNwZWN0KG9ialtrZXldLCBvYmopKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHhzLnB1c2goa2V5ICsgJzogJyArIGluc3BlY3Qob2JqW2tleV0sIG9iaikpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZ09QUyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHN5bXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgIGlmIChpc0VudW1lcmFibGUuY2FsbChvYmosIHN5bXNbal0pKSB7XG4gICAgICAgICAgICAgICAgeHMucHVzaCgnWycgKyBpbnNwZWN0KHN5bXNbal0pICsgJ106ICcgKyBpbnNwZWN0KG9ialtzeW1zW2pdXSwgb2JqKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHhzO1xufVxuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIEdldEludHJpbnNpYyA9IHJlcXVpcmUoJ2dldC1pbnRyaW5zaWMnKTtcbnZhciBjYWxsQm91bmQgPSByZXF1aXJlKCdjYWxsLWJpbmQvY2FsbEJvdW5kJyk7XG52YXIgaW5zcGVjdCA9IHJlcXVpcmUoJ29iamVjdC1pbnNwZWN0Jyk7XG5cbnZhciAkVHlwZUVycm9yID0gcmVxdWlyZSgnZXMtZXJyb3JzL3R5cGUnKTtcbnZhciAkV2Vha01hcCA9IEdldEludHJpbnNpYygnJVdlYWtNYXAlJywgdHJ1ZSk7XG52YXIgJE1hcCA9IEdldEludHJpbnNpYygnJU1hcCUnLCB0cnVlKTtcblxudmFyICR3ZWFrTWFwR2V0ID0gY2FsbEJvdW5kKCdXZWFrTWFwLnByb3RvdHlwZS5nZXQnLCB0cnVlKTtcbnZhciAkd2Vha01hcFNldCA9IGNhbGxCb3VuZCgnV2Vha01hcC5wcm90b3R5cGUuc2V0JywgdHJ1ZSk7XG52YXIgJHdlYWtNYXBIYXMgPSBjYWxsQm91bmQoJ1dlYWtNYXAucHJvdG90eXBlLmhhcycsIHRydWUpO1xudmFyICRtYXBHZXQgPSBjYWxsQm91bmQoJ01hcC5wcm90b3R5cGUuZ2V0JywgdHJ1ZSk7XG52YXIgJG1hcFNldCA9IGNhbGxCb3VuZCgnTWFwLnByb3RvdHlwZS5zZXQnLCB0cnVlKTtcbnZhciAkbWFwSGFzID0gY2FsbEJvdW5kKCdNYXAucHJvdG90eXBlLmhhcycsIHRydWUpO1xuXG4vKlxuKiBUaGlzIGZ1bmN0aW9uIHRyYXZlcnNlcyB0aGUgbGlzdCByZXR1cm5pbmcgdGhlIG5vZGUgY29ycmVzcG9uZGluZyB0byB0aGUgZ2l2ZW4ga2V5LlxuKlxuKiBUaGF0IG5vZGUgaXMgYWxzbyBtb3ZlZCB0byB0aGUgaGVhZCBvZiB0aGUgbGlzdCwgc28gdGhhdCBpZiBpdCdzIGFjY2Vzc2VkIGFnYWluIHdlIGRvbid0IG5lZWQgdG8gdHJhdmVyc2UgdGhlIHdob2xlIGxpc3QuIEJ5IGRvaW5nIHNvLCBhbGwgdGhlIHJlY2VudGx5IHVzZWQgbm9kZXMgY2FuIGJlIGFjY2Vzc2VkIHJlbGF0aXZlbHkgcXVpY2tseS5cbiovXG4vKiogQHR5cGUge2ltcG9ydCgnLicpLmxpc3RHZXROb2RlfSAqL1xudmFyIGxpc3RHZXROb2RlID0gZnVuY3Rpb24gKGxpc3QsIGtleSkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG5cdC8qKiBAdHlwZSB7dHlwZW9mIGxpc3QgfCBOb25OdWxsYWJsZTwodHlwZW9mIGxpc3QpWyduZXh0J10+fSAqL1xuXHR2YXIgcHJldiA9IGxpc3Q7XG5cdC8qKiBAdHlwZSB7KHR5cGVvZiBsaXN0KVsnbmV4dCddfSAqL1xuXHR2YXIgY3Vycjtcblx0Zm9yICg7IChjdXJyID0gcHJldi5uZXh0KSAhPT0gbnVsbDsgcHJldiA9IGN1cnIpIHtcblx0XHRpZiAoY3Vyci5rZXkgPT09IGtleSkge1xuXHRcdFx0cHJldi5uZXh0ID0gY3Vyci5uZXh0O1xuXHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWV4dHJhLXBhcmVuc1xuXHRcdFx0Y3Vyci5uZXh0ID0gLyoqIEB0eXBlIHtOb25OdWxsYWJsZTx0eXBlb2YgbGlzdC5uZXh0Pn0gKi8gKGxpc3QubmV4dCk7XG5cdFx0XHRsaXN0Lm5leHQgPSBjdXJyOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG5cdFx0XHRyZXR1cm4gY3Vycjtcblx0XHR9XG5cdH1cbn07XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuJykubGlzdEdldH0gKi9cbnZhciBsaXN0R2V0ID0gZnVuY3Rpb24gKG9iamVjdHMsIGtleSkge1xuXHR2YXIgbm9kZSA9IGxpc3RHZXROb2RlKG9iamVjdHMsIGtleSk7XG5cdHJldHVybiBub2RlICYmIG5vZGUudmFsdWU7XG59O1xuLyoqIEB0eXBlIHtpbXBvcnQoJy4nKS5saXN0U2V0fSAqL1xudmFyIGxpc3RTZXQgPSBmdW5jdGlvbiAob2JqZWN0cywga2V5LCB2YWx1ZSkge1xuXHR2YXIgbm9kZSA9IGxpc3RHZXROb2RlKG9iamVjdHMsIGtleSk7XG5cdGlmIChub2RlKSB7XG5cdFx0bm9kZS52YWx1ZSA9IHZhbHVlO1xuXHR9IGVsc2Uge1xuXHRcdC8vIFByZXBlbmQgdGhlIG5ldyBub2RlIHRvIHRoZSBiZWdpbm5pbmcgb2YgdGhlIGxpc3Rcblx0XHRvYmplY3RzLm5leHQgPSAvKiogQHR5cGUge2ltcG9ydCgnLicpLkxpc3ROb2RlPHR5cGVvZiB2YWx1ZT59ICovICh7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tcGFyYW0tcmVhc3NpZ24sIG5vLWV4dHJhLXBhcmVuc1xuXHRcdFx0a2V5OiBrZXksXG5cdFx0XHRuZXh0OiBvYmplY3RzLm5leHQsXG5cdFx0XHR2YWx1ZTogdmFsdWVcblx0XHR9KTtcblx0fVxufTtcbi8qKiBAdHlwZSB7aW1wb3J0KCcuJykubGlzdEhhc30gKi9cbnZhciBsaXN0SGFzID0gZnVuY3Rpb24gKG9iamVjdHMsIGtleSkge1xuXHRyZXR1cm4gISFsaXN0R2V0Tm9kZShvYmplY3RzLCBrZXkpO1xufTtcblxuLyoqIEB0eXBlIHtpbXBvcnQoJy4nKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZ2V0U2lkZUNoYW5uZWwoKSB7XG5cdC8qKiBAdHlwZSB7V2Vha01hcDxvYmplY3QsIHVua25vd24+fSAqLyB2YXIgJHdtO1xuXHQvKiogQHR5cGUge01hcDxvYmplY3QsIHVua25vd24+fSAqLyB2YXIgJG07XG5cdC8qKiBAdHlwZSB7aW1wb3J0KCcuJykuUm9vdE5vZGU8dW5rbm93bj59ICovIHZhciAkbztcblxuXHQvKiogQHR5cGUge2ltcG9ydCgnLicpLkNoYW5uZWx9ICovXG5cdHZhciBjaGFubmVsID0ge1xuXHRcdGFzc2VydDogZnVuY3Rpb24gKGtleSkge1xuXHRcdFx0aWYgKCFjaGFubmVsLmhhcyhrZXkpKSB7XG5cdFx0XHRcdHRocm93IG5ldyAkVHlwZUVycm9yKCdTaWRlIGNoYW5uZWwgZG9lcyBub3QgY29udGFpbiAnICsgaW5zcGVjdChrZXkpKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGdldDogZnVuY3Rpb24gKGtleSkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG5cdFx0XHRpZiAoJFdlYWtNYXAgJiYga2V5ICYmICh0eXBlb2Yga2V5ID09PSAnb2JqZWN0JyB8fCB0eXBlb2Yga2V5ID09PSAnZnVuY3Rpb24nKSkge1xuXHRcdFx0XHRpZiAoJHdtKSB7XG5cdFx0XHRcdFx0cmV0dXJuICR3ZWFrTWFwR2V0KCR3bSwga2V5KTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmICgkTWFwKSB7XG5cdFx0XHRcdGlmICgkbSkge1xuXHRcdFx0XHRcdHJldHVybiAkbWFwR2V0KCRtLCBrZXkpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRpZiAoJG8pIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1sb25lbHktaWZcblx0XHRcdFx0XHRyZXR1cm4gbGlzdEdldCgkbywga2V5KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0sXG5cdFx0aGFzOiBmdW5jdGlvbiAoa2V5KSB7XG5cdFx0XHRpZiAoJFdlYWtNYXAgJiYga2V5ICYmICh0eXBlb2Yga2V5ID09PSAnb2JqZWN0JyB8fCB0eXBlb2Yga2V5ID09PSAnZnVuY3Rpb24nKSkge1xuXHRcdFx0XHRpZiAoJHdtKSB7XG5cdFx0XHRcdFx0cmV0dXJuICR3ZWFrTWFwSGFzKCR3bSwga2V5KTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmICgkTWFwKSB7XG5cdFx0XHRcdGlmICgkbSkge1xuXHRcdFx0XHRcdHJldHVybiAkbWFwSGFzKCRtLCBrZXkpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRpZiAoJG8pIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1sb25lbHktaWZcblx0XHRcdFx0XHRyZXR1cm4gbGlzdEhhcygkbywga2V5KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH0sXG5cdFx0c2V0OiBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuXHRcdFx0aWYgKCRXZWFrTWFwICYmIGtleSAmJiAodHlwZW9mIGtleSA9PT0gJ29iamVjdCcgfHwgdHlwZW9mIGtleSA9PT0gJ2Z1bmN0aW9uJykpIHtcblx0XHRcdFx0aWYgKCEkd20pIHtcblx0XHRcdFx0XHQkd20gPSBuZXcgJFdlYWtNYXAoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHQkd2Vha01hcFNldCgkd20sIGtleSwgdmFsdWUpO1xuXHRcdFx0fSBlbHNlIGlmICgkTWFwKSB7XG5cdFx0XHRcdGlmICghJG0pIHtcblx0XHRcdFx0XHQkbSA9IG5ldyAkTWFwKCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0JG1hcFNldCgkbSwga2V5LCB2YWx1ZSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRpZiAoISRvKSB7XG5cdFx0XHRcdFx0Ly8gSW5pdGlhbGl6ZSB0aGUgbGlua2VkIGxpc3QgYXMgYW4gZW1wdHkgbm9kZSwgc28gdGhhdCB3ZSBkb24ndCBoYXZlIHRvIHNwZWNpYWwtY2FzZSBoYW5kbGluZyBvZiB0aGUgZmlyc3Qgbm9kZTogd2UgY2FuIGFsd2F5cyByZWZlciB0byBpdCBhcyAocHJldmlvdXMgbm9kZSkubmV4dCwgaW5zdGVhZCBvZiBzb21ldGhpbmcgbGlrZSAobGlzdCkuaGVhZFxuXHRcdFx0XHRcdCRvID0geyBrZXk6IHt9LCBuZXh0OiBudWxsIH07XG5cdFx0XHRcdH1cblx0XHRcdFx0bGlzdFNldCgkbywga2V5LCB2YWx1ZSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gY2hhbm5lbDtcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgbnVtYmVySXNOYU4gPSBmdW5jdGlvbiAodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlICE9PSB2YWx1ZTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXMoYSwgYikge1xuXHRpZiAoYSA9PT0gMCAmJiBiID09PSAwKSB7XG5cdFx0cmV0dXJuIDEgLyBhID09PSAxIC8gYjtcblx0fVxuXHRpZiAoYSA9PT0gYikge1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdGlmIChudW1iZXJJc05hTihhKSAmJiBudW1iZXJJc05hTihiKSkge1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn07XG5cbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBpbXBsZW1lbnRhdGlvbiA9IHJlcXVpcmUoJy4vaW1wbGVtZW50YXRpb24nKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBnZXRQb2x5ZmlsbCgpIHtcblx0cmV0dXJuIHR5cGVvZiBPYmplY3QuaXMgPT09ICdmdW5jdGlvbicgPyBPYmplY3QuaXMgOiBpbXBsZW1lbnRhdGlvbjtcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgZ2V0UG9seWZpbGwgPSByZXF1aXJlKCcuL3BvbHlmaWxsJyk7XG52YXIgZGVmaW5lID0gcmVxdWlyZSgnZGVmaW5lLXByb3BlcnRpZXMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBzaGltT2JqZWN0SXMoKSB7XG5cdHZhciBwb2x5ZmlsbCA9IGdldFBvbHlmaWxsKCk7XG5cdGRlZmluZShPYmplY3QsIHsgaXM6IHBvbHlmaWxsIH0sIHtcblx0XHRpczogZnVuY3Rpb24gdGVzdE9iamVjdElzKCkge1xuXHRcdFx0cmV0dXJuIE9iamVjdC5pcyAhPT0gcG9seWZpbGw7XG5cdFx0fVxuXHR9KTtcblx0cmV0dXJuIHBvbHlmaWxsO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBkZWZpbmUgPSByZXF1aXJlKCdkZWZpbmUtcHJvcGVydGllcycpO1xudmFyIGNhbGxCaW5kID0gcmVxdWlyZSgnY2FsbC1iaW5kJyk7XG5cbnZhciBpbXBsZW1lbnRhdGlvbiA9IHJlcXVpcmUoJy4vaW1wbGVtZW50YXRpb24nKTtcbnZhciBnZXRQb2x5ZmlsbCA9IHJlcXVpcmUoJy4vcG9seWZpbGwnKTtcbnZhciBzaGltID0gcmVxdWlyZSgnLi9zaGltJyk7XG5cbnZhciBwb2x5ZmlsbCA9IGNhbGxCaW5kKGdldFBvbHlmaWxsKCksIE9iamVjdCk7XG5cbmRlZmluZShwb2x5ZmlsbCwge1xuXHRnZXRQb2x5ZmlsbDogZ2V0UG9seWZpbGwsXG5cdGltcGxlbWVudGF0aW9uOiBpbXBsZW1lbnRhdGlvbixcblx0c2hpbTogc2hpbVxufSk7XG5cbm1vZHVsZS5leHBvcnRzID0gcG9seWZpbGw7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgaGFzU3ltYm9scyA9IHJlcXVpcmUoJ2hhcy1zeW1ib2xzL3NoYW1zJyk7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGhhc1RvU3RyaW5nVGFnU2hhbXMoKSB7XG5cdHJldHVybiBoYXNTeW1ib2xzKCkgJiYgISFTeW1ib2wudG9TdHJpbmdUYWc7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGhhc1RvU3RyaW5nVGFnID0gcmVxdWlyZSgnaGFzLXRvc3RyaW5ndGFnL3NoYW1zJykoKTtcbnZhciBjYWxsQm91bmQgPSByZXF1aXJlKCdjYWxsLWJpbmQvY2FsbEJvdW5kJyk7XG5cbnZhciAkdG9TdHJpbmcgPSBjYWxsQm91bmQoJ09iamVjdC5wcm90b3R5cGUudG9TdHJpbmcnKTtcblxudmFyIGlzU3RhbmRhcmRBcmd1bWVudHMgPSBmdW5jdGlvbiBpc0FyZ3VtZW50cyh2YWx1ZSkge1xuXHRpZiAoaGFzVG9TdHJpbmdUYWcgJiYgdmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiBTeW1ib2wudG9TdHJpbmdUYWcgaW4gdmFsdWUpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0cmV0dXJuICR0b1N0cmluZyh2YWx1ZSkgPT09ICdbb2JqZWN0IEFyZ3VtZW50c10nO1xufTtcblxudmFyIGlzTGVnYWN5QXJndW1lbnRzID0gZnVuY3Rpb24gaXNBcmd1bWVudHModmFsdWUpIHtcblx0aWYgKGlzU3RhbmRhcmRBcmd1bWVudHModmFsdWUpKSB7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblx0cmV0dXJuIHZhbHVlICE9PSBudWxsICYmXG5cdFx0dHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJlxuXHRcdHR5cGVvZiB2YWx1ZS5sZW5ndGggPT09ICdudW1iZXInICYmXG5cdFx0dmFsdWUubGVuZ3RoID49IDAgJiZcblx0XHQkdG9TdHJpbmcodmFsdWUpICE9PSAnW29iamVjdCBBcnJheV0nICYmXG5cdFx0JHRvU3RyaW5nKHZhbHVlLmNhbGxlZSkgPT09ICdbb2JqZWN0IEZ1bmN0aW9uXSc7XG59O1xuXG52YXIgc3VwcG9ydHNTdGFuZGFyZEFyZ3VtZW50cyA9IChmdW5jdGlvbiAoKSB7XG5cdHJldHVybiBpc1N0YW5kYXJkQXJndW1lbnRzKGFyZ3VtZW50cyk7XG59KCkpO1xuXG5pc1N0YW5kYXJkQXJndW1lbnRzLmlzTGVnYWN5QXJndW1lbnRzID0gaXNMZWdhY3lBcmd1bWVudHM7IC8vIGZvciB0ZXN0c1xuXG5tb2R1bGUuZXhwb3J0cyA9IHN1cHBvcnRzU3RhbmRhcmRBcmd1bWVudHMgPyBpc1N0YW5kYXJkQXJndW1lbnRzIDogaXNMZWdhY3lBcmd1bWVudHM7XG4iLCAidmFyIHRvU3RyaW5nID0ge30udG9TdHJpbmc7XG5cbm1vZHVsZS5leHBvcnRzID0gQXJyYXkuaXNBcnJheSB8fCBmdW5jdGlvbiAoYXJyKSB7XG4gIHJldHVybiB0b1N0cmluZy5jYWxsKGFycikgPT0gJ1tvYmplY3QgQXJyYXldJztcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgY2FsbEJpbmQgPSByZXF1aXJlKCdjYWxsLWJpbmQnKTtcbnZhciBjYWxsQm91bmQgPSByZXF1aXJlKCdjYWxsLWJpbmQvY2FsbEJvdW5kJyk7XG52YXIgR2V0SW50cmluc2ljID0gcmVxdWlyZSgnZ2V0LWludHJpbnNpYycpO1xuXG52YXIgJEFycmF5QnVmZmVyID0gR2V0SW50cmluc2ljKCclQXJyYXlCdWZmZXIlJywgdHJ1ZSk7XG4vKiogQHR5cGUge3VuZGVmaW5lZCB8ICgocmVjZWl2ZXI6IEFycmF5QnVmZmVyKSA9PiBudW1iZXIpIHwgKChyZWNlaXZlcjogdW5rbm93bikgPT4gbmV2ZXIpfSAqL1xudmFyICRieXRlTGVuZ3RoID0gY2FsbEJvdW5kKCdBcnJheUJ1ZmZlci5wcm90b3R5cGUuYnl0ZUxlbmd0aCcsIHRydWUpO1xudmFyICR0b1N0cmluZyA9IGNhbGxCb3VuZCgnT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZycpO1xuXG4vLyBpbiBub2RlIDAuMTAsIEFycmF5QnVmZmVycyBoYXZlIG5vIHByb3RvdHlwZSBtZXRob2RzLCBidXQgaGF2ZSBhbiBvd24gc2xvdC1jaGVja2luZyBgc2xpY2VgIG1ldGhvZFxudmFyIGFiU2xpY2UgPSAhISRBcnJheUJ1ZmZlciAmJiAhJGJ5dGVMZW5ndGggJiYgbmV3ICRBcnJheUJ1ZmZlcigwKS5zbGljZTtcbnZhciAkYWJTbGljZSA9ICEhYWJTbGljZSAmJiBjYWxsQmluZChhYlNsaWNlKTtcblxuLyoqIEB0eXBlIHtpbXBvcnQoJy4nKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gJGJ5dGVMZW5ndGggfHwgJGFiU2xpY2Vcblx0PyBmdW5jdGlvbiBpc0FycmF5QnVmZmVyKG9iaikge1xuXHRcdGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHRpZiAoJGJ5dGVMZW5ndGgpIHtcblx0XHRcdFx0Ly8gQHRzLWV4cGVjdC1lcnJvciBubyBpZGVhIHdoeSBUUyBjYW4ndCBoYW5kbGUgdGhlIG92ZXJsb2FkXG5cdFx0XHRcdCRieXRlTGVuZ3RoKG9iaik7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHQvLyBAdHMtZXhwZWN0LWVycm9yIFRTIGNob29zZXMgbm90IHRvIHR5cGUtbmFycm93IGluc2lkZSBhIGNsb3N1cmVcblx0XHRcdFx0JGFiU2xpY2Uob2JqLCAwKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdH1cblx0OiAkQXJyYXlCdWZmZXJcblx0XHQvLyBpbiBub2RlIDAuOCwgQXJyYXlCdWZmZXJzIGhhdmUgbm8gcHJvdG90eXBlIG9yIG93biBtZXRob2RzLCBidXQgYWxzbyBubyBTeW1ib2wudG9TdHJpbmdUYWdcblx0XHQ/IGZ1bmN0aW9uIGlzQXJyYXlCdWZmZXIob2JqKSB7XG5cdFx0XHRyZXR1cm4gJHRvU3RyaW5nKG9iaikgPT09ICdbb2JqZWN0IEFycmF5QnVmZmVyXSc7XG5cdFx0fVxuXHRcdDogZnVuY3Rpb24gaXNBcnJheUJ1ZmZlcihvYmopIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtdmFyc1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgZ2V0RGF5ID0gRGF0ZS5wcm90b3R5cGUuZ2V0RGF5O1xudmFyIHRyeURhdGVPYmplY3QgPSBmdW5jdGlvbiB0cnlEYXRlR2V0RGF5Q2FsbCh2YWx1ZSkge1xuXHR0cnkge1xuXHRcdGdldERheS5jYWxsKHZhbHVlKTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufTtcblxudmFyIHRvU3RyID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbnZhciBkYXRlQ2xhc3MgPSAnW29iamVjdCBEYXRlXSc7XG52YXIgaGFzVG9TdHJpbmdUYWcgPSByZXF1aXJlKCdoYXMtdG9zdHJpbmd0YWcvc2hhbXMnKSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzRGF0ZU9iamVjdCh2YWx1ZSkge1xuXHRpZiAodHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JyB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gaGFzVG9TdHJpbmdUYWcgPyB0cnlEYXRlT2JqZWN0KHZhbHVlKSA6IHRvU3RyLmNhbGwodmFsdWUpID09PSBkYXRlQ2xhc3M7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGNhbGxCb3VuZCA9IHJlcXVpcmUoJ2NhbGwtYmluZC9jYWxsQm91bmQnKTtcbnZhciBoYXNUb1N0cmluZ1RhZyA9IHJlcXVpcmUoJ2hhcy10b3N0cmluZ3RhZy9zaGFtcycpKCk7XG52YXIgaGFzO1xudmFyICRleGVjO1xudmFyIGlzUmVnZXhNYXJrZXI7XG52YXIgYmFkU3RyaW5naWZpZXI7XG5cbmlmIChoYXNUb1N0cmluZ1RhZykge1xuXHRoYXMgPSBjYWxsQm91bmQoJ09iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHknKTtcblx0JGV4ZWMgPSBjYWxsQm91bmQoJ1JlZ0V4cC5wcm90b3R5cGUuZXhlYycpO1xuXHRpc1JlZ2V4TWFya2VyID0ge307XG5cblx0dmFyIHRocm93UmVnZXhNYXJrZXIgPSBmdW5jdGlvbiAoKSB7XG5cdFx0dGhyb3cgaXNSZWdleE1hcmtlcjtcblx0fTtcblx0YmFkU3RyaW5naWZpZXIgPSB7XG5cdFx0dG9TdHJpbmc6IHRocm93UmVnZXhNYXJrZXIsXG5cdFx0dmFsdWVPZjogdGhyb3dSZWdleE1hcmtlclxuXHR9O1xuXG5cdGlmICh0eXBlb2YgU3ltYm9sLnRvUHJpbWl0aXZlID09PSAnc3ltYm9sJykge1xuXHRcdGJhZFN0cmluZ2lmaWVyW1N5bWJvbC50b1ByaW1pdGl2ZV0gPSB0aHJvd1JlZ2V4TWFya2VyO1xuXHR9XG59XG5cbnZhciAkdG9TdHJpbmcgPSBjYWxsQm91bmQoJ09iamVjdC5wcm90b3R5cGUudG9TdHJpbmcnKTtcbnZhciBnT1BEID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbnZhciByZWdleENsYXNzID0gJ1tvYmplY3QgUmVnRXhwXSc7XG5cbm1vZHVsZS5leHBvcnRzID0gaGFzVG9TdHJpbmdUYWdcblx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG5cdD8gZnVuY3Rpb24gaXNSZWdleCh2YWx1ZSkge1xuXHRcdGlmICghdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0Jykge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblxuXHRcdHZhciBkZXNjcmlwdG9yID0gZ09QRCh2YWx1ZSwgJ2xhc3RJbmRleCcpO1xuXHRcdHZhciBoYXNMYXN0SW5kZXhEYXRhUHJvcGVydHkgPSBkZXNjcmlwdG9yICYmIGhhcyhkZXNjcmlwdG9yLCAndmFsdWUnKTtcblx0XHRpZiAoIWhhc0xhc3RJbmRleERhdGFQcm9wZXJ0eSkge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblxuXHRcdHRyeSB7XG5cdFx0XHQkZXhlYyh2YWx1ZSwgYmFkU3RyaW5naWZpZXIpO1xuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdHJldHVybiBlID09PSBpc1JlZ2V4TWFya2VyO1xuXHRcdH1cblx0fVxuXHQ6IGZ1bmN0aW9uIGlzUmVnZXgodmFsdWUpIHtcblx0XHQvLyBJbiBvbGRlciBicm93c2VycywgdHlwZW9mIHJlZ2V4IGluY29ycmVjdGx5IHJldHVybnMgJ2Z1bmN0aW9uJ1xuXHRcdGlmICghdmFsdWUgfHwgKHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcgJiYgdHlwZW9mIHZhbHVlICE9PSAnZnVuY3Rpb24nKSkge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblxuXHRcdHJldHVybiAkdG9TdHJpbmcodmFsdWUpID09PSByZWdleENsYXNzO1xuXHR9O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGNhbGxCb3VuZCA9IHJlcXVpcmUoJ2NhbGwtYmluZC9jYWxsQm91bmQnKTtcblxudmFyICRieXRlTGVuZ3RoID0gY2FsbEJvdW5kKCdTaGFyZWRBcnJheUJ1ZmZlci5wcm90b3R5cGUuYnl0ZUxlbmd0aCcsIHRydWUpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSAkYnl0ZUxlbmd0aFxuXHQ/IGZ1bmN0aW9uIGlzU2hhcmVkQXJyYXlCdWZmZXIob2JqKSB7XG5cdFx0aWYgKCFvYmogfHwgdHlwZW9mIG9iaiAhPT0gJ29iamVjdCcpIHtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdCRieXRlTGVuZ3RoKG9iaik7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9XG5cdDogZnVuY3Rpb24gaXNTaGFyZWRBcnJheUJ1ZmZlcihvYmopIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtdmFyc1xuXHRcdHJldHVybiBmYWxzZTtcblx0fTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBzdHJWYWx1ZSA9IFN0cmluZy5wcm90b3R5cGUudmFsdWVPZjtcbnZhciB0cnlTdHJpbmdPYmplY3QgPSBmdW5jdGlvbiB0cnlTdHJpbmdPYmplY3QodmFsdWUpIHtcblx0dHJ5IHtcblx0XHRzdHJWYWx1ZS5jYWxsKHZhbHVlKTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufTtcbnZhciB0b1N0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG52YXIgc3RyQ2xhc3MgPSAnW29iamVjdCBTdHJpbmddJztcbnZhciBoYXNUb1N0cmluZ1RhZyA9IHJlcXVpcmUoJ2hhcy10b3N0cmluZ3RhZy9zaGFtcycpKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNTdHJpbmcodmFsdWUpIHtcblx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRpZiAodHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0Jykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gaGFzVG9TdHJpbmdUYWcgPyB0cnlTdHJpbmdPYmplY3QodmFsdWUpIDogdG9TdHIuY2FsbCh2YWx1ZSkgPT09IHN0ckNsYXNzO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBudW1Ub1N0ciA9IE51bWJlci5wcm90b3R5cGUudG9TdHJpbmc7XG52YXIgdHJ5TnVtYmVyT2JqZWN0ID0gZnVuY3Rpb24gdHJ5TnVtYmVyT2JqZWN0KHZhbHVlKSB7XG5cdHRyeSB7XG5cdFx0bnVtVG9TdHIuY2FsbCh2YWx1ZSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn07XG52YXIgdG9TdHIgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xudmFyIG51bUNsYXNzID0gJ1tvYmplY3QgTnVtYmVyXSc7XG52YXIgaGFzVG9TdHJpbmdUYWcgPSByZXF1aXJlKCdoYXMtdG9zdHJpbmd0YWcvc2hhbXMnKSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzTnVtYmVyT2JqZWN0KHZhbHVlKSB7XG5cdGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblx0aWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0cmV0dXJuIGhhc1RvU3RyaW5nVGFnID8gdHJ5TnVtYmVyT2JqZWN0KHZhbHVlKSA6IHRvU3RyLmNhbGwodmFsdWUpID09PSBudW1DbGFzcztcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgY2FsbEJvdW5kID0gcmVxdWlyZSgnY2FsbC1iaW5kL2NhbGxCb3VuZCcpO1xudmFyICRib29sVG9TdHIgPSBjYWxsQm91bmQoJ0Jvb2xlYW4ucHJvdG90eXBlLnRvU3RyaW5nJyk7XG52YXIgJHRvU3RyaW5nID0gY2FsbEJvdW5kKCdPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nJyk7XG5cbnZhciB0cnlCb29sZWFuT2JqZWN0ID0gZnVuY3Rpb24gYm9vbGVhbkJyYW5kQ2hlY2sodmFsdWUpIHtcblx0dHJ5IHtcblx0XHQkYm9vbFRvU3RyKHZhbHVlKTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufTtcbnZhciBib29sQ2xhc3MgPSAnW29iamVjdCBCb29sZWFuXSc7XG52YXIgaGFzVG9TdHJpbmdUYWcgPSByZXF1aXJlKCdoYXMtdG9zdHJpbmd0YWcvc2hhbXMnKSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzQm9vbGVhbih2YWx1ZSkge1xuXHRpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRpZiAodmFsdWUgPT09IG51bGwgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0Jykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gaGFzVG9TdHJpbmdUYWcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnIGluIHZhbHVlID8gdHJ5Qm9vbGVhbk9iamVjdCh2YWx1ZSkgOiAkdG9TdHJpbmcodmFsdWUpID09PSBib29sQ2xhc3M7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIHRvU3RyID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbnZhciBoYXNTeW1ib2xzID0gcmVxdWlyZSgnaGFzLXN5bWJvbHMnKSgpO1xuXG5pZiAoaGFzU3ltYm9scykge1xuXHR2YXIgc3ltVG9TdHIgPSBTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nO1xuXHR2YXIgc3ltU3RyaW5nUmVnZXggPSAvXlN5bWJvbFxcKC4qXFwpJC87XG5cdHZhciBpc1N5bWJvbE9iamVjdCA9IGZ1bmN0aW9uIGlzUmVhbFN5bWJvbE9iamVjdCh2YWx1ZSkge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUudmFsdWVPZigpICE9PSAnc3ltYm9sJykge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRyZXR1cm4gc3ltU3RyaW5nUmVnZXgudGVzdChzeW1Ub1N0ci5jYWxsKHZhbHVlKSk7XG5cdH07XG5cblx0bW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpc1N5bWJvbCh2YWx1ZSkge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdzeW1ib2wnKSB7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0aWYgKHRvU3RyLmNhbGwodmFsdWUpICE9PSAnW29iamVjdCBTeW1ib2xdJykge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0cmV0dXJuIGlzU3ltYm9sT2JqZWN0KHZhbHVlKTtcblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9O1xufSBlbHNlIHtcblxuXHRtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzU3ltYm9sKHZhbHVlKSB7XG5cdFx0Ly8gdGhpcyBlbnZpcm9ubWVudCBkb2VzIG5vdCBzdXBwb3J0IFN5bWJvbHMuXG5cdFx0cmV0dXJuIGZhbHNlICYmIHZhbHVlO1xuXHR9O1xufVxuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyICRCaWdJbnQgPSB0eXBlb2YgQmlnSW50ICE9PSAndW5kZWZpbmVkJyAmJiBCaWdJbnQ7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaGFzTmF0aXZlQmlnSW50cygpIHtcblx0cmV0dXJuIHR5cGVvZiAkQmlnSW50ID09PSAnZnVuY3Rpb24nXG5cdFx0JiYgdHlwZW9mIEJpZ0ludCA9PT0gJ2Z1bmN0aW9uJ1xuXHRcdCYmIHR5cGVvZiAkQmlnSW50KDQyKSA9PT0gJ2JpZ2ludCcgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1tYWdpYy1udW1iZXJzXG5cdFx0JiYgdHlwZW9mIEJpZ0ludCg0MikgPT09ICdiaWdpbnQnOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLW1hZ2ljLW51bWJlcnNcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgaGFzQmlnSW50cyA9IHJlcXVpcmUoJ2hhcy1iaWdpbnRzJykoKTtcblxuaWYgKGhhc0JpZ0ludHMpIHtcblx0dmFyIGJpZ0ludFZhbHVlT2YgPSBCaWdJbnQucHJvdG90eXBlLnZhbHVlT2Y7XG5cdHZhciB0cnlCaWdJbnQgPSBmdW5jdGlvbiB0cnlCaWdJbnRPYmplY3QodmFsdWUpIHtcblx0XHR0cnkge1xuXHRcdFx0YmlnSW50VmFsdWVPZi5jYWxsKHZhbHVlKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHR9XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9O1xuXG5cdG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNCaWdJbnQodmFsdWUpIHtcblx0XHRpZiAoXG5cdFx0XHR2YWx1ZSA9PT0gbnVsbFxuXHRcdFx0fHwgdHlwZW9mIHZhbHVlID09PSAndW5kZWZpbmVkJ1xuXHRcdFx0fHwgdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbidcblx0XHRcdHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZydcblx0XHRcdHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcidcblx0XHRcdHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ3N5bWJvbCdcblx0XHRcdHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJ1xuXHRcdCkge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnYmlnaW50Jykge1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHRyeUJpZ0ludCh2YWx1ZSk7XG5cdH07XG59IGVsc2Uge1xuXHRtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzQmlnSW50KHZhbHVlKSB7XG5cdFx0cmV0dXJuIGZhbHNlICYmIHZhbHVlO1xuXHR9O1xufVxuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGlzU3RyaW5nID0gcmVxdWlyZSgnaXMtc3RyaW5nJyk7XG52YXIgaXNOdW1iZXIgPSByZXF1aXJlKCdpcy1udW1iZXItb2JqZWN0Jyk7XG52YXIgaXNCb29sZWFuID0gcmVxdWlyZSgnaXMtYm9vbGVhbi1vYmplY3QnKTtcbnZhciBpc1N5bWJvbCA9IHJlcXVpcmUoJ2lzLXN5bWJvbCcpO1xudmFyIGlzQmlnSW50ID0gcmVxdWlyZSgnaXMtYmlnaW50Jyk7XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiB3aGljaEJveGVkUHJpbWl0aXZlKHZhbHVlKSB7XG5cdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBlcWVxZXFcblx0aWYgKHZhbHVlID09IG51bGwgfHwgKHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcgJiYgdHlwZW9mIHZhbHVlICE9PSAnZnVuY3Rpb24nKSkge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGlmIChpc1N0cmluZyh2YWx1ZSkpIHtcblx0XHRyZXR1cm4gJ1N0cmluZyc7XG5cdH1cblx0aWYgKGlzTnVtYmVyKHZhbHVlKSkge1xuXHRcdHJldHVybiAnTnVtYmVyJztcblx0fVxuXHRpZiAoaXNCb29sZWFuKHZhbHVlKSkge1xuXHRcdHJldHVybiAnQm9vbGVhbic7XG5cdH1cblx0aWYgKGlzU3ltYm9sKHZhbHVlKSkge1xuXHRcdHJldHVybiAnU3ltYm9sJztcblx0fVxuXHRpZiAoaXNCaWdJbnQodmFsdWUpKSB7XG5cdFx0cmV0dXJuICdCaWdJbnQnO1xuXHR9XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxuLyoqIEBjb25zdCAqL1xudmFyICRNYXAgPSB0eXBlb2YgTWFwID09PSAnZnVuY3Rpb24nICYmIE1hcC5wcm90b3R5cGUgPyBNYXAgOiBudWxsO1xudmFyICRTZXQgPSB0eXBlb2YgU2V0ID09PSAnZnVuY3Rpb24nICYmIFNldC5wcm90b3R5cGUgPyBTZXQgOiBudWxsO1xuXG52YXIgZXhwb3J0ZWQ7XG5cbmlmICghJE1hcCkge1xuXHQvKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xuXHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLXZhcnNcblx0ZXhwb3J0ZWQgPSBmdW5jdGlvbiBpc01hcCh4KSB7XG5cdFx0Ly8gYE1hcGAgaXMgbm90IHByZXNlbnQgaW4gdGhpcyBlbnZpcm9ubWVudC5cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG59XG5cbnZhciAkbWFwSGFzID0gJE1hcCA/IE1hcC5wcm90b3R5cGUuaGFzIDogbnVsbDtcbnZhciAkc2V0SGFzID0gJFNldCA/IFNldC5wcm90b3R5cGUuaGFzIDogbnVsbDtcbmlmICghZXhwb3J0ZWQgJiYgISRtYXBIYXMpIHtcblx0LyoqIEB0eXBlIHtpbXBvcnQoJy4nKX0gKi9cblx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVudXNlZC12YXJzXG5cdGV4cG9ydGVkID0gZnVuY3Rpb24gaXNNYXAoeCkge1xuXHRcdC8vIGBNYXBgIGRvZXMgbm90IGhhdmUgYSBgaGFzYCBtZXRob2Rcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG59XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5tb2R1bGUuZXhwb3J0cyA9IGV4cG9ydGVkIHx8IGZ1bmN0aW9uIGlzTWFwKHgpIHtcblx0aWYgKCF4IHx8IHR5cGVvZiB4ICE9PSAnb2JqZWN0Jykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHR0cnkge1xuXHRcdCRtYXBIYXMuY2FsbCh4KTtcblx0XHRpZiAoJHNldEhhcykge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0JHNldEhhcy5jYWxsKHgpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gQHRzLWV4cGVjdC1lcnJvciBUUyBjYW4ndCBmaWd1cmUgb3V0IHRoYXQgJE1hcCBpcyBhbHdheXMgdHJ1dGh5IGhlcmVcblx0XHRyZXR1cm4geCBpbnN0YW5jZW9mICRNYXA7IC8vIGNvcmUtanMgd29ya2Fyb3VuZCwgcHJlLXYyLjUuMFxuXHR9IGNhdGNoIChlKSB7fVxuXHRyZXR1cm4gZmFsc2U7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyICRNYXAgPSB0eXBlb2YgTWFwID09PSAnZnVuY3Rpb24nICYmIE1hcC5wcm90b3R5cGUgPyBNYXAgOiBudWxsO1xudmFyICRTZXQgPSB0eXBlb2YgU2V0ID09PSAnZnVuY3Rpb24nICYmIFNldC5wcm90b3R5cGUgPyBTZXQgOiBudWxsO1xuXG52YXIgZXhwb3J0ZWQ7XG5cbmlmICghJFNldCkge1xuXHQvKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xuXHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLXZhcnNcblx0ZXhwb3J0ZWQgPSBmdW5jdGlvbiBpc1NldCh4KSB7XG5cdFx0Ly8gYFNldGAgaXMgbm90IHByZXNlbnQgaW4gdGhpcyBlbnZpcm9ubWVudC5cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG59XG5cbnZhciAkbWFwSGFzID0gJE1hcCA/IE1hcC5wcm90b3R5cGUuaGFzIDogbnVsbDtcbnZhciAkc2V0SGFzID0gJFNldCA/IFNldC5wcm90b3R5cGUuaGFzIDogbnVsbDtcbmlmICghZXhwb3J0ZWQgJiYgISRzZXRIYXMpIHtcblx0LyoqIEB0eXBlIHtpbXBvcnQoJy4nKX0gKi9cblx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVudXNlZC12YXJzXG5cdGV4cG9ydGVkID0gZnVuY3Rpb24gaXNTZXQoeCkge1xuXHRcdC8vIGBTZXRgIGRvZXMgbm90IGhhdmUgYSBgaGFzYCBtZXRob2Rcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG59XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5tb2R1bGUuZXhwb3J0cyA9IGV4cG9ydGVkIHx8IGZ1bmN0aW9uIGlzU2V0KHgpIHtcblx0aWYgKCF4IHx8IHR5cGVvZiB4ICE9PSAnb2JqZWN0Jykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHR0cnkge1xuXHRcdCRzZXRIYXMuY2FsbCh4KTtcblx0XHRpZiAoJG1hcEhhcykge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0JG1hcEhhcy5jYWxsKHgpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gQHRzLWV4cGVjdC1lcnJvciBUUyBjYW4ndCBmaWd1cmUgb3V0IHRoYXQgJFNldCBpcyBhbHdheXMgdHJ1dGh5IGhlcmVcblx0XHRyZXR1cm4geCBpbnN0YW5jZW9mICRTZXQ7IC8vIGNvcmUtanMgd29ya2Fyb3VuZCwgcHJlLXYyLjUuMFxuXHR9IGNhdGNoIChlKSB7fVxuXHRyZXR1cm4gZmFsc2U7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyICRXZWFrTWFwID0gdHlwZW9mIFdlYWtNYXAgPT09ICdmdW5jdGlvbicgJiYgV2Vha01hcC5wcm90b3R5cGUgPyBXZWFrTWFwIDogbnVsbDtcbnZhciAkV2Vha1NldCA9IHR5cGVvZiBXZWFrU2V0ID09PSAnZnVuY3Rpb24nICYmIFdlYWtTZXQucHJvdG90eXBlID8gV2Vha1NldCA6IG51bGw7XG5cbnZhciBleHBvcnRlZDtcblxuaWYgKCEkV2Vha01hcCkge1xuXHQvKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xuXHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLXZhcnNcblx0ZXhwb3J0ZWQgPSBmdW5jdGlvbiBpc1dlYWtNYXAoeCkge1xuXHRcdC8vIGBXZWFrTWFwYCBpcyBub3QgcHJlc2VudCBpbiB0aGlzIGVudmlyb25tZW50LlxuXHRcdHJldHVybiBmYWxzZTtcblx0fTtcbn1cblxudmFyICRtYXBIYXMgPSAkV2Vha01hcCA/ICRXZWFrTWFwLnByb3RvdHlwZS5oYXMgOiBudWxsO1xudmFyICRzZXRIYXMgPSAkV2Vha1NldCA/ICRXZWFrU2V0LnByb3RvdHlwZS5oYXMgOiBudWxsO1xuaWYgKCFleHBvcnRlZCAmJiAhJG1hcEhhcykge1xuXHQvKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xuXHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW51c2VkLXZhcnNcblx0ZXhwb3J0ZWQgPSBmdW5jdGlvbiBpc1dlYWtNYXAoeCkge1xuXHRcdC8vIGBXZWFrTWFwYCBkb2VzIG5vdCBoYXZlIGEgYGhhc2AgbWV0aG9kXG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9O1xufVxuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBleHBvcnRlZCB8fCBmdW5jdGlvbiBpc1dlYWtNYXAoeCkge1xuXHRpZiAoIXggfHwgdHlwZW9mIHggIT09ICdvYmplY3QnKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdHRyeSB7XG5cdFx0JG1hcEhhcy5jYWxsKHgsICRtYXBIYXMpO1xuXHRcdGlmICgkc2V0SGFzKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHQkc2V0SGFzLmNhbGwoeCwgJHNldEhhcyk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHQvLyBAdHMtZXhwZWN0LWVycm9yIFRTIGNhbid0IGZpZ3VyZSBvdXQgdGhhdCAkV2Vha01hcCBpcyBhbHdheXMgdHJ1dGh5IGhlcmVcblx0XHRyZXR1cm4geCBpbnN0YW5jZW9mICRXZWFrTWFwOyAvLyBjb3JlLWpzIHdvcmthcm91bmQsIHByZS12M1xuXHR9IGNhdGNoIChlKSB7fVxuXHRyZXR1cm4gZmFsc2U7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIEdldEludHJpbnNpYyA9IHJlcXVpcmUoJ2dldC1pbnRyaW5zaWMnKTtcbnZhciBjYWxsQm91bmQgPSByZXF1aXJlKCdjYWxsLWJpbmQvY2FsbEJvdW5kJyk7XG5cbnZhciAkV2Vha1NldCA9IEdldEludHJpbnNpYygnJVdlYWtTZXQlJywgdHJ1ZSk7XG5cbnZhciAkc2V0SGFzID0gY2FsbEJvdW5kKCdXZWFrU2V0LnByb3RvdHlwZS5oYXMnLCB0cnVlKTtcblxuaWYgKCRzZXRIYXMpIHtcblx0dmFyICRtYXBIYXMgPSBjYWxsQm91bmQoJ1dlYWtNYXAucHJvdG90eXBlLmhhcycsIHRydWUpO1xuXG5cdC8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5cdG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNXZWFrU2V0KHgpIHtcblx0XHRpZiAoIXggfHwgdHlwZW9mIHggIT09ICdvYmplY3QnKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHQkc2V0SGFzKHgsICRzZXRIYXMpO1xuXHRcdFx0aWYgKCRtYXBIYXMpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHQkbWFwSGFzKHgsICRtYXBIYXMpO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdC8vIEB0cy1leHBlY3QtZXJyb3IgVFMgY2FuJ3QgZmlndXJlIG91dCB0aGF0ICRXZWFrU2V0IGlzIGFsd2F5cyB0cnV0aHkgaGVyZVxuXHRcdFx0cmV0dXJuIHggaW5zdGFuY2VvZiAkV2Vha1NldDsgLy8gY29yZS1qcyB3b3JrYXJvdW5kLCBwcmUtdjNcblx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdHJldHVybiBmYWxzZTtcblx0fTtcbn0gZWxzZSB7XG5cdC8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5cdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bnVzZWQtdmFyc1xuXHRtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzV2Vha1NldCh4KSB7XG5cdFx0Ly8gYFdlYWtTZXRgIGRvZXMgbm90IGV4aXN0LCBvciBkb2VzIG5vdCBoYXZlIGEgYGhhc2AgbWV0aG9kXG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9O1xufVxuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIGlzTWFwID0gcmVxdWlyZSgnaXMtbWFwJyk7XG52YXIgaXNTZXQgPSByZXF1aXJlKCdpcy1zZXQnKTtcbnZhciBpc1dlYWtNYXAgPSByZXF1aXJlKCdpcy13ZWFrbWFwJyk7XG52YXIgaXNXZWFrU2V0ID0gcmVxdWlyZSgnaXMtd2Vha3NldCcpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiB3aGljaENvbGxlY3Rpb24oLyoqIEB0eXBlIHt1bmtub3dufSAqLyB2YWx1ZSkge1xuXHRpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuXHRcdGlmIChpc01hcCh2YWx1ZSkpIHtcblx0XHRcdHJldHVybiAnTWFwJztcblx0XHR9XG5cdFx0aWYgKGlzU2V0KHZhbHVlKSkge1xuXHRcdFx0cmV0dXJuICdTZXQnO1xuXHRcdH1cblx0XHRpZiAoaXNXZWFrTWFwKHZhbHVlKSkge1xuXHRcdFx0cmV0dXJuICdXZWFrTWFwJztcblx0XHR9XG5cdFx0aWYgKGlzV2Vha1NldCh2YWx1ZSkpIHtcblx0XHRcdHJldHVybiAnV2Vha1NldCc7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBmYWxzZTtcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgZm5Ub1N0ciA9IEZ1bmN0aW9uLnByb3RvdHlwZS50b1N0cmluZztcbnZhciByZWZsZWN0QXBwbHkgPSB0eXBlb2YgUmVmbGVjdCA9PT0gJ29iamVjdCcgJiYgUmVmbGVjdCAhPT0gbnVsbCAmJiBSZWZsZWN0LmFwcGx5O1xudmFyIGJhZEFycmF5TGlrZTtcbnZhciBpc0NhbGxhYmxlTWFya2VyO1xuaWYgKHR5cGVvZiByZWZsZWN0QXBwbHkgPT09ICdmdW5jdGlvbicgJiYgdHlwZW9mIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSA9PT0gJ2Z1bmN0aW9uJykge1xuXHR0cnkge1xuXHRcdGJhZEFycmF5TGlrZSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7fSwgJ2xlbmd0aCcsIHtcblx0XHRcdGdldDogZnVuY3Rpb24gKCkge1xuXHRcdFx0XHR0aHJvdyBpc0NhbGxhYmxlTWFya2VyO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGlzQ2FsbGFibGVNYXJrZXIgPSB7fTtcblx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdGhyb3ctbGl0ZXJhbFxuXHRcdHJlZmxlY3RBcHBseShmdW5jdGlvbiAoKSB7IHRocm93IDQyOyB9LCBudWxsLCBiYWRBcnJheUxpa2UpO1xuXHR9IGNhdGNoIChfKSB7XG5cdFx0aWYgKF8gIT09IGlzQ2FsbGFibGVNYXJrZXIpIHtcblx0XHRcdHJlZmxlY3RBcHBseSA9IG51bGw7XG5cdFx0fVxuXHR9XG59IGVsc2Uge1xuXHRyZWZsZWN0QXBwbHkgPSBudWxsO1xufVxuXG52YXIgY29uc3RydWN0b3JSZWdleCA9IC9eXFxzKmNsYXNzXFxiLztcbnZhciBpc0VTNkNsYXNzRm4gPSBmdW5jdGlvbiBpc0VTNkNsYXNzRnVuY3Rpb24odmFsdWUpIHtcblx0dHJ5IHtcblx0XHR2YXIgZm5TdHIgPSBmblRvU3RyLmNhbGwodmFsdWUpO1xuXHRcdHJldHVybiBjb25zdHJ1Y3RvclJlZ2V4LnRlc3QoZm5TdHIpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0cmV0dXJuIGZhbHNlOyAvLyBub3QgYSBmdW5jdGlvblxuXHR9XG59O1xuXG52YXIgdHJ5RnVuY3Rpb25PYmplY3QgPSBmdW5jdGlvbiB0cnlGdW5jdGlvblRvU3RyKHZhbHVlKSB7XG5cdHRyeSB7XG5cdFx0aWYgKGlzRVM2Q2xhc3NGbih2YWx1ZSkpIHsgcmV0dXJuIGZhbHNlOyB9XG5cdFx0Zm5Ub1N0ci5jYWxsKHZhbHVlKTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufTtcbnZhciB0b1N0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG52YXIgb2JqZWN0Q2xhc3MgPSAnW29iamVjdCBPYmplY3RdJztcbnZhciBmbkNsYXNzID0gJ1tvYmplY3QgRnVuY3Rpb25dJztcbnZhciBnZW5DbGFzcyA9ICdbb2JqZWN0IEdlbmVyYXRvckZ1bmN0aW9uXSc7XG52YXIgZGRhQ2xhc3MgPSAnW29iamVjdCBIVE1MQWxsQ29sbGVjdGlvbl0nOyAvLyBJRSAxMVxudmFyIGRkYUNsYXNzMiA9ICdbb2JqZWN0IEhUTUwgZG9jdW1lbnQuYWxsIGNsYXNzXSc7XG52YXIgZGRhQ2xhc3MzID0gJ1tvYmplY3QgSFRNTENvbGxlY3Rpb25dJzsgLy8gSUUgOS0xMFxudmFyIGhhc1RvU3RyaW5nVGFnID0gdHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiAhIVN5bWJvbC50b1N0cmluZ1RhZzsgLy8gYmV0dGVyOiB1c2UgYGhhcy10b3N0cmluZ3RhZ2BcblxudmFyIGlzSUU2OCA9ICEoMCBpbiBbLF0pOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXNwYXJzZS1hcnJheXMsIGNvbW1hLXNwYWNpbmdcblxudmFyIGlzRERBID0gZnVuY3Rpb24gaXNEb2N1bWVudERvdEFsbCgpIHsgcmV0dXJuIGZhbHNlOyB9O1xuaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ29iamVjdCcpIHtcblx0Ly8gRmlyZWZveCAzIGNhbm9uaWNhbGl6ZXMgRERBIHRvIHVuZGVmaW5lZCB3aGVuIGl0J3Mgbm90IGFjY2Vzc2VkIGRpcmVjdGx5XG5cdHZhciBhbGwgPSBkb2N1bWVudC5hbGw7XG5cdGlmICh0b1N0ci5jYWxsKGFsbCkgPT09IHRvU3RyLmNhbGwoZG9jdW1lbnQuYWxsKSkge1xuXHRcdGlzRERBID0gZnVuY3Rpb24gaXNEb2N1bWVudERvdEFsbCh2YWx1ZSkge1xuXHRcdFx0LyogZ2xvYmFscyBkb2N1bWVudDogZmFsc2UgKi9cblx0XHRcdC8vIGluIElFIDYtOCwgdHlwZW9mIGRvY3VtZW50LmFsbCBpcyBcIm9iamVjdFwiIGFuZCBpdCdzIHRydXRoeVxuXHRcdFx0aWYgKChpc0lFNjggfHwgIXZhbHVlKSAmJiAodHlwZW9mIHZhbHVlID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHZhciBzdHIgPSB0b1N0ci5jYWxsKHZhbHVlKTtcblx0XHRcdFx0XHRyZXR1cm4gKFxuXHRcdFx0XHRcdFx0c3RyID09PSBkZGFDbGFzc1xuXHRcdFx0XHRcdFx0fHwgc3RyID09PSBkZGFDbGFzczJcblx0XHRcdFx0XHRcdHx8IHN0ciA9PT0gZGRhQ2xhc3MzIC8vIG9wZXJhIDEyLjE2XG5cdFx0XHRcdFx0XHR8fCBzdHIgPT09IG9iamVjdENsYXNzIC8vIElFIDYtOFxuXHRcdFx0XHRcdCkgJiYgdmFsdWUoJycpID09IG51bGw7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZXFlcWVxXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHsgLyoqLyB9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fTtcblx0fVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHJlZmxlY3RBcHBseVxuXHQ/IGZ1bmN0aW9uIGlzQ2FsbGFibGUodmFsdWUpIHtcblx0XHRpZiAoaXNEREEodmFsdWUpKSB7IHJldHVybiB0cnVlOyB9XG5cdFx0aWYgKCF2YWx1ZSkgeyByZXR1cm4gZmFsc2U7IH1cblx0XHRpZiAodHlwZW9mIHZhbHVlICE9PSAnZnVuY3Rpb24nICYmIHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpIHsgcmV0dXJuIGZhbHNlOyB9XG5cdFx0dHJ5IHtcblx0XHRcdHJlZmxlY3RBcHBseSh2YWx1ZSwgbnVsbCwgYmFkQXJyYXlMaWtlKTtcblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRpZiAoZSAhPT0gaXNDYWxsYWJsZU1hcmtlcikgeyByZXR1cm4gZmFsc2U7IH1cblx0XHR9XG5cdFx0cmV0dXJuICFpc0VTNkNsYXNzRm4odmFsdWUpICYmIHRyeUZ1bmN0aW9uT2JqZWN0KHZhbHVlKTtcblx0fVxuXHQ6IGZ1bmN0aW9uIGlzQ2FsbGFibGUodmFsdWUpIHtcblx0XHRpZiAoaXNEREEodmFsdWUpKSB7IHJldHVybiB0cnVlOyB9XG5cdFx0aWYgKCF2YWx1ZSkgeyByZXR1cm4gZmFsc2U7IH1cblx0XHRpZiAodHlwZW9mIHZhbHVlICE9PSAnZnVuY3Rpb24nICYmIHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpIHsgcmV0dXJuIGZhbHNlOyB9XG5cdFx0aWYgKGhhc1RvU3RyaW5nVGFnKSB7IHJldHVybiB0cnlGdW5jdGlvbk9iamVjdCh2YWx1ZSk7IH1cblx0XHRpZiAoaXNFUzZDbGFzc0ZuKHZhbHVlKSkgeyByZXR1cm4gZmFsc2U7IH1cblx0XHR2YXIgc3RyQ2xhc3MgPSB0b1N0ci5jYWxsKHZhbHVlKTtcblx0XHRpZiAoc3RyQ2xhc3MgIT09IGZuQ2xhc3MgJiYgc3RyQ2xhc3MgIT09IGdlbkNsYXNzICYmICEoL15cXFtvYmplY3QgSFRNTC8pLnRlc3Qoc3RyQ2xhc3MpKSB7IHJldHVybiBmYWxzZTsgfVxuXHRcdHJldHVybiB0cnlGdW5jdGlvbk9iamVjdCh2YWx1ZSk7XG5cdH07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgaXNDYWxsYWJsZSA9IHJlcXVpcmUoJ2lzLWNhbGxhYmxlJyk7XG5cbnZhciB0b1N0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG52YXIgaGFzT3duUHJvcGVydHkgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG52YXIgZm9yRWFjaEFycmF5ID0gZnVuY3Rpb24gZm9yRWFjaEFycmF5KGFycmF5LCBpdGVyYXRvciwgcmVjZWl2ZXIpIHtcbiAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gYXJyYXkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgaWYgKGhhc093blByb3BlcnR5LmNhbGwoYXJyYXksIGkpKSB7XG4gICAgICAgICAgICBpZiAocmVjZWl2ZXIgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIGl0ZXJhdG9yKGFycmF5W2ldLCBpLCBhcnJheSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGl0ZXJhdG9yLmNhbGwocmVjZWl2ZXIsIGFycmF5W2ldLCBpLCBhcnJheSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59O1xuXG52YXIgZm9yRWFjaFN0cmluZyA9IGZ1bmN0aW9uIGZvckVhY2hTdHJpbmcoc3RyaW5nLCBpdGVyYXRvciwgcmVjZWl2ZXIpIHtcbiAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gc3RyaW5nLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIC8vIG5vIHN1Y2ggdGhpbmcgYXMgYSBzcGFyc2Ugc3RyaW5nLlxuICAgICAgICBpZiAocmVjZWl2ZXIgPT0gbnVsbCkge1xuICAgICAgICAgICAgaXRlcmF0b3Ioc3RyaW5nLmNoYXJBdChpKSwgaSwgc3RyaW5nKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGl0ZXJhdG9yLmNhbGwocmVjZWl2ZXIsIHN0cmluZy5jaGFyQXQoaSksIGksIHN0cmluZyk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuXG52YXIgZm9yRWFjaE9iamVjdCA9IGZ1bmN0aW9uIGZvckVhY2hPYmplY3Qob2JqZWN0LCBpdGVyYXRvciwgcmVjZWl2ZXIpIHtcbiAgICBmb3IgKHZhciBrIGluIG9iamVjdCkge1xuICAgICAgICBpZiAoaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIGspKSB7XG4gICAgICAgICAgICBpZiAocmVjZWl2ZXIgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIGl0ZXJhdG9yKG9iamVjdFtrXSwgaywgb2JqZWN0KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaXRlcmF0b3IuY2FsbChyZWNlaXZlciwgb2JqZWN0W2tdLCBrLCBvYmplY3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufTtcblxudmFyIGZvckVhY2ggPSBmdW5jdGlvbiBmb3JFYWNoKGxpc3QsIGl0ZXJhdG9yLCB0aGlzQXJnKSB7XG4gICAgaWYgKCFpc0NhbGxhYmxlKGl0ZXJhdG9yKSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdpdGVyYXRvciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcbiAgICB9XG5cbiAgICB2YXIgcmVjZWl2ZXI7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPj0gMykge1xuICAgICAgICByZWNlaXZlciA9IHRoaXNBcmc7XG4gICAgfVxuXG4gICAgaWYgKHRvU3RyLmNhbGwobGlzdCkgPT09ICdbb2JqZWN0IEFycmF5XScpIHtcbiAgICAgICAgZm9yRWFjaEFycmF5KGxpc3QsIGl0ZXJhdG9yLCByZWNlaXZlcik7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgbGlzdCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgZm9yRWFjaFN0cmluZyhsaXN0LCBpdGVyYXRvciwgcmVjZWl2ZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGZvckVhY2hPYmplY3QobGlzdCwgaXRlcmF0b3IsIHJlY2VpdmVyKTtcbiAgICB9XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZvckVhY2g7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBbXG5cdCdGbG9hdDMyQXJyYXknLFxuXHQnRmxvYXQ2NEFycmF5Jyxcblx0J0ludDhBcnJheScsXG5cdCdJbnQxNkFycmF5Jyxcblx0J0ludDMyQXJyYXknLFxuXHQnVWludDhBcnJheScsXG5cdCdVaW50OENsYW1wZWRBcnJheScsXG5cdCdVaW50MTZBcnJheScsXG5cdCdVaW50MzJBcnJheScsXG5cdCdCaWdJbnQ2NEFycmF5Jyxcblx0J0JpZ1VpbnQ2NEFycmF5J1xuXTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBwb3NzaWJsZU5hbWVzID0gcmVxdWlyZSgncG9zc2libGUtdHlwZWQtYXJyYXktbmFtZXMnKTtcblxudmFyIGcgPSB0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ3VuZGVmaW5lZCcgPyBnbG9iYWwgOiBnbG9iYWxUaGlzO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnLicpfSAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBhdmFpbGFibGVUeXBlZEFycmF5cygpIHtcblx0dmFyIC8qKiBAdHlwZSB7UmV0dXJuVHlwZTx0eXBlb2YgYXZhaWxhYmxlVHlwZWRBcnJheXM+fSAqLyBvdXQgPSBbXTtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBwb3NzaWJsZU5hbWVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0aWYgKHR5cGVvZiBnW3Bvc3NpYmxlTmFtZXNbaV1dID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHQvLyBAdHMtZXhwZWN0LWVycm9yXG5cdFx0XHRvdXRbb3V0Lmxlbmd0aF0gPSBwb3NzaWJsZU5hbWVzW2ldO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gb3V0O1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBmb3JFYWNoID0gcmVxdWlyZSgnZm9yLWVhY2gnKTtcbnZhciBhdmFpbGFibGVUeXBlZEFycmF5cyA9IHJlcXVpcmUoJ2F2YWlsYWJsZS10eXBlZC1hcnJheXMnKTtcbnZhciBjYWxsQmluZCA9IHJlcXVpcmUoJ2NhbGwtYmluZCcpO1xudmFyIGNhbGxCb3VuZCA9IHJlcXVpcmUoJ2NhbGwtYmluZC9jYWxsQm91bmQnKTtcbnZhciBnT1BEID0gcmVxdWlyZSgnZ29wZCcpO1xuXG4vKiogQHR5cGUgeyhPOiBvYmplY3QpID0+IHN0cmluZ30gKi9cbnZhciAkdG9TdHJpbmcgPSBjYWxsQm91bmQoJ09iamVjdC5wcm90b3R5cGUudG9TdHJpbmcnKTtcbnZhciBoYXNUb1N0cmluZ1RhZyA9IHJlcXVpcmUoJ2hhcy10b3N0cmluZ3RhZy9zaGFtcycpKCk7XG5cbnZhciBnID0gdHlwZW9mIGdsb2JhbFRoaXMgPT09ICd1bmRlZmluZWQnID8gZ2xvYmFsIDogZ2xvYmFsVGhpcztcbnZhciB0eXBlZEFycmF5cyA9IGF2YWlsYWJsZVR5cGVkQXJyYXlzKCk7XG5cbnZhciAkc2xpY2UgPSBjYWxsQm91bmQoJ1N0cmluZy5wcm90b3R5cGUuc2xpY2UnKTtcbnZhciBnZXRQcm90b3R5cGVPZiA9IE9iamVjdC5nZXRQcm90b3R5cGVPZjsgLy8gcmVxdWlyZSgnZ2V0cHJvdG90eXBlb2YnKTtcblxuLyoqIEB0eXBlIHs8VCA9IHVua25vd24+KGFycmF5OiByZWFkb25seSBUW10sIHZhbHVlOiB1bmtub3duKSA9PiBudW1iZXJ9ICovXG52YXIgJGluZGV4T2YgPSBjYWxsQm91bmQoJ0FycmF5LnByb3RvdHlwZS5pbmRleE9mJywgdHJ1ZSkgfHwgZnVuY3Rpb24gaW5kZXhPZihhcnJheSwgdmFsdWUpIHtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBhcnJheS5sZW5ndGg7IGkgKz0gMSkge1xuXHRcdGlmIChhcnJheVtpXSA9PT0gdmFsdWUpIHtcblx0XHRcdHJldHVybiBpO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gLTE7XG59O1xuXG4vKiogQHR5cGVkZWYgeyhyZWNlaXZlcjogaW1wb3J0KCcuJykuVHlwZWRBcnJheSkgPT4gc3RyaW5nIHwgdHlwZW9mIFVpbnQ4QXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwgfCB0eXBlb2YgVWludDhBcnJheS5wcm90b3R5cGUuc2V0LmNhbGx9IEdldHRlciAqL1xuLyoqIEB0eXBlIHt7IFtrIGluIGBcXCQke2ltcG9ydCgnLicpLlR5cGVkQXJyYXlOYW1lfWBdPzogR2V0dGVyIH0gJiB7IF9fcHJvdG9fXzogbnVsbCB9fSAqL1xudmFyIGNhY2hlID0geyBfX3Byb3RvX186IG51bGwgfTtcbmlmIChoYXNUb1N0cmluZ1RhZyAmJiBnT1BEICYmIGdldFByb3RvdHlwZU9mKSB7XG5cdGZvckVhY2godHlwZWRBcnJheXMsIGZ1bmN0aW9uICh0eXBlZEFycmF5KSB7XG5cdFx0dmFyIGFyciA9IG5ldyBnW3R5cGVkQXJyYXldKCk7XG5cdFx0aWYgKFN5bWJvbC50b1N0cmluZ1RhZyBpbiBhcnIpIHtcblx0XHRcdHZhciBwcm90byA9IGdldFByb3RvdHlwZU9mKGFycik7XG5cdFx0XHQvLyBAdHMtZXhwZWN0LWVycm9yIFRTIHdvbid0IG5hcnJvdyBpbnNpZGUgYSBjbG9zdXJlXG5cdFx0XHR2YXIgZGVzY3JpcHRvciA9IGdPUEQocHJvdG8sIFN5bWJvbC50b1N0cmluZ1RhZyk7XG5cdFx0XHRpZiAoIWRlc2NyaXB0b3IpIHtcblx0XHRcdFx0dmFyIHN1cGVyUHJvdG8gPSBnZXRQcm90b3R5cGVPZihwcm90byk7XG5cdFx0XHRcdC8vIEB0cy1leHBlY3QtZXJyb3IgVFMgd29uJ3QgbmFycm93IGluc2lkZSBhIGNsb3N1cmVcblx0XHRcdFx0ZGVzY3JpcHRvciA9IGdPUEQoc3VwZXJQcm90bywgU3ltYm9sLnRvU3RyaW5nVGFnKTtcblx0XHRcdH1cblx0XHRcdC8vIEB0cy1leHBlY3QtZXJyb3IgVE9ETzogZml4XG5cdFx0XHRjYWNoZVsnJCcgKyB0eXBlZEFycmF5XSA9IGNhbGxCaW5kKGRlc2NyaXB0b3IuZ2V0KTtcblx0XHR9XG5cdH0pO1xufSBlbHNlIHtcblx0Zm9yRWFjaCh0eXBlZEFycmF5cywgZnVuY3Rpb24gKHR5cGVkQXJyYXkpIHtcblx0XHR2YXIgYXJyID0gbmV3IGdbdHlwZWRBcnJheV0oKTtcblx0XHR2YXIgZm4gPSBhcnIuc2xpY2UgfHwgYXJyLnNldDtcblx0XHRpZiAoZm4pIHtcblx0XHRcdC8vIEB0cy1leHBlY3QtZXJyb3IgVE9ETzogZml4XG5cdFx0XHRjYWNoZVsnJCcgKyB0eXBlZEFycmF5XSA9IGNhbGxCaW5kKGZuKTtcblx0XHR9XG5cdH0pO1xufVxuXG4vKiogQHR5cGUgeyh2YWx1ZTogb2JqZWN0KSA9PiBmYWxzZSB8IGltcG9ydCgnLicpLlR5cGVkQXJyYXlOYW1lfSAqL1xudmFyIHRyeVR5cGVkQXJyYXlzID0gZnVuY3Rpb24gdHJ5QWxsVHlwZWRBcnJheXModmFsdWUpIHtcblx0LyoqIEB0eXBlIHtSZXR1cm5UeXBlPHR5cGVvZiB0cnlBbGxUeXBlZEFycmF5cz59ICovIHZhciBmb3VuZCA9IGZhbHNlO1xuXHRmb3JFYWNoKFxuXHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1leHRyYS1wYXJlbnNcblx0XHQvKiogQHR5cGUge1JlY29yZDxgXFwkJHtUeXBlZEFycmF5TmFtZX1gLCBHZXR0ZXI+fSAqLyAvKiogQHR5cGUge2FueX0gKi8gKGNhY2hlKSxcblx0XHQvKiogQHR5cGUgeyhnZXR0ZXI6IEdldHRlciwgbmFtZTogYFxcJCR7aW1wb3J0KCcuJykuVHlwZWRBcnJheU5hbWV9YCkgPT4gdm9pZH0gKi9cblx0XHRmdW5jdGlvbiAoZ2V0dGVyLCB0eXBlZEFycmF5KSB7XG5cdFx0XHRpZiAoIWZvdW5kKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdC8vIEB0cy1leHBlY3QtZXJyb3IgVE9ETzogZml4XG5cdFx0XHRcdFx0aWYgKCckJyArIGdldHRlcih2YWx1ZSkgPT09IHR5cGVkQXJyYXkpIHtcblx0XHRcdFx0XHRcdGZvdW5kID0gJHNsaWNlKHR5cGVkQXJyYXksIDEpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBjYXRjaCAoZSkgeyAvKiovIH1cblx0XHRcdH1cblx0XHR9XG5cdCk7XG5cdHJldHVybiBmb3VuZDtcbn07XG5cbi8qKiBAdHlwZSB7KHZhbHVlOiBvYmplY3QpID0+IGZhbHNlIHwgaW1wb3J0KCcuJykuVHlwZWRBcnJheU5hbWV9ICovXG52YXIgdHJ5U2xpY2VzID0gZnVuY3Rpb24gdHJ5QWxsU2xpY2VzKHZhbHVlKSB7XG5cdC8qKiBAdHlwZSB7UmV0dXJuVHlwZTx0eXBlb2YgdHJ5QWxsU2xpY2VzPn0gKi8gdmFyIGZvdW5kID0gZmFsc2U7XG5cdGZvckVhY2goXG5cdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWV4dHJhLXBhcmVuc1xuXHRcdC8qKiBAdHlwZSB7UmVjb3JkPGBcXCQke1R5cGVkQXJyYXlOYW1lfWAsIEdldHRlcj59ICovIC8qKiBAdHlwZSB7YW55fSAqLyAoY2FjaGUpLFxuXHRcdC8qKiBAdHlwZSB7KGdldHRlcjogdHlwZW9mIGNhY2hlLCBuYW1lOiBgXFwkJHtpbXBvcnQoJy4nKS5UeXBlZEFycmF5TmFtZX1gKSA9PiB2b2lkfSAqLyBmdW5jdGlvbiAoZ2V0dGVyLCBuYW1lKSB7XG5cdFx0XHRpZiAoIWZvdW5kKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Ly8gQHRzLWV4cGVjdC1lcnJvciBUT0RPOiBmaXhcblx0XHRcdFx0XHRnZXR0ZXIodmFsdWUpO1xuXHRcdFx0XHRcdGZvdW5kID0gJHNsaWNlKG5hbWUsIDEpO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7IC8qKi8gfVxuXHRcdFx0fVxuXHRcdH1cblx0KTtcblx0cmV0dXJuIGZvdW5kO1xufTtcblxuLyoqIEB0eXBlIHtpbXBvcnQoJy4nKX0gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gd2hpY2hUeXBlZEFycmF5KHZhbHVlKSB7XG5cdGlmICghdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JykgeyByZXR1cm4gZmFsc2U7IH1cblx0aWYgKCFoYXNUb1N0cmluZ1RhZykge1xuXHRcdC8qKiBAdHlwZSB7c3RyaW5nfSAqL1xuXHRcdHZhciB0YWcgPSAkc2xpY2UoJHRvU3RyaW5nKHZhbHVlKSwgOCwgLTEpO1xuXHRcdGlmICgkaW5kZXhPZih0eXBlZEFycmF5cywgdGFnKSA+IC0xKSB7XG5cdFx0XHRyZXR1cm4gdGFnO1xuXHRcdH1cblx0XHRpZiAodGFnICE9PSAnT2JqZWN0Jykge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHQvLyBub2RlIDwgMC42IGhpdHMgaGVyZSBvbiByZWFsIFR5cGVkIEFycmF5c1xuXHRcdHJldHVybiB0cnlTbGljZXModmFsdWUpO1xuXHR9XG5cdGlmICghZ09QRCkgeyByZXR1cm4gbnVsbDsgfSAvLyB1bmtub3duIGVuZ2luZVxuXHRyZXR1cm4gdHJ5VHlwZWRBcnJheXModmFsdWUpO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBjYWxsQm91bmQgPSByZXF1aXJlKCdjYWxsLWJpbmQvY2FsbEJvdW5kJyk7XG52YXIgJGJ5dGVMZW5ndGggPSBjYWxsQm91bmQoJ0FycmF5QnVmZmVyLnByb3RvdHlwZS5ieXRlTGVuZ3RoJywgdHJ1ZSk7XG5cbnZhciBpc0FycmF5QnVmZmVyID0gcmVxdWlyZSgnaXMtYXJyYXktYnVmZmVyJyk7XG5cbi8qKiBAdHlwZSB7aW1wb3J0KCcuJyl9ICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGJ5dGVMZW5ndGgoYWIpIHtcblx0aWYgKCFpc0FycmF5QnVmZmVyKGFiKSkge1xuXHRcdHJldHVybiBOYU47XG5cdH1cblx0cmV0dXJuICRieXRlTGVuZ3RoID8gJGJ5dGVMZW5ndGgoYWIpIDogYWIuYnl0ZUxlbmd0aDtcbn07IC8vIGluIG5vZGUgPCAwLjExLCBieXRlTGVuZ3RoIGlzIGFuIG93biBub25jb25maWd1cmFibGUgcHJvcGVydHlcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBhc3NpZ24gPSByZXF1aXJlKCdvYmplY3QuYXNzaWduJyk7XG52YXIgY2FsbEJvdW5kID0gcmVxdWlyZSgnY2FsbC1iaW5kL2NhbGxCb3VuZCcpO1xudmFyIGZsYWdzID0gcmVxdWlyZSgncmVnZXhwLnByb3RvdHlwZS5mbGFncycpO1xudmFyIEdldEludHJpbnNpYyA9IHJlcXVpcmUoJ2dldC1pbnRyaW5zaWMnKTtcbnZhciBnZXRJdGVyYXRvciA9IHJlcXVpcmUoJ2VzLWdldC1pdGVyYXRvcicpO1xudmFyIGdldFNpZGVDaGFubmVsID0gcmVxdWlyZSgnc2lkZS1jaGFubmVsJyk7XG52YXIgaXMgPSByZXF1aXJlKCdvYmplY3QtaXMnKTtcbnZhciBpc0FyZ3VtZW50cyA9IHJlcXVpcmUoJ2lzLWFyZ3VtZW50cycpO1xudmFyIGlzQXJyYXkgPSByZXF1aXJlKCdpc2FycmF5Jyk7XG52YXIgaXNBcnJheUJ1ZmZlciA9IHJlcXVpcmUoJ2lzLWFycmF5LWJ1ZmZlcicpO1xudmFyIGlzRGF0ZSA9IHJlcXVpcmUoJ2lzLWRhdGUtb2JqZWN0Jyk7XG52YXIgaXNSZWdleCA9IHJlcXVpcmUoJ2lzLXJlZ2V4Jyk7XG52YXIgaXNTaGFyZWRBcnJheUJ1ZmZlciA9IHJlcXVpcmUoJ2lzLXNoYXJlZC1hcnJheS1idWZmZXInKTtcbnZhciBvYmplY3RLZXlzID0gcmVxdWlyZSgnb2JqZWN0LWtleXMnKTtcbnZhciB3aGljaEJveGVkUHJpbWl0aXZlID0gcmVxdWlyZSgnd2hpY2gtYm94ZWQtcHJpbWl0aXZlJyk7XG52YXIgd2hpY2hDb2xsZWN0aW9uID0gcmVxdWlyZSgnd2hpY2gtY29sbGVjdGlvbicpO1xudmFyIHdoaWNoVHlwZWRBcnJheSA9IHJlcXVpcmUoJ3doaWNoLXR5cGVkLWFycmF5Jyk7XG52YXIgYnl0ZUxlbmd0aCA9IHJlcXVpcmUoJ2FycmF5LWJ1ZmZlci1ieXRlLWxlbmd0aCcpO1xuXG52YXIgc2FiQnl0ZUxlbmd0aCA9IGNhbGxCb3VuZCgnU2hhcmVkQXJyYXlCdWZmZXIucHJvdG90eXBlLmJ5dGVMZW5ndGgnLCB0cnVlKTtcblxudmFyICRnZXRUaW1lID0gY2FsbEJvdW5kKCdEYXRlLnByb3RvdHlwZS5nZXRUaW1lJyk7XG52YXIgZ1BPID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyICRvYmpUb1N0cmluZyA9IGNhbGxCb3VuZCgnT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZycpO1xuXG52YXIgJFNldCA9IEdldEludHJpbnNpYygnJVNldCUnLCB0cnVlKTtcbnZhciAkbWFwSGFzID0gY2FsbEJvdW5kKCdNYXAucHJvdG90eXBlLmhhcycsIHRydWUpO1xudmFyICRtYXBHZXQgPSBjYWxsQm91bmQoJ01hcC5wcm90b3R5cGUuZ2V0JywgdHJ1ZSk7XG52YXIgJG1hcFNpemUgPSBjYWxsQm91bmQoJ01hcC5wcm90b3R5cGUuc2l6ZScsIHRydWUpO1xudmFyICRzZXRBZGQgPSBjYWxsQm91bmQoJ1NldC5wcm90b3R5cGUuYWRkJywgdHJ1ZSk7XG52YXIgJHNldERlbGV0ZSA9IGNhbGxCb3VuZCgnU2V0LnByb3RvdHlwZS5kZWxldGUnLCB0cnVlKTtcbnZhciAkc2V0SGFzID0gY2FsbEJvdW5kKCdTZXQucHJvdG90eXBlLmhhcycsIHRydWUpO1xudmFyICRzZXRTaXplID0gY2FsbEJvdW5kKCdTZXQucHJvdG90eXBlLnNpemUnLCB0cnVlKTtcblxuLy8gdGFrZW4gZnJvbSBodHRwczovL2dpdGh1Yi5jb20vYnJvd3NlcmlmeS9jb21tb25qcy1hc3NlcnQvYmxvYi9iYmE4MzhlOWJhOWUyOGVkZjMxMjdjZTY5NzQ2MjQyMDg1MDJmNmJjL2ludGVybmFsL3V0aWwvY29tcGFyaXNvbnMuanMjTDQwMS1MNDE0XG5mdW5jdGlvbiBzZXRIYXNFcXVhbEVsZW1lbnQoc2V0LCB2YWwxLCBvcHRzLCBjaGFubmVsKSB7XG4gIHZhciBpID0gZ2V0SXRlcmF0b3Ioc2V0KTtcbiAgdmFyIHJlc3VsdDtcbiAgd2hpbGUgKChyZXN1bHQgPSBpLm5leHQoKSkgJiYgIXJlc3VsdC5kb25lKSB7XG4gICAgaWYgKGludGVybmFsRGVlcEVxdWFsKHZhbDEsIHJlc3VsdC52YWx1ZSwgb3B0cywgY2hhbm5lbCkpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11c2UtYmVmb3JlLWRlZmluZVxuICAgICAgLy8gUmVtb3ZlIHRoZSBtYXRjaGluZyBlbGVtZW50IHRvIG1ha2Ugc3VyZSB3ZSBkbyBub3QgY2hlY2sgdGhhdCBhZ2Fpbi5cbiAgICAgICRzZXREZWxldGUoc2V0LCByZXN1bHQudmFsdWUpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyB0YWtlbiBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9icm93c2VyaWZ5L2NvbW1vbmpzLWFzc2VydC9ibG9iL2JiYTgzOGU5YmE5ZTI4ZWRmMzEyN2NlNjk3NDYyNDIwODUwMmY2YmMvaW50ZXJuYWwvdXRpbC9jb21wYXJpc29ucy5qcyNMNDE2LUw0MzlcbmZ1bmN0aW9uIGZpbmRMb29zZU1hdGNoaW5nUHJpbWl0aXZlcyhwcmltKSB7XG4gIGlmICh0eXBlb2YgcHJpbSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAodHlwZW9mIHByaW0gPT09ICdvYmplY3QnKSB7IC8vIE9ubHkgcGFzcyBpbiBudWxsIGFzIG9iamVjdCFcbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG4gIGlmICh0eXBlb2YgcHJpbSA9PT0gJ3N5bWJvbCcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKHR5cGVvZiBwcmltID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgcHJpbSA9PT0gJ251bWJlcicpIHtcbiAgICAvLyBMb29zZSBlcXVhbCBlbnRyaWVzIGV4aXN0IG9ubHkgaWYgdGhlIHN0cmluZyBpcyBwb3NzaWJsZSB0byBjb252ZXJ0IHRvIGEgcmVndWxhciBudW1iZXIgYW5kIG5vdCBOYU4uXG4gICAgcmV0dXJuICtwcmltID09PSArcHJpbTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1pbXBsaWNpdC1jb2VyY2lvblxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyB0YWtlbiBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9icm93c2VyaWZ5L2NvbW1vbmpzLWFzc2VydC9ibG9iL2JiYTgzOGU5YmE5ZTI4ZWRmMzEyN2NlNjk3NDYyNDIwODUwMmY2YmMvaW50ZXJuYWwvdXRpbC9jb21wYXJpc29ucy5qcyNMNDQ5LUw0NjBcbmZ1bmN0aW9uIG1hcE1pZ2h0SGF2ZUxvb3NlUHJpbShhLCBiLCBwcmltLCBpdGVtLCBvcHRzLCBjaGFubmVsKSB7XG4gIHZhciBhbHRWYWx1ZSA9IGZpbmRMb29zZU1hdGNoaW5nUHJpbWl0aXZlcyhwcmltKTtcbiAgaWYgKGFsdFZhbHVlICE9IG51bGwpIHtcbiAgICByZXR1cm4gYWx0VmFsdWU7XG4gIH1cbiAgdmFyIGN1ckIgPSAkbWFwR2V0KGIsIGFsdFZhbHVlKTtcbiAgdmFyIGxvb3NlT3B0cyA9IGFzc2lnbih7fSwgb3B0cywgeyBzdHJpY3Q6IGZhbHNlIH0pO1xuICBpZiAoXG4gICAgKHR5cGVvZiBjdXJCID09PSAndW5kZWZpbmVkJyAmJiAhJG1hcEhhcyhiLCBhbHRWYWx1ZSkpXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lXG4gICAgfHwgIWludGVybmFsRGVlcEVxdWFsKGl0ZW0sIGN1ckIsIGxvb3NlT3B0cywgY2hhbm5lbClcbiAgKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2UtYmVmb3JlLWRlZmluZVxuICByZXR1cm4gISRtYXBIYXMoYSwgYWx0VmFsdWUpICYmIGludGVybmFsRGVlcEVxdWFsKGl0ZW0sIGN1ckIsIGxvb3NlT3B0cywgY2hhbm5lbCk7XG59XG5cbi8vIHRha2VuIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2Jyb3dzZXJpZnkvY29tbW9uanMtYXNzZXJ0L2Jsb2IvYmJhODM4ZTliYTllMjhlZGYzMTI3Y2U2OTc0NjI0MjA4NTAyZjZiYy9pbnRlcm5hbC91dGlsL2NvbXBhcmlzb25zLmpzI0w0NDEtTDQ0N1xuZnVuY3Rpb24gc2V0TWlnaHRIYXZlTG9vc2VQcmltKGEsIGIsIHByaW0pIHtcbiAgdmFyIGFsdFZhbHVlID0gZmluZExvb3NlTWF0Y2hpbmdQcmltaXRpdmVzKHByaW0pO1xuICBpZiAoYWx0VmFsdWUgIT0gbnVsbCkge1xuICAgIHJldHVybiBhbHRWYWx1ZTtcbiAgfVxuXG4gIHJldHVybiAkc2V0SGFzKGIsIGFsdFZhbHVlKSAmJiAhJHNldEhhcyhhLCBhbHRWYWx1ZSk7XG59XG5cbi8vIHRha2VuIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2Jyb3dzZXJpZnkvY29tbW9uanMtYXNzZXJ0L2Jsb2IvYmJhODM4ZTliYTllMjhlZGYzMTI3Y2U2OTc0NjI0MjA4NTAyZjZiYy9pbnRlcm5hbC91dGlsL2NvbXBhcmlzb25zLmpzI0w1MTgtTDUzM1xuZnVuY3Rpb24gbWFwSGFzRXF1YWxFbnRyeShzZXQsIG1hcCwga2V5MSwgaXRlbTEsIG9wdHMsIGNoYW5uZWwpIHtcbiAgdmFyIGkgPSBnZXRJdGVyYXRvcihzZXQpO1xuICB2YXIgcmVzdWx0O1xuICB2YXIga2V5MjtcbiAgd2hpbGUgKChyZXN1bHQgPSBpLm5leHQoKSkgJiYgIXJlc3VsdC5kb25lKSB7XG4gICAga2V5MiA9IHJlc3VsdC52YWx1ZTtcbiAgICBpZiAoXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlLWJlZm9yZS1kZWZpbmVcbiAgICAgIGludGVybmFsRGVlcEVxdWFsKGtleTEsIGtleTIsIG9wdHMsIGNoYW5uZWwpXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlLWJlZm9yZS1kZWZpbmVcbiAgICAgICYmIGludGVybmFsRGVlcEVxdWFsKGl0ZW0xLCAkbWFwR2V0KG1hcCwga2V5MiksIG9wdHMsIGNoYW5uZWwpXG4gICAgKSB7XG4gICAgICAkc2V0RGVsZXRlKHNldCwga2V5Mik7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIGludGVybmFsRGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG9wdGlvbnMsIGNoYW5uZWwpIHtcbiAgdmFyIG9wdHMgPSBvcHRpb25zIHx8IHt9O1xuXG4gIC8vIDcuMS4gQWxsIGlkZW50aWNhbCB2YWx1ZXMgYXJlIGVxdWl2YWxlbnQsIGFzIGRldGVybWluZWQgYnkgPT09LlxuICBpZiAob3B0cy5zdHJpY3QgPyBpcyhhY3R1YWwsIGV4cGVjdGVkKSA6IGFjdHVhbCA9PT0gZXhwZWN0ZWQpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHZhciBhY3R1YWxCb3hlZCA9IHdoaWNoQm94ZWRQcmltaXRpdmUoYWN0dWFsKTtcbiAgdmFyIGV4cGVjdGVkQm94ZWQgPSB3aGljaEJveGVkUHJpbWl0aXZlKGV4cGVjdGVkKTtcbiAgaWYgKGFjdHVhbEJveGVkICE9PSBleHBlY3RlZEJveGVkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLy8gNy4zLiBPdGhlciBwYWlycyB0aGF0IGRvIG5vdCBib3RoIHBhc3MgdHlwZW9mIHZhbHVlID09ICdvYmplY3QnLCBlcXVpdmFsZW5jZSBpcyBkZXRlcm1pbmVkIGJ5ID09LlxuICBpZiAoIWFjdHVhbCB8fCAhZXhwZWN0ZWQgfHwgKHR5cGVvZiBhY3R1YWwgIT09ICdvYmplY3QnICYmIHR5cGVvZiBleHBlY3RlZCAhPT0gJ29iamVjdCcpKSB7XG4gICAgcmV0dXJuIG9wdHMuc3RyaWN0ID8gaXMoYWN0dWFsLCBleHBlY3RlZCkgOiBhY3R1YWwgPT0gZXhwZWN0ZWQ7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgZXFlcWVxXG4gIH1cblxuICAvKlxuICAgKiA3LjQuIEZvciBhbGwgb3RoZXIgT2JqZWN0IHBhaXJzLCBpbmNsdWRpbmcgQXJyYXkgb2JqZWN0cywgZXF1aXZhbGVuY2UgaXNcbiAgICogZGV0ZXJtaW5lZCBieSBoYXZpbmcgdGhlIHNhbWUgbnVtYmVyIG9mIG93bmVkIHByb3BlcnRpZXMgKGFzIHZlcmlmaWVkXG4gICAqIHdpdGggT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKSwgdGhlIHNhbWUgc2V0IG9mIGtleXNcbiAgICogKGFsdGhvdWdoIG5vdCBuZWNlc3NhcmlseSB0aGUgc2FtZSBvcmRlciksIGVxdWl2YWxlbnQgdmFsdWVzIGZvciBldmVyeVxuICAgKiBjb3JyZXNwb25kaW5nIGtleSwgYW5kIGFuIGlkZW50aWNhbCAncHJvdG90eXBlJyBwcm9wZXJ0eS4gTm90ZTogdGhpc1xuICAgKiBhY2NvdW50cyBmb3IgYm90aCBuYW1lZCBhbmQgaW5kZXhlZCBwcm9wZXJ0aWVzIG9uIEFycmF5cy5cbiAgICovXG4gIC8vIHNlZSBodHRwczovL2dpdGh1Yi5jb20vbm9kZWpzL25vZGUvY29tbWl0L2QzYWFmZDAyZWZkM2E0MDNkNjQ2YTMwNDRhZGNmMTRlNjNhODhkMzIgZm9yIG1lbW9zL2NoYW5uZWwgaW5zcGlyYXRpb25cblxuICB2YXIgaGFzQWN0dWFsID0gY2hhbm5lbC5oYXMoYWN0dWFsKTtcbiAgdmFyIGhhc0V4cGVjdGVkID0gY2hhbm5lbC5oYXMoZXhwZWN0ZWQpO1xuICB2YXIgc2VudGluZWw7XG4gIGlmIChoYXNBY3R1YWwgJiYgaGFzRXhwZWN0ZWQpIHtcbiAgICBpZiAoY2hhbm5lbC5nZXQoYWN0dWFsKSA9PT0gY2hhbm5lbC5nZXQoZXhwZWN0ZWQpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgc2VudGluZWwgPSB7fTtcbiAgfVxuICBpZiAoIWhhc0FjdHVhbCkgeyBjaGFubmVsLnNldChhY3R1YWwsIHNlbnRpbmVsKTsgfVxuICBpZiAoIWhhc0V4cGVjdGVkKSB7IGNoYW5uZWwuc2V0KGV4cGVjdGVkLCBzZW50aW5lbCk7IH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlLWJlZm9yZS1kZWZpbmVcbiAgcmV0dXJuIG9iakVxdWl2KGFjdHVhbCwgZXhwZWN0ZWQsIG9wdHMsIGNoYW5uZWwpO1xufVxuXG5mdW5jdGlvbiBpc0J1ZmZlcih4KSB7XG4gIGlmICgheCB8fCB0eXBlb2YgeCAhPT0gJ29iamVjdCcgfHwgdHlwZW9mIHgubGVuZ3RoICE9PSAnbnVtYmVyJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAodHlwZW9mIHguY29weSAhPT0gJ2Z1bmN0aW9uJyB8fCB0eXBlb2YgeC5zbGljZSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoeC5sZW5ndGggPiAwICYmIHR5cGVvZiB4WzBdICE9PSAnbnVtYmVyJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHJldHVybiAhISh4LmNvbnN0cnVjdG9yICYmIHguY29uc3RydWN0b3IuaXNCdWZmZXIgJiYgeC5jb25zdHJ1Y3Rvci5pc0J1ZmZlcih4KSk7XG59XG5cbmZ1bmN0aW9uIHNldEVxdWl2KGEsIGIsIG9wdHMsIGNoYW5uZWwpIHtcbiAgaWYgKCRzZXRTaXplKGEpICE9PSAkc2V0U2l6ZShiKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB2YXIgaUEgPSBnZXRJdGVyYXRvcihhKTtcbiAgdmFyIGlCID0gZ2V0SXRlcmF0b3IoYik7XG4gIHZhciByZXN1bHRBO1xuICB2YXIgcmVzdWx0QjtcbiAgdmFyIHNldDtcbiAgd2hpbGUgKChyZXN1bHRBID0gaUEubmV4dCgpKSAmJiAhcmVzdWx0QS5kb25lKSB7XG4gICAgaWYgKHJlc3VsdEEudmFsdWUgJiYgdHlwZW9mIHJlc3VsdEEudmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICBpZiAoIXNldCkgeyBzZXQgPSBuZXcgJFNldCgpOyB9XG4gICAgICAkc2V0QWRkKHNldCwgcmVzdWx0QS52YWx1ZSk7XG4gICAgfSBlbHNlIGlmICghJHNldEhhcyhiLCByZXN1bHRBLnZhbHVlKSkge1xuICAgICAgaWYgKG9wdHMuc3RyaWN0KSB7IHJldHVybiBmYWxzZTsgfVxuICAgICAgaWYgKCFzZXRNaWdodEhhdmVMb29zZVByaW0oYSwgYiwgcmVzdWx0QS52YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKCFzZXQpIHsgc2V0ID0gbmV3ICRTZXQoKTsgfVxuICAgICAgJHNldEFkZChzZXQsIHJlc3VsdEEudmFsdWUpO1xuICAgIH1cbiAgfVxuICBpZiAoc2V0KSB7XG4gICAgd2hpbGUgKChyZXN1bHRCID0gaUIubmV4dCgpKSAmJiAhcmVzdWx0Qi5kb25lKSB7XG4gICAgICAvLyBXZSBoYXZlIHRvIGNoZWNrIGlmIGEgcHJpbWl0aXZlIHZhbHVlIGlzIGFscmVhZHkgbWF0Y2hpbmcgYW5kIG9ubHkgaWYgaXQncyBub3QsIGdvIGh1bnRpbmcgZm9yIGl0LlxuICAgICAgaWYgKHJlc3VsdEIudmFsdWUgJiYgdHlwZW9mIHJlc3VsdEIudmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGlmICghc2V0SGFzRXF1YWxFbGVtZW50KHNldCwgcmVzdWx0Qi52YWx1ZSwgb3B0cy5zdHJpY3QsIGNoYW5uZWwpKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAhb3B0cy5zdHJpY3RcbiAgICAgICAgJiYgISRzZXRIYXMoYSwgcmVzdWx0Qi52YWx1ZSlcbiAgICAgICAgJiYgIXNldEhhc0VxdWFsRWxlbWVudChzZXQsIHJlc3VsdEIudmFsdWUsIG9wdHMuc3RyaWN0LCBjaGFubmVsKVxuICAgICAgKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuICRzZXRTaXplKHNldCkgPT09IDA7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5cbmZ1bmN0aW9uIG1hcEVxdWl2KGEsIGIsIG9wdHMsIGNoYW5uZWwpIHtcbiAgaWYgKCRtYXBTaXplKGEpICE9PSAkbWFwU2l6ZShiKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB2YXIgaUEgPSBnZXRJdGVyYXRvcihhKTtcbiAgdmFyIGlCID0gZ2V0SXRlcmF0b3IoYik7XG4gIHZhciByZXN1bHRBO1xuICB2YXIgcmVzdWx0QjtcbiAgdmFyIHNldDtcbiAgdmFyIGtleTtcbiAgdmFyIGl0ZW0xO1xuICB2YXIgaXRlbTI7XG4gIHdoaWxlICgocmVzdWx0QSA9IGlBLm5leHQoKSkgJiYgIXJlc3VsdEEuZG9uZSkge1xuICAgIGtleSA9IHJlc3VsdEEudmFsdWVbMF07XG4gICAgaXRlbTEgPSByZXN1bHRBLnZhbHVlWzFdO1xuICAgIGlmIChrZXkgJiYgdHlwZW9mIGtleSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGlmICghc2V0KSB7IHNldCA9IG5ldyAkU2V0KCk7IH1cbiAgICAgICRzZXRBZGQoc2V0LCBrZXkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpdGVtMiA9ICRtYXBHZXQoYiwga2V5KTtcbiAgICAgIGlmICgodHlwZW9mIGl0ZW0yID09PSAndW5kZWZpbmVkJyAmJiAhJG1hcEhhcyhiLCBrZXkpKSB8fCAhaW50ZXJuYWxEZWVwRXF1YWwoaXRlbTEsIGl0ZW0yLCBvcHRzLCBjaGFubmVsKSkge1xuICAgICAgICBpZiAob3B0cy5zdHJpY3QpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFtYXBNaWdodEhhdmVMb29zZVByaW0oYSwgYiwga2V5LCBpdGVtMSwgb3B0cywgY2hhbm5lbCkpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFzZXQpIHsgc2V0ID0gbmV3ICRTZXQoKTsgfVxuICAgICAgICAkc2V0QWRkKHNldCwga2V5KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpZiAoc2V0KSB7XG4gICAgd2hpbGUgKChyZXN1bHRCID0gaUIubmV4dCgpKSAmJiAhcmVzdWx0Qi5kb25lKSB7XG4gICAgICBrZXkgPSByZXN1bHRCLnZhbHVlWzBdO1xuICAgICAgaXRlbTIgPSByZXN1bHRCLnZhbHVlWzFdO1xuICAgICAgaWYgKGtleSAmJiB0eXBlb2Yga2V5ID09PSAnb2JqZWN0Jykge1xuICAgICAgICBpZiAoIW1hcEhhc0VxdWFsRW50cnkoc2V0LCBhLCBrZXksIGl0ZW0yLCBvcHRzLCBjaGFubmVsKSkge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgIW9wdHMuc3RyaWN0XG4gICAgICAgICYmICghYS5oYXMoa2V5KSB8fCAhaW50ZXJuYWxEZWVwRXF1YWwoJG1hcEdldChhLCBrZXkpLCBpdGVtMiwgb3B0cywgY2hhbm5lbCkpXG4gICAgICAgICYmICFtYXBIYXNFcXVhbEVudHJ5KHNldCwgYSwga2V5LCBpdGVtMiwgYXNzaWduKHt9LCBvcHRzLCB7IHN0cmljdDogZmFsc2UgfSksIGNoYW5uZWwpXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gJHNldFNpemUoc2V0KSA9PT0gMDtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gb2JqRXF1aXYoYSwgYiwgb3B0cywgY2hhbm5lbCkge1xuICAvKiBlc2xpbnQgbWF4LXN0YXRlbWVudHM6IFsyLCAxMDBdLCBtYXgtbGluZXMtcGVyLWZ1bmN0aW9uOiBbMiwgMTIwXSwgbWF4LWRlcHRoOiBbMiwgNV0sIG1heC1saW5lczogWzIsIDQwMF0gKi9cbiAgdmFyIGksIGtleTtcblxuICBpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSB7IHJldHVybiBmYWxzZTsgfVxuICBpZiAoYSA9PSBudWxsIHx8IGIgPT0gbnVsbCkgeyByZXR1cm4gZmFsc2U7IH1cblxuICBpZiAoJG9ialRvU3RyaW5nKGEpICE9PSAkb2JqVG9TdHJpbmcoYikpIHsgcmV0dXJuIGZhbHNlOyB9XG5cbiAgaWYgKGlzQXJndW1lbnRzKGEpICE9PSBpc0FyZ3VtZW50cyhiKSkgeyByZXR1cm4gZmFsc2U7IH1cblxuICB2YXIgYUlzQXJyYXkgPSBpc0FycmF5KGEpO1xuICB2YXIgYklzQXJyYXkgPSBpc0FycmF5KGIpO1xuICBpZiAoYUlzQXJyYXkgIT09IGJJc0FycmF5KSB7IHJldHVybiBmYWxzZTsgfVxuXG4gIC8vIFRPRE86IHJlcGxhY2Ugd2hlbiBhIGNyb3NzLXJlYWxtIGJyYW5kIGNoZWNrIGlzIGF2YWlsYWJsZVxuICB2YXIgYUlzRXJyb3IgPSBhIGluc3RhbmNlb2YgRXJyb3I7XG4gIHZhciBiSXNFcnJvciA9IGIgaW5zdGFuY2VvZiBFcnJvcjtcbiAgaWYgKGFJc0Vycm9yICE9PSBiSXNFcnJvcikgeyByZXR1cm4gZmFsc2U7IH1cbiAgaWYgKGFJc0Vycm9yIHx8IGJJc0Vycm9yKSB7XG4gICAgaWYgKGEubmFtZSAhPT0gYi5uYW1lIHx8IGEubWVzc2FnZSAhPT0gYi5tZXNzYWdlKSB7IHJldHVybiBmYWxzZTsgfVxuICB9XG5cbiAgdmFyIGFJc1JlZ2V4ID0gaXNSZWdleChhKTtcbiAgdmFyIGJJc1JlZ2V4ID0gaXNSZWdleChiKTtcbiAgaWYgKGFJc1JlZ2V4ICE9PSBiSXNSZWdleCkgeyByZXR1cm4gZmFsc2U7IH1cbiAgaWYgKChhSXNSZWdleCB8fCBiSXNSZWdleCkgJiYgKGEuc291cmNlICE9PSBiLnNvdXJjZSB8fCBmbGFncyhhKSAhPT0gZmxhZ3MoYikpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgdmFyIGFJc0RhdGUgPSBpc0RhdGUoYSk7XG4gIHZhciBiSXNEYXRlID0gaXNEYXRlKGIpO1xuICBpZiAoYUlzRGF0ZSAhPT0gYklzRGF0ZSkgeyByZXR1cm4gZmFsc2U7IH1cbiAgaWYgKGFJc0RhdGUgfHwgYklzRGF0ZSkgeyAvLyAmJiB3b3VsZCB3b3JrIHRvbywgYmVjYXVzZSBib3RoIGFyZSB0cnVlIG9yIGJvdGggZmFsc2UgaGVyZVxuICAgIGlmICgkZ2V0VGltZShhKSAhPT0gJGdldFRpbWUoYikpIHsgcmV0dXJuIGZhbHNlOyB9XG4gIH1cbiAgaWYgKG9wdHMuc3RyaWN0ICYmIGdQTyAmJiBnUE8oYSkgIT09IGdQTyhiKSkgeyByZXR1cm4gZmFsc2U7IH1cblxuICB2YXIgYVdoaWNoID0gd2hpY2hUeXBlZEFycmF5KGEpO1xuICB2YXIgYldoaWNoID0gd2hpY2hUeXBlZEFycmF5KGIpO1xuICBpZiAoYVdoaWNoICE9PSBiV2hpY2gpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGFXaGljaCB8fCBiV2hpY2gpIHsgLy8gJiYgd291bGQgd29yayB0b28sIGJlY2F1c2UgYm90aCBhcmUgdHJ1ZSBvciBib3RoIGZhbHNlIGhlcmVcbiAgICBpZiAoYS5sZW5ndGggIT09IGIubGVuZ3RoKSB7IHJldHVybiBmYWxzZTsgfVxuICAgIGZvciAoaSA9IDA7IGkgPCBhLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoYVtpXSAhPT0gYltpXSkgeyByZXR1cm4gZmFsc2U7IH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICB2YXIgYUlzQnVmZmVyID0gaXNCdWZmZXIoYSk7XG4gIHZhciBiSXNCdWZmZXIgPSBpc0J1ZmZlcihiKTtcbiAgaWYgKGFJc0J1ZmZlciAhPT0gYklzQnVmZmVyKSB7IHJldHVybiBmYWxzZTsgfVxuICBpZiAoYUlzQnVmZmVyIHx8IGJJc0J1ZmZlcikgeyAvLyAmJiB3b3VsZCB3b3JrIHRvbywgYmVjYXVzZSBib3RoIGFyZSB0cnVlIG9yIGJvdGggZmFsc2UgaGVyZVxuICAgIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgZm9yIChpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChhW2ldICE9PSBiW2ldKSB7IHJldHVybiBmYWxzZTsgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHZhciBhSXNBcnJheUJ1ZmZlciA9IGlzQXJyYXlCdWZmZXIoYSk7XG4gIHZhciBiSXNBcnJheUJ1ZmZlciA9IGlzQXJyYXlCdWZmZXIoYik7XG4gIGlmIChhSXNBcnJheUJ1ZmZlciAhPT0gYklzQXJyYXlCdWZmZXIpIHsgcmV0dXJuIGZhbHNlOyB9XG4gIGlmIChhSXNBcnJheUJ1ZmZlciB8fCBiSXNBcnJheUJ1ZmZlcikgeyAvLyAmJiB3b3VsZCB3b3JrIHRvbywgYmVjYXVzZSBib3RoIGFyZSB0cnVlIG9yIGJvdGggZmFsc2UgaGVyZVxuICAgIGlmIChieXRlTGVuZ3RoKGEpICE9PSBieXRlTGVuZ3RoKGIpKSB7IHJldHVybiBmYWxzZTsgfVxuICAgIHJldHVybiB0eXBlb2YgVWludDhBcnJheSA9PT0gJ2Z1bmN0aW9uJyAmJiBpbnRlcm5hbERlZXBFcXVhbChuZXcgVWludDhBcnJheShhKSwgbmV3IFVpbnQ4QXJyYXkoYiksIG9wdHMsIGNoYW5uZWwpO1xuICB9XG5cbiAgdmFyIGFJc1NBQiA9IGlzU2hhcmVkQXJyYXlCdWZmZXIoYSk7XG4gIHZhciBiSXNTQUIgPSBpc1NoYXJlZEFycmF5QnVmZmVyKGIpO1xuICBpZiAoYUlzU0FCICE9PSBiSXNTQUIpIHsgcmV0dXJuIGZhbHNlOyB9XG4gIGlmIChhSXNTQUIgfHwgYklzU0FCKSB7IC8vICYmIHdvdWxkIHdvcmsgdG9vLCBiZWNhdXNlIGJvdGggYXJlIHRydWUgb3IgYm90aCBmYWxzZSBoZXJlXG4gICAgaWYgKHNhYkJ5dGVMZW5ndGgoYSkgIT09IHNhYkJ5dGVMZW5ndGgoYikpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgcmV0dXJuIHR5cGVvZiBVaW50OEFycmF5ID09PSAnZnVuY3Rpb24nICYmIGludGVybmFsRGVlcEVxdWFsKG5ldyBVaW50OEFycmF5KGEpLCBuZXcgVWludDhBcnJheShiKSwgb3B0cywgY2hhbm5lbCk7XG4gIH1cblxuICBpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSB7IHJldHVybiBmYWxzZTsgfVxuXG4gIHZhciBrYSA9IG9iamVjdEtleXMoYSk7XG4gIHZhciBrYiA9IG9iamVjdEtleXMoYik7XG4gIC8vIGhhdmluZyB0aGUgc2FtZSBudW1iZXIgb2Ygb3duZWQgcHJvcGVydGllcyAoa2V5cyBpbmNvcnBvcmF0ZXMgaGFzT3duUHJvcGVydHkpXG4gIGlmIChrYS5sZW5ndGggIT09IGtiLmxlbmd0aCkgeyByZXR1cm4gZmFsc2U7IH1cblxuICAvLyB0aGUgc2FtZSBzZXQgb2Yga2V5cyAoYWx0aG91Z2ggbm90IG5lY2Vzc2FyaWx5IHRoZSBzYW1lIG9yZGVyKSxcbiAga2Euc29ydCgpO1xuICBrYi5zb3J0KCk7XG4gIC8vIH5+fmNoZWFwIGtleSB0ZXN0XG4gIGZvciAoaSA9IGthLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgaWYgKGthW2ldICE9IGtiW2ldKSB7IHJldHVybiBmYWxzZTsgfSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGVxZXFlcVxuICB9XG5cbiAgLy8gZXF1aXZhbGVudCB2YWx1ZXMgZm9yIGV2ZXJ5IGNvcnJlc3BvbmRpbmcga2V5LCBhbmQgfn5+cG9zc2libHkgZXhwZW5zaXZlIGRlZXAgdGVzdFxuICBmb3IgKGkgPSBrYS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgIGtleSA9IGthW2ldO1xuICAgIGlmICghaW50ZXJuYWxEZWVwRXF1YWwoYVtrZXldLCBiW2tleV0sIG9wdHMsIGNoYW5uZWwpKSB7IHJldHVybiBmYWxzZTsgfVxuICB9XG5cbiAgdmFyIGFDb2xsZWN0aW9uID0gd2hpY2hDb2xsZWN0aW9uKGEpO1xuICB2YXIgYkNvbGxlY3Rpb24gPSB3aGljaENvbGxlY3Rpb24oYik7XG4gIGlmIChhQ29sbGVjdGlvbiAhPT0gYkNvbGxlY3Rpb24pIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGFDb2xsZWN0aW9uID09PSAnU2V0JyB8fCBiQ29sbGVjdGlvbiA9PT0gJ1NldCcpIHsgLy8gYUNvbGxlY3Rpb24gPT09IGJDb2xsZWN0aW9uXG4gICAgcmV0dXJuIHNldEVxdWl2KGEsIGIsIG9wdHMsIGNoYW5uZWwpO1xuICB9XG4gIGlmIChhQ29sbGVjdGlvbiA9PT0gJ01hcCcpIHsgLy8gYUNvbGxlY3Rpb24gPT09IGJDb2xsZWN0aW9uXG4gICAgcmV0dXJuIG1hcEVxdWl2KGEsIGIsIG9wdHMsIGNoYW5uZWwpO1xuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZGVlcEVxdWFsKGEsIGIsIG9wdHMpIHtcbiAgcmV0dXJuIGludGVybmFsRGVlcEVxdWFsKGEsIGIsIG9wdHMsIGdldFNpZGVDaGFubmVsKCkpO1xufTtcbiIsICJpbXBvcnQgKiBhcyBwcyBmcm9tIFwidS1zdHJlYW0tY29tYmluYXRvcnMvcHVsbFwiO1xuaW1wb3J0ICogYXMgYXBzIGZyb20gXCJ1LXN0cmVhbS1jb21iaW5hdG9ycy9wdWxsL2FzeW5jXCI7XG5pbXBvcnQgKiBhcyBocyBmcm9tIFwidS1zdHJlYW0tY29tYmluYXRvcnMvcHVzaFwiO1xuXG5pbXBvcnQge2NyZWF0ZUxpbWl0ZXJ9IGZyb20gXCJ1LWZyZXF1ZW5jeS1saW1pdGVyXCI7XG5cbmltcG9ydCB7IHJ1bl90ZXN0c19wcmludCB9IGZyb20gJ3UtdGVzdHJ1bm5lcic7XG5pbXBvcnQgeyBTX2Rpc2Nvbm5lY3QsIFNfZW5kLCBTX3BhdXNlLCBTX3N0YXJ0LCB0X2VuZCB9IGZyb20gXCIvc3ltYm9sc1wiO1xuaW1wb3J0IHsgbWFwX2NvbmN1cnJlbnRseSwgcHVzaF90b19wdWxsIH0gZnJvbSBcIi90cmFuc2Zvcm1lcnMvYXN5bmNcIjtcbmltcG9ydCB7IEV4cGVjdGF0aW9uIH0gZnJvbSBcIi90c21vbm8vdS10ZXN0cnVubmVyXCI7XG5cbmNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpID0+IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSlcblxuZXhwb3J0IGNvbnN0IHB1c2hfc3RyZWFtX2Zyb21fYXJyYXkgPSA8VD4oYTogVFtdKTogaHMuQWRkU2luazxUPiA9PiB7XG4gICAgbGV0IGludGVydmFsVGltZXI6IHVuZGVmaW5lZCB8IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiA9IHVuZGVmaW5lZFxuICAgIGxldCBjb25uZWN0ZWQgPSBmYWxzZVxuICAgIGxldCBzaW5rOiBocy5QdXNoU291cmNlUHVzaDxUPiB8IHVuZGVmaW5lZD0gdW5kZWZpbmVkXG4gICAgY29uc3Qgc3RvcCA9ICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxUaW1lcilcbiAgICBjb25zdCBzdGFydCA9ICgpID0+IHtcbiAgICAgICAgaW50ZXJ2YWxUaW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHYgPSBhLnNoaWZ0KClcbiAgICAgICAgICAgIGlmICh2ID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHNpbmshLnB1c2goU19lbmQpXG4gICAgICAgICAgICAgICAgc3RvcCgpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNpbmshLnB1c2goe3ZhbHVlOiB2fSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMzApXG4gICAgfVxuXG4gICAgY29uc3QgYWRkU2luazogaHMuQWRkU2luazxUPltcImFkZFNpbmtcIl0gPSAoX3NpbmspID0+IHtcbiAgICAgICAgaWYgKGNvbm5lY3RlZCkgdGhyb3cgRXJyb3IoJ3gnKVxuICAgICAgICBzaW5rID0gX3NpbmtcbiAgICAgICAgY29ubmVjdGVkID0gdHJ1ZVxuICAgICAgICByZXR1cm4gKHNpZ25hbDogaHMuUHVzaFNvdXJjZUFwaVNpZ25hbCkgPT4ge1xuICAgICAgICAgICAgaWYgKHNpZ25hbCA9PSBTX3N0YXJ0KSBzdGFydCgpXG4gICAgICAgICAgICBpZiAoc2lnbmFsID09IFNfcGF1c2UpIHN0b3AoKVxuICAgICAgICAgICAgaWYgKHNpZ25hbCA9PSBTX2Rpc2Nvbm5lY3QpIHN0b3AoKVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGFkZFNpbmtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBhZGRfZGVsYXkgPSA8VD4oc3RyZWFtOiBhcHMuQXN5bmNQdWxsU3RyZWFtPFQ+LCBkZWxheTogbnVtYmVyKTogYXBzLkFzeW5jUHVsbFN0cmVhbTxUPiA9PiB7XG4gICAgY29uc3QgZ2V0VG9rZW4gPSBjcmVhdGVMaW1pdGVyKCgpID0+IGRlbGF5KVxuICAgIHJldHVybiAoYXN5bmMgKGVuZD86IHRfZW5kKSA9PiB7XG4gICAgICAgIGF3YWl0IGdldFRva2VuKClcbiAgICAgICAgcmV0dXJuIHN0cmVhbShlbmQpXG4gICAgfSkgYXMgYXBzLkFzeW5jUHVsbFN0cmVhbTxUPlxufVxuXG5ydW5fdGVzdHNfcHJpbnQoe1xuICAnZGVzY3JpcHRpb24nOiAndGVzdHMnLFxuICAndGltZW91dCcgOiA0MDAwLFxufSwgYXN5bmMgKGMpID0+IHtcblxuICAgIGxldCB0ZXN0czogUmVjb3JkPCBzdHJpbmcsIChhOkV4cGVjdGF0aW9uKSA9PiBQcm9taXNlPHZvaWQ+PiA9IHtcblxuICAgICAgICAgICAgdGVzdF9wdXNoX3RvX3B1bGxfc3RyZWFtOiBhc3luYyAoYSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHB1c2hfc3RyZWFtID0gcHVzaF9zdHJlYW1fZnJvbV9hcnJheShbMSwyLDNdKVxuICAgICAgICAgICAgICAgIGNvbnN0IHB1bGxfc3RyZWFtID0gcHVzaF90b19wdWxsKHB1c2hfc3RyZWFtKVxuICAgICAgICAgICAgICAgIGEuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgICAgIFsxLDIsM10sXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGFwcy5hcHNfdG9fYXJyYXkocHVsbF9zdHJlYW0pXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSxcblxuXG5cbiAgICAgICAgICAgIHRlc3RfYXBzX3ppcDogYXN5bmMgKGEpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgc3RyZWFtMSA9IGFwcy5hcHNfZnJvbV9hcnJheShbMSwyLDNdKS5uZXh0XG4gICAgICAgICAgICAgICAgbGV0IHN0cmVhbTIgPSBhcHMuYXBzX2Zyb21fYXJyYXkoWydBJywgJ0InLCBcIkNcIl0pLm5leHRcbiAgICAgICAgICAgICAgICBjb25zdCBzdHJlYW0gPSBhcHMuYXBzX3ppcCh7fSwgc3RyZWFtMSwgc3RyZWFtMilcbiAgICAgICAgICAgICAgICBhLmV4cGVjdF9kZWVwX2VxdWFsKFxuICAgICAgICAgICAgICAgICAgICBbWzEsXCJBXCJdLCBbMixcIkJcIl0sIFszLCBcIkNcIl1dLFxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhcHMuYXBzX3RvX2FycmF5KHN0cmVhbSlcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgYy50b2RvKCdlYXJseSA9IHRydWUgL2ZhbHNlIGNhc2VzJylcbiAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgIHRlc3RfYnVmZmVyZWRfc3RyZWFtX21hcDogYXN5bmMgKGEpID0+IHtcbiAgICAgICAgICAgIGxldCBzdHJlYW0gPSBhcHMuYXBzX2Zyb21fYXJyYXkoWzEsMiwzXSkubmV4dFxuICAgICAgICAgICAgc3RyZWFtID0gYWRkX2RlbGF5KHN0cmVhbSwgNTApXG4gICAgICAgICAgICBzdHJlYW0gPSBhcHMuYXBzX2J1ZmZlcmVkKHN0cmVhbSlcbiAgICAgICAgICAgIGEuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgWzEsMiwzXSxcbiAgICAgICAgICAgICAgICBhd2FpdCBhcHMuYXBzX3RvX2FycmF5KHN0cmVhbSlcbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcblxuICAgICAgICB0ZXN0X2J1ZmZlcmVkX3N0cmVhbTogYXN5bmMgKGEpID0+IHtcbiAgICAgICAgICAgIGxldCBzdHJlYW0gPSBhcHMuYXBzX2Zyb21fYXJyYXkoWzEsMiwzLDQsNV0pLm5leHRcbiAgICAgICAgICAgIHN0cmVhbSA9IGFkZF9kZWxheShzdHJlYW0sIDUwKVxuICAgICAgICAgICAgc3RyZWFtID0gYXBzLmFwc19idWZmZXJlZChzdHJlYW0sIHsgd2F0ZXJtYXJrczoge2xvd193YXRlcm1hcms6IDEsIGhpZ2hfd2F0ZXJtYXJrOiAyIH19KVxuICAgICAgICAgICAgc3RyZWFtID0gYWRkX2RlbGF5KHN0cmVhbSwgNTApXG4gICAgICAgICAgICBhLmV4cGVjdF9kZWVwX2VxdWFsKFxuICAgICAgICAgICAgICAgIFsxLDIsMyw0LDVdLFxuICAgICAgICAgICAgICAgIGF3YWl0IGFwcy5hcHNfdG9fYXJyYXkoc3RyZWFtKVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuXG4gICAgICAgIHRlc3RfaXRlcmF0b3Jfd29ya3NfMTogYXN5bmMgKGEpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlYWRlciA9IHBzLmZyb21fYXJyYXkoWzEsMiwzXSlcbiAgICAgICAgICAgIGEuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgWzEsMiwzXSxcbiAgICAgICAgICAgICAgICBwcy50b19hcnJheShyZWFkZXIubmV4dClcbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcblxuICAgICAgICAvLyBTWU5DIGZyb21fYXJyYXkgKyBtYXBcbiAgICAgICAgXG4gICAgICAgIHRlc3RfaXRlcmF0b3Jfd2l0aF9tYXBfd29ya3M6IGFzeW5jIChhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBwcy5mcm9tX2FycmF5KFsxLDIsM10pXG4gICAgICAgICAgICBjb25zdCBtYXBwZWQgPSBwcy5tYXAocmVhZGVyLm5leHQsICh4KSA9PiB4ICogMilcbiAgICAgICAgICAgIGEuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgWzIsNCw2XSxcbiAgICAgICAgICAgICAgICBwcy50b19hcnJheShtYXBwZWQpXG4gICAgICAgICAgICApXG4gICAgICAgIH0sXG5cbiAgICAgICAgLy8gQVNZTkMgZnJvbV9hcnJheSBlbmRcbiAgICAgICAgICAgIHRlc3RfaXRlcmF0b3Jfd29ya3MyOiBhc3luYyAoYSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gYXBzLmFwc19mcm9tX2FycmF5KFsxLDIsM10pXG4gICAgICAgICAgICBhLmV4cGVjdF9kZWVwX2VxdWFsKFxuICAgICAgICAgICAgICAgIFsxLDIsM10sXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBzLmFwc190b19hcnJheShyZWFkZXIubmV4dClcbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcblxuICAgICAgICB0ZXN0X2l0ZXJhdG9yX3dvcmtzMmI6IGFzeW5jIChhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBhcHMuYXBzX2Zyb21fYXJyYXkoWzEsMiwzXSwge2RvbmU6IGZhbHNlfSlcbiAgICAgICAgICAgIHJlYWRlci5wdXNoKDQsNSw2KVxuICAgICAgICAgICAgcmVhZGVyLmRvbmUoKVxuICAgICAgICAgICAgYS5leHBlY3RfZGVlcF9lcXVhbChcbiAgICAgICAgICAgICAgICBbMSwyLDMsIDQsNSw2XSxcbiAgICAgICAgICAgICAgICBhd2FpdCBhcHMuYXBzX3RvX2FycmF5KHJlYWRlci5uZXh0KVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuXG4gICAgICAgIHRlc3RfYXN5bmNfaXRlcmF0b3Jfd2l0aF9hc3luY19tYXA6IGFzeW5jIChhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBhcHMuYXBzX2Zyb21fYXJyYXkoWzEsMiwzXSwge2RvbmU6IGZhbHNlfSlcbiAgICAgICAgICAgIGNvbnN0IG1hcHBlZCA9IGFwcy5hcHNfbWFwKHJlYWRlci5uZXh0LCBhc3luYyAoeCkgPT4geCAqIDIpXG4gICAgICAgICAgICByZWFkZXIucHVzaCg0LDUsNilcbiAgICAgICAgICAgIHJlYWRlci5kb25lKClcbiAgICAgICAgICAgIGEuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgWzIsNCw2LCA4LCAxMCwgMTJdLFxuICAgICAgICAgICAgICAgIGF3YWl0IGFwcy5hcHNfdG9fYXJyYXkobWFwcGVkKVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuXG4gICAgICAgIC8vIG11bHRpcGxleGVyXG4gICAgICAgIHRlc3RfbXVsdGlwbGV4ZXI6IGFzeW5jIChhKSA9PiB7XG4gICAgICAgICAgICBhLmV4cGVjdF90cnVlKHRydWUpXG4gICAgICAgICAgICBjb25zdCBhMSA9IGMuZGVzY3JpYmUoJ211bHRpcGxleGVyIGFyciAxJylcbiAgICAgICAgICAgIGNvbnN0IGEyID0gYy5kZXNjcmliZSgnbXVsdGlwbGV4ZXIgYXJyIDInKVxuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gYXBzLmFwc19mcm9tX2FycmF5KFsxLDIsM10pXG5cbiAgICAgICAgICAgIGNvbnN0IG1hcHBlZCA9IGFwcy5hcHNfbWFwKHJlYWRlci5uZXh0LCBhc3luYyAoeCkgPT4geCAqIDIpXG4gICAgICAgICAgICBjb25zdCBtID0gYXBzLmFwc19tdWx0aXBsZXhlcihtYXBwZWQsIHthdXRvZW5kOiB0cnVlfSlcblxuICAgICAgICAgICAgY29uc3QgczEgPSBtLnNvdXJjZSgpXG4gICAgICAgICAgICBjb25zdCBzMiA9IG0uc291cmNlKClcblxuICAgICAgICAgICAgY29uc3QgW0ExLCBBMl0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgYXBzLmFwc190b19hcnJheShzMSksXG4gICAgICAgICAgICAgICAgYXBzLmFwc190b19hcnJheShzMilcbiAgICAgICAgICAgIF0pXG4gICAgICAgICAgICBhMS5leHBlY3RfZGVlcF9lcXVhbCggWzIsNCw2XSwgQTEpXG4gICAgICAgICAgICBhMi5leHBlY3RfZGVlcF9lcXVhbCggWzIsNCw2XSwgQTIpXG4gICAgICAgIH0sXG5cblxuICAgICAgICB0ZXN0X2FzeW5jX3F1ZXVlOiBhc3luYyAoYSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVhZGVyMSA9IGFwcy5hcHNfZnJvbV9hcnJheShbMSwyLDNdKVxuICAgICAgICAgICAgY29uc3QgcmVhZGVyMiA9IGFwcy5hcHNfZnJvbV9hcnJheShbXSlcbiAgICAgICAgICAgIGNvbnN0IHJlYWRlcjMgPSBhcHMuYXBzX2Zyb21fYXJyYXkoWzEsMiwzXSlcbiAgICAgICAgICAgIGNvbnN0IHEgPSBhcHMuYXBzX3F1ZXVlKHtzdHJlYW1zOiBbcmVhZGVyMS5uZXh0LCByZWFkZXIyLm5leHQsIHJlYWRlcjMubmV4dF19KVxuICAgICAgICAgICAgYS5leHBlY3RfZGVlcF9lcXVhbChcbiAgICAgICAgICAgICAgICBhd2FpdCBhcHMuYXBzX3RvX2FycmF5KHEubmV4dCksXG4gICAgICAgICAgICAgICAgWzEsMiwzLCAxLDIsM11cbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcblxuICAgICAgICAgdGVzdF9hc3luY19xdWV1ZTI6IGFzeW5jIChhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBhcHMuYXBzX3BhcnRpdGlvbihhcHMuYXBzX2Zyb21fYXJyYXkoWzEsMiwzXSkubmV4dCwgMilcbiAgICAgICAgICAgIGEuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBzLmFwc190b19hcnJheShyZWFkZXIpLFxuICAgICAgICAgICAgICAgW1sxLDJdLFszXV1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcblxuICAgICAgICB0ZXN0X2FzeW5jX3F1ZXVlX2RvbmU6IGFzeW5jIChhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIxID0gYXBzLmFwc19mcm9tX2FycmF5KFsxLDIsM10pXG4gICAgICAgICAgICBjb25zdCByZWFkZXIyID0gYXBzLmFwc19mcm9tX2FycmF5KFtdKVxuICAgICAgICAgICAgY29uc3QgcmVhZGVyMyA9IGFwcy5hcHNfZnJvbV9hcnJheShbMSwyLDNdKVxuICAgICAgICAgICAgY29uc3QgcSA9IGFwcy5hcHNfcXVldWUoe3N0cmVhbXM6IFtyZWFkZXIxLm5leHRdLCBkb25lOiBmYWxzZX0pO1xuXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcS5wdXNoKHJlYWRlcjIubmV4dCwgcmVhZGVyMy5uZXh0KVxuICAgICAgICAgICAgICAgICAgICBxLmRvbmUoKVxuICAgICAgICAgICAgfSwgMTAwKVxuXG4gICAgICAgICAgICBhLmV4cGVjdF9kZWVwX2VxdWFsKFxuICAgICAgICAgICAgICAgIGF3YWl0IGFwcy5hcHNfdG9fYXJyYXkocS5uZXh0KSxcbiAgICAgICAgICAgICAgICBbMSwyLDMsIDEsMiwzXVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuXG4gICAgICAgICAgICB0ZXN0X2FzeW5jX2NvbmN1cnJlbmN5OiBhc3luYyAoYSkgPT4ge1xuICAgICAgICAgICAgYS5leHBlY3RfdHJ1ZSh0cnVlKVxuICAgICAgICAgICAgY29uc3QgYV9vcmRlcmVkID0gYy5kZXNjcmliZSgnYV9vcmRlcmVkJylcbiAgICAgICAgICAgIGNvbnN0IGFfYW55X29yZGVyID0gYy5kZXNjcmliZSgnYV9hbnlfb3JkZXInKVxuXG4gICAgICAgICAgICBjb25zdCByID0gKHByZXNlcnZlX29yZGVyOiBib29sZWFuKSA9PiBcbiAgICAgICAgICAgICAgICBtYXBfY29uY3VycmVudGx5KFxuICAgICAgICAgICAgICAgICAgICBhcHMuYXBzX2Zyb21fYXJyYXkoWzEwLDksOCw3LDYsNSw0LDMsMiwxXSkubmV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jIChpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgc2xlZXAoaSAqIDMwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAge3ByZXNlcnZlX29yZGVyLCBjb25jdXJyZW5jeTogMTB9XG4gICAgICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICAvLyBmb3IgYXdhaXQgKGNvbnN0IHYgb2YgYXBzLmFwc190b19pdGVyKHIodHJ1ZSkpKSB7XG4gICAgICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKGB2ICR7dn1gKTtcbiAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgYV9hbnlfb3JkZXIuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgWzEsMiwzLDQsNSw2LDcsOCw5LDEwXSxcbiAgICAgICAgICAgICAgICBhd2FpdCBhcHMuYXBzX3RvX2FycmF5KHIoZmFsc2UpKVxuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICBhX29yZGVyZWQuZXhwZWN0X2RlZXBfZXF1YWwoXG4gICAgICAgICAgICAgICAgWzEwLDksOCw3LDYsNSw0LDMsMiwxXSxcbiAgICAgICAgICAgICAgICBhd2FpdCBhcHMuYXBzX3RvX2FycmF5KHIodHJ1ZSkpXG4gICAgICAgICAgICApXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBydW4gYSBzaW5nbGUgdGVzdDpcbiAgICAvLyB0ZXN0cyA9IHsgdGVzdF9hc3luY19jb25jdXJyZW5jeTogdGVzdHMudGVzdF9hc3luY19jb25jdXJyZW5jeSB9XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgIE9iamVjdC5lbnRyaWVzKHRlc3RzKS5tYXAoKFtrLHZdKSA9PiB2KGMuZGVzY3JpYmUoaykpKVxuICAgIClcblxuICAgIGMudG9kbygnZi5zY3JlYXRlU3RyZWFtUmVhZGVyICYgcHVzaF90b19wdWxsJylcbiAgICBjLnRvZG8oJ3RvdGFsbHkgbWlzc2luZyAtPiBlbmQgb2Ygc3RyZWFtIGNhbGxiYWNrIGV2ZW50cycpXG4gICAgYy50b2RvKCd0ZXN0IGVuZGluZyBmcm9tIHJlY2lldmluZyBzaWRlIScpXG5cbn0pLnRoZW4oY29uc29sZS5sb2csIGNvbnNvbGUubG9nKVxuIiwgImV4cG9ydCBjb25zdCBTX2VuZCA9IFN5bWJvbChcImVuZFwiKVxuZXhwb3J0IHR5cGUgdF9lbmQgPSB0eXBlb2YgU19lbmRcblxuZXhwb3J0IGNvbnN0IFNfcnVubmluZyA9IFN5bWJvbChcInJ1bm5pbmdcIilcbmV4cG9ydCBjb25zdCBTX2VuZGluZyA9IFN5bWJvbChcImVuZGluZ1wiKVxuZXhwb3J0IGNvbnN0IFNfcGF1c2VkID0gU3ltYm9sKFwicGF1c2VkXCIpXG5leHBvcnQgY29uc3QgU19wYXVzaW5nID0gU3ltYm9sKFwicGF1c2luZ1wiKVxuXG5leHBvcnQgY29uc3QgU19wYXVzZSA9IFN5bWJvbChcInBhdXNlXCIpXG5leHBvcnQgY29uc3QgU19zdGFydCA9IFN5bWJvbChcInN0YXJ0XCIpXG5leHBvcnQgY29uc3QgU19kaXNjb25uZWN0ID0gU3ltYm9sKFwiZGlzY29ubmVjdFwiKVxuXG4vLyBzaW5rIHdhbnRzIHRvIHBhdXNlXG5leHBvcnQgY29uc3QgU19wYXVzZWRfaW50ZXJuYWwgPSBTeW1ib2woJ3BhdXNlZF9leHRlcm5hbCcpXG4iLCAiLy8ganVzdCBwYXNzIHNpbXBsZSB2YWx1ZXNcbi8vIG5vIHByb2dyZXNzIGluZm9ybWF0aW9uXG5cbmltcG9ydCB7IHRfZW5kLCBTX2VuZCB9IGZyb20gXCIuLi9zeW1ib2xzXCJcblxuZXhwb3J0IGNvbnN0IGVvZmkgPSBTeW1ib2woJ2VuZC1vZi1mdW5jdGlvbi1pdGVyYXRvcicpXG5cbmV4cG9ydCB0eXBlIFB1bGxTdHJlYW08VD4gPSA8TyBleHRlbmRzIHVuZGVmaW5lZCB8IHRfZW5kID4obz86IE8pID0+IE8gZXh0ZW5kcyB0X2VuZCA/IHRfZW5kIDogVCB8IHRfZW5kXG5cbmV4cG9ydCBjb25zdCBmcm9tX2FycmF5ID0gPFQ+KGJ1ZmZlcjogVFtdID0gW10pID0+IHtcbiAgICAvLyBkb2Vzbid0IGFsbG93IHdhaXRpbmcgZm9yIGl0ZW1zIHRvIGJlIHB1c2hlZCxcbiAgICAvLyB1c2UgLi9hc3luYydzIHZlcnNpb24gaW5zdGVhZFxuICAgIGNvbnN0IHB1c2ggPSAoLi4uaTogVFtdKSA9PiBidWZmZXIucHVzaCguLi5pKVxuICAgIGNvbnN0IG5leHQ6IFB1bGxTdHJlYW08VD4gPSAoIChlbmQpID0+IHtcbiAgICAgICAgaWYgKCBlbmQgPT0gU19lbmQpIHJldHVybiBTX2VuZFxuICAgICAgICByZXR1cm4gKChidWZmZXIubGVuZ3RoID09IDApID8gU19lbmQgOiBidWZmZXIuc2hpZnQoKSEpXG4gICAgfSkgYXMgUHVsbFN0cmVhbTxUPlxuICAgIHJldHVybiB7XG4gICAgICAgIHB1c2gsIC8vIHlvdSBjYW4gcHVzaCwgYXBwZW5kIHJlcGxhY2Ugd2hhdGV2ZXIgeW91IHdhbnRcbiAgICAgICAgbmV4dFxuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IG1hcCA9IDxBLEI+KGk6IFB1bGxTdHJlYW08QT4sIG1hcDogKGE6QSkgPT4gQik6IFB1bGxTdHJlYW08Qj4gPT4gKGUpID0+IHtcbiAgICBpZiAoZSA9PSBTX2VuZCkgcmV0dXJuIGkoU19lbmQpXG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IHYgPSBpKGUpXG4gICAgICAgIHJldHVybiAodiA9PT0gU19lbmQpID8gU19lbmQgOiBtYXAodilcbiAgICB9XG59XG5cblxuZXhwb3J0IGNvbnN0IGZpbHRlciA9IDxUPihpOiBQdWxsU3RyZWFtPFQ+LCBmaWx0ZXI6IChhOlQpID0+IGJvb2xlYW4pOiBQdWxsU3RyZWFtPFQ+ID0+IChlKSA9PiB7XG4gICAgbGV0IHYgPSBpKGUpXG4gICAgd2hpbGUgKHYgIT09IFNfZW5kICYmICFmaWx0ZXIodikpe1xuICAgICAgICB2ID0gaShlKVxuICAgIH1cbiAgICByZXR1cm4gdlxufVxuXG5leHBvcnQgY29uc3QgX3RvX2l0ZXIgPSA8VD4oeDogVCkgPT4gKHsgZG9uZTp4ID09PSBTX2VuZCAsIHZhbHVlOiB4IGFzIEV4Y2x1ZGU8VCwgdW5kZWZpbmVkIHwgdF9lbmQ+IH0pXG5cbmV4cG9ydCBjb25zdCB0b19pdGVyID0gPFQ+KGk6IFB1bGxTdHJlYW08VD4pID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgICBbU3ltYm9sLml0ZXJhdG9yXTogKCkgPT4gKHtcbiAgICAgICAgICAgIG5leHQ6ICgpID0+IF90b19pdGVyKGkodW5kZWZpbmVkKSlcbiAgICAgICAgfSlcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCB0b19hcnJheSA9IDxUPihpOiBQdWxsU3RyZWFtPFQ+KTogVFtdID0+IHtcbiAgICBjb25zdCByOiBUW10gPSBbXVxuICAgIHdoaWxlICh0cnVlKXtcbiAgICAgICAgY29uc3QgdiA9IGkoKVxuICAgICAgICBpZiAodiA9PSBTX2VuZCkgYnJlYWtcbiAgICAgICAgZWxzZSByLnB1c2godilcbiAgICB9XG4gICAgZm9yIChjb25zdCB2IG9mIHRvX2l0ZXIoaSkpIHtcbiAgICAgICAgci5wdXNoKHYpXG4gICAgfVxuICAgIHJldHVybiByXG59XG4iLCAiaW1wb3J0IHsgU19lbmQsIHRfZW5kIH0gZnJvbSBcIi4vc3ltYm9sc1wiO1xuaW1wb3J0IHsgTWF5YmVQcm9taXNlLCBSZXNvbHZlUmVqZWN0QXJyYXkgfSBmcm9tIFwidS1wcm9taXNlXCI7XG5cbmV4cG9ydCB0eXBlIFZhbHVlRXJyb3JFbmQ8VD4gPSB7IHZhbHVlOiBUIH0gfCB7IGVycm9yOiBhbnkgfSB8IHRfZW5kXG5cbmV4cG9ydCBjb25zdCB2ZWVfdG9fcF9oYW5kbGVyID0gPFQ+KHY6IFZhbHVlRXJyb3JFbmQ8VD4sIHBfaGFuZGxlcnM6IFJlc29sdmVSZWplY3RBcnJheTxUIHwgdF9lbmQ+KSA9PiB7XG4gICAgaWYgKHYgPT09IFNfZW5kKVxuICAgICAgICBwX2hhbmRsZXJzWzBdKFNfZW5kKSBcbiAgICBlbHNlIGlmICgndmFsdWUnIGluIHYpXG4gICAgICAgIHBfaGFuZGxlcnNbMF0odi52YWx1ZSkgXG4gICAgZWxzZSBwX2hhbmRsZXJzWzFdKHYuZXJyb3IpXG59XG5cbmV4cG9ydCBjb25zdCB2ZWVfdG9fdmFsdWUgPSA8VD4odjogVmFsdWVFcnJvckVuZDxUPik6IFQgfCB0X2VuZCA9PiB7XG4gICAgaWYgKHYgPT09IFNfZW5kKVxuICAgICAgICByZXR1cm4gU19lbmRcbiAgICBlbHNlIGlmICgndmFsdWUnIGluIHYpXG4gICAgICAgIHJldHVybiB2LnZhbHVlXG4gICAgZWxzZSB0aHJvdyB2LmVycm9yXG59XG5cbmV4cG9ydCBjb25zdCBwcm9taXNlX3RvX3ZlZSA9IGFzeW5jIDxUPihwOiBNYXliZVByb21pc2U8VCB8IHRfZW5kPik6IFByb21pc2U8VmFsdWVFcnJvckVuZDxUPj4gPT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHYgPSBhd2FpdCBwXG4gICAgICAgIGlmICh2ID09PSBTX2VuZCkgcmV0dXJuIFNfZW5kXG4gICAgICAgIHJldHVybiB7IHZhbHVlOiB2IH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiB7ZXJyb3I6IGV9XG4gICAgfVxufVxuXG5leHBvcnQgdHlwZSBIaWdoTG93ID0geyBoaWdoX3dhdGVybWFyazogbnVtYmVyLCBsb3dfd2F0ZXJtYXJrOiBudW1iZXIgfVxuZXhwb3J0IHR5cGUgSGlnaExvd09yV2F0ZXJtYXJrID0gXG4gICAgICB7IHdhdGVybWFya3M/OiBudW1iZXIgfCBIaWdoTG93fVxuXG5leHBvcnQgY29uc3Qgd2F0ZXJtYXJrcyA9IChobDogSGlnaExvd09yV2F0ZXJtYXJrKTogSGlnaExvdyA9PiB7XG4gICAgY29uc3QgdyA9IGhsLndhdGVybWFya3NcbiAgICBpZiAoIXcpIHJldHVybiB7IGxvd193YXRlcm1hcms6IDIwLCBoaWdoX3dhdGVybWFyazogMTAwIH1cbiAgICByZXR1cm4gKHR5cGVvZiB3ID09ICdudW1iZXInKSA/IHsgbG93X3dhdGVybWFyazogdywgaGlnaF93YXRlcm1hcms6IHcgKiAxMCB9IDogd1xufVxuIiwgImltcG9ydCB7IF90b19pdGVyLCBQdWxsU3RyZWFtIH0gZnJvbSBcIi5cIlxuaW1wb3J0IHsgTWF5YmVQcm9taXNlLCBSZXNvbHZlUmVqZWN0QXJyYXkgfSBmcm9tIFwidS1wcm9taXNlXCJcbmltcG9ydCB7IHRfZW5kLCBTX2VuZCB9IGZyb20gXCIuLi9zeW1ib2xzXCJcbmltcG9ydCB7IEhpZ2hMb3dPcldhdGVybWFyaywgcHJvbWlzZV90b192ZWUsIFZhbHVlRXJyb3JFbmQsIHZlZV90b19wX2hhbmRsZXIsIHZlZV90b192YWx1ZSwgd2F0ZXJtYXJrcyB9IGZyb20gXCIuLi9pbnRlcm5hbFwiXG5cbmV4cG9ydCB0eXBlIEFzeW5jUHVsbFN0cmVhbTxUPiA9IDxPIGV4dGVuZHMgdW5kZWZpbmVkIHwgdF9lbmQgPihvPzogTykgPT4gTWF5YmVQcm9taXNlPE8gZXh0ZW5kcyB0X2VuZCA/IGFueSA6IFQgfCB0X2VuZD5cblxuLy8gd291bGQgY2xhc3MgYmUgYSBiZXR0ZXIgaW50ZXJmYWNlID8gKG5ldyBGcm9tQXJyYXkoW10pLnB1c2goKS5lbmQoKVxuZXhwb3J0IHR5cGUgZnJvbV9hcnJheV9vcHRpb25zID0geyBkb25lPzogYm9vbGVhbiB9XG5cbmV4cG9ydCBjb25zdCBhcHNfZnJvbV9hcnJheSA9IDxUPihidWZmZXI6IFRbXSA9IFtdLCBvOiBmcm9tX2FycmF5X29wdGlvbnMgPSB7fSkgPT4ge1xuICAgIGxldCBlbmRpbmc6IGJvb2xlYW4gPSBmYWxzZVxuICAgIGxldCBfYnVmZmVyOiB1bmRlZmluZWQgfCBUW10gPSBidWZmZXJcbiAgICBsZXQgcF9oYW5kbGVyczogdW5kZWZpbmVkIHwgUmVzb2x2ZVJlamVjdEFycmF5PFQgfCB0X2VuZD4gPSB1bmRlZmluZWRcbiAgICBsZXQgZG9uZSA9IG8uZG9uZSA/PyB0cnVlXG5cbiAgICBsZXQgY29tcGxldGUgPSBmYWxzZVxuXG4gICAgY29uc3QgcHVzaCA9ICguLi5pOiBUW10pID0+IHtcbiAgICAgICAgaWYgKHBfaGFuZGxlcnMpe1xuICAgICAgICAgICAgcF9oYW5kbGVyc1swXShpLnNoaWZ0KCkpXG4gICAgICAgICAgICBwX2hhbmRsZXJzID0gdW5kZWZpbmVkXG4gICAgICAgIH1cbiAgICAgICAgYnVmZmVyLnB1c2goLi4uaSlcbiAgICB9XG4gICAgY29uc3QgbmV4dDogQXN5bmNQdWxsU3RyZWFtPFQ+ID0gYXN5bmMgKCkgPT4gbmV3IFByb21pc2UoKHIsaikgPT4ge1xuICAgICAgICBpZiAoIV9idWZmZXIpe1xuICAgICAgICAgICAgcmV0dXJuIFNfZW5kIC8vIGVuZFxuICAgICAgICB9XG4gICAgICAgIGlmIChfYnVmZmVyLmxlbmd0aCA9PSAwKXtcbiAgICAgICAgICAgIGlmIChwX2hhbmRsZXJzKSB0aHJvdyBFcnJvcigncF9oYW5kbGVycyBzZXQsIGNhbGxlZCBpdGVyYXRvciB3aXRob3V0IHdhaXRpbmcgZm9yIHByZXZpb3VzIHJlc3VsdCcpXG4gICAgICAgICAgICBpZiAoZG9uZSkgcihTX2VuZClcbiAgICAgICAgICAgIGVsc2UgcF9oYW5kbGVycyA9IFtyLGpdXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByKF9idWZmZXIuc2hpZnQoKSEpXG4gICAgICAgIH1cbiAgICB9KVxuICAgIGNvbnN0IGVuZCA9ICgpID0+IHsgXG4gICAgICAgIGlmICghX2J1ZmZlcikgcmV0dXJuXG4gICAgICAgIGVuZGluZyA9IHRydWU7XG4gICAgICAgIGlmIChfYnVmZmVyLmxlbmd0aCA9PSAwKSBfYnVmZmVyID0gdW5kZWZpbmVkXG4gICAgICAgIGlmIChwX2hhbmRsZXJzKSBwX2hhbmRsZXJzWzBdKFNfZW5kKVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICAgIHB1c2gsIC8vIHlvdSBjYW4gcHVzaCwgYXBwZW5kIHJlcGxhY2Ugd2hhdGV2ZXIgeW91IHdhbnRcbiAgICAgICAgZW5kLFxuICAgICAgICBuZXh0LFxuICAgICAgICBkb25lOiAoKSA9PiBkb25lID0gdHJ1ZVxuICAgIH1cbn1cbmV4cG9ydCBjb25zdCBhcHNfbWFwID0gPEEsIEI+KGk6IEFzeW5jUHVsbFN0cmVhbTxBPiwgbWFwOiAoYTpBKSA9PiBNYXliZVByb21pc2U8Qj4pOiBBc3luY1B1bGxTdHJlYW08Qj4gPT4gYXN5bmMgKGUpID0+IHtcbiAgICBpZiAoZSA9PSBTX2VuZCkge1xuICAgICAgICBhd2FpdCBpKFNfZW5kKVxuICAgICAgICByZXR1cm4gU19lbmRcbiAgICB9XG4gICAgY29uc3QgdiA9IGF3YWl0IGkoKVxuICAgIHJldHVybiB2ID09IFNfZW5kID8gU19lbmQgOiBhd2FpdCBtYXAodilcbn1cblxuZXhwb3J0IGNvbnN0IGFwc19maWx0ZXIgPSA8VD4oaTogUHVsbFN0cmVhbTxUPiwgZmlsdGVyOiAoYTpUKSA9PiBNYXliZVByb21pc2U8Ym9vbGVhbj4pOiBBc3luY1B1bGxTdHJlYW08VD4gPT4gYXN5bmMgKGUpID0+IHtcbiAgICBpZiAoZSA9PSBTX2VuZCl7XG4gICAgICAgIGF3YWl0IGkoU19lbmQpXG4gICAgICAgIHJldHVybiBTX2VuZFxuICAgIH1cbiAgICBsZXQgdiA9IGF3YWl0IGkoKVxuICAgIGlmICh2ID09IFNfZW5kKSByZXR1cm4gU19lbmRcbiAgICB3aGlsZSAodiAhPT0gdW5kZWZpbmVkICYmICEgYXdhaXQgZmlsdGVyKHYpKXtcbiAgICAgICAgdiA9IGF3YWl0IGkoKVxuICAgICAgICBpZiAodiA9PSBTX2VuZClcbiAgICAgICAgcmV0dXJuIFNfZW5kXG4gICAgfVxuICAgIHJldHVybiB2XG59XG5cbmV4cG9ydCBjb25zdCBhcHNfdG9faXRlciA9IDxUPihpOiBBc3luY1B1bGxTdHJlYW08VD4pID0+ICh7XG4gICAgICAgIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl06ICgpID0+ICh7XG4gICAgICAgICAgICBuZXh0OiBhc3luYyAoKSA9PiBfdG9faXRlciggYXdhaXQgaSh1bmRlZmluZWQpKVxuICAgICAgICB9KVxufSlcblxuZXhwb3J0IGNvbnN0IGFwc190b19hcnJheSA9IGFzeW5jIDxUPihpOiBBc3luY1B1bGxTdHJlYW08VD4pOiBQcm9taXNlPFRbXT4gPT4ge1xuICAgIGNvbnN0IHI6IFRbXSA9IFtdXG4gICAgZm9yIGF3YWl0IChjb25zdCB2IG9mIGFwc190b19pdGVyKGkpKSB7XG4gICAgICAgIHIucHVzaCh2KVxuICAgIH1cbiAgICByZXR1cm4gclxufVxuXG4vLyBlbmRlZCBieSBzb3VyY2UgcmV0dXJuaW5nIFwiZW5kXCIgLT4gd2lsbCBiZSBwYXNzZWQgdG8gYWxsXG4vLyBlbmRlZCBieSBlbmQoKSAtPiB3aWxsIFNfZW5kIFwiZW5kXCIgdG8gYWxsIGNvbnN1bWVycyBvbmNlIGFza2VkXG5leHBvcnQgY29uc3QgYXBzX211bHRpcGxleGVyID0gPFQ+KHM6IEFzeW5jUHVsbFN0cmVhbTxUPiwgbzogeyBhdXRvZW5kOiBib29sZWFuIH0gPSB7IGF1dG9lbmQ6IHRydWV9KSA9PiB7XG5cbiAgICBsZXQgX2NvbXBsZXRlID0gZmFsc2VcbiAgICBsZXQgX2VuZGluZyA9IGZhbHNlXG5cbiAgICBjb25zdCBzb3VyY2VzOiBBcnJheTwgdW5kZWZpbmVkIHwge1xuICAgICAgICB3YWl0aW5nOiBSZXNvbHZlUmVqZWN0QXJyYXk8VD4gfCB1bmRlZmluZWRcbiAgICB9PiA9IFtdXG5cbiAgICBjb25zdCBlbmQgPSAoKSA9PiB7XG4gICAgICAgIF9lbmRpbmcgPSB0cnVlXG4gICAgICAgIHMoU19lbmQpXG4gICAgfVxuXG4gICAgY29uc3QgdHJ5X2VuZCA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFzb3VyY2VzLmZpbmQoKHgpID0+IHgpICYmIG8uYXV0b2VuZCl7XG4gICAgICAgICAgICAvLyBhbGwgc291cmNlcyBnb25lLCAuLlxuICAgICAgICAgICAgZW5kKClcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHRyeV9maWxsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoX2NvbXBsZXRlKSB7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAoIXNvdXJjZXMuZmluZCgoeCkgPT4geCAmJiAheC53YWl0aW5nKSl7XG4gICAgICAgICAgICAgICAgIC8vIGFsbCB3YWl0aW5nXG4gICAgICAgICAgICAgICAgY29uc3QgZiA9IGF3YWl0IHMoKS50aGVuKFxuICAgICAgICAgICAgICAgICAgICAodikgPT4gKHg6IFJlc29sdmVSZWplY3RBcnJheTxUPikgPT4geFswXSh2KSxcbiAgICAgICAgICAgICAgICAgICAgKHYpID0+ICh4OiBSZXNvbHZlUmVqZWN0QXJyYXk8VD4pID0+IHhbMV0odilcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgdiBvZiBzb3VyY2VzKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmKHYud2FpdGluZyEpIFxuICAgICAgICAgICAgICAgICAgICAgICAgdi53YWl0aW5nID0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBjb21wbGV0ZSA9ICgpID0+IHtcbiAgICAgICAgX2NvbXBsZXRlID0gdHJ1ZVxuICAgICAgICB0cnlfZmlsbCgpXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZW5kLFxuICAgICAgICBjb21wbGV0ZSwgLy8gc3RhcnRzIGFza2luZyBpZiBhbGwgdGFyZ2V0cyBzdGFydGVkIGFza2luZ1xuICAgICAgICBzb3VyY2U6ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlkID0gc291cmNlcy5sZW5ndGhcbiAgICAgICAgICAgIHNvdXJjZXMucHVzaCh7IHdhaXRpbmc6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgICAgY29uc3Qgc3RyZWFtID0gKDxPIGV4dGVuZHMgVCB8IHRfZW5kPihvPzogTyk6IE1heWJlUHJvbWlzZTxPIGV4dGVuZHMgdF9lbmQgPyB0X2VuZCA6IFQgfCB0X2VuZD4gPT4ge1xuICAgICAgICAgICAgICAgIGlmIChvID09IFNfZW5kKXtcbiAgICAgICAgICAgICAgICAgICAgc291cmNlc1tpZF0gPSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgdHJ5X2VuZCgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChfZW5kaW5nKSByZXR1cm4gU19lbmRcblxuICAgICAgICAgICAgICAgIGlmIChzb3VyY2VzW2lkXT8ud2FpdGluZykgdGhyb3cgRXJyb3IoJ3lvdSBmYWlsZWQgYXdhaXRpbmcgcHJldmlvdXMgUHJvbWlzZScpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyLGopID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc291cmNlc1tpZF0hLndhaXRpbmcgPSBbcixqXVxuICAgICAgICAgICAgICAgICAgICB0cnlfZmlsbCgpXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pIGFzIEFzeW5jUHVsbFN0cmVhbTxUPlxuICAgICAgICAgICAgcmV0dXJuIHN0cmVhbVxuICAgICAgICB9XG4gICAgfVxufVxuXG5cbmV4cG9ydCB0eXBlIGFwc19RdWVPcHRpb25zPFQ+ID0ge1xuICAgIGRvbmU/OiBib29sZWFuXG4gICAgc3RyZWFtczogQXN5bmNQdWxsU3RyZWFtPFQ+W11cbn1cblxuZXhwb3J0IGNvbnN0IGFwc19xdWV1ZSA9IDxUPihvOiBhcHNfUXVlT3B0aW9uczxUPikgPT4ge1xuICAgIGNvbnN0IHN0cmVhbXMgPSBvLnN0cmVhbXNcbiAgICBsZXQgIGRvbmUgPSBvLmRvbmUgPz8gdHJ1ZVxuICAgIGxldCBwX2hhbmRsZXJzOiB1bmRlZmluZWQgfCBbYW55LCBhbnldID0gdW5kZWZpbmVkXG4gICAgbGV0IHRyeWluZ19uZXh0OiBQcm9taXNlPGFueT4gfCB1bmRlZmluZWQgPSB1bmRlZmluZWRcblxuICAgIGNvbnN0IHRyeV9uZXh0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICB3aGlsZSAodHJ1ZSl7XG4gICAgICAgICAgICBpZiAoc3RyZWFtcy5sZW5ndGggPT0gMCl7XG4gICAgICAgICAgICAgICAgaWYgKGRvbmUpe1xuICAgICAgICAgICAgICAgICAgICBwX2hhbmRsZXJzIVswXShTX2VuZClcbiAgICAgICAgICAgICAgICAgICAgcF9oYW5kbGVycyA9IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHYgPSBhd2FpdCBzdHJlYW1zWzBdKClcbiAgICAgICAgICAgICAgICBpZiAodiA9PSBTX2VuZCl7XG4gICAgICAgICAgICAgICAgICAgIHN0cmVhbXMuc2hpZnQoKVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHBfaGFuZGxlcnMhWzBdKHYpXG4gICAgICAgICAgICAgICAgICAgIHBfaGFuZGxlcnMgPSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIHBfaGFuZGxlcnMhWzFdKGUpXG4gICAgICAgICAgICAgICAgcF9oYW5kbGVycyA9IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgcHVzaCA9IGFzeW5jICguLi5fc3RyZWFtczogQXN5bmNQdWxsU3RyZWFtPFQ+W10pID0+IHtcbiAgICAgICAgaWYgKHRyeWluZ19uZXh0KSBhd2FpdCB0cnlpbmdfbmV4dFxuICAgICAgICBzdHJlYW1zLnB1c2goLi4uX3N0cmVhbXMpXG4gICAgICAgIGlmIChwX2hhbmRsZXJzKXtcbiAgICAgICAgICAgIHRyeWluZ19uZXh0ID0gdHJ5X25leHQoKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgbmV4dCA9IChhc3luYyAoZW5kKSA9PiB7XG4gICAgICAgIGlmIChlbmQgPT0gU19lbmQpe1xuICAgICAgICAgICAgZm9yIChsZXQgcyBvZiBzdHJlYW1zKSB7XG4gICAgICAgICAgICAgICAgcyhTX2VuZClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAocF9oYW5kbGVycykgdGhyb3cgRXJyb3IoJ3BfaGFuZGxlcnMgc2V0LCBjYWxsZWQgaXRlcmF0b3Igd2l0aG91dCB3YWl0aW5nIGZvciBwcmV2aW91cyByZXN1bHQnKVxuICAgICAgICBjb25zdCBwID0gbmV3IFByb21pc2UoKHIsaikgPT4gcF9oYW5kbGVycyA9IFtyLGpdKVxuICAgICAgICB0cnlpbmdfbmV4dCA9IHRyeV9uZXh0KClcbiAgICAgICAgcmV0dXJuIHBcblxuICAgIH0pIGFzIEFzeW5jUHVsbFN0cmVhbTxUPlxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgcHVzaCxcbiAgICAgICAgbmV4dCxcbiAgICAgICAgZG9uZTogKCkgPT4geyBkb25lID0gdHJ1ZTsgfVxuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgYXBzX2l0ZW1zX2Zyb21fYXJyYXkgPSA8VD4oc3RyZWFtOiBBc3luY1B1bGxTdHJlYW08VFtdPik6IEFzeW5jUHVsbFN0cmVhbTxUPiA9PiB7XG5cbiAgICBsZXQgYXJyYXk6IFRbXSA9IFtdXG5cbiAgICByZXR1cm4gKGFzeW5jIChlbmQ/OiB0X2VuZCkgPT4ge1xuXG4gICAgICAgIGlmIChlbmQgPT0gU19lbmQpe1xuICAgICAgICAgICAgc3RyZWFtKFNfZW5kKVxuICAgICAgICAgICAgcmV0dXJuIFNfZW5kXG4gICAgICAgIH1cblxuICAgICAgICB3aGlsZSAoYXJyYXkubGVuZ3RoID09IDApe1xuICAgICAgICAgICAgY29uc3QgdiA9IGF3YWl0IHN0cmVhbSgpXG4gICAgICAgICAgICBpZiAodiA9PSBTX2VuZCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFNfZW5kXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhcnJheSA9IHZcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXJyYXkuc2hpZnQoKSFcbiAgICB9KVxufVxuXG4vLyBiYXNpY2FsbHkgdGhpcyBpcyAgIHB1bGxfdG9fcHVzaCBhbmQgcHVzaF90b19wdWxsIChwdXNoX3RvX3B1bGwgY29udGFpbnMgYnVmZmVyaW5nIGJlY2F1c2UgaXQgaGFzIHRvIHN0YXJ0L3N0b3AgXG4vLyB0aGUgc291cmNlIHN0cmVhbVxuZXhwb3J0IGNvbnN0IGFwc19idWZmZXJlZCA9IDxUPihzdHJlYW06IEFzeW5jUHVsbFN0cmVhbTxUPiwgbzogSGlnaExvd09yV2F0ZXJtYXJrID0ge30pOiBBc3luY1B1bGxTdHJlYW08VD4gPT4ge1xuICAgIGNvbnN0IHsgbG93X3dhdGVybWFyaywgaGlnaF93YXRlcm1hcmt9ID0gd2F0ZXJtYXJrcyhvKVxuXG4gICAgY29uc3QgYnVmZmVyOiBWYWx1ZUVycm9yRW5kPFQ+W10gPSBbXVxuICAgIGxldCBwX2hhbmRsZXJzOiB1bmRlZmluZWQgfCBSZXNvbHZlUmVqZWN0QXJyYXk8VCB8IHRfZW5kPiA9IHVuZGVmaW5lZFxuXG4gICAgbGV0IHJ1bm5pbmcgPSBmYWxzZVxuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKHJ1bm5pbmcpIHJldHVybiBcbiAgICAgICAgcnVubmluZyA9IHRydWVcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdoaWxlICggYnVmZmVyLmxlbmd0aCA8IGhpZ2hfd2F0ZXJtYXJrKXtcbiAgICAgICAgICAgICAgICBjb25zdCB2ID0gYXdhaXQgcHJvbWlzZV90b192ZWUoc3RyZWFtKCkpXG4gICAgICAgICAgICAgICAgaWYgKHBfaGFuZGxlcnMpIHsgdmVlX3RvX3BfaGFuZGxlcih2LCBwX2hhbmRsZXJzKTsgcF9oYW5kbGVycyA9IHVuZGVmaW5lZDsgfVxuICAgICAgICAgICAgICAgIGVsc2UgYnVmZmVyLnB1c2godilcbiAgICAgICAgICAgICAgICBpZiAodiA9PSBTX2VuZCkgYnJlYWtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHJ1bm5pbmcgPSBmYWxzZVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIChhc3luYyAoZW5kPzogdF9lbmQpID0+IHtcblxuICAgICAgICBpZiAoZW5kID09IFNfZW5kKXtcbiAgICAgICAgICAgIHN0cmVhbShTX2VuZClcbiAgICAgICAgICAgIHJldHVybiBTX2VuZFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGJ1ZmZlci5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgIGNvbnN0IHIgPSBidWZmZXIuc2hpZnQoKSFcbiAgICAgICAgICAgIGlmIChidWZmZXIubGVuZ3RoIDwgbG93X3dhdGVybWFyaylcbiAgICAgICAgICAgICAgICBydW4oKVxuICAgICAgICAgICAgcmV0dXJuIHZlZV90b192YWx1ZShyKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgcCA9IG5ldyBQcm9taXNlPFQ+KChyLGopID0+IHsgcF9oYW5kbGVycyA9IFtyLGpdIH0pXG4gICAgICAgICAgICBydW4oKVxuICAgICAgICAgICAgcmV0dXJuIHBcbiAgICAgICAgfVxuICAgIH0pIGFzIEFzeW5jUHVsbFN0cmVhbTxUPlxufVxuXG5leHBvcnQgdHlwZSBhcHNfemlwX28gPSB7XG4gICAgZW5kX29uX2ZpcnN0X2VuZD86IGJvb2xlYW4gLy8gZGVmYXVsdHMgdG8gdHJ1ZVxufVxuXG4vLyB6aXAgdmFsdWVzIG9mIG9uZSBvciBtb3JlIHN0cmVhbXMgYXMgW3YxLHYyXVxuZXhwb3J0IGNvbnN0IGFwc196aXAgPSA8VCBleHRlbmRzIEFzeW5jUHVsbFN0cmVhbTx1bmtub3duPltdPihvOiBhcHNfemlwX28sIC4uLnN0cmVhbXM6IFQpOiBBc3luY1B1bGxTdHJlYW08eyBbSyBpbiBrZXlvZiBUXTogVFtLXSBleHRlbmRzIChpbmZlciBVKVtdID8gVSA6IG5ldmVyIH0+ID0+IHtcblxuICAgIGNvbnN0IGVuZF9hbGwgPSAoKSA9PiBQcm9taXNlLmFsbChzdHJlYW1zLm1hcCgoeCkgPT4geChTX2VuZCkpKVxuICAgIGNvbnN0IGMgPSBzdHJlYW1zLmxlbmd0aFxuXG4gICAgcmV0dXJuIChhc3luYyAoZW5kPzogdF9lbmQpID0+IHtcblxuICAgICAgICAvLyBUT0RPIHdvdWxkIGJlIG5pY2UgaWYgd2UgYWRkZWQgaGludHMgd2hpY2ggc3RyZWFtIGNhdXNlZCBhbiBhbiBpc3N1ZVxuICAgICAgICBjb25zdCB2YWx1ZXMgPSBhd2FpdCBQcm9taXNlLmFsbChzdHJlYW1zLm1hcCgoeCkgPT4geCgpKSlcblxuICAgICAgICBjb25zdCBjb3VudF9lbmRzID0gdmFsdWVzLmZpbHRlcigoeCkgPT4geCA9PT0gU19lbmQpLmxlbmd0aFxuXG4gICAgICAgIGlmIChjb3VudF9lbmRzID4gMCAmJiAoby5lbmRfb25fZmlyc3RfZW5kID8/IHRydWUpKXtcbiAgICAgICAgICAgIGVuZF9hbGwoKSAvLyBUT0RPIGF3YWl0IG9yIGxldCBnbyA/XG4gICAgICAgICAgICByZXR1cm4gU19lbmRcbiAgICAgICAgfSBlbHNlIGlmIChjb3VudF9lbmRzID09IGMpIHtcbiAgICAgICAgICAgIGVuZF9hbGwoKSAvLyBUT0RPIGF3YWl0IG9yIGxldCBnbyA/XG4gICAgICAgICAgICByZXR1cm4gU19lbmRcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB2YWx1ZXNcblxuICAgIH0pIGFzIEFzeW5jUHVsbFN0cmVhbTxUPlxufVxuXG4vLyBjaHVuayBjb3VudCBpdGVtcyBpbnRvIGFuIGFycmF5XG5leHBvcnQgY29uc3QgYXBzX3BhcnRpdGlvbiA9IDxUPihzdHJlYW06IEFzeW5jUHVsbFN0cmVhbTxUPiwgY291bnQ6IG51bWJlcik6IEFzeW5jUHVsbFN0cmVhbTxUW10+ID0+IHtcbiAgICBsZXQgZW5kaW5nID0gZmFsc2VcbiAgICByZXR1cm4gKGFzeW5jIChlbmQ/OiB0X2VuZCkgPT4ge1xuICAgICAgICBpZiAoZW5kKSByZXR1cm4gc3RyZWFtKFNfZW5kKVxuICAgICAgICBpZiAoZW5kaW5nKSByZXR1cm4gU19lbmRcbiAgICAgICAgY29uc3QgYTogVFtdID0gW11cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjb3VudCA7IGkrKykge1xuICAgICAgICAgICBjb25zdCB2ID0gYXdhaXQgc3RyZWFtKClcbiAgICAgICAgICAgaWYgKHYgPT0gU19lbmQpe1xuICAgICAgICAgICAgICAgZW5kaW5nID0gdHJ1ZVxuICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgIH0gZWxzZSBhLnB1c2godilcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYVxuICAgIH0pXG59XG5cblxuZXhwb3J0IHR5cGUgYXBzX2NvbmN1cnJlbnRfb3B0cyA9IHtcbiAgICBwcmVzZXJ2ZV9vcmRlcjogYm9vbGVhbixcbiAgICBjb25jdXJyZW5jeTogbnVtYmVyXG59XG4iLCAiLy8gdXNhZ2U6XG4vLyBjb25zdCBnZXRUb2tlbiA9IGNyZWF0ZUxpbWl0ZXIoKCkgPT4gMTAwKVxuLy8gd2hpbGUgKHRydWUpOyB7IGF3YWl0IGdldFRva2VuKCk7IC4ufVxuZXhwb3J0IHR5cGUgR2V0VG9rZW4gPSAoKSA9PiBQcm9taXNlPHZvaWQ+XG5cbmNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpID0+IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSlcblxuZXhwb3J0IGNvbnN0IGNyZWF0ZUxpbWl0ZXIgPSAobXNfZnVuOiAoKSA9PiBudW1iZXIpOiAoKSA9PiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICBsZXQgbGFzdDogdW5kZWZpbmVkIHwgbnVtYmVyID0gdW5kZWZpbmVkXG4gICAgLy8gcmV0dXJucyBnZXRUb2tlbigpIGZ1bmN0aW9uIHRvIGJlIGF3YWl0ZWQgZm9yXG4gICAgcmV0dXJuIGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICAgICAgY29uc3Qgd2FpdCA9IG1zX2Z1bigpXG4gICAgICAgIGNvbnN0IG4gPSAobmV3IERhdGUpLmdldFRpbWUoKVxuICAgICAgICBpZiAoIWxhc3Qpe1xuICAgICAgICAgICAgbGFzdCA9IG5cbiAgICAgICAgICAgIHJldHVybjsgLy8gZmlyc3QgcnVuXG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2xlZXBfbXMgPSB3YWl0IC0gKG4gLSBsYXN0KVxuICAgICAgICBpZiAoc2xlZXBfbXMgPiAwKSBhd2FpdCBzbGVlcChzbGVlcF9tcylcbiAgICAgICAgbGFzdCA9IG4gKyBzbGVlcF9tc1xuICAgICAgICByZXR1cm4gXG4gICAgfVxufVxuXG4vLyBjcmVhdGVSYW5kb21MaW1pdGVyKDIwMCwgMjAwMCkgcmFuZG9tIGludGVydmFsIGJldHdlZW4gMjAwIGFuZCAyMDAwIG1zXG5leHBvcnQgY29uc3QgY3JlYXRlUmFuZG9tTGltaXRlciA9IChtczogWyBudW1iZXIsIG51bWJlcl0pID0+IGNyZWF0ZUxpbWl0ZXIoKCkgPT4gbXNbMF0gKyAobXNbMV0gLSBtc1swXSkgKiBNYXRoLnJhbmRvbSgpKVxuIiwgIi8vIHJlcGxhY2UgZGVlcC1lcXVhbCB3aXRoIGxvZGFzaC9pc0VxdWFsP1xuaW1wb3J0IGVxdWFsIGZyb20gXCJkZWVwLWVxdWFsXCJcbmltcG9ydCB7IGV4Y2VwdGlvbl90b19zdHIgfSBmcm9tIFwidS1leGNlcHRpb24tdG8tc3RyaW5nXCI7XG4vKiB1c2FnZVxuXG5pbXBvcnQge3J1bl90ZXN0c19wcmludH0gZnJvbSAndS10ZXN0cnVubmVyJztcblxuYXdhaXQgcnVuX3Rlc3RzX3ByaW50KHtcbiAgJ2Rlc2NyaXB0aW9uJzogJ3Rlc3QnLFxuICAndGltZW91dCcgOiAyMDAwLFxufSwgYXN5bmMgKHJ1bm5lcikgPT4ge1xuXG4gIGNvbnN0IGQgPSAoczogc3RyaW5nKSA9PiBydW5uZXIuZGVzY3JpYmUoYGRlbW8gZXhwZWN0YXRpb24gJHtzfSlcblxuICB7XG4gICAgY29uc3QgcCA9IGQoXCJzaG91bGQgc3VjY2VlZFwiKVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge3AucmVzb2x2ZSgpOyB9LCAyMDApO1xuICB9XG5cblxuICB7IC8vIHRoaXMgaXMgYSBub3RpY2UsIG5vdCBhIGZhaWx1cmVcbiAgICBjb25zdCBwID0gZChcInNob3VsZCBiZSBpbXBsZW1lbnRlZCBsYXRlclwiKVxuICAgIHAudG9kbygpXG4gIH1cblxuICB7XG4gICAgY29uc3QgcCA9IGQoXCJ0aGlzIGV4cGVjdGF0aW9uIGZhaWxzXCIpXG4gICAgcC5mYWlsKClcbiAgfVxuXG4gIHtcbiAgICBjb25zdCBwID0gZChcInNob3VsZCBiZSB0cnVlXCIpXG4gICAgcC5leHBlY3RfdHJ1ZSh0cnVlKVxuICB9XG5cbiAge1xuICAgIGNvbnN0IHAgPSBkKGBzaG91bGQgY2F1c2UgZXhjZXB0aW9uIFwiZmFpbFwiYClcbiAgICBwLmV4cGVjdF9leGNlcHRpb24oKCkgPT4gdGhyb3cgXCJmYWlsXCIpXG4gICAgLy8gcC5leHBlY3RfZXhjZXB0aW9uKCgpID0+IHRocm93IFwiZmFpbFwiLCAvXmZhaWwkLylcbiAgICAvLyBwLmV4cGVjdF9leGNlcHRpb24oKCkgPT4gdGhyb3cgXCJmYWlsXCIsIChlKSA9PiBlLnRvU3RyaW5nIGlzIGZhaWwgb3Igc3VjaCApXG4gIH1cblxuICB7XG4gICAgY29uc3QgcCA9IGQoYHNob3VsZCBjYXVzZSBwcm9taXNlIGZhbGluZyB3aXRoIGV4Y2VwdGlvbiBcImZhaWxcImApXG4gICAgICAgcC5leHBlY3RfZXhjZXB0aW9uKGFzeW5jICgpID0+IHRocm93IFwiZmFpbFwiKVxuICAgIC8vIHAuZXhwZWN0X2V4Y2VwdGlvbihhc3luYyAoKSA9PiB0aHJvdyBcImZhaWxcIiwgL15mYWlsJC8pXG4gICAgLy8gcC5leHBlY3RfZXhjZXB0aW9uKGFzeW5jICgpID0+IHRocm93IFwiZmFpbFwiLCAoZSkgPT4gZS50b1N0cmluZyBpcyBmYWlsIG9yIHN1Y2ggKVxuXG4gIH1cblxuICB7XG4gICAgY29uc3QgcCA9IGQoYHNob3VsZCBiZSBkZWVwIGVxdWFsYClcbiAgICBwLmV4cGVjdF9kZWVwX2VxdWFsKFsxLDJdLCBbMSwyXSlcbiAgfVxuXG4gIC8vIGlmIHRoaXMgZnVuY3Rpb24gZmFpbHMsIGl0IHRlc3QgY2FzZSB3aWxsIGhhdmUgYSBmYWlsdXJlLCB0b29cbiAgdGhyb3cgXCJmYWlsdXJlXCJcblxufSlcblxuVG8gcnVuIGluIGJyb3dzZXJcbnVzZSBydW4sIHRoZW4gdGVzdHNfZmFpbGVkIGFuZCByZXN1bHRfdG9fc3RyaW5nIHRvIGdldCB0ZXN0IHJlc3VsdFxuXG49PVxuXG5XaHkgbm90IHVzZSBjaGFpLCBodHRwczovL2dpdGh1Yi5jb20vYXZhanMvYXZhIG9yIHNvbWV0aGluZyBzaW1pbGFyP1xuQmVjYXVzZSB0aGlzIGlzIGxlc3MgY29kZSAtIGl0cyBtb3N0IHNpbXBsZSBieSBkZXNpZ24gOilcblxuY29weV9yZXN1bHRzIGNhbiBiZSB1c2VkIHRvIGludGVncmF0ZSBzZXJpYWxpemVkIHRlc3QgcmVzdXRscyBydW4gc29tZXdoZXJlXG5lbHNlIGVnIGluIHRoZSBicm93c2VyIGludG8gbWFpbiB0ZXN0IHJlc3VsdC5cblxuV2hhdCdzIHJlYWxseSBtaXNzaW5nIGlzIGFsbG93aW5nIHRvIHJ1biAnc29tZScgdGVzdHMgb25seS5cbkJ1dCB0aGlzIGhpZ2hseSBkZXBlbmRzIG9uIHRoZSB3aGF0IGlzIHRvIGJlIHRlc3RlZC5cblxuXG5jb25zdCBjYXNlcyA9IFsndGhhdF9ibG9jaycsICdhbm90aGVyX2Jsb2NrJ11cblxuXG5hd2FpdCBydW5fdGVzdHNfcHJpbnQoe1xuICAnZGVzY3JpcHRpb24nOiAndGVzdCcsXG4gICd0aW1lb3V0JyA6IDIwMDAsXG59LCBhc3luYyAocnVubmVyKSA9PiB7XG4gICAgaWYgKGNhc2VzLmluY2x1ZGVzKFwidGhhdF9ibG9jaycpKVxuICAgICAgICBydW5fdGhhdF9ibG9ja190ZXN0cyhydW5uZXIpXG4gICAgLi4uXG59KVxuXG4qL1xuaW50ZXJmYWNlIFRlc3RTdGF0ZSB7XG4gICAgbGFiZWw6IHN0cmluZztcbiAgICBwcm9taXNlOiBQcm9taXNlTGlrZTxhbnk+fHVuZGVmaW5lZDtcbn1cblxuLy8gc2VyaWFsaXphYmxlIHN0YXRlIHJlcHJlc2VudGluZyB0ZXN0IHJlc3VsdCAoZS5nLiBKU09OKVxuZXhwb3J0IHR5cGUgVGVzdHNSZXN1bHQgPSB7XG4gICAgZmFpbGVkOiBBcnJheTx7bGFiZWw6IHN0cmluZywgZmFpbHVyZTogYW55fT4sXG4gICAgdG9kbzogQXJyYXk8c3RyaW5nPixcbiAgICBwYXNzZWQ6IHN0cmluZ1tdLFxuICAgIHRpbWVkb3V0OiBzdHJpbmdbXSxcbn1cblxuZXhwb3J0IGNvbnN0IGNvcHlfcmVzdWx0cyA9IChmcm9tOiBUZXN0c1Jlc3VsdCwgdG86IFRlc3RzUmVzdWx0LCBwcmVmaXg6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IGFkZHAgPSAoeDogc3RyaW5nKSA9PiBgJHtwcmVmaXh9JHt4fWBcbiAgICB0by5mYWlsZWQgICAgPSBbLi4udG8uZmFpbGVkLCAuLi5mcm9tLmZhaWxlZC5tYXAoeCA9PiAoey4uLngsIGxhYmVsOiBgJHtwcmVmaXh9JHt4LmxhYmVsfWB9KSldXG4gICAgdG8ucGFzc2VkID0gWy4uLnRvLnBhc3NlZCwgLi4uZnJvbS5wYXNzZWQubWFwKGFkZHApXVxuICAgIHRvLnRpbWVkb3V0ICA9IFsuLi50by50aW1lZG91dCwgIC4uLmZyb20udGltZWRvdXQubWFwKGFkZHApXVxuICAgIHRvLnRvZG8gICAgICA9IFsuLi50by50b2RvLCAuLi5mcm9tLnRvZG8ubWFwKGFkZHApXVxufVxuXG5jb25zdCB0ZXN0c19yZXN1bHQgPSAoKSA9PiAoe1xuICAgIGZhaWxlZDogW10sXG4gICAgdG9kbzogW10sXG4gICAgcGFzc2VkOiBbXSxcbiAgICB0aW1lZG91dDogW10gLy8gZ2V0cyBwb3B1bGF0ZWQgYXQgZW5kIG9mIHJ1bigpXG59KVxuXG5leHBvcnQgdHlwZSBUZXN0c1N0YXRlID0ge1xuICAgIF9uciA6IG51bWJlciwgLy8gaW50ZXJuYWxcblxuICAgIHJ1bm5pbmc6IHtba2V5OiBudW1iZXJdOiBUZXN0U3RhdGV9LFxuICAgIHJlc3VsdDogVGVzdHNSZXN1bHRcbn1cbmV4cG9ydCBjb25zdCB0ZXN0c19zdGF0ZSA9ICgpOiBUZXN0c1N0YXRlID0+ICh7XG4gICAgX25yOiAwLFxuICAgIHJ1bm5pbmc6IHt9LFxuICAgIHJlc3VsdDogdGVzdHNfcmVzdWx0KClcbn0pXG5cbmV4cG9ydCBjb25zdCB0ZXN0c19mYWlsZWQgPSAocmVzdWx0OiBUZXN0c1Jlc3VsdCkgPT4gcmVzdWx0LmZhaWxlZC5sZW5ndGggPiAwIHx8IHJlc3VsdC50aW1lZG91dC5sZW5ndGggPiAwXG5cbmV4cG9ydCBjb25zdCByZXN1bHRfdG9fc3RyaW5nID0gKHRyOlRlc3RzUmVzdWx0KSA9PiB7XG4gICAgbGV0IHI6IHN0cmluZ1tdID0gW11cbiAgICByLnB1c2goYHBhc3NlZDogJHt0ci5wYXNzZWQubGVuZ3RofWApXG5cbiAgICBjb25zdCBhZGQgPSAobGFiZWw6IHN0cmluZywgbGlzdDogc3RyaW5nW10pID0+IHtcbiAgICAgICAgaWYgKGxpc3QubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICByLnB1c2goYD09PSAke2xhYmVsfVxcbmApXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB0ci5mYWlsZWQuZm9yRWFjaCgodiwgaSkgPT4ge1xuICAgICAgICByLnB1c2goYGZhaWxlZDogJHt2LmxhYmVsfWApO1xuICAgICAgICByID0gW1wiIFwiLCAuLi5yLCAuLi5leGNlcHRpb25fdG9fc3RyKHYuZmFpbHVyZSkuc3BsaXQoXCJcXG5cIildO1xuICAgIH0pO1xuXG4gICAgdHIudG9kby5mb3JFYWNoKCh2LCBpKSA9PiB7XG4gICAgICAgIHIucHVzaChgdG9kbzogJHt2fWApO1xuICAgIH0pO1xuXG4gICAgKHRyLnRpbWVkb3V0ID8/W10pLmZvckVhY2goKHYsIGkpID0+IHtcbiAgICAgICAgci5wdXNoKGB0aW1lZG91dDogJHt2fWApO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHJcbn1cblxuZXhwb3J0IGNvbnN0IHByaW50X3Rlc3RzX3Jlc3VsdHMgPSAocmVzdWx0OiBUZXN0c1Jlc3VsdCwgZGVzY3JpcHRpb24/OiBzdHJpbmcpID0+IHtcbiAgICBpZiAodGVzdHNfZmFpbGVkKHJlc3VsdCkpXG4gICAgICAgIGNvbnNvbGUubG9nKGA9PT0gOi0oIHRlc3RzIGZhaWxlZCAke2Rlc2NyaXB0aW9ufWAsIHJlc3VsdF90b19zdHJpbmcocmVzdWx0KSk7XG4gICAgZWxzZVxuICAgICAgICBjb25zb2xlLmxvZyhgPT09IDotKSB0ZXN0cyBwYXNzZWQgJHtkZXNjcmlwdGlvbn1gLCByZXN1bHRfdG9fc3RyaW5nKHJlc3VsdCkpO1xufVxuZXhwb3J0IGNvbnN0IHJ1bl90ZXN0c19wcmludCA9IGFzeW5jIChjOiBDb25maWcsIGY6IFRlc3QpID0+IHtcbiAgICBjb25zb2xlLmxvZyhgPT0gJHtjLmRlc2NyaXB0aW9ufWApXG4gICAgcHJpbnRfdGVzdHNfcmVzdWx0cyhhd2FpdCBydW4oYywgZikpXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlnIHtcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgIGFib3J0X29uX2ZhaWx1cmU/OiBib29sZWFuLFxuICAgIHRpbWVvdXQ6IG51bWJlcjtcbiAgICByZXBvcnRfcGVyaW9kPzogbnVtYmVyO1xuICAgIHJlcG9ydF9zdGF0ZT86IChzdGF0ZTogVGVzdHNTdGF0ZSkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IHR5cGUgRXhwZWN0RXhjZXB0aW9uID0gUmVnRXhwIHwgKChlOmFueSkgPT4gdm9pZClcblxuZXhwb3J0IHR5cGUgRGVzY3JpYmUgPSAobGFiZWw6IHN0cmluZykgPT4ge1xuICAgIFwicmVzb2x2ZVwiOiAoKSA9PiB2b2lkLFxuICAgIFwidG9kb1wiOiAoKSA9PiB2b2lkLFxuICAgIFwiZmFpbFwiOiAoeDogc3RyaW5nKSA9PiB2b2lkLFxuICAgIFwiZXhwZWN0X3RydWVcIjogKHg6IGJvb2xlYW4sIHJlYXNvbj86IHN0cmluZykgPT4gdm9pZCwgLy8gVE9ETzogZHJvcCByZWFzb24gP1xuICAgIFwiZXhwZWN0X2FsbF90cnVlXCI6ICguLi54OiBib29sZWFuW10pID0+IHZvaWQsXG4gICAgXCJleHBlY3RfZGVlcF9lcXVhbFwiOiA8VD4oYTogVCwgYjogVCwgc3RyaWN0PzogYm9vbGVhbikgPT4gdm9pZCxcbiAgICBcImV4cGVjdF9leGNlcHRpb25cIjogPFQ+KGY6ICgpID0+IHZvaWQsIGV4cGVjdF9leGNlcHRpb24/OiBFeHBlY3RFeGNlcHRpb24pID0+IHZvaWQsXG4gICAgXCJleHBlY3RfZmFpbGluZ19wcm9taXNlXCI6IDxUPihmOiAoKSA9PiBQcm9taXNlPGFueT4sIGV4cGVjdF9leGNlcHRpb24/OiBFeHBlY3RFeGNlcHRpb24pID0+IFByb21pc2U8dm9pZD4sXG4gICAgXCJleHBlY3RfcmVzb2x2aW5nX3Byb21pc2VcIjogPFQ+KHA6IFByb21pc2U8YW55PikgPT4gUHJvbWlzZTx2b2lkPixcbn1cbmV4cG9ydCB0eXBlIEV4cGVjdGF0aW9uID0gUmV0dXJuVHlwZTxEZXNjcmliZT5cblxuZXhwb3J0IGludGVyZmFjZSBSdW5uZXIge1xuICAgIFwicHJvbWlzZVwiOiAocDogUHJvbWlzZTxhbnk+LCBsYWJlbD86IHN0cmluZykgPT4gdm9pZCxcbiAgICAgICAgXCJzdGF0ZVwiOiBUZXN0c1N0YXRlLCAvLyBmb3Igc2hvd2luZyBwcm9ncmVzcyBldmVyeSB4IHNlY29uZHMgb3Igc28gP1xuICAgICAgICBcInRvZG9cIjogKHg6IHN0cmluZykgPT4gdm9pZFxuICAgICAgICBcImRlc2NyaWJlXCI6IERlc2NyaWJlXG4gICAgXCJmaW5hbGx5XCI6ICh4OiAoKSA9PiB2b2lkKSA9PiB2b2lkLFxufVxuXG5leHBvcnQgdHlwZSBUZXN0ID0gKHJ1bm5lcjogUnVubmVyKSA9PiBQcm9taXNlPHZvaWQ+O1xuXG4vLyBleHBvcnQgdHlwZSBFRXhjZXB0aW9uV2hpbGVSdW5uaW5nTWF0Y2hFeHBlY3RlZEV4Y2VwdGlvbiA9IHtcbi8vICAgICBlcnJvcjogc3RyaW5nLFxuLy8gICAgIGV4Y2VwdGlvbl90b19iZV9tYXRjaGVkOiBhbnksXG4vLyAgICAgY2F1Z2h0X2V4Y2VwdGlvbjogYW55XG4vLyB9XG5cbmV4cG9ydCBjb25zdCBydW4gPSAoXG4gICAgY2ZnOiBDb25maWcsXG4gICAgZjogVGVzdCxcbiAgICBvPzoge3N0YXRlPzogVGVzdHNTdGF0ZX0gLy8gYWxsb3cgcmV1c2luZyBzdGF0ZSBmb3IgbXVsdGlwbGUgcnVuc1xuKTogUHJvbWlzZTxUZXN0c1Jlc3VsdD4gPT4ge1xuICAgIGNvbnN0IGZpbmFsbGllczogQXJyYXk8KCkgPT4gdm9pZD4gICA9IFtdO1xuICAgIGNvbnN0IHN0YXRlOiBUZXN0c1N0YXRlID0gbz8uc3RhdGUgPz8gdGVzdHNfc3RhdGUoKVxuICAgIGxldCB0aW1lcjogYW55O1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblxuICAgICAgICBjb25zdCBlbmRfcnVuID0gKHdoeTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICAgICAgc3RhdGUucmVzdWx0LnRpbWVkb3V0ID0gT2JqZWN0LnZhbHVlcyhzdGF0ZS5ydW5uaW5nKS5tYXAoeCA9PiB4LmxhYmVsKVxuICAgICAgICAgICAgcmVzb2x2ZShzdGF0ZS5yZXN1bHQpO1xuICAgICAgICAgICAgZmluYWxsaWVzLmZvckVhY2goKHopID0+IHooKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgdHJhY2sgPSAobGFiZWw6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IHN0YXRlLl9ucisrO1xuICAgICAgICAgICAgc3RhdGUucnVubmluZ1tuZXh0XSA9IHtcbiAgICAgICAgICAgICAgICBwcm9taXNlOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgbGFiZWwsXG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICByZXR1cm4gKHA6IFByb21pc2VMaWtlPGFueXx2b2lkPikgPT4ge1xuICAgICAgICAgICAgICAgIHN0YXRlLnJ1bm5pbmdbbmV4dF0ucHJvbWlzZSA9IHA7XG4gICAgICAgICAgICAgICAgY29uc3QgZG9uZSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHN0YXRlLnJ1bm5pbmdbbmV4dF07XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGBkZWxldGVkICR7bnJ9YClcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKHN0YXRlLnJ1bm5pbmcpLmxlbmd0aCA9PT0gMCkgeyBlbmRfcnVuKFwibm8gbW9yZSBydW5uaW5nXCIpOyB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBwLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICh4KSA9PiB7IHN0YXRlLnJlc3VsdC5wYXNzZWQucHVzaChgb2s6ICR7bGFiZWx9YCk7IGRvbmUoKTsgfSxcbiAgICAgICAgICAgICAgICAgICAgKHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVfc3RyID0gZXhjZXB0aW9uX3RvX3N0cih4KVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJmYWlsZWRcIiwgeCwgZV9zdHIpXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5yZXN1bHQuZmFpbGVkLnB1c2goe2xhYmVsLCBmYWlsdXJlOiBlX3N0ciB9KTsgZG9uZSgpOyB9LFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBzdGVwID0gY2ZnLnJlcG9ydF9wZXJpb2QgfHwgY2ZnLnRpbWVvdXQ7XG4gICAgICAgIGNvbnN0IHByaW50X2FuZF9yZXN0YXJ0ID0gKHRpbWVvdXQ6IG51bWJlciwgZmlyc3Q/OiBib29sZWFuKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2ZnLnJlcG9ydF9zdGF0ZSAmJiAhZmlyc3QpIHsgY2ZnLnJlcG9ydF9zdGF0ZShzdGF0ZSk7IH1cbiAgICAgICAgICAgIGlmICh0aW1lb3V0ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgZW5kX3J1bihcImVuZGluZyBydW4gZHVlIHRvIHRpbWVvdXRcIik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7IHByaW50X2FuZF9yZXN0YXJ0KHRpbWVvdXQgLSBzdGVwKTsgfSwgc3RlcCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7IHByaW50X2FuZF9yZXN0YXJ0KGNmZy50aW1lb3V0LCB0cnVlKTsgfSwgMCk7XG5cbiAgICAgICAgY29uc3QgZGVzY3JpYmUgPSAobGFiZWw6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgY29uc3QgZDogYW55ID0ge307XG4gICAgICAgICAgICBkLnByb21pc2UgPSBuZXcgUHJvbWlzZTx2b2lkPigociwgaikgPT4ge1xuXG4gICAgICAgICAgICAgICAgaWYgKGNmZy5hYm9ydF9vbl9mYWlsdXJlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgal9vID0gajtcbiAgICAgICAgICAgICAgICAgICAgaiA9IChlKSA9PiB7IGpfbyhlKTsgdGhyb3cgRXJyb3IoYCR7ZX1gKSB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGFzc2VydF90cnVlID0gKGI6IGJvb2xlYW4sIHJlYXNvbj86IHN0cmluZykgPT4geyBpZiAoYikgeyByKCk7IH0gZWxzZSB7IGoocmVhc29uIHx8IFwibm8gcmVhc29uIGdpdmVuXCIpOyB9IH07XG4gICAgICAgICAgICAgICAgY29uc3QgZXhwZWN0X2FsbF90cnVlID0gKC4uLmI6IGJvb2xlYW5bXSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJzID0gW11cbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IGIubGVuZ3RoOyBpIDwgbGVuIDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFiW2ldKSBlcnJzLnB1c2goYGFyZ3VtZW50ICR7aSArIDF9IGZhaWxlZGApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJzLmxlbmd0aCA+IDApIGooZXJycy5qb2luKFwiLFxcblwiKSlcbiAgICAgICAgICAgICAgICAgICAgcigpXG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IF9leHBlY3RfZXhjZXB0aW9uID0gKGU6YW55LCBleHBlY3RfZXhjZXB0aW9uPzogRXhwZWN0RXhjZXB0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChleHBlY3RfZXhjZXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhwZWN0X2V4Y2VwdGlvbiBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLnRvU3RyaW5nKCkubWF0Y2goZXhwZWN0X2V4Y2VwdGlvbikpIHIoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGooe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcjogYEV4cGVjdGVkIGV4Y2VwdGlvbiB0byBtYXRjaCBnaXZlbiByZWdleCAke2V4cGVjdF9leGNlcHRpb259YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhjZXB0aW9uOiBlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0X2V4Y2VwdGlvbihlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGooe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2Vycm9yJzogJ2V4Y2VwdGlvbiB3aGlsZSBsb29raW5nIGF0IGV4cGVjdGVkIGV4Y2VwdGlvbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZXhjZXB0aW9uJzogZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBpZiAoZXhwZWN0X2V4Y2VwdGlvbihlKSkgcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBlbHNlIGooYGdvdCBleGNlcHRpb24gJHtlfSBidXQgbm90IHRoZSBvbmUgbWF0Y2hpbmcgZnVuY3Rpb25gKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIH0gY2F0Y2ggKGUyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgaih7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICBlcnJvcjogXCJleGNlcHRpb24td2hpbGUtcnVubmluZy1tYXRjaC1leGNlcHRpb25cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIGV4Y2VwdGlvbl90b19iZV9tYXRjaGVkOiBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgY2F1Z2h0X2V4Y2VwdGlvbjogZTIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIH0gYXMgRUV4Y2VwdGlvbldoaWxlUnVubmluZ01hdGNoRXhwZWN0ZWRFeGNlcHRpb24pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgcigpIC8vIHdlIGdvdCBhbnkgZXhjZXB0aW9uIGRvbid0IGNhcmUgd2hhdFxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGQucmVzb2x2ZSA9IHI7XG4gICAgICAgICAgICAgICAgZC50b2RvID0gKCkgPT4geyByKCk7IHN0YXRlLnJlc3VsdC50b2RvLnB1c2gobGFiZWwpIH07XG4gICAgICAgICAgICAgICAgZC5mYWlsID0gajtcbiAgICAgICAgICAgICAgICBkLmV4cGVjdF90cnVlID0gYXNzZXJ0X3RydWVcbiAgICAgICAgICAgICAgICBkLmV4cGVjdF9hbGxfdHJ1ZSA9IGV4cGVjdF9hbGxfdHJ1ZVxuICAgICAgICAgICAgICAgIGQuZXhwZWN0X2V4Y2VwdGlvbiA9IChmOiAoKSA9PiBhbnksIGV4cGVjdF9leGNlcHRpb24/OiBFeHBlY3RFeGNlcHRpb24pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGYoKVxuICAgICAgICAgICAgICAgICAgICAgICAgaihgZXhjZXB0aW9uIGV4cGVjdGVkYClcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBfZXhwZWN0X2V4Y2VwdGlvbihlLCBleHBlY3RfZXhjZXB0aW9uKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGQuZXhwZWN0X2ZhaWxpbmdfcHJvbWlzZSA9IChmOiAoKSA9PiBQcm9taXNlPGFueT4sIGV4cGVjdF9leGNlcHRpb24/OiBSZWdFeHAgfCAoKGU6YW55KSA9PiBib29sZWFuKSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwID0gZigpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICAgICAoKSA9PiBqKGBleGNlcHRpb24gZXhwZWN0ZWQgbWF0Y2hpbmcgJHtleHBlY3RfZXhjZXB0aW9uPy50b1N0cmluZygpfWApLFxuICAgICAgICAgICAgICAgICAgICAgICAgKGU6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlYnVnZ2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9leHBlY3RfZXhjZXB0aW9uKGUsIGV4cGVjdF9leGNlcHRpb24pXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGQuZXhwZWN0X3Jlc29sdmluZ19wcm9taXNlID0gKHA6IFByb21pc2U8YW55PikgPT4gcC50aGVuKCByLCBqIClcblxuICAgICAgICAgICAgICAgIGQuZXhwZWN0X2RlZXBfZXF1YWwgPSA8VD4oYTogVCwgYjogVCwgc3RyaWN0PzogYm9vbGVhbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBhc3NlcnRfdHJ1ZShlcXVhbChhLCBiLCB7IHN0cmljdDogISFzdHJpY3QgfSksIGBhIHRvIGRlZXAgZXF1YWwgYlxcbmE6JHtKU09OLnN0cmluZ2lmeShhKX1cXG5iOiR7SlNPTi5zdHJpbmdpZnkoYil9YClcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHRyYWNrKGAke2xhYmVsfWApKGQucHJvbWlzZSk7XG4gICAgICAgICAgICByZXR1cm4gZDtcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBwcm9taXNlID0gKHA6IFByb21pc2U8YW55PiwgbGFiZWw/OiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIC8vIGlmIHlvdSBkb24ndCBwYXNzIGEgbGFibGUgdXNlIHN0YWNrIHdoaWNoIHdpbGwgbGVhZCB0byB0aGUgZmFpbGluZyBjb2RlXG4gICAgICAgICAgICBjb25zdCBzdGFjayA9IChuZXcgRXJyb3IoKSkuc3RhY2tcbiAgICAgICAgICAgIHJldHVybiB0cmFjayhsYWJlbCA/IGxhYmVsIDogc3RhY2shLnRvU3RyaW5nKCkpKHApO1xuICAgICAgICB9O1xuXG4gICAgICAgIHByb21pc2UoXG4gICAgICAgICAgICBmKHtcbiAgICAgICAgICAgICAgICBwcm9taXNlLCBkZXNjcmliZSwgc3RhdGUsXG4gICAgICAgICAgICAgICAgdG9kbzogKHM6IHN0cmluZykgPT4gZGVzY3JpYmUocykudG9kbygpLFxuICAgICAgICAgICAgICAgIGZpbmFsbHk6ICh6KSA9PiB7IGZpbmFsbGllcy5wdXNoKHopOyB9LFxuICAgICAgICAgICAgfSksIFwidGVzdCBmdW5jdGlvbiBydW5zIHdpdGhvdXQgZXhjZXB0aW9uIGFuZCByZXR1cm5zIHdpdGhpbiB0aW1lb3V0XCJcbiAgICAgICAgKTtcbiAgICB9KTtcblxufTtcbiIsICJleHBvcnQgY29uc3QgZXhjZXB0aW9uX3RvX3N0ciA9IChlOiBhbnkpID0+IHtcbiAgaWYgKHR5cGVvZiBlID09IFwib2JqZWN0XCIpIHtcbiAgICAgIGlmICgnc3RhY2snIGluIGUpe1xuICAgICAgICAgIC8vIGJyb3dzZXIgY2hyb21pdW0gbGlrZSBFcnJvciBvYmplY3Qgc3RhY2sgY29udGFpbnMgLm1lc3NhZ2UgYW5kIHN0YWNrIHRyYWNlXG4gICAgICAgICAgcmV0dXJuIGUuc3RhY2tcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIGNoYWkgbGlrZSBleGNlcHRpb24gP1xuICAgICAgICBjb25zdCByID0gW107XG4gICAgICAgIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGUpKSB7XG4gICAgICAgICAgci5wdXNoKGAke0pTT04uc3RyaW5naWZ5KGspfTogJHtKU09OLnN0cmluZ2lmeSh2KX1gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gci5qb2luKFwiXFxuXCIpO1xuICAgICAgfVxuICB9IGVsc2UgaWYgKGUgJiYgZS50cmFjZSkge1xuICAgIHJldHVybiBgJHtlfVxcbiR7ZS50cmFjZX1gO1xuICB9XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeShlKTtcbn07XG4iLCAiaW1wb3J0IHsgYXBzX21hcCwgQXN5bmNQdWxsU3RyZWFtIH0gZnJvbSBcIi4uL3B1bGwvYXN5bmNcIlxuaW1wb3J0IHsgQWRkU2luaywgUHVzaFNvdXJjZUFwaVNpZ25hbCwgUHVzaFNvdXJjZVB1c2h9IGZyb20gXCIuLi9wdXNoXCJcbmltcG9ydCB7IE1heWJlUHJvbWlzZSwgUmVzb2x2ZVJlamVjdEFycmF5IH0gZnJvbSBcInUtcHJvbWlzZVwiXG5pbXBvcnQgeyBTX2Rpc2Nvbm5lY3QsIFNfZW5kaW5nLCBTX3BhdXNlLCBTX3BhdXNlZCwgU19ydW5uaW5nLCBTX3N0YXJ0LCBTX2VuZCwgdF9lbmQsIFNfcGF1c2luZywgU19wYXVzaW5nX2ludGVybmFsLCBTX3BhdXNlZF9pbnRlcm5hbCB9IGZyb20gXCIuLi9zeW1ib2xzXCJcbmltcG9ydCB7IEhpZ2hMb3dPcldhdGVybWFyaywgcHJvbWlzZV90b192ZWUsIFZhbHVlRXJyb3JFbmQsIHdhdGVybWFya3MgfSBmcm9tIFwiL2ludGVybmFsXCJcbmltcG9ydCB7IFB1bGxTdHJlYW0gfSBmcm9tIFwiL3B1bGxcIlxuXG5leHBvcnQgY29uc3QgcHVzaF90b19wdWxsID0gPFQ+KHB1c2g6IEFkZFNpbms8VD4sIG86IEhpZ2hMb3dPcldhdGVybWFyayA9IHt9KTogQXN5bmNQdWxsU3RyZWFtPFQ+ID0+IHtcbiAgICBjb25zdCB7IGxvd193YXRlcm1hcmssIGhpZ2hfd2F0ZXJtYXJrfSA9IHdhdGVybWFya3MobylcblxuICAgIGNvbnN0IGl0ZW1zOiBWYWx1ZUVycm9yRW5kPFQ+W10gPSBbXVxuICAgIGxldCBzdGF0dXM6IFxuICAgICAgICB0eXBlb2YgU19ydW5uaW5nXG4gICAgICAgIHwgdHlwZW9mIFNfZW5kaW5nXG4gICAgICAgIHwgdHlwZW9mIFNfcGF1c2VkID0gU19wYXVzZWRcbiAgICBsZXQgd2FpdGluZzogdW5kZWZpbmVkIHwgUmVzb2x2ZVJlamVjdEFycmF5PFQgfCB0X2VuZD5cblxuICAgIGNvbnN0IGFwaSA9IHB1c2guYWRkU2luayh7XG4gICAgICAgIHB1c2g6ICh0KSA9PiB7XG4gICAgICAgICAgICBpZiAod2FpdGluZykge1xuICAgICAgICAgICAgICAgIGlmICh0ID09IFNfZW5kKXtcbiAgICAgICAgICAgICAgICAgICAgd2FpdGluZ1swXShTX2VuZClcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzID0gU19lbmRpbmdcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKFwidmFsdWVcIiBpbiB0KSB7XG4gICAgICAgICAgICAgICAgICAgIHdhaXRpbmdbMF0odC52YWx1ZSlcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKFwiZXJyb3JcIiBpbiB0KSB7XG4gICAgICAgICAgICAgICAgICAgIHdhaXRpbmdbMV0odC5lcnJvcilcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgd2FpdGluZyA9IHVuZGVmaW5lZFxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpdGVtcy5wdXNoKHQpXG4gICAgICAgICAgICAgICAgaWYgKGl0ZW1zLmxlbmd0aCA+IGhpZ2hfd2F0ZXJtYXJrKSBhcGkoU19wYXVzZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pXG5cbiAgICByZXR1cm4gPE8gZXh0ZW5kcyBUIHwgdF9lbmQgPihlbmQ/OiBPKTogTWF5YmVQcm9taXNlPE8gZXh0ZW5kcyB0X2VuZCA/IGFueSA6IFQgfCB0X2VuZD4gPT4ge1xuXG4gICAgICAgIGlmIChlbmQgPT0gU19lbmQpe1xuICAgICAgICAgICAgYXBpKFNfZGlzY29ubmVjdClcbiAgICAgICAgICAgIHJldHVybiBTX2VuZFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGl0ZW1zLmxlbmd0aCA9PSAwKXtcbiAgICAgICAgICAgIGlmIChzdGF0dXMgPT0gU19wYXVzZWQpe1xuICAgICAgICAgICAgICAgIGFwaShTX3N0YXJ0KVxuICAgICAgICAgICAgICAgIHN0YXR1cyA9IFNfcnVubmluZ1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKGl0ZW1zLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgY29uc3QgeCA9IGl0ZW1zLnNoaWZ0KCkhXG4gICAgICAgICAgICBpZiAoaXRlbXMubGVuZ3RoIDwgbG93X3dhdGVybWFyayl7XG4gICAgICAgICAgICAgICAgYXBpKFNfc3RhcnQpXG4gICAgICAgICAgICAgICAgc3RhdHVzID0gU19ydW5uaW5nXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoeCA9PSBTX2VuZCkgcmV0dXJuIFNfZW5kXG4gICAgICAgICAgICBlbHNlIGlmICgndmFsdWUnIGluIHgpIHJldHVybiB4LnZhbHVlXG4gICAgICAgICAgICBlbHNlIHRocm93IHguZXJyb3JcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzdGF0dXMgPT0gU19lbmRpbmcpIHJldHVybiBTX2VuZFxuXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZTxUPigocixqKSA9PiB7XG4gICAgICAgICAgICB3YWl0aW5nID0gW3Isal1cbiAgICAgICAgfSlcblxuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IHB1bGxfdG9fcHVzaCA9IDxUPihzdHJlYW06IEFzeW5jUHVsbFN0cmVhbTxUPikgPT4ge1xuICAgIC8vIG5vdCB0ZXN0ZWQgdmVyeSB3ZWxsIHlldFxuICAgIC8vIHNlZSBhcHNfYnVmZmVyZWQgaVxuICAgIC8vIHJ1biBjYW4gb25seSBiZSBpbnRlcnJ1cHRlZCBhdCBhd2FpdC5cbiAgICAvLyBzbyBwYXVzaW5nIGNhbiBiZSByZXN1bWVkIHdpdGhvdXQgaW50ZXJydXB0aW5nIHJ1blxuICAgIC8vIGlmIGl0IGRpZG4ndCBxdWl0IHRoZSBsb29wIHlldFxuXG4gICAgbGV0IHNpbms6IFB1c2hTb3VyY2VQdXNoPFQ+IHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkXG5cbiAgICBsZXQgc3RhdHVzOiBcbiAgICAgICAgdHlwZW9mIFNfcGF1c2VkXG4gICAgICAgIHwgdHlwZW9mIFNfcGF1c2luZ1xuICAgICAgICB8IHR5cGVvZiBTX2VuZGluZyAvLyBlbmRlZFxuICAgICAgICB8IHR5cGVvZiBTX3J1bm5pbmdcbiAgICAgICAgPSBTX3BhdXNlZFxuXG4gICAgbGV0IHAgPSBQcm9taXNlLnJlc29sdmUobnVsbClcblxuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKFtTX3J1bm5pbmcsIFNfZW5kaW5nXS5pbmNsdWRlcyhzdGF0dXMpKSByZXR1cm5cbiAgICAgICAgc3RhdHVzID0gU19ydW5uaW5nXG4gICAgICAgIHdoaWxlIChzdGF0dXMgPT09IFNfcnVubmluZyl7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIC8vIHlvdSBjYW4gb25seSBzdGFydCBpZiBzaW5rIGlzIGFzc2lnbmVkXG4gICAgICAgICAgICAgICAgY29uc3QgdiA9IGF3YWl0IHByb21pc2VfdG9fdmVlKHN0cmVhbSgpKVxuICAgICAgICAgICAgICAgIHNpbmshLnB1c2godilcbiAgICAgICAgICAgICAgICBpZiAodiA9PSBTX2VuZCl7XG4gICAgICAgICAgICAgICAgICAgIHN0YXR1cyA9IFNfZW5kaW5nXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIC8vIFRPRE8gd2hhdCBzaG91bGQgaGFwcGVuIGlmIHNpbmsgY2F1c2VzIGFuIGVycm9yP1xuICAgICAgICAgICAgICAgIC8vIEl0J3Mgbm90IHJlYWxseSB0aGUgcmVzcG9uc2liaWxpdHkgb2YgdGhpcyBjb2RlXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXR1cyA9IFNfcGF1c2luZykgc3RhdHVzID0gU19wYXVzZWRcbiAgICB9XG5cbiAgICBjb25zdCBhZGRTaW5rOiBBZGRTaW5rPFQ+W1wiYWRkU2lua1wiXSA9IChfc2luaykgPT4ge1xuXG4gICAgICAgIGlmIChzaW5rKSB0aHJvdyBFcnJvcignb25seSBvbmUgc2luayBjYW4gYmUgYWRkZWQhJylcblxuICAgICAgICBzaW5rID0gX3NpbmtcblxuICAgICAgICByZXR1cm4gKHNpZ25hbDogUHVzaFNvdXJjZUFwaVNpZ25hbCkgPT4ge1xuICAgICAgICAgICAgaWYgKHNpZ25hbCA9PSBTX3N0YXJ0KSB7XG4gICAgICAgICAgICAgICAgaWYgKHN0YXR1cyA9PSBTX3BhdXNpbmcpIHN0YXR1cyA9IFNfcnVubmluZ1xuICAgICAgICAgICAgICAgIGVsc2UgcnVuKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChzaWduYWwgPT0gU19wYXVzZSkgc3RhdHVzID0gU19wYXVzaW5nXG4gICAgICAgICAgICBpZiAoc2lnbmFsID09IFNfZGlzY29ubmVjdCl7XG4gICAgICAgICAgICAgICAgc3RhdHVzID0gU19lbmRpbmdcbiAgICAgICAgICAgICAgICBzdHJlYW0oU19lbmQpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBhZGRTaW5rXG4gICAgfVxufVxuXG5cbmV4cG9ydCB0eXBlIHB1bGxfdG9fcHVzaF9jb25jdXJyZW50bHkgPSBcbnsgY29uY3VycmVuY3k6IG51bWJlciwgcHJlc2VydmVfb3JkZXI6IGJvb2xlYW4gfVxuXG4vLyB1c2FnZTpcbi8vIFNlZSBtYXBfY29uY3VycmVudGx5IG9yXG4vLyBwdXNoX3RvX3B1bGwocHVsbF90b19wdXNoX2NvbmN1cnJlbnRseShzdHJlYW0sIHtjb25jdXJyZW5jeTogMjAsIHByZXNlcnZlX29yZGVyOiB0cnVlfSkpXG4vLyBwcmVzZXJ2ZV9vcmRlcj10cnVlOiByZXN1bHRzIHdpbGwgYWx3YXlzIGJlIHJldHVybmVkIGluIG9yZGVyIChtaWdodCBiZSBzbG93ZXIgYmVjYXVzZSBvbmUgbG9uZyBydW5uaW5nIGl0ZW0gY2FuIGJsb2NrIGFsbClcbi8vIHByZXNlcnZlX29yZGVyPWZhbHNlOiBpZiBvbmUgcnVuIHRha2VzIGxvbmcgKGVnIHRpbWVvdXQpIHRoZSBvdGhlcnMgY29udGludWUgZmVlZGluZyB0aGUgc3RyZWFtXG4vL1xuLy8gVE9ETzogXG4vLyBjb25jdXJyZW5jeT0xOiBzcGVjaWFsIGNhc2Ugc2hvdWxkIGJlaGF2ZSBsaWtlIHB1bGxfdG9fcHVzaCBhbmQgcHJlc2VydmVfb3JkZXIgZG9lc24ndCBtYXR0ZXJcbmV4cG9ydCBjb25zdCBwdWxsX3RvX3B1c2hfY29uY3VycmVudGx5ID0gPFQ+KHN0cmVhbTogQXN5bmNQdWxsU3RyZWFtPFQ+LG8gOiBwdWxsX3RvX3B1c2hfY29uY3VycmVudGx5KSA9PiB7XG4gICAgLy8gdGhpcyBjb3VsZCBwdXNoIFNfZW5kIG11bHRpcGxlIHRpbWVzIGJlYWN1c2UgcHJvbWlzZXMgZ2V0IHN0YXJ0ZWQgYmVmb3JlIHRoZSBTX2VuZCBtaWdodCBiZSByZWNpZXZlZCAhXG4gICAgLy8gbm90IHRlc3RlZCB2ZXJ5IHdlbGwgeWV0XG4gICAgLy9cbiAgICAvLyBUT0RPOiBzb21lIG9mIHRoZSBhcHNfKiBzdHJlYW0gZnVuY3Rpb24gcmVxdWlyZSB0aGUgcmV0dXJuZWQgcHJvbWlzZXMgXG4gICAgLy8gdG8gYmUgYXdhaXRlZCBmb3IgdGh1cyB3aWxsIG5vdCBwbGF5IHdlbGwgYWxvbmcgd2l0aCB0aGlzXG4gICAgLy8gV2hvc2UgcmVzcG9uc2liaWxpdHkgaXMgdGhpcyA/XG4gICAgLy9cbiAgICAvLyBJIGd1ZXNzIHRoaXMgcmVxdWlyZXMgbWFueSB0ZXN0IGNhc2VzIGJlY2F1c2Ugd3Jvbmcgb3JkZXIgZW5kaW5nIGV0YyB0aGVyZSBhcmUgbWFueSBjYXNlc1xuICAgIGNvbnNvbGUubG9nKGB3YXJuaW5nIHB1bGxfdG9fcHVzaF9jb25jdXJyZW50bHkgbm90IHdlbGwgdGVzdGVkYCk7XG5cbiAgICBsZXQgc2luazogUHVzaFNvdXJjZVB1c2g8VD4gfCB1bmRlZmluZWQgPSB1bmRlZmluZWRcbiAgICBsZXQgcnVubmluZyA9IDBcbiAgICBsZXQgZW5kaW5nID0gZmFsc2UgLy8gYW55IHJldHVybmVkIFNfZW5kXG4gICAgbGV0IG9yZGVyOiBQcm9taXNlPGFueT4gPSBQcm9taXNlLnJlc29sdmUodW5kZWZpbmVkKVxuXG4gICAgbGV0IHN0YXR1czogdHlwZW9mIFNfcGF1c2luZ1xuICAgICAgICB8IHR5cGVvZiBTX2VuZGluZyAvLyBkaXNjb25uZWN0XG4gICAgICAgIHwgdHlwZW9mIFNfcnVubmluZ1xuICAgICAgICB8IHR5cGVvZiBTX3BhdXNlZF9pbnRlcm5hbFxuXG4gICAgICAgIC8vIGV4dGVybmFsIHdpc2ggdG8gcGF1c2VcbiAgICAgICAgfCB0eXBlb2YgU19wYXVzZWQgXG4gICAgICAgIHwgdHlwZW9mIFNfcGF1c2luZyBcblxuICAgICAgICA9IFNfcGF1c2VkXG5cbiAgICBsZXQgcCA9IFByb21pc2UucmVzb2x2ZShudWxsKVxuXG4gICAgbGV0IHJlc3RhcnQ6ICgpID0+IHZvaWRcblxuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKFtTX3J1bm5pbmcsIFNfZW5kaW5nXS5pbmNsdWRlcyhzdGF0dXMpKSByZXR1cm5cbiAgICAgICAgc3RhdHVzID0gU19ydW5uaW5nXG5cbiAgICAgICAgLy9jb25zb2xlLmxvZyh7IHN0YXR1cywgcnVubmluZywgY29uY3VycmVuY3k6IG8uY29uY3VycmVuY3kgfSk7XG5cbiAgICAgICAgd2hpbGUgKHN0YXR1cyA9PT0gU19ydW5uaW5nICYmIHJ1bm5pbmcgPCBvLmNvbmN1cnJlbmN5KXtcbiAgICAgICAgICAgIGNvbnN0IHBfID0gcHJvbWlzZV90b192ZWUoc3RyZWFtKHVuZGVmaW5lZCkpXG4gICAgICAgICAgICBydW5uaW5nICs9IDFcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGBydW5uaW5nICR7cnVubmluZ31gKTtcbiAgICAgICAgICAgIGlmIChvLnByZXNlcnZlX29yZGVyKXtcbiAgICAgICAgICAgICAgICBvcmRlciA9IG9yZGVyLnRoZW4oIGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcF9cbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYHJlcyAke3Jlcy50b1N0cmluZygpfSAke0pTT04uc3RyaW5naWZ5KHJlcyl9ICR7c3RhdHVzLnRvU3RyaW5nKCl9YCk7XG4gICAgICAgICAgICAgICAgICAgIHJ1bm5pbmcgLT0gMVxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhgcnVubmluZyAke3J1bm5pbmd9YCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXMgPT0gU19lbmQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJFTkRJTkcgYW5kIHB1c2hpbmcgaXQhXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZW5kaW5nID0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHNpbmshLnB1c2gocmVzKVxuICAgICAgICAgICAgICAgICAgICByZXN0YXJ0KClcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwXy50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcnVubmluZyAtPSAxXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGBydW5uaW5nICR7cnVubmluZ31gKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlcyA9PSBTX2VuZCkgZW5kaW5nID0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHNpbmshLnB1c2gocmVzKVxuICAgICAgICAgICAgICAgICAgICBpZiAocnVubmluZyA9PSAwICYmIGVuZGluZylcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpbmshLnB1c2goU19lbmQpXG4gICAgICAgICAgICAgICAgICAgIHJlc3RhcnQoKVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXR1cyA9PT0gU19wYXVzaW5nKSBzdGF0dXMgPSBTX3BhdXNlZFxuICAgICAgICBlbHNlIHN0YXR1cyA9IFNfcGF1c2VkX2ludGVybmFsXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGBydW5uaW5nIGVuZGVkICR7c3RhdHVzLnRvU3RyaW5nKCl9YCk7XG4gICAgfVxuXG4gICAgcmVzdGFydCA9ICgpID0+IHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJyZXN0YXJ0aW5nMVwiKTtcbiAgICAgICAgaWYgKGVuZGluZykgcmV0dXJuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwicmVzdGFydGluZzJcIik7XG4gICAgICAgIGlmIChbU19wYXVzZWQsIFNfcGF1c2luZywgU19lbmRpbmddLmluY2x1ZGVzKHN0YXR1cykpIHJldHVyblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcInJlc3RhcnRpbmczXCIpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh7cnVubmluZywgY29uY3VycmVuY3k6IG8uY29uY3VycmVuY3ksIHN0YXR1c30pO1xuICAgICAgICBpZiAocnVubmluZyA8IG8uY29uY3VycmVuY3kpe1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJyZXN0YXJ0aW5nNFwiKTtcbiAgICAgICAgICAgIGlmIChzdGF0dXMgPT0gU19wYXVzZWRfaW50ZXJuYWwpIHJ1bigpXG4gICAgICAgIH1cbiAgICB9XG5cblxuICAgIGNvbnN0IGFkZFNpbms6IEFkZFNpbms8VD5bXCJhZGRTaW5rXCJdID0gKF9zaW5rKSA9PiB7XG5cbiAgICAgICAgaWYgKHNpbmspIHRocm93IEVycm9yKCdvbmx5IG9uZSBzaW5rIGNhbiBiZSBhZGRlZCEnKVxuXG4gICAgICAgIHNpbmsgPSBfc2lua1xuXG4gICAgICAgIHJldHVybiAoc2lnbmFsOiBQdXNoU291cmNlQXBpU2lnbmFsKSA9PiB7XG4gICAgICAgICAgICBpZiAoc2lnbmFsID09IFNfc3RhcnQpIHtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdHVzID09IFNfcGF1c2luZykgc3RhdHVzID0gU19ydW5uaW5nXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RhdHVzID09IFNfcGF1c2VkKSB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXR1cyA9IFNfcGF1c2VkX2ludGVybmFsXG4gICAgICAgICAgICAgICAgICAgIHJlc3RhcnQoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChzaWduYWwgPT0gU19wYXVzZSkgc3RhdHVzID0gU19wYXVzaW5nXG4gICAgICAgICAgICBpZiAoc2lnbmFsID09IFNfZGlzY29ubmVjdCl7XG4gICAgICAgICAgICAgICAgc3RhdHVzID0gU19lbmRpbmdcbiAgICAgICAgICAgICAgICBzdHJlYW0oU19lbmQpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBhZGRTaW5rXG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgbWFwX2NvbmN1cnJlbnRseSA9IDxJLCBPPihzdHJlYW06IEFzeW5jUHVsbFN0cmVhbTxJPiwgXG4gICAgICAgICAgICBtYXA6IChpdGVtOiBJKSA9PiBQcm9taXNlPE8+LFxuICAgICAgICAgICAgbzogcHVsbF90b19wdXNoX2NvbmN1cnJlbnRseSAmIEhpZ2hMb3dPcldhdGVybWFyaykgPT5cbiAgICBwdXNoX3RvX3B1bGwoXG4gICAgICAgIHB1bGxfdG9fcHVzaF9jb25jdXJyZW50bHkoYXBzX21hcChzdHJlYW0sIG1hcCksIG8pLCBcbiAgICAgICAgeyB3YXRlcm1hcmtzOiBvLndhdGVybWFya3MgPz8gMCAvKiB3aWxsIGFjY2VwdCBwdXNoaW4gYW55d2F5LCBkZWZhdWx0IHRvIGRvbid0IHJlcXVzZXQgbW9yZSB0aGFuIHJlcXVpcmVkICovIFxuICAgICAgICB9XG4gICAgKVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQSw0Q0FBQUEsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxRQUFRLE9BQU8sVUFBVTtBQUU3QixJQUFBQSxRQUFPLFVBQVUsU0FBUyxZQUFZLE9BQU87QUFDNUMsVUFBSSxNQUFNLE1BQU0sS0FBSyxLQUFLO0FBQzFCLFVBQUksU0FBUyxRQUFRO0FBQ3JCLFVBQUksQ0FBQyxRQUFRO0FBQ1osaUJBQVMsUUFBUSxvQkFDaEIsVUFBVSxRQUNWLE9BQU8sVUFBVSxZQUNqQixPQUFPLE1BQU0sV0FBVyxZQUN4QixNQUFNLFVBQVUsS0FDaEIsTUFBTSxLQUFLLE1BQU0sTUFBTSxNQUFNO0FBQUEsTUFDL0I7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQ2hCQTtBQUFBLCtDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJO0FBQ0osUUFBSSxDQUFDLE9BQU8sTUFBTTtBQUViLFlBQU0sT0FBTyxVQUFVO0FBQ3ZCLGNBQVEsT0FBTyxVQUFVO0FBQ3pCLGVBQVM7QUFDVCxxQkFBZSxPQUFPLFVBQVU7QUFDaEMsdUJBQWlCLENBQUMsYUFBYSxLQUFLLEVBQUUsVUFBVSxLQUFLLEdBQUcsVUFBVTtBQUNsRSx3QkFBa0IsYUFBYSxLQUFLLFdBQVk7QUFBQSxNQUFDLEdBQUcsV0FBVztBQUMvRCxrQkFBWTtBQUFBLFFBQ2Y7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNEO0FBQ0ksbUNBQTZCLFNBQVUsR0FBRztBQUM3QyxZQUFJLE9BQU8sRUFBRTtBQUNiLGVBQU8sUUFBUSxLQUFLLGNBQWM7QUFBQSxNQUNuQztBQUNJLHFCQUFlO0FBQUEsUUFDbEIsbUJBQW1CO0FBQUEsUUFDbkIsVUFBVTtBQUFBLFFBQ1YsV0FBVztBQUFBLFFBQ1gsUUFBUTtBQUFBLFFBQ1IsZUFBZTtBQUFBLFFBQ2YsU0FBUztBQUFBLFFBQ1QsY0FBYztBQUFBLFFBQ2QsYUFBYTtBQUFBLFFBQ2Isd0JBQXdCO0FBQUEsUUFDeEIsdUJBQXVCO0FBQUEsUUFDdkIsY0FBYztBQUFBLFFBQ2QsYUFBYTtBQUFBLFFBQ2IsY0FBYztBQUFBLFFBQ2QsY0FBYztBQUFBLFFBQ2QsU0FBUztBQUFBLFFBQ1QsYUFBYTtBQUFBLFFBQ2IsWUFBWTtBQUFBLFFBQ1osVUFBVTtBQUFBLFFBQ1YsVUFBVTtBQUFBLFFBQ1YsT0FBTztBQUFBLFFBQ1Asa0JBQWtCO0FBQUEsUUFDbEIsb0JBQW9CO0FBQUEsUUFDcEIsU0FBUztBQUFBLE1BQ1Y7QUFDSSxpQ0FBNEIsV0FBWTtBQUUzQyxZQUFJLE9BQU8sV0FBVyxhQUFhO0FBQUUsaUJBQU87QUFBQSxRQUFPO0FBQ25ELGlCQUFTLEtBQUssUUFBUTtBQUNyQixjQUFJO0FBQ0gsZ0JBQUksQ0FBQyxhQUFhLE1BQU0sQ0FBQyxLQUFLLElBQUksS0FBSyxRQUFRLENBQUMsS0FBSyxPQUFPLENBQUMsTUFBTSxRQUFRLE9BQU8sT0FBTyxDQUFDLE1BQU0sVUFBVTtBQUN6RyxrQkFBSTtBQUNILDJDQUEyQixPQUFPLENBQUMsQ0FBQztBQUFBLGNBQ3JDLFNBQVMsR0FBRztBQUNYLHVCQUFPO0FBQUEsY0FDUjtBQUFBLFlBQ0Q7QUFBQSxVQUNELFNBQVMsR0FBRztBQUNYLG1CQUFPO0FBQUEsVUFDUjtBQUFBLFFBQ0Q7QUFDQSxlQUFPO0FBQUEsTUFDUixFQUFFO0FBQ0UsNkNBQXVDLFNBQVUsR0FBRztBQUV2RCxZQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsMEJBQTBCO0FBQy9ELGlCQUFPLDJCQUEyQixDQUFDO0FBQUEsUUFDcEM7QUFDQSxZQUFJO0FBQ0gsaUJBQU8sMkJBQTJCLENBQUM7QUFBQSxRQUNwQyxTQUFTLEdBQUc7QUFDWCxpQkFBTztBQUFBLFFBQ1I7QUFBQSxNQUNEO0FBRUEsaUJBQVcsU0FBUyxLQUFLLFFBQVE7QUFDaEMsWUFBSSxXQUFXLFdBQVcsUUFBUSxPQUFPLFdBQVc7QUFDcEQsWUFBSSxhQUFhLE1BQU0sS0FBSyxNQUFNLE1BQU07QUFDeEMsWUFBSSxjQUFjLE9BQU8sTUFBTTtBQUMvQixZQUFJLFdBQVcsWUFBWSxNQUFNLEtBQUssTUFBTSxNQUFNO0FBQ2xELFlBQUksVUFBVSxDQUFDO0FBRWYsWUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsYUFBYTtBQUM3QyxnQkFBTSxJQUFJLFVBQVUsb0NBQW9DO0FBQUEsUUFDekQ7QUFFQSxZQUFJLFlBQVksbUJBQW1CO0FBQ25DLFlBQUksWUFBWSxPQUFPLFNBQVMsS0FBSyxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsR0FBRztBQUMxRCxtQkFBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsRUFBRSxHQUFHO0FBQ3ZDLG9CQUFRLEtBQUssT0FBTyxDQUFDLENBQUM7QUFBQSxVQUN2QjtBQUFBLFFBQ0Q7QUFFQSxZQUFJLGVBQWUsT0FBTyxTQUFTLEdBQUc7QUFDckMsbUJBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEVBQUUsR0FBRztBQUN2QyxvQkFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDO0FBQUEsVUFDdkI7QUFBQSxRQUNELE9BQU87QUFDTixtQkFBUyxRQUFRLFFBQVE7QUFDeEIsZ0JBQUksRUFBRSxhQUFhLFNBQVMsZ0JBQWdCLElBQUksS0FBSyxRQUFRLElBQUksR0FBRztBQUNuRSxzQkFBUSxLQUFLLE9BQU8sSUFBSSxDQUFDO0FBQUEsWUFDMUI7QUFBQSxVQUNEO0FBQUEsUUFDRDtBQUVBLFlBQUksZ0JBQWdCO0FBQ25CLGNBQUksa0JBQWtCLHFDQUFxQyxNQUFNO0FBRWpFLG1CQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxFQUFFLEdBQUc7QUFDMUMsZ0JBQUksRUFBRSxtQkFBbUIsVUFBVSxDQUFDLE1BQU0sa0JBQWtCLElBQUksS0FBSyxRQUFRLFVBQVUsQ0FBQyxDQUFDLEdBQUc7QUFDM0Ysc0JBQVEsS0FBSyxVQUFVLENBQUMsQ0FBQztBQUFBLFlBQzFCO0FBQUEsVUFDRDtBQUFBLFFBQ0Q7QUFDQSxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFuSEs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFTQTtBQUlBO0FBeUJBO0FBa0JBO0FBc0RMLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ3pIakI7QUFBQSxzQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxRQUFRLE1BQU0sVUFBVTtBQUM1QixRQUFJLFNBQVM7QUFFYixRQUFJLFdBQVcsT0FBTztBQUN0QixRQUFJLFdBQVcsV0FBVyxTQUFTLEtBQUssR0FBRztBQUFFLGFBQU8sU0FBUyxDQUFDO0FBQUEsSUFBRyxJQUFJO0FBRXJFLFFBQUksZUFBZSxPQUFPO0FBRTFCLGFBQVMsT0FBTyxTQUFTLGlCQUFpQjtBQUN6QyxVQUFJLE9BQU8sTUFBTTtBQUNoQixZQUFJLHlCQUEwQixXQUFZO0FBRXpDLGNBQUksT0FBTyxPQUFPLEtBQUssU0FBUztBQUNoQyxpQkFBTyxRQUFRLEtBQUssV0FBVyxVQUFVO0FBQUEsUUFDMUMsRUFBRSxHQUFHLENBQUM7QUFDTixZQUFJLENBQUMsd0JBQXdCO0FBQzVCLGlCQUFPLE9BQU8sU0FBUyxLQUFLLFFBQVE7QUFDbkMsZ0JBQUksT0FBTyxNQUFNLEdBQUc7QUFDbkIscUJBQU8sYUFBYSxNQUFNLEtBQUssTUFBTSxDQUFDO0FBQUEsWUFDdkM7QUFDQSxtQkFBTyxhQUFhLE1BQU07QUFBQSxVQUMzQjtBQUFBLFFBQ0Q7QUFBQSxNQUNELE9BQU87QUFDTixlQUFPLE9BQU87QUFBQSxNQUNmO0FBQ0EsYUFBTyxPQUFPLFFBQVE7QUFBQSxJQUN2QjtBQUVBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQy9CakI7QUFBQSxvQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBR0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSGpCO0FBQUEsbUNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUdBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0hqQjtBQUFBLG9DQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFHQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUNIakI7QUFBQSxrQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBR0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSGpCO0FBQUEscUNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUdBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0hqQjtBQUFBLG1DQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFHQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUNIakI7QUFBQSxrQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBR0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSGpCO0FBQUEsc0NBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUdBLElBQUFBLFFBQU8sVUFBVSxTQUFTLGFBQWE7QUFDdEMsVUFBSSxPQUFPLFdBQVcsY0FBYyxPQUFPLE9BQU8sMEJBQTBCLFlBQVk7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUN4RyxVQUFJLE9BQU8sT0FBTyxhQUFhLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFBTTtBQUV4RCxVQUFJLE1BQU0sQ0FBQztBQUNYLFVBQUksTUFBTSxPQUFPLE1BQU07QUFDdkIsVUFBSSxTQUFTLE9BQU8sR0FBRztBQUN2QixVQUFJLE9BQU8sUUFBUSxVQUFVO0FBQUUsZUFBTztBQUFBLE1BQU87QUFFN0MsVUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLEdBQUcsTUFBTSxtQkFBbUI7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUMvRSxVQUFJLE9BQU8sVUFBVSxTQUFTLEtBQUssTUFBTSxNQUFNLG1CQUFtQjtBQUFFLGVBQU87QUFBQSxNQUFPO0FBVWxGLFVBQUksU0FBUztBQUNiLFVBQUksR0FBRyxJQUFJO0FBQ1gsV0FBSyxPQUFPLEtBQUs7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUNqQyxVQUFJLE9BQU8sT0FBTyxTQUFTLGNBQWMsT0FBTyxLQUFLLEdBQUcsRUFBRSxXQUFXLEdBQUc7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUV4RixVQUFJLE9BQU8sT0FBTyx3QkFBd0IsY0FBYyxPQUFPLG9CQUFvQixHQUFHLEVBQUUsV0FBVyxHQUFHO0FBQUUsZUFBTztBQUFBLE1BQU87QUFFdEgsVUFBSSxPQUFPLE9BQU8sc0JBQXNCLEdBQUc7QUFDM0MsVUFBSSxLQUFLLFdBQVcsS0FBSyxLQUFLLENBQUMsTUFBTSxLQUFLO0FBQUUsZUFBTztBQUFBLE1BQU87QUFFMUQsVUFBSSxDQUFDLE9BQU8sVUFBVSxxQkFBcUIsS0FBSyxLQUFLLEdBQUcsR0FBRztBQUFFLGVBQU87QUFBQSxNQUFPO0FBRTNFLFVBQUksT0FBTyxPQUFPLDZCQUE2QixZQUFZO0FBQzFELFlBQUksYUFBYSxPQUFPLHlCQUF5QixLQUFLLEdBQUc7QUFDekQsWUFBSSxXQUFXLFVBQVUsVUFBVSxXQUFXLGVBQWUsTUFBTTtBQUFFLGlCQUFPO0FBQUEsUUFBTztBQUFBLE1BQ3BGO0FBRUEsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUN6Q0E7QUFBQSxzQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxhQUFhLE9BQU8sV0FBVyxlQUFlO0FBQ2xELFFBQUksZ0JBQWdCO0FBRXBCLElBQUFBLFFBQU8sVUFBVSxTQUFTLG1CQUFtQjtBQUM1QyxVQUFJLE9BQU8sZUFBZSxZQUFZO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDdEQsVUFBSSxPQUFPLFdBQVcsWUFBWTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBQ2xELFVBQUksT0FBTyxXQUFXLEtBQUssTUFBTSxVQUFVO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDM0QsVUFBSSxPQUFPLE9BQU8sS0FBSyxNQUFNLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUV2RCxhQUFPLGNBQWM7QUFBQSxJQUN0QjtBQUFBO0FBQUE7OztBQ1pBO0FBQUEsb0NBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksT0FBTztBQUFBLE1BQ1YsV0FBVztBQUFBLE1BQ1gsS0FBSyxDQUFDO0FBQUEsSUFDUDtBQUVBLFFBQUksVUFBVTtBQUdkLElBQUFBLFFBQU8sVUFBVSxTQUFTLFdBQVc7QUFFcEMsYUFBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLFFBQVEsS0FBSyxPQUNwQyxFQUFFLGdCQUFnQjtBQUFBLElBQ3ZCO0FBQUE7QUFBQTs7O0FDZEEsSUFBQUMsMEJBQUE7QUFBQSxpREFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBSUEsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxRQUFRLE9BQU8sVUFBVTtBQUM3QixRQUFJLE1BQU0sS0FBSztBQUNmLFFBQUksV0FBVztBQUVmLFFBQUksV0FBVyxTQUFTQyxVQUFTLEdBQUcsR0FBRztBQUNuQyxVQUFJLE1BQU0sQ0FBQztBQUVYLGVBQVMsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssR0FBRztBQUNsQyxZQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7QUFBQSxNQUNoQjtBQUNBLGVBQVMsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssR0FBRztBQUNsQyxZQUFJLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxDQUFDO0FBQUEsTUFDM0I7QUFFQSxhQUFPO0FBQUEsSUFDWDtBQUVBLFFBQUksUUFBUSxTQUFTQyxPQUFNLFNBQVMsUUFBUTtBQUN4QyxVQUFJLE1BQU0sQ0FBQztBQUNYLGVBQVMsSUFBSSxVQUFVLEdBQUcsSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUssR0FBRyxLQUFLLEdBQUc7QUFDakUsWUFBSSxDQUFDLElBQUksUUFBUSxDQUFDO0FBQUEsTUFDdEI7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUVBLFFBQUksUUFBUSxTQUFVLEtBQUssUUFBUTtBQUMvQixVQUFJLE1BQU07QUFDVixlQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLLEdBQUc7QUFDcEMsZUFBTyxJQUFJLENBQUM7QUFDWixZQUFJLElBQUksSUFBSSxJQUFJLFFBQVE7QUFDcEIsaUJBQU87QUFBQSxRQUNYO0FBQUEsTUFDSjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBRUEsSUFBQUYsUUFBTyxVQUFVLFNBQVMsS0FBSyxNQUFNO0FBQ2pDLFVBQUksU0FBUztBQUNiLFVBQUksT0FBTyxXQUFXLGNBQWMsTUFBTSxNQUFNLE1BQU0sTUFBTSxVQUFVO0FBQ2xFLGNBQU0sSUFBSSxVQUFVLGdCQUFnQixNQUFNO0FBQUEsTUFDOUM7QUFDQSxVQUFJLE9BQU8sTUFBTSxXQUFXLENBQUM7QUFFN0IsVUFBSTtBQUNKLFVBQUksU0FBUyxXQUFZO0FBQ3JCLFlBQUksZ0JBQWdCLE9BQU87QUFDdkIsY0FBSSxTQUFTLE9BQU87QUFBQSxZQUNoQjtBQUFBLFlBQ0EsU0FBUyxNQUFNLFNBQVM7QUFBQSxVQUM1QjtBQUNBLGNBQUksT0FBTyxNQUFNLE1BQU0sUUFBUTtBQUMzQixtQkFBTztBQUFBLFVBQ1g7QUFDQSxpQkFBTztBQUFBLFFBQ1g7QUFDQSxlQUFPLE9BQU87QUFBQSxVQUNWO0FBQUEsVUFDQSxTQUFTLE1BQU0sU0FBUztBQUFBLFFBQzVCO0FBQUEsTUFFSjtBQUVBLFVBQUksY0FBYyxJQUFJLEdBQUcsT0FBTyxTQUFTLEtBQUssTUFBTTtBQUNwRCxVQUFJLFlBQVksQ0FBQztBQUNqQixlQUFTLElBQUksR0FBRyxJQUFJLGFBQWEsS0FBSztBQUNsQyxrQkFBVSxDQUFDLElBQUksTUFBTTtBQUFBLE1BQ3pCO0FBRUEsY0FBUSxTQUFTLFVBQVUsc0JBQXNCLE1BQU0sV0FBVyxHQUFHLElBQUksMkNBQTJDLEVBQUUsTUFBTTtBQUU1SCxVQUFJLE9BQU8sV0FBVztBQUNsQixZQUFJLFFBQVEsU0FBU0csU0FBUTtBQUFBLFFBQUM7QUFDOUIsY0FBTSxZQUFZLE9BQU87QUFDekIsY0FBTSxZQUFZLElBQUksTUFBTTtBQUM1QixjQUFNLFlBQVk7QUFBQSxNQUN0QjtBQUVBLGFBQU87QUFBQSxJQUNYO0FBQUE7QUFBQTs7O0FDbkZBO0FBQUEsd0NBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksaUJBQWlCO0FBRXJCLElBQUFBLFFBQU8sVUFBVSxTQUFTLFVBQVUsUUFBUTtBQUFBO0FBQUE7OztBQ0o1QztBQUFBLGlDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzlCLFFBQUksVUFBVSxPQUFPLFVBQVU7QUFDL0IsUUFBSSxPQUFPO0FBR1gsSUFBQUEsUUFBTyxVQUFVLEtBQUssS0FBSyxNQUFNLE9BQU87QUFBQTtBQUFBOzs7QUNQeEM7QUFBQSx3Q0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSUM7QUFFSixRQUFJLFNBQVM7QUFDYixRQUFJLGFBQWE7QUFDakIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksa0JBQWtCO0FBQ3RCLFFBQUksZUFBZTtBQUNuQixRQUFJLGFBQWE7QUFDakIsUUFBSSxZQUFZO0FBRWhCLFFBQUksWUFBWTtBQUdoQixRQUFJLHdCQUF3QixTQUFVLGtCQUFrQjtBQUN2RCxVQUFJO0FBQ0gsZUFBTyxVQUFVLDJCQUEyQixtQkFBbUIsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsRixTQUFTLEdBQUc7QUFBQSxNQUFDO0FBQUEsSUFDZDtBQUVBLFFBQUksUUFBUSxPQUFPO0FBQ25CLFFBQUksT0FBTztBQUNWLFVBQUk7QUFDSCxjQUFNLENBQUMsR0FBRyxFQUFFO0FBQUEsTUFDYixTQUFTLEdBQUc7QUFDWCxnQkFBUTtBQUFBLE1BQ1Q7QUFBQSxJQUNEO0FBRUEsUUFBSSxpQkFBaUIsV0FBWTtBQUNoQyxZQUFNLElBQUksV0FBVztBQUFBLElBQ3RCO0FBQ0EsUUFBSSxpQkFBaUIsUUFDakIsV0FBWTtBQUNkLFVBQUk7QUFFSCxrQkFBVTtBQUNWLGVBQU87QUFBQSxNQUNSLFNBQVMsY0FBYztBQUN0QixZQUFJO0FBRUgsaUJBQU8sTUFBTSxXQUFXLFFBQVEsRUFBRTtBQUFBLFFBQ25DLFNBQVMsWUFBWTtBQUNwQixpQkFBTztBQUFBLFFBQ1I7QUFBQSxNQUNEO0FBQUEsSUFDRCxFQUFFLElBQ0E7QUFFSCxRQUFJLGFBQWEsc0JBQXVCO0FBQ3hDLFFBQUksV0FBVyxvQkFBcUI7QUFFcEMsUUFBSSxXQUFXLE9BQU8sbUJBQ3JCLFdBQ0csU0FBVSxHQUFHO0FBQUUsYUFBTyxFQUFFO0FBQUEsSUFBVyxJQUNuQztBQUdKLFFBQUksWUFBWSxDQUFDO0FBRWpCLFFBQUksYUFBYSxPQUFPLGVBQWUsZUFBZSxDQUFDLFdBQVdBLGFBQVksU0FBUyxVQUFVO0FBRWpHLFFBQUksYUFBYTtBQUFBLE1BQ2hCLFdBQVc7QUFBQSxNQUNYLG9CQUFvQixPQUFPLG1CQUFtQixjQUFjQSxhQUFZO0FBQUEsTUFDeEUsV0FBVztBQUFBLE1BQ1gsaUJBQWlCLE9BQU8sZ0JBQWdCLGNBQWNBLGFBQVk7QUFBQSxNQUNsRSw0QkFBNEIsY0FBYyxXQUFXLFNBQVMsQ0FBQyxFQUFFLE9BQU8sUUFBUSxFQUFFLENBQUMsSUFBSUE7QUFBQSxNQUN2RixvQ0FBb0NBO0FBQUEsTUFDcEMsbUJBQW1CO0FBQUEsTUFDbkIsb0JBQW9CO0FBQUEsTUFDcEIsNEJBQTRCO0FBQUEsTUFDNUIsNEJBQTRCO0FBQUEsTUFDNUIsYUFBYSxPQUFPLFlBQVksY0FBY0EsYUFBWTtBQUFBLE1BQzFELFlBQVksT0FBTyxXQUFXLGNBQWNBLGFBQVk7QUFBQSxNQUN4RCxtQkFBbUIsT0FBTyxrQkFBa0IsY0FBY0EsYUFBWTtBQUFBLE1BQ3RFLG9CQUFvQixPQUFPLG1CQUFtQixjQUFjQSxhQUFZO0FBQUEsTUFDeEUsYUFBYTtBQUFBLE1BQ2IsY0FBYyxPQUFPLGFBQWEsY0FBY0EsYUFBWTtBQUFBLE1BQzVELFVBQVU7QUFBQSxNQUNWLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLFdBQVc7QUFBQSxNQUNYLFVBQVU7QUFBQTtBQUFBLE1BQ1YsZUFBZTtBQUFBLE1BQ2Ysa0JBQWtCLE9BQU8saUJBQWlCLGNBQWNBLGFBQVk7QUFBQSxNQUNwRSxrQkFBa0IsT0FBTyxpQkFBaUIsY0FBY0EsYUFBWTtBQUFBLE1BQ3BFLDBCQUEwQixPQUFPLHlCQUF5QixjQUFjQSxhQUFZO0FBQUEsTUFDcEYsY0FBYztBQUFBLE1BQ2QsdUJBQXVCO0FBQUEsTUFDdkIsZUFBZSxPQUFPLGNBQWMsY0FBY0EsYUFBWTtBQUFBLE1BQzlELGdCQUFnQixPQUFPLGVBQWUsY0FBY0EsYUFBWTtBQUFBLE1BQ2hFLGdCQUFnQixPQUFPLGVBQWUsY0FBY0EsYUFBWTtBQUFBLE1BQ2hFLGNBQWM7QUFBQSxNQUNkLFdBQVc7QUFBQSxNQUNYLHVCQUF1QixjQUFjLFdBQVcsU0FBUyxTQUFTLENBQUMsRUFBRSxPQUFPLFFBQVEsRUFBRSxDQUFDLENBQUMsSUFBSUE7QUFBQSxNQUM1RixVQUFVLE9BQU8sU0FBUyxXQUFXLE9BQU9BO0FBQUEsTUFDNUMsU0FBUyxPQUFPLFFBQVEsY0FBY0EsYUFBWTtBQUFBLE1BQ2xELDBCQUEwQixPQUFPLFFBQVEsZUFBZSxDQUFDLGNBQWMsQ0FBQyxXQUFXQSxhQUFZLFVBQVMsb0JBQUksSUFBSSxHQUFFLE9BQU8sUUFBUSxFQUFFLENBQUM7QUFBQSxNQUNwSSxVQUFVO0FBQUEsTUFDVixZQUFZO0FBQUEsTUFDWixZQUFZO0FBQUEsTUFDWixnQkFBZ0I7QUFBQSxNQUNoQixjQUFjO0FBQUEsTUFDZCxhQUFhLE9BQU8sWUFBWSxjQUFjQSxhQUFZO0FBQUEsTUFDMUQsV0FBVyxPQUFPLFVBQVUsY0FBY0EsYUFBWTtBQUFBLE1BQ3RELGdCQUFnQjtBQUFBLE1BQ2hCLG9CQUFvQjtBQUFBLE1BQ3BCLGFBQWEsT0FBTyxZQUFZLGNBQWNBLGFBQVk7QUFBQSxNQUMxRCxZQUFZO0FBQUEsTUFDWixTQUFTLE9BQU8sUUFBUSxjQUFjQSxhQUFZO0FBQUEsTUFDbEQsMEJBQTBCLE9BQU8sUUFBUSxlQUFlLENBQUMsY0FBYyxDQUFDLFdBQVdBLGFBQVksVUFBUyxvQkFBSSxJQUFJLEdBQUUsT0FBTyxRQUFRLEVBQUUsQ0FBQztBQUFBLE1BQ3BJLHVCQUF1QixPQUFPLHNCQUFzQixjQUFjQSxhQUFZO0FBQUEsTUFDOUUsWUFBWTtBQUFBLE1BQ1osNkJBQTZCLGNBQWMsV0FBVyxTQUFTLEdBQUcsT0FBTyxRQUFRLEVBQUUsQ0FBQyxJQUFJQTtBQUFBLE1BQ3hGLFlBQVksYUFBYSxTQUFTQTtBQUFBLE1BQ2xDLGlCQUFpQjtBQUFBLE1BQ2pCLG9CQUFvQjtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGVBQWU7QUFBQSxNQUNmLGdCQUFnQixPQUFPLGVBQWUsY0FBY0EsYUFBWTtBQUFBLE1BQ2hFLHVCQUF1QixPQUFPLHNCQUFzQixjQUFjQSxhQUFZO0FBQUEsTUFDOUUsaUJBQWlCLE9BQU8sZ0JBQWdCLGNBQWNBLGFBQVk7QUFBQSxNQUNsRSxpQkFBaUIsT0FBTyxnQkFBZ0IsY0FBY0EsYUFBWTtBQUFBLE1BQ2xFLGNBQWM7QUFBQSxNQUNkLGFBQWEsT0FBTyxZQUFZLGNBQWNBLGFBQVk7QUFBQSxNQUMxRCxhQUFhLE9BQU8sWUFBWSxjQUFjQSxhQUFZO0FBQUEsTUFDMUQsYUFBYSxPQUFPLFlBQVksY0FBY0EsYUFBWTtBQUFBLElBQzNEO0FBRUEsUUFBSSxVQUFVO0FBQ2IsVUFBSTtBQUNILGFBQUs7QUFBQSxNQUNOLFNBQVMsR0FBRztBQUVQLHFCQUFhLFNBQVMsU0FBUyxDQUFDLENBQUM7QUFDckMsbUJBQVcsbUJBQW1CLElBQUk7QUFBQSxNQUNuQztBQUFBLElBQ0Q7QUFITTtBQUtOLFFBQUksU0FBUyxTQUFTQyxRQUFPLE1BQU07QUFDbEMsVUFBSTtBQUNKLFVBQUksU0FBUyxtQkFBbUI7QUFDL0IsZ0JBQVEsc0JBQXNCLHNCQUFzQjtBQUFBLE1BQ3JELFdBQVcsU0FBUyx1QkFBdUI7QUFDMUMsZ0JBQVEsc0JBQXNCLGlCQUFpQjtBQUFBLE1BQ2hELFdBQVcsU0FBUyw0QkFBNEI7QUFDL0MsZ0JBQVEsc0JBQXNCLHVCQUF1QjtBQUFBLE1BQ3RELFdBQVcsU0FBUyxvQkFBb0I7QUFDdkMsWUFBSSxLQUFLQSxRQUFPLDBCQUEwQjtBQUMxQyxZQUFJLElBQUk7QUFDUCxrQkFBUSxHQUFHO0FBQUEsUUFDWjtBQUFBLE1BQ0QsV0FBVyxTQUFTLDRCQUE0QjtBQUMvQyxZQUFJLE1BQU1BLFFBQU8sa0JBQWtCO0FBQ25DLFlBQUksT0FBTyxVQUFVO0FBQ3BCLGtCQUFRLFNBQVMsSUFBSSxTQUFTO0FBQUEsUUFDL0I7QUFBQSxNQUNEO0FBRUEsaUJBQVcsSUFBSSxJQUFJO0FBRW5CLGFBQU87QUFBQSxJQUNSO0FBRUEsUUFBSSxpQkFBaUI7QUFBQSxNQUNwQixXQUFXO0FBQUEsTUFDWCwwQkFBMEIsQ0FBQyxlQUFlLFdBQVc7QUFBQSxNQUNyRCxvQkFBb0IsQ0FBQyxTQUFTLFdBQVc7QUFBQSxNQUN6Qyx3QkFBd0IsQ0FBQyxTQUFTLGFBQWEsU0FBUztBQUFBLE1BQ3hELHdCQUF3QixDQUFDLFNBQVMsYUFBYSxTQUFTO0FBQUEsTUFDeEQscUJBQXFCLENBQUMsU0FBUyxhQUFhLE1BQU07QUFBQSxNQUNsRCx1QkFBdUIsQ0FBQyxTQUFTLGFBQWEsUUFBUTtBQUFBLE1BQ3RELDRCQUE0QixDQUFDLGlCQUFpQixXQUFXO0FBQUEsTUFDekQsb0JBQW9CLENBQUMsMEJBQTBCLFdBQVc7QUFBQSxNQUMxRCw2QkFBNkIsQ0FBQywwQkFBMEIsYUFBYSxXQUFXO0FBQUEsTUFDaEYsc0JBQXNCLENBQUMsV0FBVyxXQUFXO0FBQUEsTUFDN0MsdUJBQXVCLENBQUMsWUFBWSxXQUFXO0FBQUEsTUFDL0MsbUJBQW1CLENBQUMsUUFBUSxXQUFXO0FBQUEsTUFDdkMsb0JBQW9CLENBQUMsU0FBUyxXQUFXO0FBQUEsTUFDekMsd0JBQXdCLENBQUMsYUFBYSxXQUFXO0FBQUEsTUFDakQsMkJBQTJCLENBQUMsZ0JBQWdCLFdBQVc7QUFBQSxNQUN2RCwyQkFBMkIsQ0FBQyxnQkFBZ0IsV0FBVztBQUFBLE1BQ3ZELHVCQUF1QixDQUFDLFlBQVksV0FBVztBQUFBLE1BQy9DLGVBQWUsQ0FBQyxxQkFBcUIsV0FBVztBQUFBLE1BQ2hELHdCQUF3QixDQUFDLHFCQUFxQixhQUFhLFdBQVc7QUFBQSxNQUN0RSx3QkFBd0IsQ0FBQyxhQUFhLFdBQVc7QUFBQSxNQUNqRCx5QkFBeUIsQ0FBQyxjQUFjLFdBQVc7QUFBQSxNQUNuRCx5QkFBeUIsQ0FBQyxjQUFjLFdBQVc7QUFBQSxNQUNuRCxlQUFlLENBQUMsUUFBUSxPQUFPO0FBQUEsTUFDL0IsbUJBQW1CLENBQUMsUUFBUSxXQUFXO0FBQUEsTUFDdkMsa0JBQWtCLENBQUMsT0FBTyxXQUFXO0FBQUEsTUFDckMscUJBQXFCLENBQUMsVUFBVSxXQUFXO0FBQUEsTUFDM0MscUJBQXFCLENBQUMsVUFBVSxXQUFXO0FBQUEsTUFDM0MsdUJBQXVCLENBQUMsVUFBVSxhQUFhLFVBQVU7QUFBQSxNQUN6RCxzQkFBc0IsQ0FBQyxVQUFVLGFBQWEsU0FBUztBQUFBLE1BQ3ZELHNCQUFzQixDQUFDLFdBQVcsV0FBVztBQUFBLE1BQzdDLHVCQUF1QixDQUFDLFdBQVcsYUFBYSxNQUFNO0FBQUEsTUFDdEQsaUJBQWlCLENBQUMsV0FBVyxLQUFLO0FBQUEsTUFDbEMsb0JBQW9CLENBQUMsV0FBVyxRQUFRO0FBQUEsTUFDeEMscUJBQXFCLENBQUMsV0FBVyxTQUFTO0FBQUEsTUFDMUMseUJBQXlCLENBQUMsY0FBYyxXQUFXO0FBQUEsTUFDbkQsNkJBQTZCLENBQUMsa0JBQWtCLFdBQVc7QUFBQSxNQUMzRCxxQkFBcUIsQ0FBQyxVQUFVLFdBQVc7QUFBQSxNQUMzQyxrQkFBa0IsQ0FBQyxPQUFPLFdBQVc7QUFBQSxNQUNyQyxnQ0FBZ0MsQ0FBQyxxQkFBcUIsV0FBVztBQUFBLE1BQ2pFLHFCQUFxQixDQUFDLFVBQVUsV0FBVztBQUFBLE1BQzNDLHFCQUFxQixDQUFDLFVBQVUsV0FBVztBQUFBLE1BQzNDLDBCQUEwQixDQUFDLGVBQWUsV0FBVztBQUFBLE1BQ3JELHlCQUF5QixDQUFDLGNBQWMsV0FBVztBQUFBLE1BQ25ELHdCQUF3QixDQUFDLGFBQWEsV0FBVztBQUFBLE1BQ2pELHlCQUF5QixDQUFDLGNBQWMsV0FBVztBQUFBLE1BQ25ELGdDQUFnQyxDQUFDLHFCQUFxQixXQUFXO0FBQUEsTUFDakUsMEJBQTBCLENBQUMsZUFBZSxXQUFXO0FBQUEsTUFDckQsMEJBQTBCLENBQUMsZUFBZSxXQUFXO0FBQUEsTUFDckQsdUJBQXVCLENBQUMsWUFBWSxXQUFXO0FBQUEsTUFDL0Msc0JBQXNCLENBQUMsV0FBVyxXQUFXO0FBQUEsTUFDN0Msc0JBQXNCLENBQUMsV0FBVyxXQUFXO0FBQUEsSUFDOUM7QUFFQSxRQUFJLE9BQU87QUFDWCxRQUFJLFNBQVM7QUFDYixRQUFJLFVBQVUsS0FBSyxLQUFLLFNBQVMsTUFBTSxNQUFNLFVBQVUsTUFBTTtBQUM3RCxRQUFJLGVBQWUsS0FBSyxLQUFLLFNBQVMsT0FBTyxNQUFNLFVBQVUsTUFBTTtBQUNuRSxRQUFJLFdBQVcsS0FBSyxLQUFLLFNBQVMsTUFBTSxPQUFPLFVBQVUsT0FBTztBQUNoRSxRQUFJLFlBQVksS0FBSyxLQUFLLFNBQVMsTUFBTSxPQUFPLFVBQVUsS0FBSztBQUMvRCxRQUFJLFFBQVEsS0FBSyxLQUFLLFNBQVMsTUFBTSxPQUFPLFVBQVUsSUFBSTtBQUcxRCxRQUFJLGFBQWE7QUFDakIsUUFBSSxlQUFlO0FBQ25CLFFBQUksZUFBZSxTQUFTQyxjQUFhLFFBQVE7QUFDaEQsVUFBSSxRQUFRLFVBQVUsUUFBUSxHQUFHLENBQUM7QUFDbEMsVUFBSSxPQUFPLFVBQVUsUUFBUSxFQUFFO0FBQy9CLFVBQUksVUFBVSxPQUFPLFNBQVMsS0FBSztBQUNsQyxjQUFNLElBQUksYUFBYSxnREFBZ0Q7QUFBQSxNQUN4RSxXQUFXLFNBQVMsT0FBTyxVQUFVLEtBQUs7QUFDekMsY0FBTSxJQUFJLGFBQWEsZ0RBQWdEO0FBQUEsTUFDeEU7QUFDQSxVQUFJLFNBQVMsQ0FBQztBQUNkLGVBQVMsUUFBUSxZQUFZLFNBQVUsT0FBTyxRQUFRLE9BQU8sV0FBVztBQUN2RSxlQUFPLE9BQU8sTUFBTSxJQUFJLFFBQVEsU0FBUyxXQUFXLGNBQWMsSUFBSSxJQUFJLFVBQVU7QUFBQSxNQUNyRixDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1I7QUFHQSxRQUFJLG1CQUFtQixTQUFTQyxrQkFBaUIsTUFBTSxjQUFjO0FBQ3BFLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUk7QUFDSixVQUFJLE9BQU8sZ0JBQWdCLGFBQWEsR0FBRztBQUMxQyxnQkFBUSxlQUFlLGFBQWE7QUFDcEMsd0JBQWdCLE1BQU0sTUFBTSxDQUFDLElBQUk7QUFBQSxNQUNsQztBQUVBLFVBQUksT0FBTyxZQUFZLGFBQWEsR0FBRztBQUN0QyxZQUFJLFFBQVEsV0FBVyxhQUFhO0FBQ3BDLFlBQUksVUFBVSxXQUFXO0FBQ3hCLGtCQUFRLE9BQU8sYUFBYTtBQUFBLFFBQzdCO0FBQ0EsWUFBSSxPQUFPLFVBQVUsZUFBZSxDQUFDLGNBQWM7QUFDbEQsZ0JBQU0sSUFBSSxXQUFXLGVBQWUsT0FBTyxzREFBc0Q7QUFBQSxRQUNsRztBQUVBLGVBQU87QUFBQSxVQUNOO0FBQUEsVUFDQSxNQUFNO0FBQUEsVUFDTjtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBRUEsWUFBTSxJQUFJLGFBQWEsZUFBZSxPQUFPLGtCQUFrQjtBQUFBLElBQ2hFO0FBRUEsSUFBQUosUUFBTyxVQUFVLFNBQVMsYUFBYSxNQUFNLGNBQWM7QUFDMUQsVUFBSSxPQUFPLFNBQVMsWUFBWSxLQUFLLFdBQVcsR0FBRztBQUNsRCxjQUFNLElBQUksV0FBVywyQ0FBMkM7QUFBQSxNQUNqRTtBQUNBLFVBQUksVUFBVSxTQUFTLEtBQUssT0FBTyxpQkFBaUIsV0FBVztBQUM5RCxjQUFNLElBQUksV0FBVywyQ0FBMkM7QUFBQSxNQUNqRTtBQUVBLFVBQUksTUFBTSxlQUFlLElBQUksTUFBTSxNQUFNO0FBQ3hDLGNBQU0sSUFBSSxhQUFhLG9GQUFvRjtBQUFBLE1BQzVHO0FBQ0EsVUFBSSxRQUFRLGFBQWEsSUFBSTtBQUM3QixVQUFJLG9CQUFvQixNQUFNLFNBQVMsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUV0RCxVQUFJLFlBQVksaUJBQWlCLE1BQU0sb0JBQW9CLEtBQUssWUFBWTtBQUM1RSxVQUFJLG9CQUFvQixVQUFVO0FBQ2xDLFVBQUksUUFBUSxVQUFVO0FBQ3RCLFVBQUkscUJBQXFCO0FBRXpCLFVBQUksUUFBUSxVQUFVO0FBQ3RCLFVBQUksT0FBTztBQUNWLDRCQUFvQixNQUFNLENBQUM7QUFDM0IscUJBQWEsT0FBTyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0FBQUEsTUFDM0M7QUFFQSxlQUFTLElBQUksR0FBRyxRQUFRLE1BQU0sSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQ3ZELFlBQUksT0FBTyxNQUFNLENBQUM7QUFDbEIsWUFBSSxRQUFRLFVBQVUsTUFBTSxHQUFHLENBQUM7QUFDaEMsWUFBSSxPQUFPLFVBQVUsTUFBTSxFQUFFO0FBQzdCLGFBRUcsVUFBVSxPQUFPLFVBQVUsT0FBTyxVQUFVLFFBQ3pDLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxTQUUzQyxVQUFVLE1BQ1o7QUFDRCxnQkFBTSxJQUFJLGFBQWEsc0RBQXNEO0FBQUEsUUFDOUU7QUFDQSxZQUFJLFNBQVMsaUJBQWlCLENBQUMsT0FBTztBQUNyQywrQkFBcUI7QUFBQSxRQUN0QjtBQUVBLDZCQUFxQixNQUFNO0FBQzNCLDRCQUFvQixNQUFNLG9CQUFvQjtBQUU5QyxZQUFJLE9BQU8sWUFBWSxpQkFBaUIsR0FBRztBQUMxQyxrQkFBUSxXQUFXLGlCQUFpQjtBQUFBLFFBQ3JDLFdBQVcsU0FBUyxNQUFNO0FBQ3pCLGNBQUksRUFBRSxRQUFRLFFBQVE7QUFDckIsZ0JBQUksQ0FBQyxjQUFjO0FBQ2xCLG9CQUFNLElBQUksV0FBVyx3QkFBd0IsT0FBTyw2Q0FBNkM7QUFBQSxZQUNsRztBQUNBLG1CQUFPO0FBQUEsVUFDUjtBQUNBLGNBQUksU0FBVSxJQUFJLEtBQU0sTUFBTSxRQUFRO0FBQ3JDLGdCQUFJLE9BQU8sTUFBTSxPQUFPLElBQUk7QUFDNUIsb0JBQVEsQ0FBQyxDQUFDO0FBU1YsZ0JBQUksU0FBUyxTQUFTLFFBQVEsRUFBRSxtQkFBbUIsS0FBSyxNQUFNO0FBQzdELHNCQUFRLEtBQUs7QUFBQSxZQUNkLE9BQU87QUFDTixzQkFBUSxNQUFNLElBQUk7QUFBQSxZQUNuQjtBQUFBLFVBQ0QsT0FBTztBQUNOLG9CQUFRLE9BQU8sT0FBTyxJQUFJO0FBQzFCLG9CQUFRLE1BQU0sSUFBSTtBQUFBLFVBQ25CO0FBRUEsY0FBSSxTQUFTLENBQUMsb0JBQW9CO0FBQ2pDLHVCQUFXLGlCQUFpQixJQUFJO0FBQUEsVUFDakM7QUFBQSxRQUNEO0FBQUEsTUFDRDtBQUNBLGFBQU87QUFBQSxJQUNSO0FBQUE7QUFBQTs7O0FDdFdBO0FBQUEsNkNBQUFLLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksZUFBZTtBQUduQixRQUFJLGtCQUFrQixhQUFhLDJCQUEyQixJQUFJLEtBQUs7QUFDdkUsUUFBSSxpQkFBaUI7QUFDcEIsVUFBSTtBQUNILHdCQUFnQixDQUFDLEdBQUcsS0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDO0FBQUEsTUFDdEMsU0FBUyxHQUFHO0FBRVgsMEJBQWtCO0FBQUEsTUFDbkI7QUFBQSxJQUNEO0FBRUEsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDZmpCO0FBQUEsK0JBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksZUFBZTtBQUVuQixRQUFJLFFBQVEsYUFBYSxxQ0FBcUMsSUFBSTtBQUVsRSxRQUFJLE9BQU87QUFDVixVQUFJO0FBQ0gsY0FBTSxDQUFDLEdBQUcsUUFBUTtBQUFBLE1BQ25CLFNBQVMsR0FBRztBQUVYLGdCQUFRO0FBQUEsTUFDVDtBQUFBLElBQ0Q7QUFFQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUNmakI7QUFBQSwrQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxrQkFBa0I7QUFFdEIsUUFBSSxlQUFlO0FBQ25CLFFBQUksYUFBYTtBQUVqQixRQUFJLE9BQU87QUFHWCxJQUFBQSxRQUFPLFVBQVUsU0FBUyxtQkFDekIsS0FDQSxVQUNBLE9BQ0M7QUFDRCxVQUFJLENBQUMsT0FBUSxPQUFPLFFBQVEsWUFBWSxPQUFPLFFBQVEsWUFBYTtBQUNuRSxjQUFNLElBQUksV0FBVyx3Q0FBd0M7QUFBQSxNQUM5RDtBQUNBLFVBQUksT0FBTyxhQUFhLFlBQVksT0FBTyxhQUFhLFVBQVU7QUFDakUsY0FBTSxJQUFJLFdBQVcsMENBQTBDO0FBQUEsTUFDaEU7QUFDQSxVQUFJLFVBQVUsU0FBUyxLQUFLLE9BQU8sVUFBVSxDQUFDLE1BQU0sYUFBYSxVQUFVLENBQUMsTUFBTSxNQUFNO0FBQ3ZGLGNBQU0sSUFBSSxXQUFXLHlEQUF5RDtBQUFBLE1BQy9FO0FBQ0EsVUFBSSxVQUFVLFNBQVMsS0FBSyxPQUFPLFVBQVUsQ0FBQyxNQUFNLGFBQWEsVUFBVSxDQUFDLE1BQU0sTUFBTTtBQUN2RixjQUFNLElBQUksV0FBVyx1REFBdUQ7QUFBQSxNQUM3RTtBQUNBLFVBQUksVUFBVSxTQUFTLEtBQUssT0FBTyxVQUFVLENBQUMsTUFBTSxhQUFhLFVBQVUsQ0FBQyxNQUFNLE1BQU07QUFDdkYsY0FBTSxJQUFJLFdBQVcsMkRBQTJEO0FBQUEsTUFDakY7QUFDQSxVQUFJLFVBQVUsU0FBUyxLQUFLLE9BQU8sVUFBVSxDQUFDLE1BQU0sV0FBVztBQUM5RCxjQUFNLElBQUksV0FBVyx5Q0FBeUM7QUFBQSxNQUMvRDtBQUVBLFVBQUksZ0JBQWdCLFVBQVUsU0FBUyxJQUFJLFVBQVUsQ0FBQyxJQUFJO0FBQzFELFVBQUksY0FBYyxVQUFVLFNBQVMsSUFBSSxVQUFVLENBQUMsSUFBSTtBQUN4RCxVQUFJLGtCQUFrQixVQUFVLFNBQVMsSUFBSSxVQUFVLENBQUMsSUFBSTtBQUM1RCxVQUFJLFFBQVEsVUFBVSxTQUFTLElBQUksVUFBVSxDQUFDLElBQUk7QUFHbEQsVUFBSSxPQUFPLENBQUMsQ0FBQyxRQUFRLEtBQUssS0FBSyxRQUFRO0FBRXZDLFVBQUksaUJBQWlCO0FBQ3BCLHdCQUFnQixLQUFLLFVBQVU7QUFBQSxVQUM5QixjQUFjLG9CQUFvQixRQUFRLE9BQU8sS0FBSyxlQUFlLENBQUM7QUFBQSxVQUN0RSxZQUFZLGtCQUFrQixRQUFRLE9BQU8sS0FBSyxhQUFhLENBQUM7QUFBQSxVQUNoRTtBQUFBLFVBQ0EsVUFBVSxnQkFBZ0IsUUFBUSxPQUFPLEtBQUssV0FBVyxDQUFDO0FBQUEsUUFDM0QsQ0FBQztBQUFBLE1BQ0YsV0FBVyxTQUFVLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLGlCQUFrQjtBQUV6RSxZQUFJLFFBQVEsSUFBSTtBQUFBLE1BQ2pCLE9BQU87QUFDTixjQUFNLElBQUksYUFBYSw2R0FBNkc7QUFBQSxNQUNySTtBQUFBLElBQ0Q7QUFBQTtBQUFBOzs7QUN2REE7QUFBQSxtREFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxrQkFBa0I7QUFFdEIsUUFBSSx5QkFBeUIsU0FBU0MsMEJBQXlCO0FBQzlELGFBQU8sQ0FBQyxDQUFDO0FBQUEsSUFDVjtBQUVBLDJCQUF1QiwwQkFBMEIsU0FBUywwQkFBMEI7QUFFbkYsVUFBSSxDQUFDLGlCQUFpQjtBQUNyQixlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUk7QUFDSCxlQUFPLGdCQUFnQixDQUFDLEdBQUcsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsV0FBVztBQUFBLE1BQy9ELFNBQVMsR0FBRztBQUVYLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQUVBLElBQUFELFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ3JCakI7QUFBQSw0Q0FBQUUsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxPQUFPO0FBQ1gsUUFBSSxhQUFhLE9BQU8sV0FBVyxjQUFjLE9BQU8sT0FBTyxLQUFLLE1BQU07QUFFMUUsUUFBSSxRQUFRLE9BQU8sVUFBVTtBQUM3QixRQUFJLFNBQVMsTUFBTSxVQUFVO0FBQzdCLFFBQUkscUJBQXFCO0FBRXpCLFFBQUksYUFBYSxTQUFVLElBQUk7QUFDOUIsYUFBTyxPQUFPLE9BQU8sY0FBYyxNQUFNLEtBQUssRUFBRSxNQUFNO0FBQUEsSUFDdkQ7QUFFQSxRQUFJLHNCQUFzQixtQ0FBb0M7QUFFOUQsUUFBSSxpQkFBaUIsU0FBVSxRQUFRLE1BQU0sT0FBTyxXQUFXO0FBQzlELFVBQUksUUFBUSxRQUFRO0FBQ25CLFlBQUksY0FBYyxNQUFNO0FBQ3ZCLGNBQUksT0FBTyxJQUFJLE1BQU0sT0FBTztBQUMzQjtBQUFBLFVBQ0Q7QUFBQSxRQUNELFdBQVcsQ0FBQyxXQUFXLFNBQVMsS0FBSyxDQUFDLFVBQVUsR0FBRztBQUNsRDtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBRUEsVUFBSSxxQkFBcUI7QUFDeEIsMkJBQW1CLFFBQVEsTUFBTSxPQUFPLElBQUk7QUFBQSxNQUM3QyxPQUFPO0FBQ04sMkJBQW1CLFFBQVEsTUFBTSxLQUFLO0FBQUEsTUFDdkM7QUFBQSxJQUNEO0FBRUEsUUFBSSxtQkFBbUIsU0FBVSxRQUFRQyxNQUFLO0FBQzdDLFVBQUksYUFBYSxVQUFVLFNBQVMsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDO0FBQ3hELFVBQUksUUFBUSxLQUFLQSxJQUFHO0FBQ3BCLFVBQUksWUFBWTtBQUNmLGdCQUFRLE9BQU8sS0FBSyxPQUFPLE9BQU8sc0JBQXNCQSxJQUFHLENBQUM7QUFBQSxNQUM3RDtBQUNBLGVBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN6Qyx1QkFBZSxRQUFRLE1BQU0sQ0FBQyxHQUFHQSxLQUFJLE1BQU0sQ0FBQyxDQUFDLEdBQUcsV0FBVyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDckU7QUFBQSxJQUNEO0FBRUEscUJBQWlCLHNCQUFzQixDQUFDLENBQUM7QUFFekMsSUFBQUQsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDOUNqQjtBQUFBLDhDQUFBRSxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLGVBQWU7QUFDbkIsUUFBSSxTQUFTO0FBQ2IsUUFBSSxpQkFBaUIsbUNBQW9DO0FBQ3pELFFBQUksT0FBTztBQUVYLFFBQUksYUFBYTtBQUNqQixRQUFJLFNBQVMsYUFBYSxjQUFjO0FBR3hDLElBQUFBLFFBQU8sVUFBVSxTQUFTLGtCQUFrQixJQUFJLFFBQVE7QUFDdkQsVUFBSSxPQUFPLE9BQU8sWUFBWTtBQUM3QixjQUFNLElBQUksV0FBVyx3QkFBd0I7QUFBQSxNQUM5QztBQUNBLFVBQUksT0FBTyxXQUFXLFlBQVksU0FBUyxLQUFLLFNBQVMsY0FBYyxPQUFPLE1BQU0sTUFBTSxRQUFRO0FBQ2pHLGNBQU0sSUFBSSxXQUFXLDRDQUE0QztBQUFBLE1BQ2xFO0FBRUEsVUFBSSxRQUFRLFVBQVUsU0FBUyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFFakQsVUFBSSwrQkFBK0I7QUFDbkMsVUFBSSwyQkFBMkI7QUFDL0IsVUFBSSxZQUFZLE1BQU0sTUFBTTtBQUMzQixZQUFJLE9BQU8sS0FBSyxJQUFJLFFBQVE7QUFDNUIsWUFBSSxRQUFRLENBQUMsS0FBSyxjQUFjO0FBQy9CLHlDQUErQjtBQUFBLFFBQ2hDO0FBQ0EsWUFBSSxRQUFRLENBQUMsS0FBSyxVQUFVO0FBQzNCLHFDQUEyQjtBQUFBLFFBQzVCO0FBQUEsTUFDRDtBQUVBLFVBQUksZ0NBQWdDLDRCQUE0QixDQUFDLE9BQU87QUFDdkUsWUFBSSxnQkFBZ0I7QUFDbkI7QUFBQTtBQUFBLFlBQTZDO0FBQUEsWUFBSztBQUFBLFlBQVU7QUFBQSxZQUFRO0FBQUEsWUFBTTtBQUFBLFVBQUk7QUFBQSxRQUMvRSxPQUFPO0FBQ047QUFBQTtBQUFBLFlBQTZDO0FBQUEsWUFBSztBQUFBLFlBQVU7QUFBQSxVQUFNO0FBQUEsUUFDbkU7QUFBQSxNQUNEO0FBQ0EsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUN6Q0E7QUFBQSxvQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxPQUFPO0FBQ1gsUUFBSSxlQUFlO0FBQ25CLFFBQUksb0JBQW9CO0FBRXhCLFFBQUksYUFBYTtBQUNqQixRQUFJLFNBQVMsYUFBYSw0QkFBNEI7QUFDdEQsUUFBSSxRQUFRLGFBQWEsMkJBQTJCO0FBQ3BELFFBQUksZ0JBQWdCLGFBQWEsbUJBQW1CLElBQUksS0FBSyxLQUFLLEtBQUssT0FBTyxNQUFNO0FBRXBGLFFBQUksa0JBQWtCO0FBQ3RCLFFBQUksT0FBTyxhQUFhLFlBQVk7QUFFcEMsSUFBQUEsUUFBTyxVQUFVLFNBQVMsU0FBUyxrQkFBa0I7QUFDcEQsVUFBSSxPQUFPLHFCQUFxQixZQUFZO0FBQzNDLGNBQU0sSUFBSSxXQUFXLHdCQUF3QjtBQUFBLE1BQzlDO0FBQ0EsVUFBSSxPQUFPLGNBQWMsTUFBTSxPQUFPLFNBQVM7QUFDL0MsYUFBTztBQUFBLFFBQ047QUFBQSxRQUNBLElBQUksS0FBSyxHQUFHLGlCQUFpQixVQUFVLFVBQVUsU0FBUyxFQUFFO0FBQUEsUUFDNUQ7QUFBQSxNQUNEO0FBQUEsSUFDRDtBQUVBLFFBQUksWUFBWSxTQUFTQyxhQUFZO0FBQ3BDLGFBQU8sY0FBYyxNQUFNLFFBQVEsU0FBUztBQUFBLElBQzdDO0FBRUEsUUFBSSxpQkFBaUI7QUFDcEIsc0JBQWdCRCxRQUFPLFNBQVMsU0FBUyxFQUFFLE9BQU8sVUFBVSxDQUFDO0FBQUEsSUFDOUQsT0FBTztBQUNOLE1BQUFBLFFBQU8sUUFBUSxRQUFRO0FBQUEsSUFDeEI7QUFBQTtBQUFBOzs7QUNsQ0E7QUFBQSx3Q0FBQUUsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxlQUFlO0FBRW5CLFFBQUksV0FBVztBQUVmLFFBQUksV0FBVyxTQUFTLGFBQWEsMEJBQTBCLENBQUM7QUFFaEUsSUFBQUEsUUFBTyxVQUFVLFNBQVMsbUJBQW1CLE1BQU0sY0FBYztBQUNoRSxVQUFJLFlBQVksYUFBYSxNQUFNLENBQUMsQ0FBQyxZQUFZO0FBQ2pELFVBQUksT0FBTyxjQUFjLGNBQWMsU0FBUyxNQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzFFLGVBQU8sU0FBUyxTQUFTO0FBQUEsTUFDMUI7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQ2RBLElBQUFDLDBCQUFBO0FBQUEsaURBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUdBLFFBQUksYUFBYTtBQUNqQixRQUFJLGFBQWEsZ0JBQTZCO0FBQzlDLFFBQUksWUFBWTtBQUNoQixRQUFJLFdBQVc7QUFDZixRQUFJLFFBQVEsVUFBVSxzQkFBc0I7QUFDNUMsUUFBSSxvQkFBb0IsVUFBVSx1Q0FBdUM7QUFDekUsUUFBSSxxQkFBcUIsYUFBYSxPQUFPLHdCQUF3QjtBQUdyRSxJQUFBQSxRQUFPLFVBQVUsU0FBUyxPQUFPLFFBQVEsU0FBUztBQUNqRCxVQUFJLFVBQVUsTUFBTTtBQUFFLGNBQU0sSUFBSSxVQUFVLDBCQUEwQjtBQUFBLE1BQUc7QUFDdkUsVUFBSSxLQUFLLFNBQVMsTUFBTTtBQUN4QixVQUFJLFVBQVUsV0FBVyxHQUFHO0FBQzNCLGVBQU87QUFBQSxNQUNSO0FBQ0EsZUFBUyxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsRUFBRSxHQUFHO0FBQzFDLFlBQUksT0FBTyxTQUFTLFVBQVUsQ0FBQyxDQUFDO0FBR2hDLFlBQUksT0FBTyxXQUFXLElBQUk7QUFDMUIsWUFBSSxhQUFhLGVBQWUsT0FBTyx5QkFBeUI7QUFDaEUsWUFBSSxZQUFZO0FBQ2YsY0FBSSxPQUFPLFdBQVcsSUFBSTtBQUMxQixtQkFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsRUFBRSxHQUFHO0FBQ3JDLGdCQUFJLE1BQU0sS0FBSyxDQUFDO0FBQ2hCLGdCQUFJLGtCQUFrQixNQUFNLEdBQUcsR0FBRztBQUNqQyxvQkFBTSxNQUFNLEdBQUc7QUFBQSxZQUNoQjtBQUFBLFVBQ0Q7QUFBQSxRQUNEO0FBR0EsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEVBQUUsR0FBRztBQUNyQyxjQUFJLFVBQVUsS0FBSyxDQUFDO0FBQ3BCLGNBQUksa0JBQWtCLE1BQU0sT0FBTyxHQUFHO0FBQ3JDLGdCQUFJLFlBQVksS0FBSyxPQUFPO0FBQzVCLGVBQUcsT0FBTyxJQUFJO0FBQUEsVUFDZjtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBRUEsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUM3Q0E7QUFBQSwyQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxpQkFBaUI7QUFFckIsUUFBSSw4QkFBOEIsV0FBWTtBQUM3QyxVQUFJLENBQUMsT0FBTyxRQUFRO0FBQ25CLGVBQU87QUFBQSxNQUNSO0FBS0EsVUFBSSxNQUFNO0FBQ1YsVUFBSSxVQUFVLElBQUksTUFBTSxFQUFFO0FBQzFCLFVBQUlDLE9BQU0sQ0FBQztBQUNYLGVBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEVBQUUsR0FBRztBQUN4QyxRQUFBQSxLQUFJLFFBQVEsQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDO0FBQUEsTUFDNUI7QUFDQSxVQUFJLE1BQU0sT0FBTyxPQUFPLENBQUMsR0FBR0EsSUFBRztBQUMvQixVQUFJLFNBQVM7QUFDYixlQUFTLEtBQUssS0FBSztBQUNsQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxhQUFPLFFBQVE7QUFBQSxJQUNoQjtBQUVBLFFBQUksNkJBQTZCLFdBQVk7QUFDNUMsVUFBSSxDQUFDLE9BQU8sVUFBVSxDQUFDLE9BQU8sbUJBQW1CO0FBQ2hELGVBQU87QUFBQSxNQUNSO0FBS0EsVUFBSSxVQUFVLE9BQU8sa0JBQWtCLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDL0MsVUFBSTtBQUNILGVBQU8sT0FBTyxTQUFTLElBQUk7QUFBQSxNQUM1QixTQUFTLEdBQUc7QUFDWCxlQUFPLFFBQVEsQ0FBQyxNQUFNO0FBQUEsTUFDdkI7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUVBLElBQUFELFFBQU8sVUFBVSxTQUFTLGNBQWM7QUFDdkMsVUFBSSxDQUFDLE9BQU8sUUFBUTtBQUNuQixlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUksNEJBQTRCLEdBQUc7QUFDbEMsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJLDJCQUEyQixHQUFHO0FBQ2pDLGVBQU87QUFBQSxNQUNSO0FBQ0EsYUFBTyxPQUFPO0FBQUEsSUFDZjtBQUFBO0FBQUE7OztBQ3REQTtBQUFBLHVDQUFBRSxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFNBQVM7QUFDYixRQUFJLGNBQWM7QUFFbEIsSUFBQUEsUUFBTyxVQUFVLFNBQVMsYUFBYTtBQUN0QyxVQUFJLFdBQVcsWUFBWTtBQUMzQjtBQUFBLFFBQ0M7QUFBQSxRQUNBLEVBQUUsUUFBUSxTQUFTO0FBQUEsUUFDbkIsRUFBRSxRQUFRLFdBQVk7QUFBRSxpQkFBTyxPQUFPLFdBQVc7QUFBQSxRQUFVLEVBQUU7QUFBQSxNQUM5RDtBQUNBLGFBQU87QUFBQSxJQUNSO0FBQUE7QUFBQTs7O0FDYkE7QUFBQSx3Q0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxtQkFBbUI7QUFDdkIsUUFBSSxXQUFXO0FBRWYsUUFBSSxpQkFBaUI7QUFDckIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksT0FBTztBQUVYLFFBQUksV0FBVyxTQUFTLE1BQU0sWUFBWSxDQUFDO0FBRTNDLFFBQUksUUFBUSxTQUFTLE9BQU8sUUFBUSxTQUFTO0FBQzVDLGFBQU8sU0FBUyxRQUFRLFNBQVM7QUFBQSxJQUNsQztBQUVBLHFCQUFpQixPQUFPO0FBQUEsTUFDdkI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0QsQ0FBQztBQUVELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ3JCakI7QUFBQSwrQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxxQkFBcUIsU0FBU0Msc0JBQXFCO0FBQ3RELGFBQU8sT0FBTyxTQUFTLElBQUk7QUFBQSxNQUFDLEVBQUUsU0FBUztBQUFBLElBQ3hDO0FBRUEsUUFBSSxPQUFPLE9BQU87QUFDbEIsUUFBSSxNQUFNO0FBQ1QsVUFBSTtBQUNILGFBQUssQ0FBQyxHQUFHLFFBQVE7QUFBQSxNQUNsQixTQUFTLEdBQUc7QUFFWCxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFFQSx1QkFBbUIsaUNBQWlDLFNBQVMsaUNBQWlDO0FBQzdGLFVBQUksQ0FBQyxtQkFBbUIsS0FBSyxDQUFDLE1BQU07QUFDbkMsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJLE9BQU8sS0FBSyxXQUFZO0FBQUEsTUFBQyxHQUFHLE1BQU07QUFDdEMsYUFBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSztBQUFBLElBQ3pCO0FBRUEsUUFBSSxRQUFRLFNBQVMsVUFBVTtBQUUvQix1QkFBbUIsMEJBQTBCLFNBQVMsMEJBQTBCO0FBQy9FLGFBQU8sbUJBQW1CLEtBQUssT0FBTyxVQUFVLGNBQWMsU0FBUyxJQUFJO0FBQUEsTUFBQyxFQUFFLEtBQUssRUFBRSxTQUFTO0FBQUEsSUFDL0Y7QUFFQSxJQUFBRCxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUM5QmpCO0FBQUEsNENBQUFFLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksU0FBUztBQUNiLFFBQUksaUJBQWlCLG1DQUFvQztBQUN6RCxRQUFJLGlDQUFpQywrQkFBZ0MsK0JBQStCO0FBRXBHLFFBQUksYUFBYTtBQUdqQixJQUFBQSxRQUFPLFVBQVUsU0FBUyxnQkFBZ0IsSUFBSSxNQUFNO0FBQ25ELFVBQUksT0FBTyxPQUFPLFlBQVk7QUFDN0IsY0FBTSxJQUFJLFdBQVcsd0JBQXdCO0FBQUEsTUFDOUM7QUFDQSxVQUFJLFFBQVEsVUFBVSxTQUFTLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNqRCxVQUFJLENBQUMsU0FBUyxnQ0FBZ0M7QUFDN0MsWUFBSSxnQkFBZ0I7QUFDbkI7QUFBQTtBQUFBLFlBQTZDO0FBQUEsWUFBSztBQUFBLFlBQVE7QUFBQSxZQUFNO0FBQUEsWUFBTTtBQUFBLFVBQUk7QUFBQSxRQUMzRSxPQUFPO0FBQ047QUFBQTtBQUFBLFlBQTZDO0FBQUEsWUFBSztBQUFBLFlBQVE7QUFBQSxVQUFJO0FBQUEsUUFDL0Q7QUFBQSxNQUNEO0FBQ0EsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUN0QkEsSUFBQUMsMEJBQUE7QUFBQSwwREFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxrQkFBa0I7QUFDdEIsUUFBSSxhQUFhO0FBRWpCLFFBQUksVUFBVTtBQUVkLElBQUFBLFFBQU8sVUFBVSxnQkFBZ0IsU0FBUyxRQUFRO0FBQ2pELFVBQUksUUFBUSxRQUFRLFNBQVMsUUFBUSxJQUFJLEdBQUc7QUFDM0MsY0FBTSxJQUFJLFdBQVcsb0RBQW9EO0FBQUEsTUFDMUU7QUFDQSxVQUFJLFNBQVM7QUFDYixVQUFJLEtBQUssWUFBWTtBQUNwQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssUUFBUTtBQUNoQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssWUFBWTtBQUNwQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssV0FBVztBQUNuQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssUUFBUTtBQUNoQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssU0FBUztBQUNqQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssYUFBYTtBQUNyQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxVQUFJLEtBQUssUUFBUTtBQUNoQixrQkFBVTtBQUFBLE1BQ1g7QUFDQSxhQUFPO0FBQUEsSUFDUixHQUFHLGFBQWEsSUFBSTtBQUFBO0FBQUE7OztBQ3JDcEIsSUFBQUMsb0JBQUE7QUFBQSxvREFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxpQkFBaUI7QUFFckIsUUFBSSxzQkFBc0IsNEJBQTZCO0FBQ3ZELFFBQUksUUFBUSxPQUFPO0FBRW5CLElBQUFBLFFBQU8sVUFBVSxTQUFTLGNBQWM7QUFDdkMsVUFBSSx1QkFBd0IsT0FBUSxVQUFVLE9BQU87QUFDcEQsWUFBSSxhQUFhLE1BQU0sT0FBTyxXQUFXLE9BQU87QUFDaEQsWUFDQyxjQUNHLE9BQU8sV0FBVyxRQUFRLGNBQzFCLFlBQVksT0FBTyxhQUNuQixnQkFBZ0IsT0FBTyxXQUN6QjtBQUVELGNBQUksUUFBUTtBQUNaLGNBQUksSUFBSSxDQUFDO0FBQ1QsaUJBQU8sZUFBZSxHQUFHLGNBQWM7QUFBQSxZQUN0QyxLQUFLLFdBQVk7QUFDaEIsdUJBQVM7QUFBQSxZQUNWO0FBQUEsVUFDRCxDQUFDO0FBQ0QsaUJBQU8sZUFBZSxHQUFHLFVBQVU7QUFBQSxZQUNsQyxLQUFLLFdBQVk7QUFDaEIsdUJBQVM7QUFBQSxZQUNWO0FBQUEsVUFDRCxDQUFDO0FBRUQscUJBQVcsSUFBSSxLQUFLLENBQUM7QUFFckIsY0FBSSxVQUFVLE1BQU07QUFDbkIsbUJBQU8sV0FBVztBQUFBLFVBQ25CO0FBQUEsUUFDRDtBQUFBLE1BQ0Q7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQ3RDQSxJQUFBQyxnQkFBQTtBQUFBLGdEQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLHNCQUFzQiw0QkFBNkI7QUFDdkQsUUFBSSxjQUFjO0FBQ2xCLFFBQUksT0FBTyxPQUFPO0FBQ2xCLFFBQUksaUJBQWlCLE9BQU87QUFDNUIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxXQUFXLE9BQU87QUFDdEIsUUFBSSxRQUFRO0FBRVosSUFBQUEsUUFBTyxVQUFVLFNBQVMsWUFBWTtBQUNyQyxVQUFJLENBQUMsdUJBQXVCLENBQUMsVUFBVTtBQUN0QyxjQUFNLElBQUksUUFBUSwyRkFBMkY7QUFBQSxNQUM5RztBQUNBLFVBQUksV0FBVyxZQUFZO0FBQzNCLFVBQUksUUFBUSxTQUFTLEtBQUs7QUFDMUIsVUFBSSxhQUFhLEtBQUssT0FBTyxPQUFPO0FBQ3BDLFVBQUksQ0FBQyxjQUFjLFdBQVcsUUFBUSxVQUFVO0FBQy9DLHVCQUFlLE9BQU8sU0FBUztBQUFBLFVBQzlCLGNBQWM7QUFBQSxVQUNkLFlBQVk7QUFBQSxVQUNaLEtBQUs7QUFBQSxRQUNOLENBQUM7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUN6QkE7QUFBQSxpREFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxTQUFTO0FBQ2IsUUFBSSxXQUFXO0FBRWYsUUFBSSxpQkFBaUI7QUFDckIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksT0FBTztBQUVYLFFBQUksYUFBYSxTQUFTLFlBQVksQ0FBQztBQUV2QyxXQUFPLFlBQVk7QUFBQSxNQUNsQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRCxDQUFDO0FBRUQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDakJqQjtBQUFBLHlDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFLQSxRQUFJLFlBQVksT0FBTztBQUN2QixJQUFBQSxRQUFPLFVBQVUsU0FBUyxZQUFZLFVBQVU7QUFFL0MsVUFBSSxZQUFZLFFBQVEsT0FBTyxTQUFTLFNBQVMsTUFBTSxhQUFhO0FBQ25FLGVBQU8sU0FBUyxTQUFTLEVBQUU7QUFBQSxNQUM1QjtBQUFBLElBQ0Q7QUFBQTtBQUFBOzs7QUNYQTtBQUFBLGdEQUFBQyxVQUFBQyxTQUFBO0FBQUEsSUFBQUEsUUFBTyxVQUFVLFFBQVEsTUFBTSxFQUFFO0FBQUE7QUFBQTs7O0FDQWpDO0FBQUEseUNBQUFDLFVBQUFDLFNBQUE7QUFBQSxRQUFJLFNBQVMsT0FBTyxRQUFRLGNBQWMsSUFBSTtBQUM5QyxRQUFJLG9CQUFvQixPQUFPLDRCQUE0QixTQUFTLE9BQU8seUJBQXlCLElBQUksV0FBVyxNQUFNLElBQUk7QUFDN0gsUUFBSSxVQUFVLFVBQVUscUJBQXFCLE9BQU8sa0JBQWtCLFFBQVEsYUFBYSxrQkFBa0IsTUFBTTtBQUNuSCxRQUFJLGFBQWEsVUFBVSxJQUFJLFVBQVU7QUFDekMsUUFBSSxTQUFTLE9BQU8sUUFBUSxjQUFjLElBQUk7QUFDOUMsUUFBSSxvQkFBb0IsT0FBTyw0QkFBNEIsU0FBUyxPQUFPLHlCQUF5QixJQUFJLFdBQVcsTUFBTSxJQUFJO0FBQzdILFFBQUksVUFBVSxVQUFVLHFCQUFxQixPQUFPLGtCQUFrQixRQUFRLGFBQWEsa0JBQWtCLE1BQU07QUFDbkgsUUFBSSxhQUFhLFVBQVUsSUFBSSxVQUFVO0FBQ3pDLFFBQUksYUFBYSxPQUFPLFlBQVksY0FBYyxRQUFRO0FBQzFELFFBQUksYUFBYSxhQUFhLFFBQVEsVUFBVSxNQUFNO0FBQ3RELFFBQUksYUFBYSxPQUFPLFlBQVksY0FBYyxRQUFRO0FBQzFELFFBQUksYUFBYSxhQUFhLFFBQVEsVUFBVSxNQUFNO0FBQ3RELFFBQUksYUFBYSxPQUFPLFlBQVksY0FBYyxRQUFRO0FBQzFELFFBQUksZUFBZSxhQUFhLFFBQVEsVUFBVSxRQUFRO0FBQzFELFFBQUksaUJBQWlCLFFBQVEsVUFBVTtBQUN2QyxRQUFJLGlCQUFpQixPQUFPLFVBQVU7QUFDdEMsUUFBSSxtQkFBbUIsU0FBUyxVQUFVO0FBQzFDLFFBQUksU0FBUyxPQUFPLFVBQVU7QUFDOUIsUUFBSSxTQUFTLE9BQU8sVUFBVTtBQUM5QixRQUFJLFdBQVcsT0FBTyxVQUFVO0FBQ2hDLFFBQUksZUFBZSxPQUFPLFVBQVU7QUFDcEMsUUFBSSxlQUFlLE9BQU8sVUFBVTtBQUNwQyxRQUFJLFFBQVEsT0FBTyxVQUFVO0FBQzdCLFFBQUksVUFBVSxNQUFNLFVBQVU7QUFDOUIsUUFBSSxRQUFRLE1BQU0sVUFBVTtBQUM1QixRQUFJLFlBQVksTUFBTSxVQUFVO0FBQ2hDLFFBQUksU0FBUyxLQUFLO0FBQ2xCLFFBQUksZ0JBQWdCLE9BQU8sV0FBVyxhQUFhLE9BQU8sVUFBVSxVQUFVO0FBQzlFLFFBQUksT0FBTyxPQUFPO0FBQ2xCLFFBQUksY0FBYyxPQUFPLFdBQVcsY0FBYyxPQUFPLE9BQU8sYUFBYSxXQUFXLE9BQU8sVUFBVSxXQUFXO0FBQ3BILFFBQUksb0JBQW9CLE9BQU8sV0FBVyxjQUFjLE9BQU8sT0FBTyxhQUFhO0FBRW5GLFFBQUksY0FBYyxPQUFPLFdBQVcsY0FBYyxPQUFPLGdCQUFnQixPQUFPLE9BQU8sZ0JBQWdCLG9CQUFvQixXQUFXLFlBQ2hJLE9BQU8sY0FDUDtBQUNOLFFBQUksZUFBZSxPQUFPLFVBQVU7QUFFcEMsUUFBSSxPQUFPLE9BQU8sWUFBWSxhQUFhLFFBQVEsaUJBQWlCLE9BQU8sb0JBQ3ZFLENBQUMsRUFBRSxjQUFjLE1BQU0sWUFDakIsU0FBVSxHQUFHO0FBQ1gsYUFBTyxFQUFFO0FBQUEsSUFDYixJQUNFO0FBR1YsYUFBUyxvQkFBb0IsS0FBSyxLQUFLO0FBQ25DLFVBQ0ksUUFBUSxZQUNMLFFBQVEsYUFDUixRQUFRLE9BQ1AsT0FBTyxNQUFNLFFBQVMsTUFBTSxPQUM3QixNQUFNLEtBQUssS0FBSyxHQUFHLEdBQ3hCO0FBQ0UsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJLFdBQVc7QUFDZixVQUFJLE9BQU8sUUFBUSxVQUFVO0FBQ3pCLFlBQUksTUFBTSxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLE9BQU8sR0FBRztBQUM5QyxZQUFJLFFBQVEsS0FBSztBQUNiLGNBQUksU0FBUyxPQUFPLEdBQUc7QUFDdkIsY0FBSSxNQUFNLE9BQU8sS0FBSyxLQUFLLE9BQU8sU0FBUyxDQUFDO0FBQzVDLGlCQUFPLFNBQVMsS0FBSyxRQUFRLFVBQVUsS0FBSyxJQUFJLE1BQU0sU0FBUyxLQUFLLFNBQVMsS0FBSyxLQUFLLGVBQWUsS0FBSyxHQUFHLE1BQU0sRUFBRTtBQUFBLFFBQzFIO0FBQUEsTUFDSjtBQUNBLGFBQU8sU0FBUyxLQUFLLEtBQUssVUFBVSxLQUFLO0FBQUEsSUFDN0M7QUFFQSxRQUFJLGNBQWM7QUFDbEIsUUFBSSxnQkFBZ0IsWUFBWTtBQUNoQyxRQUFJLGdCQUFnQixTQUFTLGFBQWEsSUFBSSxnQkFBZ0I7QUFFOUQsSUFBQUEsUUFBTyxVQUFVLFNBQVMsU0FBUyxLQUFLLFNBQVMsT0FBTyxNQUFNO0FBQzFELFVBQUksT0FBTyxXQUFXLENBQUM7QUFFdkIsVUFBSSxJQUFJLE1BQU0sWUFBWSxNQUFNLEtBQUssZUFBZSxZQUFZLEtBQUssZUFBZSxXQUFXO0FBQzNGLGNBQU0sSUFBSSxVQUFVLGtEQUFrRDtBQUFBLE1BQzFFO0FBQ0EsVUFDSSxJQUFJLE1BQU0saUJBQWlCLE1BQU0sT0FBTyxLQUFLLG9CQUFvQixXQUMzRCxLQUFLLGtCQUFrQixLQUFLLEtBQUssb0JBQW9CLFdBQ3JELEtBQUssb0JBQW9CLE9BRWpDO0FBQ0UsY0FBTSxJQUFJLFVBQVUsd0ZBQXdGO0FBQUEsTUFDaEg7QUFDQSxVQUFJLGdCQUFnQixJQUFJLE1BQU0sZUFBZSxJQUFJLEtBQUssZ0JBQWdCO0FBQ3RFLFVBQUksT0FBTyxrQkFBa0IsYUFBYSxrQkFBa0IsVUFBVTtBQUNsRSxjQUFNLElBQUksVUFBVSwrRUFBK0U7QUFBQSxNQUN2RztBQUVBLFVBQ0ksSUFBSSxNQUFNLFFBQVEsS0FDZixLQUFLLFdBQVcsUUFDaEIsS0FBSyxXQUFXLE9BQ2hCLEVBQUUsU0FBUyxLQUFLLFFBQVEsRUFBRSxNQUFNLEtBQUssVUFBVSxLQUFLLFNBQVMsSUFDbEU7QUFDRSxjQUFNLElBQUksVUFBVSwwREFBMEQ7QUFBQSxNQUNsRjtBQUNBLFVBQUksSUFBSSxNQUFNLGtCQUFrQixLQUFLLE9BQU8sS0FBSyxxQkFBcUIsV0FBVztBQUM3RSxjQUFNLElBQUksVUFBVSxtRUFBbUU7QUFBQSxNQUMzRjtBQUNBLFVBQUksbUJBQW1CLEtBQUs7QUFFNUIsVUFBSSxPQUFPLFFBQVEsYUFBYTtBQUM1QixlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUksUUFBUSxNQUFNO0FBQ2QsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJLE9BQU8sUUFBUSxXQUFXO0FBQzFCLGVBQU8sTUFBTSxTQUFTO0FBQUEsTUFDMUI7QUFFQSxVQUFJLE9BQU8sUUFBUSxVQUFVO0FBQ3pCLGVBQU8sY0FBYyxLQUFLLElBQUk7QUFBQSxNQUNsQztBQUNBLFVBQUksT0FBTyxRQUFRLFVBQVU7QUFDekIsWUFBSSxRQUFRLEdBQUc7QUFDWCxpQkFBTyxXQUFXLE1BQU0sSUFBSSxNQUFNO0FBQUEsUUFDdEM7QUFDQSxZQUFJLE1BQU0sT0FBTyxHQUFHO0FBQ3BCLGVBQU8sbUJBQW1CLG9CQUFvQixLQUFLLEdBQUcsSUFBSTtBQUFBLE1BQzlEO0FBQ0EsVUFBSSxPQUFPLFFBQVEsVUFBVTtBQUN6QixZQUFJLFlBQVksT0FBTyxHQUFHLElBQUk7QUFDOUIsZUFBTyxtQkFBbUIsb0JBQW9CLEtBQUssU0FBUyxJQUFJO0FBQUEsTUFDcEU7QUFFQSxVQUFJLFdBQVcsT0FBTyxLQUFLLFVBQVUsY0FBYyxJQUFJLEtBQUs7QUFDNUQsVUFBSSxPQUFPLFVBQVUsYUFBYTtBQUFFLGdCQUFRO0FBQUEsTUFBRztBQUMvQyxVQUFJLFNBQVMsWUFBWSxXQUFXLEtBQUssT0FBTyxRQUFRLFVBQVU7QUFDOUQsZUFBTyxRQUFRLEdBQUcsSUFBSSxZQUFZO0FBQUEsTUFDdEM7QUFFQSxVQUFJLFNBQVMsVUFBVSxNQUFNLEtBQUs7QUFFbEMsVUFBSSxPQUFPLFNBQVMsYUFBYTtBQUM3QixlQUFPLENBQUM7QUFBQSxNQUNaLFdBQVcsUUFBUSxNQUFNLEdBQUcsS0FBSyxHQUFHO0FBQ2hDLGVBQU87QUFBQSxNQUNYO0FBRUEsZUFBUyxRQUFRLE9BQU8sTUFBTSxVQUFVO0FBQ3BDLFlBQUksTUFBTTtBQUNOLGlCQUFPLFVBQVUsS0FBSyxJQUFJO0FBQzFCLGVBQUssS0FBSyxJQUFJO0FBQUEsUUFDbEI7QUFDQSxZQUFJLFVBQVU7QUFDVixjQUFJLFVBQVU7QUFBQSxZQUNWLE9BQU8sS0FBSztBQUFBLFVBQ2hCO0FBQ0EsY0FBSSxJQUFJLE1BQU0sWUFBWSxHQUFHO0FBQ3pCLG9CQUFRLGFBQWEsS0FBSztBQUFBLFVBQzlCO0FBQ0EsaUJBQU8sU0FBUyxPQUFPLFNBQVMsUUFBUSxHQUFHLElBQUk7QUFBQSxRQUNuRDtBQUNBLGVBQU8sU0FBUyxPQUFPLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFBQSxNQUNoRDtBQUVBLFVBQUksT0FBTyxRQUFRLGNBQWMsQ0FBQyxTQUFTLEdBQUcsR0FBRztBQUM3QyxZQUFJLE9BQU8sT0FBTyxHQUFHO0FBQ3JCLFlBQUksT0FBTyxXQUFXLEtBQUssT0FBTztBQUNsQyxlQUFPLGVBQWUsT0FBTyxPQUFPLE9BQU8sa0JBQWtCLE9BQU8sS0FBSyxTQUFTLElBQUksUUFBUSxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksT0FBTztBQUFBLE1BQ2xJO0FBQ0EsVUFBSSxTQUFTLEdBQUcsR0FBRztBQUNmLFlBQUksWUFBWSxvQkFBb0IsU0FBUyxLQUFLLE9BQU8sR0FBRyxHQUFHLDBCQUEwQixJQUFJLElBQUksWUFBWSxLQUFLLEdBQUc7QUFDckgsZUFBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLG9CQUFvQixVQUFVLFNBQVMsSUFBSTtBQUFBLE1BQ2xGO0FBQ0EsVUFBSSxVQUFVLEdBQUcsR0FBRztBQUNoQixZQUFJLElBQUksTUFBTSxhQUFhLEtBQUssT0FBTyxJQUFJLFFBQVEsQ0FBQztBQUNwRCxZQUFJLFFBQVEsSUFBSSxjQUFjLENBQUM7QUFDL0IsaUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDbkMsZUFBSyxNQUFNLE1BQU0sQ0FBQyxFQUFFLE9BQU8sTUFBTSxXQUFXLE1BQU0sTUFBTSxDQUFDLEVBQUUsS0FBSyxHQUFHLFVBQVUsSUFBSTtBQUFBLFFBQ3JGO0FBQ0EsYUFBSztBQUNMLFlBQUksSUFBSSxjQUFjLElBQUksV0FBVyxRQUFRO0FBQUUsZUFBSztBQUFBLFFBQU87QUFDM0QsYUFBSyxPQUFPLGFBQWEsS0FBSyxPQUFPLElBQUksUUFBUSxDQUFDLElBQUk7QUFDdEQsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJLFFBQVEsR0FBRyxHQUFHO0FBQ2QsWUFBSSxJQUFJLFdBQVcsR0FBRztBQUFFLGlCQUFPO0FBQUEsUUFBTTtBQUNyQyxZQUFJLEtBQUssV0FBVyxLQUFLLE9BQU87QUFDaEMsWUFBSSxVQUFVLENBQUMsaUJBQWlCLEVBQUUsR0FBRztBQUNqQyxpQkFBTyxNQUFNLGFBQWEsSUFBSSxNQUFNLElBQUk7QUFBQSxRQUM1QztBQUNBLGVBQU8sT0FBTyxNQUFNLEtBQUssSUFBSSxJQUFJLElBQUk7QUFBQSxNQUN6QztBQUNBLFVBQUksUUFBUSxHQUFHLEdBQUc7QUFDZCxZQUFJLFFBQVEsV0FBVyxLQUFLLE9BQU87QUFDbkMsWUFBSSxFQUFFLFdBQVcsTUFBTSxjQUFjLFdBQVcsT0FBTyxDQUFDLGFBQWEsS0FBSyxLQUFLLE9BQU8sR0FBRztBQUNyRixpQkFBTyxRQUFRLE9BQU8sR0FBRyxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsS0FBSyxjQUFjLFFBQVEsSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLElBQUksSUFBSTtBQUFBLFFBQ2xIO0FBQ0EsWUFBSSxNQUFNLFdBQVcsR0FBRztBQUFFLGlCQUFPLE1BQU0sT0FBTyxHQUFHLElBQUk7QUFBQSxRQUFLO0FBQzFELGVBQU8sUUFBUSxPQUFPLEdBQUcsSUFBSSxPQUFPLE1BQU0sS0FBSyxPQUFPLElBQUksSUFBSTtBQUFBLE1BQ2xFO0FBQ0EsVUFBSSxPQUFPLFFBQVEsWUFBWSxlQUFlO0FBQzFDLFlBQUksaUJBQWlCLE9BQU8sSUFBSSxhQUFhLE1BQU0sY0FBYyxhQUFhO0FBQzFFLGlCQUFPLFlBQVksS0FBSyxFQUFFLE9BQU8sV0FBVyxNQUFNLENBQUM7QUFBQSxRQUN2RCxXQUFXLGtCQUFrQixZQUFZLE9BQU8sSUFBSSxZQUFZLFlBQVk7QUFDeEUsaUJBQU8sSUFBSSxRQUFRO0FBQUEsUUFDdkI7QUFBQSxNQUNKO0FBQ0EsVUFBSSxNQUFNLEdBQUcsR0FBRztBQUNaLFlBQUksV0FBVyxDQUFDO0FBQ2hCLFlBQUksWUFBWTtBQUNaLHFCQUFXLEtBQUssS0FBSyxTQUFVLE9BQU8sS0FBSztBQUN2QyxxQkFBUyxLQUFLLFFBQVEsS0FBSyxLQUFLLElBQUksSUFBSSxTQUFTLFFBQVEsT0FBTyxHQUFHLENBQUM7QUFBQSxVQUN4RSxDQUFDO0FBQUEsUUFDTDtBQUNBLGVBQU8sYUFBYSxPQUFPLFFBQVEsS0FBSyxHQUFHLEdBQUcsVUFBVSxNQUFNO0FBQUEsTUFDbEU7QUFDQSxVQUFJLE1BQU0sR0FBRyxHQUFHO0FBQ1osWUFBSSxXQUFXLENBQUM7QUFDaEIsWUFBSSxZQUFZO0FBQ1oscUJBQVcsS0FBSyxLQUFLLFNBQVUsT0FBTztBQUNsQyxxQkFBUyxLQUFLLFFBQVEsT0FBTyxHQUFHLENBQUM7QUFBQSxVQUNyQyxDQUFDO0FBQUEsUUFDTDtBQUNBLGVBQU8sYUFBYSxPQUFPLFFBQVEsS0FBSyxHQUFHLEdBQUcsVUFBVSxNQUFNO0FBQUEsTUFDbEU7QUFDQSxVQUFJLFVBQVUsR0FBRyxHQUFHO0FBQ2hCLGVBQU8saUJBQWlCLFNBQVM7QUFBQSxNQUNyQztBQUNBLFVBQUksVUFBVSxHQUFHLEdBQUc7QUFDaEIsZUFBTyxpQkFBaUIsU0FBUztBQUFBLE1BQ3JDO0FBQ0EsVUFBSSxVQUFVLEdBQUcsR0FBRztBQUNoQixlQUFPLGlCQUFpQixTQUFTO0FBQUEsTUFDckM7QUFDQSxVQUFJLFNBQVMsR0FBRyxHQUFHO0FBQ2YsZUFBTyxVQUFVLFFBQVEsT0FBTyxHQUFHLENBQUMsQ0FBQztBQUFBLE1BQ3pDO0FBQ0EsVUFBSSxTQUFTLEdBQUcsR0FBRztBQUNmLGVBQU8sVUFBVSxRQUFRLGNBQWMsS0FBSyxHQUFHLENBQUMsQ0FBQztBQUFBLE1BQ3JEO0FBQ0EsVUFBSSxVQUFVLEdBQUcsR0FBRztBQUNoQixlQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUcsQ0FBQztBQUFBLE1BQzdDO0FBQ0EsVUFBSSxTQUFTLEdBQUcsR0FBRztBQUNmLGVBQU8sVUFBVSxRQUFRLE9BQU8sR0FBRyxDQUFDLENBQUM7QUFBQSxNQUN6QztBQUdBLFVBQUksT0FBTyxXQUFXLGVBQWUsUUFBUSxRQUFRO0FBQ2pELGVBQU87QUFBQSxNQUNYO0FBQ0EsVUFDSyxPQUFPLGVBQWUsZUFBZSxRQUFRLGNBQzFDLE9BQU8sV0FBVyxlQUFlLFFBQVEsUUFDL0M7QUFDRSxlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLFNBQVMsR0FBRyxHQUFHO0FBQ2hDLFlBQUksS0FBSyxXQUFXLEtBQUssT0FBTztBQUNoQyxZQUFJLGdCQUFnQixNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sWUFBWSxlQUFlLFVBQVUsSUFBSSxnQkFBZ0I7QUFDdkcsWUFBSSxXQUFXLGVBQWUsU0FBUyxLQUFLO0FBQzVDLFlBQUksWUFBWSxDQUFDLGlCQUFpQixlQUFlLE9BQU8sR0FBRyxNQUFNLE9BQU8sZUFBZSxNQUFNLE9BQU8sS0FBSyxNQUFNLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxXQUFXLFdBQVc7QUFDcEosWUFBSSxpQkFBaUIsaUJBQWlCLE9BQU8sSUFBSSxnQkFBZ0IsYUFBYSxLQUFLLElBQUksWUFBWSxPQUFPLElBQUksWUFBWSxPQUFPLE1BQU07QUFDdkksWUFBSSxNQUFNLGtCQUFrQixhQUFhLFdBQVcsTUFBTSxNQUFNLEtBQUssUUFBUSxLQUFLLENBQUMsR0FBRyxhQUFhLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksSUFBSSxPQUFPO0FBQ3ZJLFlBQUksR0FBRyxXQUFXLEdBQUc7QUFBRSxpQkFBTyxNQUFNO0FBQUEsUUFBTTtBQUMxQyxZQUFJLFFBQVE7QUFDUixpQkFBTyxNQUFNLE1BQU0sYUFBYSxJQUFJLE1BQU0sSUFBSTtBQUFBLFFBQ2xEO0FBQ0EsZUFBTyxNQUFNLE9BQU8sTUFBTSxLQUFLLElBQUksSUFBSSxJQUFJO0FBQUEsTUFDL0M7QUFDQSxhQUFPLE9BQU8sR0FBRztBQUFBLElBQ3JCO0FBRUEsYUFBUyxXQUFXLEdBQUcsY0FBYyxNQUFNO0FBQ3ZDLFVBQUksYUFBYSxLQUFLLGNBQWMsa0JBQWtCLFdBQVcsTUFBTTtBQUN2RSxhQUFPLFlBQVksSUFBSTtBQUFBLElBQzNCO0FBRUEsYUFBUyxNQUFNLEdBQUc7QUFDZCxhQUFPLFNBQVMsS0FBSyxPQUFPLENBQUMsR0FBRyxNQUFNLFFBQVE7QUFBQSxJQUNsRDtBQUVBLGFBQVMsUUFBUSxLQUFLO0FBQUUsYUFBTyxNQUFNLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxlQUFlLEVBQUUsT0FBTyxRQUFRLFlBQVksZUFBZTtBQUFBLElBQU87QUFDdEksYUFBUyxPQUFPLEtBQUs7QUFBRSxhQUFPLE1BQU0sR0FBRyxNQUFNLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxPQUFPLFFBQVEsWUFBWSxlQUFlO0FBQUEsSUFBTztBQUNwSSxhQUFTLFNBQVMsS0FBSztBQUFFLGFBQU8sTUFBTSxHQUFHLE1BQU0sc0JBQXNCLENBQUMsZUFBZSxFQUFFLE9BQU8sUUFBUSxZQUFZLGVBQWU7QUFBQSxJQUFPO0FBQ3hJLGFBQVMsUUFBUSxLQUFLO0FBQUUsYUFBTyxNQUFNLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxlQUFlLEVBQUUsT0FBTyxRQUFRLFlBQVksZUFBZTtBQUFBLElBQU87QUFDdEksYUFBUyxTQUFTLEtBQUs7QUFBRSxhQUFPLE1BQU0sR0FBRyxNQUFNLHNCQUFzQixDQUFDLGVBQWUsRUFBRSxPQUFPLFFBQVEsWUFBWSxlQUFlO0FBQUEsSUFBTztBQUN4SSxhQUFTLFNBQVMsS0FBSztBQUFFLGFBQU8sTUFBTSxHQUFHLE1BQU0sc0JBQXNCLENBQUMsZUFBZSxFQUFFLE9BQU8sUUFBUSxZQUFZLGVBQWU7QUFBQSxJQUFPO0FBQ3hJLGFBQVMsVUFBVSxLQUFLO0FBQUUsYUFBTyxNQUFNLEdBQUcsTUFBTSx1QkFBdUIsQ0FBQyxlQUFlLEVBQUUsT0FBTyxRQUFRLFlBQVksZUFBZTtBQUFBLElBQU87QUFHMUksYUFBUyxTQUFTLEtBQUs7QUFDbkIsVUFBSSxtQkFBbUI7QUFDbkIsZUFBTyxPQUFPLE9BQU8sUUFBUSxZQUFZLGVBQWU7QUFBQSxNQUM1RDtBQUNBLFVBQUksT0FBTyxRQUFRLFVBQVU7QUFDekIsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLGFBQWE7QUFDakQsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJO0FBQ0Esb0JBQVksS0FBSyxHQUFHO0FBQ3BCLGVBQU87QUFBQSxNQUNYLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFDYixhQUFPO0FBQUEsSUFDWDtBQUVBLGFBQVMsU0FBUyxLQUFLO0FBQ25CLFVBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxZQUFZLENBQUMsZUFBZTtBQUNuRCxlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUk7QUFDQSxzQkFBYyxLQUFLLEdBQUc7QUFDdEIsZUFBTztBQUFBLE1BQ1gsU0FBUyxHQUFHO0FBQUEsTUFBQztBQUNiLGFBQU87QUFBQSxJQUNYO0FBRUEsUUFBSSxTQUFTLE9BQU8sVUFBVSxrQkFBa0IsU0FBVSxLQUFLO0FBQUUsYUFBTyxPQUFPO0FBQUEsSUFBTTtBQUNyRixhQUFTLElBQUksS0FBSyxLQUFLO0FBQ25CLGFBQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUFBLElBQy9CO0FBRUEsYUFBUyxNQUFNLEtBQUs7QUFDaEIsYUFBTyxlQUFlLEtBQUssR0FBRztBQUFBLElBQ2xDO0FBRUEsYUFBUyxPQUFPLEdBQUc7QUFDZixVQUFJLEVBQUUsTUFBTTtBQUFFLGVBQU8sRUFBRTtBQUFBLE1BQU07QUFDN0IsVUFBSSxJQUFJLE9BQU8sS0FBSyxpQkFBaUIsS0FBSyxDQUFDLEdBQUcsc0JBQXNCO0FBQ3BFLFVBQUksR0FBRztBQUFFLGVBQU8sRUFBRSxDQUFDO0FBQUEsTUFBRztBQUN0QixhQUFPO0FBQUEsSUFDWDtBQUVBLGFBQVMsUUFBUSxJQUFJLEdBQUc7QUFDcEIsVUFBSSxHQUFHLFNBQVM7QUFBRSxlQUFPLEdBQUcsUUFBUSxDQUFDO0FBQUEsTUFBRztBQUN4QyxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsUUFBUSxJQUFJLEdBQUcsS0FBSztBQUN2QyxZQUFJLEdBQUcsQ0FBQyxNQUFNLEdBQUc7QUFBRSxpQkFBTztBQUFBLFFBQUc7QUFBQSxNQUNqQztBQUNBLGFBQU87QUFBQSxJQUNYO0FBRUEsYUFBUyxNQUFNLEdBQUc7QUFDZCxVQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssT0FBTyxNQUFNLFVBQVU7QUFDekMsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJO0FBQ0EsZ0JBQVEsS0FBSyxDQUFDO0FBQ2QsWUFBSTtBQUNBLGtCQUFRLEtBQUssQ0FBQztBQUFBLFFBQ2xCLFNBQVMsR0FBRztBQUNSLGlCQUFPO0FBQUEsUUFDWDtBQUNBLGVBQU8sYUFBYTtBQUFBLE1BQ3hCLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFDYixhQUFPO0FBQUEsSUFDWDtBQUVBLGFBQVMsVUFBVSxHQUFHO0FBQ2xCLFVBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVTtBQUM1QyxlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUk7QUFDQSxtQkFBVyxLQUFLLEdBQUcsVUFBVTtBQUM3QixZQUFJO0FBQ0EscUJBQVcsS0FBSyxHQUFHLFVBQVU7QUFBQSxRQUNqQyxTQUFTLEdBQUc7QUFDUixpQkFBTztBQUFBLFFBQ1g7QUFDQSxlQUFPLGFBQWE7QUFBQSxNQUN4QixTQUFTLEdBQUc7QUFBQSxNQUFDO0FBQ2IsYUFBTztBQUFBLElBQ1g7QUFFQSxhQUFTLFVBQVUsR0FBRztBQUNsQixVQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVTtBQUM5QyxlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUk7QUFDQSxxQkFBYSxLQUFLLENBQUM7QUFDbkIsZUFBTztBQUFBLE1BQ1gsU0FBUyxHQUFHO0FBQUEsTUFBQztBQUNiLGFBQU87QUFBQSxJQUNYO0FBRUEsYUFBUyxNQUFNLEdBQUc7QUFDZCxVQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssT0FBTyxNQUFNLFVBQVU7QUFDekMsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJO0FBQ0EsZ0JBQVEsS0FBSyxDQUFDO0FBQ2QsWUFBSTtBQUNBLGtCQUFRLEtBQUssQ0FBQztBQUFBLFFBQ2xCLFNBQVMsR0FBRztBQUNSLGlCQUFPO0FBQUEsUUFDWDtBQUNBLGVBQU8sYUFBYTtBQUFBLE1BQ3hCLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFDYixhQUFPO0FBQUEsSUFDWDtBQUVBLGFBQVMsVUFBVSxHQUFHO0FBQ2xCLFVBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVTtBQUM1QyxlQUFPO0FBQUEsTUFDWDtBQUNBLFVBQUk7QUFDQSxtQkFBVyxLQUFLLEdBQUcsVUFBVTtBQUM3QixZQUFJO0FBQ0EscUJBQVcsS0FBSyxHQUFHLFVBQVU7QUFBQSxRQUNqQyxTQUFTLEdBQUc7QUFDUixpQkFBTztBQUFBLFFBQ1g7QUFDQSxlQUFPLGFBQWE7QUFBQSxNQUN4QixTQUFTLEdBQUc7QUFBQSxNQUFDO0FBQ2IsYUFBTztBQUFBLElBQ1g7QUFFQSxhQUFTLFVBQVUsR0FBRztBQUNsQixVQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBQ2pELFVBQUksT0FBTyxnQkFBZ0IsZUFBZSxhQUFhLGFBQWE7QUFDaEUsZUFBTztBQUFBLE1BQ1g7QUFDQSxhQUFPLE9BQU8sRUFBRSxhQUFhLFlBQVksT0FBTyxFQUFFLGlCQUFpQjtBQUFBLElBQ3ZFO0FBRUEsYUFBUyxjQUFjLEtBQUssTUFBTTtBQUM5QixVQUFJLElBQUksU0FBUyxLQUFLLGlCQUFpQjtBQUNuQyxZQUFJLFlBQVksSUFBSSxTQUFTLEtBQUs7QUFDbEMsWUFBSSxVQUFVLFNBQVMsWUFBWSxxQkFBcUIsWUFBWSxJQUFJLE1BQU07QUFDOUUsZUFBTyxjQUFjLE9BQU8sS0FBSyxLQUFLLEdBQUcsS0FBSyxlQUFlLEdBQUcsSUFBSSxJQUFJO0FBQUEsTUFDNUU7QUFFQSxVQUFJLElBQUksU0FBUyxLQUFLLFNBQVMsS0FBSyxLQUFLLFlBQVksTUFBTSxHQUFHLGdCQUFnQixPQUFPO0FBQ3JGLGFBQU8sV0FBVyxHQUFHLFVBQVUsSUFBSTtBQUFBLElBQ3ZDO0FBRUEsYUFBUyxRQUFRLEdBQUc7QUFDaEIsVUFBSSxJQUFJLEVBQUUsV0FBVyxDQUFDO0FBQ3RCLFVBQUksSUFBSTtBQUFBLFFBQ0osR0FBRztBQUFBLFFBQ0gsR0FBRztBQUFBLFFBQ0gsSUFBSTtBQUFBLFFBQ0osSUFBSTtBQUFBLFFBQ0osSUFBSTtBQUFBLE1BQ1IsRUFBRSxDQUFDO0FBQ0gsVUFBSSxHQUFHO0FBQUUsZUFBTyxPQUFPO0FBQUEsTUFBRztBQUMxQixhQUFPLFNBQVMsSUFBSSxLQUFPLE1BQU0sTUFBTSxhQUFhLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQztBQUFBLElBQzNFO0FBRUEsYUFBUyxVQUFVLEtBQUs7QUFDcEIsYUFBTyxZQUFZLE1BQU07QUFBQSxJQUM3QjtBQUVBLGFBQVMsaUJBQWlCLE1BQU07QUFDNUIsYUFBTyxPQUFPO0FBQUEsSUFDbEI7QUFFQSxhQUFTLGFBQWEsTUFBTSxNQUFNLFNBQVMsUUFBUTtBQUMvQyxVQUFJLGdCQUFnQixTQUFTLGFBQWEsU0FBUyxNQUFNLElBQUksTUFBTSxLQUFLLFNBQVMsSUFBSTtBQUNyRixhQUFPLE9BQU8sT0FBTyxPQUFPLFFBQVEsZ0JBQWdCO0FBQUEsSUFDeEQ7QUFFQSxhQUFTLGlCQUFpQixJQUFJO0FBQzFCLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLEtBQUs7QUFDaEMsWUFBSSxRQUFRLEdBQUcsQ0FBQyxHQUFHLElBQUksS0FBSyxHQUFHO0FBQzNCLGlCQUFPO0FBQUEsUUFDWDtBQUFBLE1BQ0o7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUVBLGFBQVMsVUFBVSxNQUFNLE9BQU87QUFDNUIsVUFBSTtBQUNKLFVBQUksS0FBSyxXQUFXLEtBQU07QUFDdEIscUJBQWE7QUFBQSxNQUNqQixXQUFXLE9BQU8sS0FBSyxXQUFXLFlBQVksS0FBSyxTQUFTLEdBQUc7QUFDM0QscUJBQWEsTUFBTSxLQUFLLE1BQU0sS0FBSyxTQUFTLENBQUMsR0FBRyxHQUFHO0FBQUEsTUFDdkQsT0FBTztBQUNILGVBQU87QUFBQSxNQUNYO0FBQ0EsYUFBTztBQUFBLFFBQ0gsTUFBTTtBQUFBLFFBQ04sTUFBTSxNQUFNLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRyxVQUFVO0FBQUEsTUFDakQ7QUFBQSxJQUNKO0FBRUEsYUFBUyxhQUFhLElBQUksUUFBUTtBQUM5QixVQUFJLEdBQUcsV0FBVyxHQUFHO0FBQUUsZUFBTztBQUFBLE1BQUk7QUFDbEMsVUFBSSxhQUFhLE9BQU8sT0FBTyxPQUFPLE9BQU87QUFDN0MsYUFBTyxhQUFhLE1BQU0sS0FBSyxJQUFJLE1BQU0sVUFBVSxJQUFJLE9BQU8sT0FBTztBQUFBLElBQ3pFO0FBRUEsYUFBUyxXQUFXLEtBQUssU0FBUztBQUM5QixVQUFJLFFBQVEsUUFBUSxHQUFHO0FBQ3ZCLFVBQUksS0FBSyxDQUFDO0FBQ1YsVUFBSSxPQUFPO0FBQ1AsV0FBRyxTQUFTLElBQUk7QUFDaEIsaUJBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7QUFDakMsYUFBRyxDQUFDLElBQUksSUFBSSxLQUFLLENBQUMsSUFBSSxRQUFRLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSTtBQUFBLFFBQ2pEO0FBQUEsTUFDSjtBQUNBLFVBQUksT0FBTyxPQUFPLFNBQVMsYUFBYSxLQUFLLEdBQUcsSUFBSSxDQUFDO0FBQ3JELFVBQUk7QUFDSixVQUFJLG1CQUFtQjtBQUNuQixpQkFBUyxDQUFDO0FBQ1YsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7QUFDbEMsaUJBQU8sTUFBTSxLQUFLLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQztBQUFBLFFBQ2xDO0FBQUEsTUFDSjtBQUVBLGVBQVMsT0FBTyxLQUFLO0FBQ2pCLFlBQUksQ0FBQyxJQUFJLEtBQUssR0FBRyxHQUFHO0FBQUU7QUFBQSxRQUFVO0FBQ2hDLFlBQUksU0FBUyxPQUFPLE9BQU8sR0FBRyxDQUFDLE1BQU0sT0FBTyxNQUFNLElBQUksUUFBUTtBQUFFO0FBQUEsUUFBVTtBQUMxRSxZQUFJLHFCQUFxQixPQUFPLE1BQU0sR0FBRyxhQUFhLFFBQVE7QUFFMUQ7QUFBQSxRQUNKLFdBQVcsTUFBTSxLQUFLLFVBQVUsR0FBRyxHQUFHO0FBQ2xDLGFBQUcsS0FBSyxRQUFRLEtBQUssR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFBQSxRQUM3RCxPQUFPO0FBQ0gsYUFBRyxLQUFLLE1BQU0sT0FBTyxRQUFRLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUFBLFFBQy9DO0FBQUEsTUFDSjtBQUNBLFVBQUksT0FBTyxTQUFTLFlBQVk7QUFDNUIsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7QUFDbEMsY0FBSSxhQUFhLEtBQUssS0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFHO0FBQ2pDLGVBQUcsS0FBSyxNQUFNLFFBQVEsS0FBSyxDQUFDLENBQUMsSUFBSSxRQUFRLFFBQVEsSUFBSSxLQUFLLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUFBLFVBQ3ZFO0FBQUEsUUFDSjtBQUFBLE1BQ0o7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBO0FBQUE7OztBQzlnQkE7QUFBQSx1Q0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxlQUFlO0FBQ25CLFFBQUksWUFBWTtBQUNoQixRQUFJLFVBQVU7QUFFZCxRQUFJLGFBQWE7QUFDakIsUUFBSSxXQUFXLGFBQWEsYUFBYSxJQUFJO0FBQzdDLFFBQUksT0FBTyxhQUFhLFNBQVMsSUFBSTtBQUVyQyxRQUFJLGNBQWMsVUFBVSx5QkFBeUIsSUFBSTtBQUN6RCxRQUFJLGNBQWMsVUFBVSx5QkFBeUIsSUFBSTtBQUN6RCxRQUFJLGNBQWMsVUFBVSx5QkFBeUIsSUFBSTtBQUN6RCxRQUFJLFVBQVUsVUFBVSxxQkFBcUIsSUFBSTtBQUNqRCxRQUFJLFVBQVUsVUFBVSxxQkFBcUIsSUFBSTtBQUNqRCxRQUFJLFVBQVUsVUFBVSxxQkFBcUIsSUFBSTtBQVFqRCxRQUFJLGNBQWMsU0FBVSxNQUFNLEtBQUs7QUFFdEMsVUFBSSxPQUFPO0FBRVgsVUFBSTtBQUNKLGNBQVEsT0FBTyxLQUFLLFVBQVUsTUFBTSxPQUFPLE1BQU07QUFDaEQsWUFBSSxLQUFLLFFBQVEsS0FBSztBQUNyQixlQUFLLE9BQU8sS0FBSztBQUVqQixlQUFLO0FBQUEsVUFBcUQsS0FBSztBQUMvRCxlQUFLLE9BQU87QUFDWixpQkFBTztBQUFBLFFBQ1I7QUFBQSxNQUNEO0FBQUEsSUFDRDtBQUdBLFFBQUksVUFBVSxTQUFVLFNBQVMsS0FBSztBQUNyQyxVQUFJLE9BQU8sWUFBWSxTQUFTLEdBQUc7QUFDbkMsYUFBTyxRQUFRLEtBQUs7QUFBQSxJQUNyQjtBQUVBLFFBQUksVUFBVSxTQUFVLFNBQVMsS0FBSyxPQUFPO0FBQzVDLFVBQUksT0FBTyxZQUFZLFNBQVMsR0FBRztBQUNuQyxVQUFJLE1BQU07QUFDVCxhQUFLLFFBQVE7QUFBQSxNQUNkLE9BQU87QUFFTixnQkFBUTtBQUFBLFFBQTBEO0FBQUE7QUFBQSxVQUNqRTtBQUFBLFVBQ0EsTUFBTSxRQUFRO0FBQUEsVUFDZDtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBQUEsSUFDRDtBQUVBLFFBQUksVUFBVSxTQUFVLFNBQVMsS0FBSztBQUNyQyxhQUFPLENBQUMsQ0FBQyxZQUFZLFNBQVMsR0FBRztBQUFBLElBQ2xDO0FBR0EsSUFBQUEsUUFBTyxVQUFVLFNBQVMsaUJBQWlCO0FBQ0YsVUFBSTtBQUNSLFVBQUk7QUFDSyxVQUFJO0FBR2pELFVBQUksVUFBVTtBQUFBLFFBQ2IsUUFBUSxTQUFVLEtBQUs7QUFDdEIsY0FBSSxDQUFDLFFBQVEsSUFBSSxHQUFHLEdBQUc7QUFDdEIsa0JBQU0sSUFBSSxXQUFXLG1DQUFtQyxRQUFRLEdBQUcsQ0FBQztBQUFBLFVBQ3JFO0FBQUEsUUFDRDtBQUFBLFFBQ0EsS0FBSyxTQUFVLEtBQUs7QUFDbkIsY0FBSSxZQUFZLFFBQVEsT0FBTyxRQUFRLFlBQVksT0FBTyxRQUFRLGFBQWE7QUFDOUUsZ0JBQUksS0FBSztBQUNSLHFCQUFPLFlBQVksS0FBSyxHQUFHO0FBQUEsWUFDNUI7QUFBQSxVQUNELFdBQVcsTUFBTTtBQUNoQixnQkFBSSxJQUFJO0FBQ1AscUJBQU8sUUFBUSxJQUFJLEdBQUc7QUFBQSxZQUN2QjtBQUFBLFVBQ0QsT0FBTztBQUNOLGdCQUFJLElBQUk7QUFDUCxxQkFBTyxRQUFRLElBQUksR0FBRztBQUFBLFlBQ3ZCO0FBQUEsVUFDRDtBQUFBLFFBQ0Q7QUFBQSxRQUNBLEtBQUssU0FBVSxLQUFLO0FBQ25CLGNBQUksWUFBWSxRQUFRLE9BQU8sUUFBUSxZQUFZLE9BQU8sUUFBUSxhQUFhO0FBQzlFLGdCQUFJLEtBQUs7QUFDUixxQkFBTyxZQUFZLEtBQUssR0FBRztBQUFBLFlBQzVCO0FBQUEsVUFDRCxXQUFXLE1BQU07QUFDaEIsZ0JBQUksSUFBSTtBQUNQLHFCQUFPLFFBQVEsSUFBSSxHQUFHO0FBQUEsWUFDdkI7QUFBQSxVQUNELE9BQU87QUFDTixnQkFBSSxJQUFJO0FBQ1AscUJBQU8sUUFBUSxJQUFJLEdBQUc7QUFBQSxZQUN2QjtBQUFBLFVBQ0Q7QUFDQSxpQkFBTztBQUFBLFFBQ1I7QUFBQSxRQUNBLEtBQUssU0FBVSxLQUFLLE9BQU87QUFDMUIsY0FBSSxZQUFZLFFBQVEsT0FBTyxRQUFRLFlBQVksT0FBTyxRQUFRLGFBQWE7QUFDOUUsZ0JBQUksQ0FBQyxLQUFLO0FBQ1Qsb0JBQU0sSUFBSSxTQUFTO0FBQUEsWUFDcEI7QUFDQSx3QkFBWSxLQUFLLEtBQUssS0FBSztBQUFBLFVBQzVCLFdBQVcsTUFBTTtBQUNoQixnQkFBSSxDQUFDLElBQUk7QUFDUixtQkFBSyxJQUFJLEtBQUs7QUFBQSxZQUNmO0FBQ0Esb0JBQVEsSUFBSSxLQUFLLEtBQUs7QUFBQSxVQUN2QixPQUFPO0FBQ04sZ0JBQUksQ0FBQyxJQUFJO0FBRVIsbUJBQUssRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLEtBQUs7QUFBQSxZQUM1QjtBQUNBLG9CQUFRLElBQUksS0FBSyxLQUFLO0FBQUEsVUFDdkI7QUFBQSxRQUNEO0FBQUEsTUFDRDtBQUNBLGFBQU87QUFBQSxJQUNSO0FBQUE7QUFBQTs7O0FDaElBLElBQUFDLDBCQUFBO0FBQUEsNkNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksY0FBYyxTQUFVLE9BQU87QUFDbEMsYUFBTyxVQUFVO0FBQUEsSUFDbEI7QUFFQSxJQUFBQSxRQUFPLFVBQVUsU0FBUyxHQUFHLEdBQUcsR0FBRztBQUNsQyxVQUFJLE1BQU0sS0FBSyxNQUFNLEdBQUc7QUFDdkIsZUFBTyxJQUFJLE1BQU0sSUFBSTtBQUFBLE1BQ3RCO0FBQ0EsVUFBSSxNQUFNLEdBQUc7QUFDWixlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUksWUFBWSxDQUFDLEtBQUssWUFBWSxDQUFDLEdBQUc7QUFDckMsZUFBTztBQUFBLE1BQ1I7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQ2pCQSxJQUFBQyxvQkFBQTtBQUFBLHVDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLGlCQUFpQjtBQUVyQixJQUFBQSxRQUFPLFVBQVUsU0FBUyxjQUFjO0FBQ3ZDLGFBQU8sT0FBTyxPQUFPLE9BQU8sYUFBYSxPQUFPLEtBQUs7QUFBQSxJQUN0RDtBQUFBO0FBQUE7OztBQ05BLElBQUFDLGdCQUFBO0FBQUEsbUNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksY0FBYztBQUNsQixRQUFJLFNBQVM7QUFFYixJQUFBQSxRQUFPLFVBQVUsU0FBUyxlQUFlO0FBQ3hDLFVBQUksV0FBVyxZQUFZO0FBQzNCLGFBQU8sUUFBUSxFQUFFLElBQUksU0FBUyxHQUFHO0FBQUEsUUFDaEMsSUFBSSxTQUFTLGVBQWU7QUFDM0IsaUJBQU8sT0FBTyxPQUFPO0FBQUEsUUFDdEI7QUFBQSxNQUNELENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQ2JBO0FBQUEsb0NBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksU0FBUztBQUNiLFFBQUksV0FBVztBQUVmLFFBQUksaUJBQWlCO0FBQ3JCLFFBQUksY0FBYztBQUNsQixRQUFJLE9BQU87QUFFWCxRQUFJLFdBQVcsU0FBUyxZQUFZLEdBQUcsTUFBTTtBQUU3QyxXQUFPLFVBQVU7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRCxDQUFDO0FBRUQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDakJqQixJQUFBQyxpQkFBQTtBQUFBLDBDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLGFBQWE7QUFHakIsSUFBQUEsUUFBTyxVQUFVLFNBQVMsc0JBQXNCO0FBQy9DLGFBQU8sV0FBVyxLQUFLLENBQUMsQ0FBQyxPQUFPO0FBQUEsSUFDakM7QUFBQTtBQUFBOzs7QUNQQTtBQUFBLHVDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLGlCQUFpQixpQkFBaUM7QUFDdEQsUUFBSSxZQUFZO0FBRWhCLFFBQUksWUFBWSxVQUFVLDJCQUEyQjtBQUVyRCxRQUFJLHNCQUFzQixTQUFTLFlBQVksT0FBTztBQUNyRCxVQUFJLGtCQUFrQixTQUFTLE9BQU8sVUFBVSxZQUFZLE9BQU8sZUFBZSxPQUFPO0FBQ3hGLGVBQU87QUFBQSxNQUNSO0FBQ0EsYUFBTyxVQUFVLEtBQUssTUFBTTtBQUFBLElBQzdCO0FBRUEsUUFBSSxvQkFBb0IsU0FBUyxZQUFZLE9BQU87QUFDbkQsVUFBSSxvQkFBb0IsS0FBSyxHQUFHO0FBQy9CLGVBQU87QUFBQSxNQUNSO0FBQ0EsYUFBTyxVQUFVLFFBQ2hCLE9BQU8sVUFBVSxZQUNqQixPQUFPLE1BQU0sV0FBVyxZQUN4QixNQUFNLFVBQVUsS0FDaEIsVUFBVSxLQUFLLE1BQU0sb0JBQ3JCLFVBQVUsTUFBTSxNQUFNLE1BQU07QUFBQSxJQUM5QjtBQUVBLFFBQUksNEJBQTZCLFdBQVk7QUFDNUMsYUFBTyxvQkFBb0IsU0FBUztBQUFBLElBQ3JDLEVBQUU7QUFFRix3QkFBb0Isb0JBQW9CO0FBRXhDLElBQUFBLFFBQU8sVUFBVSw0QkFBNEIsc0JBQXNCO0FBQUE7QUFBQTs7O0FDaENuRTtBQUFBLGtDQUFBQyxVQUFBQyxTQUFBO0FBQUEsUUFBSSxXQUFXLENBQUMsRUFBRTtBQUVsQixJQUFBQSxRQUFPLFVBQVUsTUFBTSxXQUFXLFNBQVUsS0FBSztBQUMvQyxhQUFPLFNBQVMsS0FBSyxHQUFHLEtBQUs7QUFBQSxJQUMvQjtBQUFBO0FBQUE7OztBQ0pBO0FBQUEsMENBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksV0FBVztBQUNmLFFBQUksWUFBWTtBQUNoQixRQUFJLGVBQWU7QUFFbkIsUUFBSSxlQUFlLGFBQWEsaUJBQWlCLElBQUk7QUFFckQsUUFBSSxjQUFjLFVBQVUsb0NBQW9DLElBQUk7QUFDcEUsUUFBSSxZQUFZLFVBQVUsMkJBQTJCO0FBR3JELFFBQUksVUFBVSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxJQUFJLGFBQWEsQ0FBQyxFQUFFO0FBQ3BFLFFBQUksV0FBVyxDQUFDLENBQUMsV0FBVyxTQUFTLE9BQU87QUFHNUMsSUFBQUEsUUFBTyxVQUFVLGVBQWUsV0FDN0IsU0FBUyxjQUFjLEtBQUs7QUFDN0IsVUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFVBQVU7QUFDcEMsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJO0FBQ0gsWUFBSSxhQUFhO0FBRWhCLHNCQUFZLEdBQUc7QUFBQSxRQUNoQixPQUFPO0FBRU4sbUJBQVMsS0FBSyxDQUFDO0FBQUEsUUFDaEI7QUFDQSxlQUFPO0FBQUEsTUFDUixTQUFTLEdBQUc7QUFDWCxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0QsSUFDRSxlQUVDLFNBQVMsY0FBYyxLQUFLO0FBQzdCLGFBQU8sVUFBVSxHQUFHLE1BQU07QUFBQSxJQUMzQixJQUNFLFNBQVMsY0FBYyxLQUFLO0FBQzdCLGFBQU87QUFBQSxJQUNSO0FBQUE7QUFBQTs7O0FDekNGO0FBQUEseUNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksU0FBUyxLQUFLLFVBQVU7QUFDNUIsUUFBSSxnQkFBZ0IsU0FBUyxrQkFBa0IsT0FBTztBQUNyRCxVQUFJO0FBQ0gsZUFBTyxLQUFLLEtBQUs7QUFDakIsZUFBTztBQUFBLE1BQ1IsU0FBUyxHQUFHO0FBQ1gsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNEO0FBRUEsUUFBSSxRQUFRLE9BQU8sVUFBVTtBQUM3QixRQUFJLFlBQVk7QUFDaEIsUUFBSSxpQkFBaUIsaUJBQWlDO0FBRXRELElBQUFBLFFBQU8sVUFBVSxTQUFTLGFBQWEsT0FBTztBQUM3QyxVQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsTUFBTTtBQUNoRCxlQUFPO0FBQUEsTUFDUjtBQUNBLGFBQU8saUJBQWlCLGNBQWMsS0FBSyxJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU07QUFBQSxJQUN0RTtBQUFBO0FBQUE7OztBQ3JCQTtBQUFBLG1DQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFlBQVk7QUFDaEIsUUFBSSxpQkFBaUIsaUJBQWlDO0FBQ3RELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUNKLFFBQUk7QUFFSixRQUFJLGdCQUFnQjtBQUNuQixZQUFNLFVBQVUsaUNBQWlDO0FBQ2pELGNBQVEsVUFBVSx1QkFBdUI7QUFDekMsc0JBQWdCLENBQUM7QUFFYix5QkFBbUIsV0FBWTtBQUNsQyxjQUFNO0FBQUEsTUFDUDtBQUNBLHVCQUFpQjtBQUFBLFFBQ2hCLFVBQVU7QUFBQSxRQUNWLFNBQVM7QUFBQSxNQUNWO0FBRUEsVUFBSSxPQUFPLE9BQU8sZ0JBQWdCLFVBQVU7QUFDM0MsdUJBQWUsT0FBTyxXQUFXLElBQUk7QUFBQSxNQUN0QztBQUFBLElBQ0Q7QUFYSztBQWFMLFFBQUksWUFBWSxVQUFVLDJCQUEyQjtBQUNyRCxRQUFJLE9BQU8sT0FBTztBQUNsQixRQUFJLGFBQWE7QUFFakIsSUFBQUEsUUFBTyxVQUFVLGlCQUVkLFNBQVMsUUFBUSxPQUFPO0FBQ3pCLFVBQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxVQUFVO0FBQ3hDLGVBQU87QUFBQSxNQUNSO0FBRUEsVUFBSSxhQUFhLEtBQUssT0FBTyxXQUFXO0FBQ3hDLFVBQUksMkJBQTJCLGNBQWMsSUFBSSxZQUFZLE9BQU87QUFDcEUsVUFBSSxDQUFDLDBCQUEwQjtBQUM5QixlQUFPO0FBQUEsTUFDUjtBQUVBLFVBQUk7QUFDSCxjQUFNLE9BQU8sY0FBYztBQUFBLE1BQzVCLFNBQVMsR0FBRztBQUNYLGVBQU8sTUFBTTtBQUFBLE1BQ2Q7QUFBQSxJQUNELElBQ0UsU0FBUyxRQUFRLE9BQU87QUFFekIsVUFBSSxDQUFDLFNBQVUsT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFlBQWE7QUFDekUsZUFBTztBQUFBLE1BQ1I7QUFFQSxhQUFPLFVBQVUsS0FBSyxNQUFNO0FBQUEsSUFDN0I7QUFBQTtBQUFBOzs7QUN6REQ7QUFBQSxpREFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxZQUFZO0FBRWhCLFFBQUksY0FBYyxVQUFVLDBDQUEwQyxJQUFJO0FBRzFFLElBQUFBLFFBQU8sVUFBVSxjQUNkLFNBQVMsb0JBQW9CLEtBQUs7QUFDbkMsVUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFVBQVU7QUFDcEMsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJO0FBQ0gsb0JBQVksR0FBRztBQUNmLGVBQU87QUFBQSxNQUNSLFNBQVMsR0FBRztBQUNYLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRCxJQUNFLFNBQVMsb0JBQW9CLEtBQUs7QUFDbkMsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUNyQkQ7QUFBQSxvQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxXQUFXLE9BQU8sVUFBVTtBQUNoQyxRQUFJLGtCQUFrQixTQUFTQyxpQkFBZ0IsT0FBTztBQUNyRCxVQUFJO0FBQ0gsaUJBQVMsS0FBSyxLQUFLO0FBQ25CLGVBQU87QUFBQSxNQUNSLFNBQVMsR0FBRztBQUNYLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQUNBLFFBQUksUUFBUSxPQUFPLFVBQVU7QUFDN0IsUUFBSSxXQUFXO0FBQ2YsUUFBSSxpQkFBaUIsaUJBQWlDO0FBRXRELElBQUFELFFBQU8sVUFBVSxTQUFTLFNBQVMsT0FBTztBQUN6QyxVQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzlCLGVBQU87QUFBQSxNQUNSO0FBQ0EsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixlQUFPO0FBQUEsTUFDUjtBQUNBLGFBQU8saUJBQWlCLGdCQUFnQixLQUFLLElBQUksTUFBTSxLQUFLLEtBQUssTUFBTTtBQUFBLElBQ3hFO0FBQUE7QUFBQTs7O0FDdkJBO0FBQUEsMkNBQUFFLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksV0FBVyxPQUFPLFVBQVU7QUFDaEMsUUFBSSxrQkFBa0IsU0FBU0MsaUJBQWdCLE9BQU87QUFDckQsVUFBSTtBQUNILGlCQUFTLEtBQUssS0FBSztBQUNuQixlQUFPO0FBQUEsTUFDUixTQUFTLEdBQUc7QUFDWCxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFDQSxRQUFJLFFBQVEsT0FBTyxVQUFVO0FBQzdCLFFBQUksV0FBVztBQUNmLFFBQUksaUJBQWlCLGlCQUFpQztBQUV0RCxJQUFBRCxRQUFPLFVBQVUsU0FBUyxlQUFlLE9BQU87QUFDL0MsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsZUFBTztBQUFBLE1BQ1I7QUFDQSxhQUFPLGlCQUFpQixnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU07QUFBQSxJQUN4RTtBQUFBO0FBQUE7OztBQ3ZCQTtBQUFBLDRDQUFBRSxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFlBQVk7QUFDaEIsUUFBSSxhQUFhLFVBQVUsNEJBQTRCO0FBQ3ZELFFBQUksWUFBWSxVQUFVLDJCQUEyQjtBQUVyRCxRQUFJLG1CQUFtQixTQUFTLGtCQUFrQixPQUFPO0FBQ3hELFVBQUk7QUFDSCxtQkFBVyxLQUFLO0FBQ2hCLGVBQU87QUFBQSxNQUNSLFNBQVMsR0FBRztBQUNYLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQUNBLFFBQUksWUFBWTtBQUNoQixRQUFJLGlCQUFpQixpQkFBaUM7QUFFdEQsSUFBQUEsUUFBTyxVQUFVLFNBQVMsVUFBVSxPQUFPO0FBQzFDLFVBQUksT0FBTyxVQUFVLFdBQVc7QUFDL0IsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJLFVBQVUsUUFBUSxPQUFPLFVBQVUsVUFBVTtBQUNoRCxlQUFPO0FBQUEsTUFDUjtBQUNBLGFBQU8sa0JBQWtCLE9BQU8sZUFBZSxRQUFRLGlCQUFpQixLQUFLLElBQUksVUFBVSxLQUFLLE1BQU07QUFBQSxJQUN2RztBQUFBO0FBQUE7OztBQ3pCQTtBQUFBLG9DQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFFBQVEsT0FBTyxVQUFVO0FBQzdCLFFBQUksYUFBYSxzQkFBdUI7QUFFeEMsUUFBSSxZQUFZO0FBQ1gsaUJBQVcsT0FBTyxVQUFVO0FBQzVCLHVCQUFpQjtBQUNqQix1QkFBaUIsU0FBUyxtQkFBbUIsT0FBTztBQUN2RCxZQUFJLE9BQU8sTUFBTSxRQUFRLE1BQU0sVUFBVTtBQUN4QyxpQkFBTztBQUFBLFFBQ1I7QUFDQSxlQUFPLGVBQWUsS0FBSyxTQUFTLEtBQUssS0FBSyxDQUFDO0FBQUEsTUFDaEQ7QUFFQSxNQUFBQSxRQUFPLFVBQVUsU0FBUyxTQUFTLE9BQU87QUFDekMsWUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixpQkFBTztBQUFBLFFBQ1I7QUFDQSxZQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU0sbUJBQW1CO0FBQzVDLGlCQUFPO0FBQUEsUUFDUjtBQUNBLFlBQUk7QUFDSCxpQkFBTyxlQUFlLEtBQUs7QUFBQSxRQUM1QixTQUFTLEdBQUc7QUFDWCxpQkFBTztBQUFBLFFBQ1I7QUFBQSxNQUNEO0FBQUEsSUFDRCxPQUFPO0FBRU4sTUFBQUEsUUFBTyxVQUFVLFNBQVMsU0FBUyxPQUFPO0FBRXpDLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQTVCSztBQUNBO0FBQ0E7QUFBQTtBQUFBOzs7QUNSTDtBQUFBLHNDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFVBQVUsT0FBTyxXQUFXLGVBQWU7QUFFL0MsSUFBQUEsUUFBTyxVQUFVLFNBQVMsbUJBQW1CO0FBQzVDLGFBQU8sT0FBTyxZQUFZLGNBQ3RCLE9BQU8sV0FBVyxjQUNsQixPQUFPLFFBQVEsRUFBRSxNQUFNLFlBQ3ZCLE9BQU8sT0FBTyxFQUFFLE1BQU07QUFBQSxJQUMzQjtBQUFBO0FBQUE7OztBQ1RBO0FBQUEsb0NBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksYUFBYSxzQkFBdUI7QUFFeEMsUUFBSSxZQUFZO0FBQ1gsc0JBQWdCLE9BQU8sVUFBVTtBQUNqQyxrQkFBWSxTQUFTLGdCQUFnQixPQUFPO0FBQy9DLFlBQUk7QUFDSCx3QkFBYyxLQUFLLEtBQUs7QUFDeEIsaUJBQU87QUFBQSxRQUNSLFNBQVMsR0FBRztBQUFBLFFBQ1o7QUFDQSxlQUFPO0FBQUEsTUFDUjtBQUVBLE1BQUFBLFFBQU8sVUFBVSxTQUFTLFNBQVMsT0FBTztBQUN6QyxZQUNDLFVBQVUsUUFDUCxPQUFPLFVBQVUsZUFDakIsT0FBTyxVQUFVLGFBQ2pCLE9BQU8sVUFBVSxZQUNqQixPQUFPLFVBQVUsWUFDakIsT0FBTyxVQUFVLFlBQ2pCLE9BQU8sVUFBVSxZQUNuQjtBQUNELGlCQUFPO0FBQUEsUUFDUjtBQUNBLFlBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsaUJBQU87QUFBQSxRQUNSO0FBRUEsZUFBTyxVQUFVLEtBQUs7QUFBQSxNQUN2QjtBQUFBLElBQ0QsT0FBTztBQUNOLE1BQUFBLFFBQU8sVUFBVSxTQUFTLFNBQVMsT0FBTztBQUN6QyxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFoQ0s7QUFDQTtBQUFBO0FBQUE7OztBQ05MO0FBQUEsZ0RBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksV0FBVztBQUNmLFFBQUksV0FBVztBQUNmLFFBQUksWUFBWTtBQUNoQixRQUFJLFdBQVc7QUFDZixRQUFJLFdBQVc7QUFHZixJQUFBQSxRQUFPLFVBQVUsU0FBUyxvQkFBb0IsT0FBTztBQUVwRCxVQUFJLFNBQVMsUUFBUyxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsWUFBYTtBQUNoRixlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUksU0FBUyxLQUFLLEdBQUc7QUFDcEIsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJLFNBQVMsS0FBSyxHQUFHO0FBQ3BCLGVBQU87QUFBQSxNQUNSO0FBQ0EsVUFBSSxVQUFVLEtBQUssR0FBRztBQUNyQixlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUksU0FBUyxLQUFLLEdBQUc7QUFDcEIsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJLFNBQVMsS0FBSyxHQUFHO0FBQ3BCLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQUFBO0FBQUE7OztBQzdCQTtBQUFBLGlDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFHQSxRQUFJLE9BQU8sT0FBTyxRQUFRLGNBQWMsSUFBSSxZQUFZLE1BQU07QUFDOUQsUUFBSSxPQUFPLE9BQU8sUUFBUSxjQUFjLElBQUksWUFBWSxNQUFNO0FBRTlELFFBQUk7QUFFSixRQUFJLENBQUMsTUFBTTtBQUdWLGlCQUFXLFNBQVMsTUFBTSxHQUFHO0FBRTVCLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQUVBLFFBQUksVUFBVSxPQUFPLElBQUksVUFBVSxNQUFNO0FBQ3pDLFFBQUksVUFBVSxPQUFPLElBQUksVUFBVSxNQUFNO0FBQ3pDLFFBQUksQ0FBQyxZQUFZLENBQUMsU0FBUztBQUcxQixpQkFBVyxTQUFTLE1BQU0sR0FBRztBQUU1QixlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFHQSxJQUFBQSxRQUFPLFVBQVUsWUFBWSxTQUFTLE1BQU0sR0FBRztBQUM5QyxVQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVTtBQUNoQyxlQUFPO0FBQUEsTUFDUjtBQUNBLFVBQUk7QUFDSCxnQkFBUSxLQUFLLENBQUM7QUFDZCxZQUFJLFNBQVM7QUFDWixjQUFJO0FBQ0gsb0JBQVEsS0FBSyxDQUFDO0FBQUEsVUFDZixTQUFTLEdBQUc7QUFDWCxtQkFBTztBQUFBLFVBQ1I7QUFBQSxRQUNEO0FBRUEsZUFBTyxhQUFhO0FBQUEsTUFDckIsU0FBUyxHQUFHO0FBQUEsTUFBQztBQUNiLGFBQU87QUFBQSxJQUNSO0FBQUE7QUFBQTs7O0FDOUNBO0FBQUEsaUNBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksT0FBTyxPQUFPLFFBQVEsY0FBYyxJQUFJLFlBQVksTUFBTTtBQUM5RCxRQUFJLE9BQU8sT0FBTyxRQUFRLGNBQWMsSUFBSSxZQUFZLE1BQU07QUFFOUQsUUFBSTtBQUVKLFFBQUksQ0FBQyxNQUFNO0FBR1YsaUJBQVcsU0FBUyxNQUFNLEdBQUc7QUFFNUIsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNEO0FBRUEsUUFBSSxVQUFVLE9BQU8sSUFBSSxVQUFVLE1BQU07QUFDekMsUUFBSSxVQUFVLE9BQU8sSUFBSSxVQUFVLE1BQU07QUFDekMsUUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTO0FBRzFCLGlCQUFXLFNBQVMsTUFBTSxHQUFHO0FBRTVCLGVBQU87QUFBQSxNQUNSO0FBQUEsSUFDRDtBQUdBLElBQUFBLFFBQU8sVUFBVSxZQUFZLFNBQVMsTUFBTSxHQUFHO0FBQzlDLFVBQUksQ0FBQyxLQUFLLE9BQU8sTUFBTSxVQUFVO0FBQ2hDLGVBQU87QUFBQSxNQUNSO0FBQ0EsVUFBSTtBQUNILGdCQUFRLEtBQUssQ0FBQztBQUNkLFlBQUksU0FBUztBQUNaLGNBQUk7QUFDSCxvQkFBUSxLQUFLLENBQUM7QUFBQSxVQUNmLFNBQVMsR0FBRztBQUNYLG1CQUFPO0FBQUEsVUFDUjtBQUFBLFFBQ0Q7QUFFQSxlQUFPLGFBQWE7QUFBQSxNQUNyQixTQUFTLEdBQUc7QUFBQSxNQUFDO0FBQ2IsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUM3Q0E7QUFBQSxxQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxXQUFXLE9BQU8sWUFBWSxjQUFjLFFBQVEsWUFBWSxVQUFVO0FBQzlFLFFBQUksV0FBVyxPQUFPLFlBQVksY0FBYyxRQUFRLFlBQVksVUFBVTtBQUU5RSxRQUFJO0FBRUosUUFBSSxDQUFDLFVBQVU7QUFHZCxpQkFBVyxTQUFTLFVBQVUsR0FBRztBQUVoQyxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFFQSxRQUFJLFVBQVUsV0FBVyxTQUFTLFVBQVUsTUFBTTtBQUNsRCxRQUFJLFVBQVUsV0FBVyxTQUFTLFVBQVUsTUFBTTtBQUNsRCxRQUFJLENBQUMsWUFBWSxDQUFDLFNBQVM7QUFHMUIsaUJBQVcsU0FBUyxVQUFVLEdBQUc7QUFFaEMsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNEO0FBR0EsSUFBQUEsUUFBTyxVQUFVLFlBQVksU0FBUyxVQUFVLEdBQUc7QUFDbEQsVUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFVBQVU7QUFDaEMsZUFBTztBQUFBLE1BQ1I7QUFDQSxVQUFJO0FBQ0gsZ0JBQVEsS0FBSyxHQUFHLE9BQU87QUFDdkIsWUFBSSxTQUFTO0FBQ1osY0FBSTtBQUNILG9CQUFRLEtBQUssR0FBRyxPQUFPO0FBQUEsVUFDeEIsU0FBUyxHQUFHO0FBQ1gsbUJBQU87QUFBQSxVQUNSO0FBQUEsUUFDRDtBQUVBLGVBQU8sYUFBYTtBQUFBLE1BQ3JCLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFDYixhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQzdDQTtBQUFBLHFDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLGVBQWU7QUFDbkIsUUFBSSxZQUFZO0FBRWhCLFFBQUksV0FBVyxhQUFhLGFBQWEsSUFBSTtBQUU3QyxRQUFJLFVBQVUsVUFBVSx5QkFBeUIsSUFBSTtBQUVyRCxRQUFJLFNBQVM7QUFDUixnQkFBVSxVQUFVLHlCQUF5QixJQUFJO0FBR3JELE1BQUFBLFFBQU8sVUFBVSxTQUFTLFVBQVUsR0FBRztBQUN0QyxZQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVTtBQUNoQyxpQkFBTztBQUFBLFFBQ1I7QUFDQSxZQUFJO0FBQ0gsa0JBQVEsR0FBRyxPQUFPO0FBQ2xCLGNBQUksU0FBUztBQUNaLGdCQUFJO0FBQ0gsc0JBQVEsR0FBRyxPQUFPO0FBQUEsWUFDbkIsU0FBUyxHQUFHO0FBQ1gscUJBQU87QUFBQSxZQUNSO0FBQUEsVUFDRDtBQUVBLGlCQUFPLGFBQWE7QUFBQSxRQUNyQixTQUFTLEdBQUc7QUFBQSxRQUFDO0FBQ2IsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNELE9BQU87QUFHTixNQUFBQSxRQUFPLFVBQVUsU0FBUyxVQUFVLEdBQUc7QUFFdEMsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNEO0FBNUJLO0FBQUE7QUFBQTs7O0FDVkw7QUFBQSwyQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxRQUFRO0FBQ1osUUFBSSxRQUFRO0FBQ1osUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWTtBQUdoQixJQUFBQSxRQUFPLFVBQVUsU0FBUyxnQkFBdUMsT0FBTztBQUN2RSxVQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7QUFDdkMsWUFBSSxNQUFNLEtBQUssR0FBRztBQUNqQixpQkFBTztBQUFBLFFBQ1I7QUFDQSxZQUFJLE1BQU0sS0FBSyxHQUFHO0FBQ2pCLGlCQUFPO0FBQUEsUUFDUjtBQUNBLFlBQUksVUFBVSxLQUFLLEdBQUc7QUFDckIsaUJBQU87QUFBQSxRQUNSO0FBQ0EsWUFBSSxVQUFVLEtBQUssR0FBRztBQUNyQixpQkFBTztBQUFBLFFBQ1I7QUFBQSxNQUNEO0FBQ0EsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBOzs7QUN4QkE7QUFBQSxzQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxVQUFVLFNBQVMsVUFBVTtBQUNqQyxRQUFJLGVBQWUsT0FBTyxZQUFZLFlBQVksWUFBWSxRQUFRLFFBQVE7QUFDOUUsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLGNBQWMsT0FBTyxPQUFPLG1CQUFtQixZQUFZO0FBQ3RGLFVBQUk7QUFDSCx1QkFBZSxPQUFPLGVBQWUsQ0FBQyxHQUFHLFVBQVU7QUFBQSxVQUNsRCxLQUFLLFdBQVk7QUFDaEIsa0JBQU07QUFBQSxVQUNQO0FBQUEsUUFDRCxDQUFDO0FBQ0QsMkJBQW1CLENBQUM7QUFFcEIscUJBQWEsV0FBWTtBQUFFLGdCQUFNO0FBQUEsUUFBSSxHQUFHLE1BQU0sWUFBWTtBQUFBLE1BQzNELFNBQVMsR0FBRztBQUNYLFlBQUksTUFBTSxrQkFBa0I7QUFDM0IseUJBQWU7QUFBQSxRQUNoQjtBQUFBLE1BQ0Q7QUFBQSxJQUNELE9BQU87QUFDTixxQkFBZTtBQUFBLElBQ2hCO0FBRUEsUUFBSSxtQkFBbUI7QUFDdkIsUUFBSSxlQUFlLFNBQVMsbUJBQW1CLE9BQU87QUFDckQsVUFBSTtBQUNILFlBQUksUUFBUSxRQUFRLEtBQUssS0FBSztBQUM5QixlQUFPLGlCQUFpQixLQUFLLEtBQUs7QUFBQSxNQUNuQyxTQUFTLEdBQUc7QUFDWCxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFFQSxRQUFJLG9CQUFvQixTQUFTLGlCQUFpQixPQUFPO0FBQ3hELFVBQUk7QUFDSCxZQUFJLGFBQWEsS0FBSyxHQUFHO0FBQUUsaUJBQU87QUFBQSxRQUFPO0FBQ3pDLGdCQUFRLEtBQUssS0FBSztBQUNsQixlQUFPO0FBQUEsTUFDUixTQUFTLEdBQUc7QUFDWCxlQUFPO0FBQUEsTUFDUjtBQUFBLElBQ0Q7QUFDQSxRQUFJLFFBQVEsT0FBTyxVQUFVO0FBQzdCLFFBQUksY0FBYztBQUNsQixRQUFJLFVBQVU7QUFDZCxRQUFJLFdBQVc7QUFDZixRQUFJLFdBQVc7QUFDZixRQUFJLFlBQVk7QUFDaEIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksaUJBQWlCLE9BQU8sV0FBVyxjQUFjLENBQUMsQ0FBQyxPQUFPO0FBRTlELFFBQUksU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBRXRCLFFBQUksUUFBUSxTQUFTLG1CQUFtQjtBQUFFLGFBQU87QUFBQSxJQUFPO0FBQ3hELFFBQUksT0FBTyxhQUFhLFVBQVU7QUFFN0IsWUFBTSxTQUFTO0FBQ25CLFVBQUksTUFBTSxLQUFLLEdBQUcsTUFBTSxNQUFNLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFDakQsZ0JBQVEsU0FBUyxpQkFBaUIsT0FBTztBQUd4QyxlQUFLLFVBQVUsQ0FBQyxXQUFXLE9BQU8sVUFBVSxlQUFlLE9BQU8sVUFBVSxXQUFXO0FBQ3RGLGdCQUFJO0FBQ0gsa0JBQUksTUFBTSxNQUFNLEtBQUssS0FBSztBQUMxQixzQkFDQyxRQUFRLFlBQ0wsUUFBUSxhQUNSLFFBQVEsYUFDUixRQUFRLGdCQUNQLE1BQU0sRUFBRSxLQUFLO0FBQUEsWUFDbkIsU0FBUyxHQUFHO0FBQUEsWUFBTztBQUFBLFVBQ3BCO0FBQ0EsaUJBQU87QUFBQSxRQUNSO0FBQUEsTUFDRDtBQUFBLElBQ0Q7QUFuQks7QUFxQkwsSUFBQUEsUUFBTyxVQUFVLGVBQ2QsU0FBUyxXQUFXLE9BQU87QUFDNUIsVUFBSSxNQUFNLEtBQUssR0FBRztBQUFFLGVBQU87QUFBQSxNQUFNO0FBQ2pDLFVBQUksQ0FBQyxPQUFPO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDNUIsVUFBSSxPQUFPLFVBQVUsY0FBYyxPQUFPLFVBQVUsVUFBVTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBQzlFLFVBQUk7QUFDSCxxQkFBYSxPQUFPLE1BQU0sWUFBWTtBQUFBLE1BQ3ZDLFNBQVMsR0FBRztBQUNYLFlBQUksTUFBTSxrQkFBa0I7QUFBRSxpQkFBTztBQUFBLFFBQU87QUFBQSxNQUM3QztBQUNBLGFBQU8sQ0FBQyxhQUFhLEtBQUssS0FBSyxrQkFBa0IsS0FBSztBQUFBLElBQ3ZELElBQ0UsU0FBUyxXQUFXLE9BQU87QUFDNUIsVUFBSSxNQUFNLEtBQUssR0FBRztBQUFFLGVBQU87QUFBQSxNQUFNO0FBQ2pDLFVBQUksQ0FBQyxPQUFPO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDNUIsVUFBSSxPQUFPLFVBQVUsY0FBYyxPQUFPLFVBQVUsVUFBVTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBQzlFLFVBQUksZ0JBQWdCO0FBQUUsZUFBTyxrQkFBa0IsS0FBSztBQUFBLE1BQUc7QUFDdkQsVUFBSSxhQUFhLEtBQUssR0FBRztBQUFFLGVBQU87QUFBQSxNQUFPO0FBQ3pDLFVBQUksV0FBVyxNQUFNLEtBQUssS0FBSztBQUMvQixVQUFJLGFBQWEsV0FBVyxhQUFhLFlBQVksQ0FBRSxpQkFBa0IsS0FBSyxRQUFRLEdBQUc7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUN6RyxhQUFPLGtCQUFrQixLQUFLO0FBQUEsSUFDL0I7QUFBQTtBQUFBOzs7QUNwR0Q7QUFBQSxtQ0FBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxhQUFhO0FBRWpCLFFBQUksUUFBUSxPQUFPLFVBQVU7QUFDN0IsUUFBSSxpQkFBaUIsT0FBTyxVQUFVO0FBRXRDLFFBQUksZUFBZSxTQUFTQyxjQUFhLE9BQU8sVUFBVSxVQUFVO0FBQ2hFLGVBQVMsSUFBSSxHQUFHLE1BQU0sTUFBTSxRQUFRLElBQUksS0FBSyxLQUFLO0FBQzlDLFlBQUksZUFBZSxLQUFLLE9BQU8sQ0FBQyxHQUFHO0FBQy9CLGNBQUksWUFBWSxNQUFNO0FBQ2xCLHFCQUFTLE1BQU0sQ0FBQyxHQUFHLEdBQUcsS0FBSztBQUFBLFVBQy9CLE9BQU87QUFDSCxxQkFBUyxLQUFLLFVBQVUsTUFBTSxDQUFDLEdBQUcsR0FBRyxLQUFLO0FBQUEsVUFDOUM7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxRQUFJLGdCQUFnQixTQUFTQyxlQUFjLFFBQVEsVUFBVSxVQUFVO0FBQ25FLGVBQVMsSUFBSSxHQUFHLE1BQU0sT0FBTyxRQUFRLElBQUksS0FBSyxLQUFLO0FBRS9DLFlBQUksWUFBWSxNQUFNO0FBQ2xCLG1CQUFTLE9BQU8sT0FBTyxDQUFDLEdBQUcsR0FBRyxNQUFNO0FBQUEsUUFDeEMsT0FBTztBQUNILG1CQUFTLEtBQUssVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLEdBQUcsTUFBTTtBQUFBLFFBQ3ZEO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxRQUFJLGdCQUFnQixTQUFTQyxlQUFjLFFBQVEsVUFBVSxVQUFVO0FBQ25FLGVBQVMsS0FBSyxRQUFRO0FBQ2xCLFlBQUksZUFBZSxLQUFLLFFBQVEsQ0FBQyxHQUFHO0FBQ2hDLGNBQUksWUFBWSxNQUFNO0FBQ2xCLHFCQUFTLE9BQU8sQ0FBQyxHQUFHLEdBQUcsTUFBTTtBQUFBLFVBQ2pDLE9BQU87QUFDSCxxQkFBUyxLQUFLLFVBQVUsT0FBTyxDQUFDLEdBQUcsR0FBRyxNQUFNO0FBQUEsVUFDaEQ7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxRQUFJLFVBQVUsU0FBU0MsU0FBUSxNQUFNLFVBQVUsU0FBUztBQUNwRCxVQUFJLENBQUMsV0FBVyxRQUFRLEdBQUc7QUFDdkIsY0FBTSxJQUFJLFVBQVUsNkJBQTZCO0FBQUEsTUFDckQ7QUFFQSxVQUFJO0FBQ0osVUFBSSxVQUFVLFVBQVUsR0FBRztBQUN2QixtQkFBVztBQUFBLE1BQ2Y7QUFFQSxVQUFJLE1BQU0sS0FBSyxJQUFJLE1BQU0sa0JBQWtCO0FBQ3ZDLHFCQUFhLE1BQU0sVUFBVSxRQUFRO0FBQUEsTUFDekMsV0FBVyxPQUFPLFNBQVMsVUFBVTtBQUNqQyxzQkFBYyxNQUFNLFVBQVUsUUFBUTtBQUFBLE1BQzFDLE9BQU87QUFDSCxzQkFBYyxNQUFNLFVBQVUsUUFBUTtBQUFBLE1BQzFDO0FBQUEsSUFDSjtBQUVBLElBQUFKLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQzdEakI7QUFBQSxxREFBQUssVUFBQUMsU0FBQTtBQUFBO0FBR0EsSUFBQUEsUUFBTyxVQUFVO0FBQUEsTUFDaEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRDtBQUFBO0FBQUE7OztBQ2ZBO0FBQUEsaURBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksZ0JBQWdCO0FBRXBCLFFBQUksSUFBSSxPQUFPLGVBQWUsY0FBYyxTQUFTO0FBR3JELElBQUFBLFFBQU8sVUFBVSxTQUFTLHVCQUF1QjtBQUNoRCxVQUEyRCxNQUFNLENBQUM7QUFDbEUsZUFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLFFBQVEsS0FBSztBQUM5QyxZQUFJLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQyxNQUFNLFlBQVk7QUFFOUMsY0FBSSxJQUFJLE1BQU0sSUFBSSxjQUFjLENBQUM7QUFBQSxRQUNsQztBQUFBLE1BQ0Q7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUFBO0FBQUE7OztBQ2hCQTtBQUFBLDRDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFVBQVU7QUFDZCxRQUFJLHVCQUF1QjtBQUMzQixRQUFJLFdBQVc7QUFDZixRQUFJLFlBQVk7QUFDaEIsUUFBSSxPQUFPO0FBR1gsUUFBSSxZQUFZLFVBQVUsMkJBQTJCO0FBQ3JELFFBQUksaUJBQWlCLGlCQUFpQztBQUV0RCxRQUFJLElBQUksT0FBTyxlQUFlLGNBQWMsU0FBUztBQUNyRCxRQUFJLGNBQWMscUJBQXFCO0FBRXZDLFFBQUksU0FBUyxVQUFVLHdCQUF3QjtBQUMvQyxRQUFJLGlCQUFpQixPQUFPO0FBRzVCLFFBQUksV0FBVyxVQUFVLDJCQUEyQixJQUFJLEtBQUssU0FBUyxRQUFRLE9BQU8sT0FBTztBQUMzRixlQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDekMsWUFBSSxNQUFNLENBQUMsTUFBTSxPQUFPO0FBQ3ZCLGlCQUFPO0FBQUEsUUFDUjtBQUFBLE1BQ0Q7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUlBLFFBQUksUUFBUSxFQUFFLFdBQVcsS0FBSztBQUM5QixRQUFJLGtCQUFrQixRQUFRLGdCQUFnQjtBQUM3QyxjQUFRLGFBQWEsU0FBVSxZQUFZO0FBQzFDLFlBQUksTUFBTSxJQUFJLEVBQUUsVUFBVSxFQUFFO0FBQzVCLFlBQUksT0FBTyxlQUFlLEtBQUs7QUFDOUIsY0FBSSxRQUFRLGVBQWUsR0FBRztBQUU5QixjQUFJLGFBQWEsS0FBSyxPQUFPLE9BQU8sV0FBVztBQUMvQyxjQUFJLENBQUMsWUFBWTtBQUNoQixnQkFBSSxhQUFhLGVBQWUsS0FBSztBQUVyQyx5QkFBYSxLQUFLLFlBQVksT0FBTyxXQUFXO0FBQUEsVUFDakQ7QUFFQSxnQkFBTSxNQUFNLFVBQVUsSUFBSSxTQUFTLFdBQVcsR0FBRztBQUFBLFFBQ2xEO0FBQUEsTUFDRCxDQUFDO0FBQUEsSUFDRixPQUFPO0FBQ04sY0FBUSxhQUFhLFNBQVUsWUFBWTtBQUMxQyxZQUFJLE1BQU0sSUFBSSxFQUFFLFVBQVUsRUFBRTtBQUM1QixZQUFJLEtBQUssSUFBSSxTQUFTLElBQUk7QUFDMUIsWUFBSSxJQUFJO0FBRVAsZ0JBQU0sTUFBTSxVQUFVLElBQUksU0FBUyxFQUFFO0FBQUEsUUFDdEM7QUFBQSxNQUNELENBQUM7QUFBQSxJQUNGO0FBR0EsUUFBSSxpQkFBaUIsU0FBUyxrQkFBa0IsT0FBTztBQUNGLFVBQUksUUFBUTtBQUNoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRTBFO0FBQUE7QUFBQSxRQUV6RSxTQUFVLFFBQVEsWUFBWTtBQUM3QixjQUFJLENBQUMsT0FBTztBQUNYLGdCQUFJO0FBRUgsa0JBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxZQUFZO0FBQ3ZDLHdCQUFRLE9BQU8sWUFBWSxDQUFDO0FBQUEsY0FDN0I7QUFBQSxZQUNELFNBQVMsR0FBRztBQUFBLFlBQU87QUFBQSxVQUNwQjtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBQ0EsYUFBTztBQUFBLElBQ1I7QUFHQSxRQUFJLFlBQVksU0FBUyxhQUFhLE9BQU87QUFDRyxVQUFJLFFBQVE7QUFDM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUUwRTtBQUFBO0FBQUEsUUFDYyxTQUFVLFFBQVEsTUFBTTtBQUM5RyxjQUFJLENBQUMsT0FBTztBQUNYLGdCQUFJO0FBRUgscUJBQU8sS0FBSztBQUNaLHNCQUFRLE9BQU8sTUFBTSxDQUFDO0FBQUEsWUFDdkIsU0FBUyxHQUFHO0FBQUEsWUFBTztBQUFBLFVBQ3BCO0FBQUEsUUFDRDtBQUFBLE1BQ0Q7QUFDQSxhQUFPO0FBQUEsSUFDUjtBQUdBLElBQUFBLFFBQU8sVUFBVSxTQUFTLGdCQUFnQixPQUFPO0FBQ2hELFVBQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxVQUFVO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDekQsVUFBSSxDQUFDLGdCQUFnQjtBQUVwQixZQUFJLE1BQU0sT0FBTyxVQUFVLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFDeEMsWUFBSSxTQUFTLGFBQWEsR0FBRyxJQUFJLElBQUk7QUFDcEMsaUJBQU87QUFBQSxRQUNSO0FBQ0EsWUFBSSxRQUFRLFVBQVU7QUFDckIsaUJBQU87QUFBQSxRQUNSO0FBRUEsZUFBTyxVQUFVLEtBQUs7QUFBQSxNQUN2QjtBQUNBLFVBQUksQ0FBQyxNQUFNO0FBQUUsZUFBTztBQUFBLE1BQU07QUFDMUIsYUFBTyxlQUFlLEtBQUs7QUFBQSxJQUM1QjtBQUFBO0FBQUE7OztBQ25IQTtBQUFBLG1EQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLFVBQVUsb0NBQW9DLElBQUk7QUFFcEUsUUFBSSxnQkFBZ0I7QUFHcEIsSUFBQUEsUUFBTyxVQUFVLFNBQVMsV0FBVyxJQUFJO0FBQ3hDLFVBQUksQ0FBQyxjQUFjLEVBQUUsR0FBRztBQUN2QixlQUFPO0FBQUEsTUFDUjtBQUNBLGFBQU8sY0FBYyxZQUFZLEVBQUUsSUFBSSxHQUFHO0FBQUEsSUFDM0M7QUFBQTtBQUFBOzs7QUNiQTtBQUFBLHFDQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFJLFNBQVM7QUFDYixRQUFJLFlBQVk7QUFDaEIsUUFBSSxRQUFRO0FBQ1osUUFBSSxlQUFlO0FBQ25CLFFBQUksY0FBYztBQUNsQixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLEtBQUs7QUFDVCxRQUFJLGNBQWM7QUFDbEIsUUFBSSxVQUFVO0FBQ2QsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxTQUFTO0FBQ2IsUUFBSSxVQUFVO0FBQ2QsUUFBSSxzQkFBc0I7QUFDMUIsUUFBSSxhQUFhO0FBQ2pCLFFBQUksc0JBQXNCO0FBQzFCLFFBQUksa0JBQWtCO0FBQ3RCLFFBQUksa0JBQWtCO0FBQ3RCLFFBQUksYUFBYTtBQUVqQixRQUFJLGdCQUFnQixVQUFVLDBDQUEwQyxJQUFJO0FBRTVFLFFBQUksV0FBVyxVQUFVLHdCQUF3QjtBQUNqRCxRQUFJLE1BQU0sT0FBTztBQUNqQixRQUFJLGVBQWUsVUFBVSwyQkFBMkI7QUFFeEQsUUFBSSxPQUFPLGFBQWEsU0FBUyxJQUFJO0FBQ3JDLFFBQUksVUFBVSxVQUFVLHFCQUFxQixJQUFJO0FBQ2pELFFBQUksVUFBVSxVQUFVLHFCQUFxQixJQUFJO0FBQ2pELFFBQUksV0FBVyxVQUFVLHNCQUFzQixJQUFJO0FBQ25ELFFBQUksVUFBVSxVQUFVLHFCQUFxQixJQUFJO0FBQ2pELFFBQUksYUFBYSxVQUFVLHdCQUF3QixJQUFJO0FBQ3ZELFFBQUksVUFBVSxVQUFVLHFCQUFxQixJQUFJO0FBQ2pELFFBQUksV0FBVyxVQUFVLHNCQUFzQixJQUFJO0FBR25ELGFBQVMsbUJBQW1CLEtBQUssTUFBTSxNQUFNLFNBQVM7QUFDcEQsVUFBSSxJQUFJLFlBQVksR0FBRztBQUN2QixVQUFJO0FBQ0osY0FBUSxTQUFTLEVBQUUsS0FBSyxNQUFNLENBQUMsT0FBTyxNQUFNO0FBQzFDLFlBQUksa0JBQWtCLE1BQU0sT0FBTyxPQUFPLE1BQU0sT0FBTyxHQUFHO0FBRXhELHFCQUFXLEtBQUssT0FBTyxLQUFLO0FBQzVCLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUdBLGFBQVMsNEJBQTRCLE1BQU07QUFDekMsVUFBSSxPQUFPLFNBQVMsYUFBYTtBQUMvQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksT0FBTyxTQUFTLFVBQVU7QUFDNUIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzVCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLFNBQVMsVUFBVTtBQUV4RCxlQUFPLENBQUMsU0FBUyxDQUFDO0FBQUEsTUFDcEI7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLGFBQVMsc0JBQXNCLEdBQUcsR0FBRyxNQUFNLE1BQU0sTUFBTSxTQUFTO0FBQzlELFVBQUksV0FBVyw0QkFBNEIsSUFBSTtBQUMvQyxVQUFJLFlBQVksTUFBTTtBQUNwQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUM5QixVQUFJLFlBQVksT0FBTyxDQUFDLEdBQUcsTUFBTSxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQ2xELFVBQ0csT0FBTyxTQUFTLGVBQWUsQ0FBQyxRQUFRLEdBQUcsUUFBUSxLQUVqRCxDQUFDLGtCQUFrQixNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQ3BEO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPLENBQUMsUUFBUSxHQUFHLFFBQVEsS0FBSyxrQkFBa0IsTUFBTSxNQUFNLFdBQVcsT0FBTztBQUFBLElBQ2xGO0FBR0EsYUFBUyxzQkFBc0IsR0FBRyxHQUFHLE1BQU07QUFDekMsVUFBSSxXQUFXLDRCQUE0QixJQUFJO0FBQy9DLFVBQUksWUFBWSxNQUFNO0FBQ3BCLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTyxRQUFRLEdBQUcsUUFBUSxLQUFLLENBQUMsUUFBUSxHQUFHLFFBQVE7QUFBQSxJQUNyRDtBQUdBLGFBQVMsaUJBQWlCLEtBQUtDLE1BQUssTUFBTSxPQUFPLE1BQU0sU0FBUztBQUM5RCxVQUFJLElBQUksWUFBWSxHQUFHO0FBQ3ZCLFVBQUk7QUFDSixVQUFJO0FBQ0osY0FBUSxTQUFTLEVBQUUsS0FBSyxNQUFNLENBQUMsT0FBTyxNQUFNO0FBQzFDLGVBQU8sT0FBTztBQUNkO0FBQUE7QUFBQSxVQUVFLGtCQUFrQixNQUFNLE1BQU0sTUFBTSxPQUFPLEtBRXhDLGtCQUFrQixPQUFPLFFBQVFBLE1BQUssSUFBSSxHQUFHLE1BQU0sT0FBTztBQUFBLFVBQzdEO0FBQ0EscUJBQVcsS0FBSyxJQUFJO0FBQ3BCLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsa0JBQWtCLFFBQVEsVUFBVSxTQUFTLFNBQVM7QUFDN0QsVUFBSSxPQUFPLFdBQVcsQ0FBQztBQUd2QixVQUFJLEtBQUssU0FBUyxHQUFHLFFBQVEsUUFBUSxJQUFJLFdBQVcsVUFBVTtBQUM1RCxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksY0FBYyxvQkFBb0IsTUFBTTtBQUM1QyxVQUFJLGdCQUFnQixvQkFBb0IsUUFBUTtBQUNoRCxVQUFJLGdCQUFnQixlQUFlO0FBQ2pDLGVBQU87QUFBQSxNQUNUO0FBR0EsVUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFhLE9BQU8sV0FBVyxZQUFZLE9BQU8sYUFBYSxVQUFXO0FBQ3hGLGVBQU8sS0FBSyxTQUFTLEdBQUcsUUFBUSxRQUFRLElBQUksVUFBVTtBQUFBLE1BQ3hEO0FBWUEsVUFBSSxZQUFZLFFBQVEsSUFBSSxNQUFNO0FBQ2xDLFVBQUksY0FBYyxRQUFRLElBQUksUUFBUTtBQUN0QyxVQUFJO0FBQ0osVUFBSSxhQUFhLGFBQWE7QUFDNUIsWUFBSSxRQUFRLElBQUksTUFBTSxNQUFNLFFBQVEsSUFBSSxRQUFRLEdBQUc7QUFDakQsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixPQUFPO0FBQ0wsbUJBQVcsQ0FBQztBQUFBLE1BQ2Q7QUFDQSxVQUFJLENBQUMsV0FBVztBQUFFLGdCQUFRLElBQUksUUFBUSxRQUFRO0FBQUEsTUFBRztBQUNqRCxVQUFJLENBQUMsYUFBYTtBQUFFLGdCQUFRLElBQUksVUFBVSxRQUFRO0FBQUEsTUFBRztBQUdyRCxhQUFPLFNBQVMsUUFBUSxVQUFVLE1BQU0sT0FBTztBQUFBLElBQ2pEO0FBRUEsYUFBUyxTQUFTLEdBQUc7QUFDbkIsVUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBTyxFQUFFLFdBQVcsVUFBVTtBQUMvRCxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksT0FBTyxFQUFFLFNBQVMsY0FBYyxPQUFPLEVBQUUsVUFBVSxZQUFZO0FBQ2pFLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxFQUFFLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxNQUFNLFVBQVU7QUFDNUMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPLENBQUMsRUFBRSxFQUFFLGVBQWUsRUFBRSxZQUFZLFlBQVksRUFBRSxZQUFZLFNBQVMsQ0FBQztBQUFBLElBQy9FO0FBRUEsYUFBUyxTQUFTLEdBQUcsR0FBRyxNQUFNLFNBQVM7QUFDckMsVUFBSSxTQUFTLENBQUMsTUFBTSxTQUFTLENBQUMsR0FBRztBQUMvQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksS0FBSyxZQUFZLENBQUM7QUFDdEIsVUFBSSxLQUFLLFlBQVksQ0FBQztBQUN0QixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSixjQUFRLFVBQVUsR0FBRyxLQUFLLE1BQU0sQ0FBQyxRQUFRLE1BQU07QUFDN0MsWUFBSSxRQUFRLFNBQVMsT0FBTyxRQUFRLFVBQVUsVUFBVTtBQUN0RCxjQUFJLENBQUMsS0FBSztBQUFFLGtCQUFNLElBQUksS0FBSztBQUFBLFVBQUc7QUFDOUIsa0JBQVEsS0FBSyxRQUFRLEtBQUs7QUFBQSxRQUM1QixXQUFXLENBQUMsUUFBUSxHQUFHLFFBQVEsS0FBSyxHQUFHO0FBQ3JDLGNBQUksS0FBSyxRQUFRO0FBQUUsbUJBQU87QUFBQSxVQUFPO0FBQ2pDLGNBQUksQ0FBQyxzQkFBc0IsR0FBRyxHQUFHLFFBQVEsS0FBSyxHQUFHO0FBQy9DLG1CQUFPO0FBQUEsVUFDVDtBQUNBLGNBQUksQ0FBQyxLQUFLO0FBQUUsa0JBQU0sSUFBSSxLQUFLO0FBQUEsVUFBRztBQUM5QixrQkFBUSxLQUFLLFFBQVEsS0FBSztBQUFBLFFBQzVCO0FBQUEsTUFDRjtBQUNBLFVBQUksS0FBSztBQUNQLGdCQUFRLFVBQVUsR0FBRyxLQUFLLE1BQU0sQ0FBQyxRQUFRLE1BQU07QUFFN0MsY0FBSSxRQUFRLFNBQVMsT0FBTyxRQUFRLFVBQVUsVUFBVTtBQUN0RCxnQkFBSSxDQUFDLG1CQUFtQixLQUFLLFFBQVEsT0FBTyxLQUFLLFFBQVEsT0FBTyxHQUFHO0FBQ2pFLHFCQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0YsV0FDRSxDQUFDLEtBQUssVUFDSCxDQUFDLFFBQVEsR0FBRyxRQUFRLEtBQUssS0FDekIsQ0FBQyxtQkFBbUIsS0FBSyxRQUFRLE9BQU8sS0FBSyxRQUFRLE9BQU8sR0FDL0Q7QUFDQSxtQkFBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBQ0EsZUFBTyxTQUFTLEdBQUcsTUFBTTtBQUFBLE1BQzNCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFNBQVMsR0FBRyxHQUFHLE1BQU0sU0FBUztBQUNyQyxVQUFJLFNBQVMsQ0FBQyxNQUFNLFNBQVMsQ0FBQyxHQUFHO0FBQy9CLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxLQUFLLFlBQVksQ0FBQztBQUN0QixVQUFJLEtBQUssWUFBWSxDQUFDO0FBQ3RCLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSTtBQUNKLGNBQVEsVUFBVSxHQUFHLEtBQUssTUFBTSxDQUFDLFFBQVEsTUFBTTtBQUM3QyxjQUFNLFFBQVEsTUFBTSxDQUFDO0FBQ3JCLGdCQUFRLFFBQVEsTUFBTSxDQUFDO0FBQ3ZCLFlBQUksT0FBTyxPQUFPLFFBQVEsVUFBVTtBQUNsQyxjQUFJLENBQUMsS0FBSztBQUFFLGtCQUFNLElBQUksS0FBSztBQUFBLFVBQUc7QUFDOUIsa0JBQVEsS0FBSyxHQUFHO0FBQUEsUUFDbEIsT0FBTztBQUNMLGtCQUFRLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGNBQUssT0FBTyxVQUFVLGVBQWUsQ0FBQyxRQUFRLEdBQUcsR0FBRyxLQUFNLENBQUMsa0JBQWtCLE9BQU8sT0FBTyxNQUFNLE9BQU8sR0FBRztBQUN6RyxnQkFBSSxLQUFLLFFBQVE7QUFDZixxQkFBTztBQUFBLFlBQ1Q7QUFDQSxnQkFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsS0FBSyxPQUFPLE1BQU0sT0FBTyxHQUFHO0FBQzNELHFCQUFPO0FBQUEsWUFDVDtBQUNBLGdCQUFJLENBQUMsS0FBSztBQUFFLG9CQUFNLElBQUksS0FBSztBQUFBLFlBQUc7QUFDOUIsb0JBQVEsS0FBSyxHQUFHO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUksS0FBSztBQUNQLGdCQUFRLFVBQVUsR0FBRyxLQUFLLE1BQU0sQ0FBQyxRQUFRLE1BQU07QUFDN0MsZ0JBQU0sUUFBUSxNQUFNLENBQUM7QUFDckIsa0JBQVEsUUFBUSxNQUFNLENBQUM7QUFDdkIsY0FBSSxPQUFPLE9BQU8sUUFBUSxVQUFVO0FBQ2xDLGdCQUFJLENBQUMsaUJBQWlCLEtBQUssR0FBRyxLQUFLLE9BQU8sTUFBTSxPQUFPLEdBQUc7QUFDeEQscUJBQU87QUFBQSxZQUNUO0FBQUEsVUFDRixXQUNFLENBQUMsS0FBSyxXQUNGLENBQUMsRUFBRSxJQUFJLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixRQUFRLEdBQUcsR0FBRyxHQUFHLE9BQU8sTUFBTSxPQUFPLE1BQ3hFLENBQUMsaUJBQWlCLEtBQUssR0FBRyxLQUFLLE9BQU8sT0FBTyxDQUFDLEdBQUcsTUFBTSxFQUFFLFFBQVEsTUFBTSxDQUFDLEdBQUcsT0FBTyxHQUNyRjtBQUNBLG1CQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFDQSxlQUFPLFNBQVMsR0FBRyxNQUFNO0FBQUEsTUFDM0I7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsU0FBUyxHQUFHLEdBQUcsTUFBTSxTQUFTO0FBRXJDLFVBQUksR0FBRztBQUVQLFVBQUksT0FBTyxNQUFNLE9BQU8sR0FBRztBQUFFLGVBQU87QUFBQSxNQUFPO0FBQzNDLFVBQUksS0FBSyxRQUFRLEtBQUssTUFBTTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBRTVDLFVBQUksYUFBYSxDQUFDLE1BQU0sYUFBYSxDQUFDLEdBQUc7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUV6RCxVQUFJLFlBQVksQ0FBQyxNQUFNLFlBQVksQ0FBQyxHQUFHO0FBQUUsZUFBTztBQUFBLE1BQU87QUFFdkQsVUFBSSxXQUFXLFFBQVEsQ0FBQztBQUN4QixVQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ3hCLFVBQUksYUFBYSxVQUFVO0FBQUUsZUFBTztBQUFBLE1BQU87QUFHM0MsVUFBSSxXQUFXLGFBQWE7QUFDNUIsVUFBSSxXQUFXLGFBQWE7QUFDNUIsVUFBSSxhQUFhLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUMzQyxVQUFJLFlBQVksVUFBVTtBQUN4QixZQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsU0FBUztBQUFFLGlCQUFPO0FBQUEsUUFBTztBQUFBLE1BQ3BFO0FBRUEsVUFBSSxXQUFXLFFBQVEsQ0FBQztBQUN4QixVQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ3hCLFVBQUksYUFBYSxVQUFVO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDM0MsV0FBSyxZQUFZLGNBQWMsRUFBRSxXQUFXLEVBQUUsVUFBVSxNQUFNLENBQUMsTUFBTSxNQUFNLENBQUMsSUFBSTtBQUM5RSxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksVUFBVSxPQUFPLENBQUM7QUFDdEIsVUFBSSxVQUFVLE9BQU8sQ0FBQztBQUN0QixVQUFJLFlBQVksU0FBUztBQUFFLGVBQU87QUFBQSxNQUFPO0FBQ3pDLFVBQUksV0FBVyxTQUFTO0FBQ3RCLFlBQUksU0FBUyxDQUFDLE1BQU0sU0FBUyxDQUFDLEdBQUc7QUFBRSxpQkFBTztBQUFBLFFBQU87QUFBQSxNQUNuRDtBQUNBLFVBQUksS0FBSyxVQUFVLE9BQU8sSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUc7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUU3RCxVQUFJLFNBQVMsZ0JBQWdCLENBQUM7QUFDOUIsVUFBSSxTQUFTLGdCQUFnQixDQUFDO0FBQzlCLFVBQUksV0FBVyxRQUFRO0FBQ3JCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxVQUFVLFFBQVE7QUFDcEIsWUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRO0FBQUUsaUJBQU87QUFBQSxRQUFPO0FBQzNDLGFBQUssSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7QUFDN0IsY0FBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRztBQUFFLG1CQUFPO0FBQUEsVUFBTztBQUFBLFFBQ3JDO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLFlBQVksU0FBUyxDQUFDO0FBQzFCLFVBQUksWUFBWSxTQUFTLENBQUM7QUFDMUIsVUFBSSxjQUFjLFdBQVc7QUFBRSxlQUFPO0FBQUEsTUFBTztBQUM3QyxVQUFJLGFBQWEsV0FBVztBQUMxQixZQUFJLEVBQUUsV0FBVyxFQUFFLFFBQVE7QUFBRSxpQkFBTztBQUFBLFFBQU87QUFDM0MsYUFBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztBQUM3QixjQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHO0FBQUUsbUJBQU87QUFBQSxVQUFPO0FBQUEsUUFDckM7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksaUJBQWlCLGNBQWMsQ0FBQztBQUNwQyxVQUFJLGlCQUFpQixjQUFjLENBQUM7QUFDcEMsVUFBSSxtQkFBbUIsZ0JBQWdCO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDdkQsVUFBSSxrQkFBa0IsZ0JBQWdCO0FBQ3BDLFlBQUksV0FBVyxDQUFDLE1BQU0sV0FBVyxDQUFDLEdBQUc7QUFBRSxpQkFBTztBQUFBLFFBQU87QUFDckQsZUFBTyxPQUFPLGVBQWUsY0FBYyxrQkFBa0IsSUFBSSxXQUFXLENBQUMsR0FBRyxJQUFJLFdBQVcsQ0FBQyxHQUFHLE1BQU0sT0FBTztBQUFBLE1BQ2xIO0FBRUEsVUFBSSxTQUFTLG9CQUFvQixDQUFDO0FBQ2xDLFVBQUksU0FBUyxvQkFBb0IsQ0FBQztBQUNsQyxVQUFJLFdBQVcsUUFBUTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBQ3ZDLFVBQUksVUFBVSxRQUFRO0FBQ3BCLFlBQUksY0FBYyxDQUFDLE1BQU0sY0FBYyxDQUFDLEdBQUc7QUFBRSxpQkFBTztBQUFBLFFBQU87QUFDM0QsZUFBTyxPQUFPLGVBQWUsY0FBYyxrQkFBa0IsSUFBSSxXQUFXLENBQUMsR0FBRyxJQUFJLFdBQVcsQ0FBQyxHQUFHLE1BQU0sT0FBTztBQUFBLE1BQ2xIO0FBRUEsVUFBSSxPQUFPLE1BQU0sT0FBTyxHQUFHO0FBQUUsZUFBTztBQUFBLE1BQU87QUFFM0MsVUFBSSxLQUFLLFdBQVcsQ0FBQztBQUNyQixVQUFJLEtBQUssV0FBVyxDQUFDO0FBRXJCLFVBQUksR0FBRyxXQUFXLEdBQUcsUUFBUTtBQUFFLGVBQU87QUFBQSxNQUFPO0FBRzdDLFNBQUcsS0FBSztBQUNSLFNBQUcsS0FBSztBQUVSLFdBQUssSUFBSSxHQUFHLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUNuQyxZQUFJLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHO0FBQUUsaUJBQU87QUFBQSxRQUFPO0FBQUEsTUFDdEM7QUFHQSxXQUFLLElBQUksR0FBRyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDbkMsY0FBTSxHQUFHLENBQUM7QUFDVixZQUFJLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxHQUFHLEVBQUUsR0FBRyxHQUFHLE1BQU0sT0FBTyxHQUFHO0FBQUUsaUJBQU87QUFBQSxRQUFPO0FBQUEsTUFDekU7QUFFQSxVQUFJLGNBQWMsZ0JBQWdCLENBQUM7QUFDbkMsVUFBSSxjQUFjLGdCQUFnQixDQUFDO0FBQ25DLFVBQUksZ0JBQWdCLGFBQWE7QUFDL0IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLGdCQUFnQixTQUFTLGdCQUFnQixPQUFPO0FBQ2xELGVBQU8sU0FBUyxHQUFHLEdBQUcsTUFBTSxPQUFPO0FBQUEsTUFDckM7QUFDQSxVQUFJLGdCQUFnQixPQUFPO0FBQ3pCLGVBQU8sU0FBUyxHQUFHLEdBQUcsTUFBTSxPQUFPO0FBQUEsTUFDckM7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLElBQUFELFFBQU8sVUFBVSxTQUFTLFVBQVUsR0FBRyxHQUFHLE1BQU07QUFDOUMsYUFBTyxrQkFBa0IsR0FBRyxHQUFHLE1BQU0sZUFBZSxDQUFDO0FBQUEsSUFDdkQ7QUFBQTtBQUFBOzs7QUN2WUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7QUNBTyxJQUFNLFFBQVEsT0FBTyxLQUFLO0FBRzFCLElBQU0sWUFBWSxPQUFPLFNBQVM7QUFDbEMsSUFBTSxXQUFXLE9BQU8sUUFBUTtBQUNoQyxJQUFNLFdBQVcsT0FBTyxRQUFRO0FBQ2hDLElBQU0sWUFBWSxPQUFPLFNBQVM7QUFFbEMsSUFBTSxVQUFVLE9BQU8sT0FBTztBQUM5QixJQUFNLFVBQVUsT0FBTyxPQUFPO0FBQzlCLElBQU0sZUFBZSxPQUFPLFlBQVk7QUFHeEMsSUFBTSxvQkFBb0IsT0FBTyxpQkFBaUI7OztBQ1JsRCxJQUFNLE9BQU8sT0FBTywwQkFBMEI7QUFJOUMsSUFBTSxhQUFhLENBQUksU0FBYyxDQUFDLE1BQU07QUFHL0MsUUFBTSxPQUFPLElBQUksTUFBVyxPQUFPLEtBQUssR0FBRyxDQUFDO0FBQzVDLFFBQU0sT0FBd0IsQ0FBQyxRQUFRO0FBQ25DLFFBQUssT0FBTztBQUFPLGFBQU87QUFDMUIsV0FBUyxPQUFPLFVBQVUsSUFBSyxRQUFRLE9BQU8sTUFBTTtBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUFBLElBQ0g7QUFBQTtBQUFBLElBQ0E7QUFBQSxFQUNKO0FBQ0o7QUFFTyxJQUFNLE1BQU0sQ0FBTSxHQUFrQkUsU0FBbUMsQ0FBQyxNQUFNO0FBQ2pGLE1BQUksS0FBSztBQUFPLFdBQU8sRUFBRSxLQUFLO0FBQUEsT0FDekI7QUFDRCxVQUFNLElBQUksRUFBRSxDQUFDO0FBQ2IsV0FBUSxNQUFNLFFBQVMsUUFBUUEsS0FBSSxDQUFDO0FBQUEsRUFDeEM7QUFDSjtBQVdPLElBQU0sV0FBVyxDQUFJLE9BQVUsRUFBRSxNQUFLLE1BQU0sT0FBUSxPQUFPLEVBQW1DO0FBRTlGLElBQU0sVUFBVSxDQUFJLE1BQXFCO0FBQzVDLFNBQU87QUFBQSxJQUNILENBQUMsT0FBTyxRQUFRLEdBQUcsT0FBTztBQUFBLE1BQ3RCLE1BQU0sTUFBTSxTQUFTLEVBQUUsTUFBUyxDQUFDO0FBQUEsSUFDckM7QUFBQSxFQUNKO0FBQ0o7QUFFTyxJQUFNLFdBQVcsQ0FBSSxNQUEwQjtBQUNsRCxRQUFNLElBQVMsQ0FBQztBQUNoQixTQUFPLE1BQUs7QUFDUixVQUFNLElBQUksRUFBRTtBQUNaLFFBQUksS0FBSztBQUFPO0FBQUE7QUFDWCxRQUFFLEtBQUssQ0FBQztBQUFBLEVBQ2pCO0FBQ0EsYUFBVyxLQUFLLFFBQVEsQ0FBQyxHQUFHO0FBQ3hCLE1BQUUsS0FBSyxDQUFDO0FBQUEsRUFDWjtBQUNBLFNBQU87QUFDWDs7O0FDeERPLElBQU0sbUJBQW1CLENBQUksR0FBcUIsZUFBOEM7QUFDbkcsTUFBSSxNQUFNO0FBQ04sZUFBVyxDQUFDLEVBQUUsS0FBSztBQUFBLFdBQ2QsV0FBVztBQUNoQixlQUFXLENBQUMsRUFBRSxFQUFFLEtBQUs7QUFBQTtBQUNwQixlQUFXLENBQUMsRUFBRSxFQUFFLEtBQUs7QUFDOUI7QUFFTyxJQUFNLGVBQWUsQ0FBSSxNQUFtQztBQUMvRCxNQUFJLE1BQU07QUFDTixXQUFPO0FBQUEsV0FDRixXQUFXO0FBQ2hCLFdBQU8sRUFBRTtBQUFBO0FBQ1IsVUFBTSxFQUFFO0FBQ2pCO0FBRU8sSUFBTSxpQkFBaUIsT0FBVSxNQUEwRDtBQUM5RixNQUFJO0FBQ0EsVUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBSSxNQUFNO0FBQU8sYUFBTztBQUN4QixXQUFPLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDdEIsU0FBUyxHQUFHO0FBQ1IsV0FBTyxFQUFDLE9BQU8sRUFBQztBQUFBLEVBQ3BCO0FBQ0o7QUFNTyxJQUFNLGFBQWEsQ0FBQyxPQUFvQztBQUMzRCxRQUFNLElBQUksR0FBRztBQUNiLE1BQUksQ0FBQztBQUFHLFdBQU8sRUFBRSxlQUFlLElBQUksZ0JBQWdCLElBQUk7QUFDeEQsU0FBUSxPQUFPLEtBQUssV0FBWSxFQUFFLGVBQWUsR0FBRyxnQkFBZ0IsSUFBSSxHQUFHLElBQUk7QUFDbkY7OztBQzdCTyxJQUFNLGlCQUFpQixDQUFJLFNBQWMsQ0FBQyxHQUFHLElBQXdCLENBQUMsTUFBTTtBQUMvRSxNQUFJLFNBQWtCO0FBQ3RCLE1BQUksVUFBMkI7QUFDL0IsTUFBSSxhQUF3RDtBQUM1RCxNQUFJLE9BQU8sRUFBRSxRQUFRO0FBRXJCLE1BQUksV0FBVztBQUVmLFFBQU0sT0FBTyxJQUFJLE1BQVc7QUFDeEIsUUFBSSxZQUFXO0FBQ1gsaUJBQVcsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDO0FBQ3ZCLG1CQUFhO0FBQUEsSUFDakI7QUFDQSxXQUFPLEtBQUssR0FBRyxDQUFDO0FBQUEsRUFDcEI7QUFDQSxRQUFNLE9BQTJCLFlBQVksSUFBSSxRQUFRLENBQUMsR0FBRSxNQUFNO0FBQzlELFFBQUksQ0FBQyxTQUFRO0FBQ1QsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLFFBQVEsVUFBVSxHQUFFO0FBQ3BCLFVBQUk7QUFBWSxjQUFNLE1BQU0scUVBQXFFO0FBQ2pHLFVBQUk7QUFBTSxVQUFFLEtBQUs7QUFBQTtBQUNaLHFCQUFhLENBQUMsR0FBRSxDQUFDO0FBQUEsSUFDMUIsT0FBTztBQUNILFFBQUUsUUFBUSxNQUFNLENBQUU7QUFBQSxJQUN0QjtBQUFBLEVBQ0osQ0FBQztBQUNELFFBQU0sTUFBTSxNQUFNO0FBQ2QsUUFBSSxDQUFDO0FBQVM7QUFDZCxhQUFTO0FBQ1QsUUFBSSxRQUFRLFVBQVU7QUFBRyxnQkFBVTtBQUNuQyxRQUFJO0FBQVksaUJBQVcsQ0FBQyxFQUFFLEtBQUs7QUFBQSxFQUN2QztBQUVBLFNBQU87QUFBQSxJQUNIO0FBQUE7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsTUFBTSxNQUFNLE9BQU87QUFBQSxFQUN2QjtBQUNKO0FBQ08sSUFBTSxVQUFVLENBQU8sR0FBdUJDLFNBQXNELE9BQU8sTUFBTTtBQUNwSCxNQUFJLEtBQUssT0FBTztBQUNaLFVBQU0sRUFBRSxLQUFLO0FBQ2IsV0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNLElBQUksTUFBTSxFQUFFO0FBQ2xCLFNBQU8sS0FBSyxRQUFRLFFBQVEsTUFBTUEsS0FBSSxDQUFDO0FBQzNDO0FBaUJPLElBQU0sY0FBYyxDQUFJLE9BQTJCO0FBQUEsRUFDbEQsQ0FBQyxPQUFPLGFBQWEsR0FBRyxPQUFPO0FBQUEsSUFDM0IsTUFBTSxZQUFZLFNBQVUsTUFBTSxFQUFFLE1BQVMsQ0FBQztBQUFBLEVBQ2xEO0FBQ1I7QUFFTyxJQUFNLGVBQWUsT0FBVSxNQUF3QztBQUMxRSxRQUFNLElBQVMsQ0FBQztBQUNoQixtQkFBaUIsS0FBSyxZQUFZLENBQUMsR0FBRztBQUNsQyxNQUFFLEtBQUssQ0FBQztBQUFBLEVBQ1o7QUFDQSxTQUFPO0FBQ1g7QUFJTyxJQUFNLGtCQUFrQixDQUFJLEdBQXVCLElBQTBCLEVBQUUsU0FBUyxLQUFJLE1BQU07QUFFckcsTUFBSSxZQUFZO0FBQ2hCLE1BQUksVUFBVTtBQUVkLFFBQU0sVUFFRCxDQUFDO0FBRU4sUUFBTSxNQUFNLE1BQU07QUFDZCxjQUFVO0FBQ1YsTUFBRSxLQUFLO0FBQUEsRUFDWDtBQUVBLFFBQU0sVUFBVSxNQUFNO0FBQ2xCLFFBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLFNBQVE7QUFFckMsVUFBSTtBQUFBLElBQ1I7QUFBQSxFQUNKO0FBRUEsUUFBTSxXQUFXLFlBQVk7QUFDekIsUUFBSSxXQUFXO0FBQUEsSUFDZixPQUFPO0FBQ0gsVUFBSSxDQUFDLFFBQVEsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTyxHQUFFO0FBRXRDLGNBQU0sSUFBSSxNQUFNLEVBQUUsRUFBRTtBQUFBLFVBQ2hCLENBQUMsTUFBTSxDQUFDLE1BQTZCLEVBQUUsQ0FBQyxFQUFFLENBQUM7QUFBQSxVQUMzQyxDQUFDLE1BQU0sQ0FBQyxNQUE2QixFQUFFLENBQUMsRUFBRSxDQUFDO0FBQUEsUUFDL0M7QUFDQSxpQkFBUyxLQUFLLFNBQVM7QUFDbkIsY0FBSSxHQUFHO0FBQ0gsY0FBRSxFQUFFLE9BQVE7QUFDWixjQUFFLFVBQVU7QUFBQSxVQUNoQjtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxRQUFNLFdBQVcsTUFBTTtBQUNuQixnQkFBWTtBQUNaLGFBQVM7QUFBQSxFQUNiO0FBRUEsU0FBTztBQUFBLElBQ0g7QUFBQSxJQUNBO0FBQUE7QUFBQSxJQUNBLFFBQVEsTUFBTTtBQUNWLFlBQU0sS0FBSyxRQUFRO0FBQ25CLGNBQVEsS0FBSyxFQUFFLFNBQVMsT0FBVSxDQUFDO0FBQ25DLFlBQU0sU0FBVSxDQUFzQkMsT0FBNkQ7QUFDL0YsWUFBSUEsTUFBSyxPQUFNO0FBQ1gsa0JBQVEsRUFBRSxJQUFJO0FBQ2Qsa0JBQVE7QUFBQSxRQUNaO0FBQ0EsWUFBSTtBQUFTLGlCQUFPO0FBRXBCLFlBQUksUUFBUSxFQUFFLEdBQUc7QUFBUyxnQkFBTSxNQUFNLHNDQUFzQztBQUM1RSxlQUFPLElBQUksUUFBUSxDQUFDLEdBQUUsTUFBTTtBQUN4QixrQkFBUSxFQUFFLEVBQUcsVUFBVSxDQUFDLEdBQUUsQ0FBQztBQUMzQixtQkFBUztBQUFBLFFBQ2IsQ0FBQztBQUFBLE1BQ0w7QUFDQSxhQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0o7QUFDSjtBQVFPLElBQU0sWUFBWSxDQUFJLE1BQXlCO0FBQ2xELFFBQU0sVUFBVSxFQUFFO0FBQ2xCLE1BQUssT0FBTyxFQUFFLFFBQVE7QUFDdEIsTUFBSSxhQUFxQztBQUN6QyxNQUFJLGNBQXdDO0FBRTVDLFFBQU0sV0FBVyxZQUFZO0FBQ3pCLFdBQU8sTUFBSztBQUNSLFVBQUksUUFBUSxVQUFVLEdBQUU7QUFDcEIsWUFBSSxNQUFLO0FBQ0wscUJBQVksQ0FBQyxFQUFFLEtBQUs7QUFDcEIsdUJBQWE7QUFBQSxRQUNqQjtBQUNBO0FBQUEsTUFDSjtBQUNBLFVBQUk7QUFDQSxjQUFNLElBQUksTUFBTSxRQUFRLENBQUMsRUFBRTtBQUMzQixZQUFJLEtBQUssT0FBTTtBQUNYLGtCQUFRLE1BQU07QUFBQSxRQUNsQixPQUFPO0FBQ0gscUJBQVksQ0FBQyxFQUFFLENBQUM7QUFDaEIsdUJBQWE7QUFDYjtBQUFBLFFBQ0o7QUFBQSxNQUNKLFNBQVMsR0FBRztBQUNSLG1CQUFZLENBQUMsRUFBRSxDQUFDO0FBQ2hCLHFCQUFhO0FBQ2I7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFFQSxRQUFNLE9BQU8sVUFBVSxhQUFtQztBQUN0RCxRQUFJO0FBQWEsWUFBTTtBQUN2QixZQUFRLEtBQUssR0FBRyxRQUFRO0FBQ3hCLFFBQUksWUFBVztBQUNYLG9CQUFjLFNBQVM7QUFBQSxJQUMzQjtBQUFBLEVBQ0o7QUFFQSxRQUFNLE9BQVEsT0FBTyxRQUFRO0FBQ3pCLFFBQUksT0FBTyxPQUFNO0FBQ2IsZUFBUyxLQUFLLFNBQVM7QUFDbkIsVUFBRSxLQUFLO0FBQUEsTUFDWDtBQUFBLElBQ0o7QUFDQSxRQUFJO0FBQVksWUFBTSxNQUFNLHFFQUFxRTtBQUNqRyxVQUFNLElBQUksSUFBSSxRQUFRLENBQUMsR0FBRSxNQUFNLGFBQWEsQ0FBQyxHQUFFLENBQUMsQ0FBQztBQUNqRCxrQkFBYyxTQUFTO0FBQ3ZCLFdBQU87QUFBQSxFQUVYO0FBRUEsU0FBTztBQUFBLElBQ0g7QUFBQSxJQUNBO0FBQUEsSUFDQSxNQUFNLE1BQU07QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUFBLEVBQy9CO0FBQ0o7QUEyQk8sSUFBTSxlQUFlLENBQUksUUFBNEIsSUFBd0IsQ0FBQyxNQUEwQjtBQUMzRyxRQUFNLEVBQUUsZUFBZSxlQUFjLElBQUksV0FBVyxDQUFDO0FBRXJELFFBQU0sU0FBNkIsQ0FBQztBQUNwQyxNQUFJLGFBQXdEO0FBRTVELE1BQUksVUFBVTtBQUNkLFFBQU1DLE9BQU0sWUFBWTtBQUNwQixRQUFJO0FBQVM7QUFDYixjQUFVO0FBQ1YsUUFBSTtBQUNBLGFBQVEsT0FBTyxTQUFTLGdCQUFlO0FBQ25DLGNBQU0sSUFBSSxNQUFNLGVBQWUsT0FBTyxDQUFDO0FBQ3ZDLFlBQUksWUFBWTtBQUFFLDJCQUFpQixHQUFHLFVBQVU7QUFBRyx1QkFBYTtBQUFBLFFBQVc7QUFDdEUsaUJBQU8sS0FBSyxDQUFDO0FBQ2xCLFlBQUksS0FBSztBQUFPO0FBQUEsTUFDcEI7QUFBQSxJQUNKLFVBQUU7QUFDRSxnQkFBVTtBQUFBLElBQ2Q7QUFBQSxFQUNKO0FBRUEsU0FBUSxPQUFPLFFBQWdCO0FBRTNCLFFBQUksT0FBTyxPQUFNO0FBQ2IsYUFBTyxLQUFLO0FBQ1osYUFBTztBQUFBLElBQ1g7QUFFQSxRQUFJLE9BQU8sU0FBUyxHQUFFO0FBQ2xCLFlBQU0sSUFBSSxPQUFPLE1BQU07QUFDdkIsVUFBSSxPQUFPLFNBQVM7QUFDaEIsUUFBQUEsS0FBSTtBQUNSLGFBQU8sYUFBYSxDQUFDO0FBQUEsSUFDekIsT0FBTztBQUNILFlBQU0sSUFBSSxJQUFJLFFBQVcsQ0FBQyxHQUFFLE1BQU07QUFBRSxxQkFBYSxDQUFDLEdBQUUsQ0FBQztBQUFBLE1BQUUsQ0FBQztBQUN4RCxNQUFBQSxLQUFJO0FBQ0osYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0o7QUFPTyxJQUFNLFVBQVUsQ0FBdUMsTUFBaUIsWUFBMEY7QUFFckssUUFBTSxVQUFVLE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM5RCxRQUFNLElBQUksUUFBUTtBQUVsQixTQUFRLE9BQU8sUUFBZ0I7QUFHM0IsVUFBTSxTQUFTLE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7QUFFeEQsVUFBTSxhQUFhLE9BQU8sT0FBTyxDQUFDLE1BQU0sTUFBTSxLQUFLLEVBQUU7QUFFckQsUUFBSSxhQUFhLE1BQU0sRUFBRSxvQkFBb0IsT0FBTTtBQUMvQyxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1gsV0FBVyxjQUFjLEdBQUc7QUFDeEIsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNYO0FBRUEsV0FBTztBQUFBLEVBRVg7QUFDSjtBQUdPLElBQU0sZ0JBQWdCLENBQUksUUFBNEIsVUFBd0M7QUFDakcsTUFBSSxTQUFTO0FBQ2IsU0FBUSxPQUFPLFFBQWdCO0FBQzNCLFFBQUk7QUFBSyxhQUFPLE9BQU8sS0FBSztBQUM1QixRQUFJO0FBQVEsYUFBTztBQUNuQixVQUFNLElBQVMsQ0FBQztBQUNoQixhQUFTLElBQUksR0FBRyxJQUFJLE9BQVEsS0FBSztBQUM5QixZQUFNLElBQUksTUFBTSxPQUFPO0FBQ3ZCLFVBQUksS0FBSyxPQUFNO0FBQ1gsaUJBQVM7QUFDVDtBQUFBLE1BQ0o7QUFBTyxVQUFFLEtBQUssQ0FBQztBQUFBLElBQ2xCO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDSjs7O0FDOVVBLElBQU0sUUFBUSxDQUFDLE9BQWUsSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBRTNELElBQU0sZ0JBQWdCLENBQUMsV0FBOEM7QUFDeEUsTUFBSSxPQUEyQjtBQUUvQixTQUFPLFlBQTJCO0FBQzlCLFVBQU0sT0FBTyxPQUFPO0FBQ3BCLFVBQU0sS0FBSyxvQkFBSSxRQUFNLFFBQVE7QUFDN0IsUUFBSSxDQUFDLE1BQUs7QUFDTixhQUFPO0FBQ1A7QUFBQSxJQUNKO0FBQ0EsVUFBTSxXQUFXLFFBQVEsSUFBSTtBQUM3QixRQUFJLFdBQVc7QUFBRyxZQUFNLE1BQU0sUUFBUTtBQUN0QyxXQUFPLElBQUk7QUFDWDtBQUFBLEVBQ0o7QUFDSjs7O0FDckJBLHdCQUFrQjs7O0FDRFgsSUFBTSxtQkFBbUIsQ0FBQyxNQUFXO0FBQzFDLE1BQUksT0FBTyxLQUFLLFVBQVU7QUFDdEIsUUFBSSxXQUFXLEdBQUU7QUFFYixhQUFPLEVBQUU7QUFBQSxJQUNiLE9BQU87QUFFTCxZQUFNLElBQUksQ0FBQztBQUNYLGlCQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUN0QyxVQUFFLEtBQUssR0FBRyxLQUFLLFVBQVUsQ0FBQyxDQUFDLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQyxFQUFFO0FBQUEsTUFDckQ7QUFDQSxhQUFPLEVBQUUsS0FBSyxJQUFJO0FBQUEsSUFDcEI7QUFBQSxFQUNKLFdBQVcsS0FBSyxFQUFFLE9BQU87QUFDdkIsV0FBTyxHQUFHLENBQUM7QUFBQSxFQUFLLEVBQUUsS0FBSztBQUFBLEVBQ3pCO0FBQ0EsU0FBTyxLQUFLLFVBQVUsQ0FBQztBQUN6Qjs7O0FENEZBLElBQU0sZUFBZSxPQUFPO0FBQUEsRUFDeEIsUUFBUSxDQUFDO0FBQUEsRUFDVCxNQUFNLENBQUM7QUFBQSxFQUNQLFFBQVEsQ0FBQztBQUFBLEVBQ1QsVUFBVSxDQUFDO0FBQUE7QUFDZjtBQVFPLElBQU0sY0FBYyxPQUFtQjtBQUFBLEVBQzFDLEtBQUs7QUFBQSxFQUNMLFNBQVMsQ0FBQztBQUFBLEVBQ1YsUUFBUSxhQUFhO0FBQ3pCO0FBRU8sSUFBTSxlQUFlLENBQUMsV0FBd0IsT0FBTyxPQUFPLFNBQVMsS0FBSyxPQUFPLFNBQVMsU0FBUztBQUVuRyxJQUFNLG1CQUFtQixDQUFDLE9BQW1CO0FBQ2hELE1BQUksSUFBYyxDQUFDO0FBQ25CLElBQUUsS0FBSyxXQUFXLEdBQUcsT0FBTyxNQUFNLEVBQUU7QUFFcEMsUUFBTSxNQUFNLENBQUMsT0FBZSxTQUFtQjtBQUMzQyxRQUFJLEtBQUssU0FBUyxHQUFFO0FBQ2hCLFFBQUUsS0FBSyxPQUFPLEtBQUs7QUFBQSxDQUFJO0FBQUEsSUFDM0I7QUFBQSxFQUNKO0FBRUEsS0FBRyxPQUFPLFFBQVEsQ0FBQyxHQUFHLE1BQU07QUFDeEIsTUFBRSxLQUFLLFdBQVcsRUFBRSxLQUFLLEVBQUU7QUFDM0IsUUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsaUJBQWlCLEVBQUUsT0FBTyxFQUFFLE1BQU0sSUFBSSxDQUFDO0FBQUEsRUFDOUQsQ0FBQztBQUVELEtBQUcsS0FBSyxRQUFRLENBQUMsR0FBRyxNQUFNO0FBQ3RCLE1BQUUsS0FBSyxTQUFTLENBQUMsRUFBRTtBQUFBLEVBQ3ZCLENBQUM7QUFFRCxHQUFDLEdBQUcsWUFBVyxDQUFDLEdBQUcsUUFBUSxDQUFDLEdBQUcsTUFBTTtBQUNqQyxNQUFFLEtBQUssYUFBYSxDQUFDLEVBQUU7QUFBQSxFQUMzQixDQUFDO0FBRUQsU0FBTztBQUNYO0FBRU8sSUFBTSxzQkFBc0IsQ0FBQyxRQUFxQixnQkFBeUI7QUFDOUUsTUFBSSxhQUFhLE1BQU07QUFDbkIsWUFBUSxJQUFJLHdCQUF3QixXQUFXLElBQUksaUJBQWlCLE1BQU0sQ0FBQztBQUFBO0FBRTNFLFlBQVEsSUFBSSx3QkFBd0IsV0FBVyxJQUFJLGlCQUFpQixNQUFNLENBQUM7QUFDbkY7QUFDTyxJQUFNLGtCQUFrQixPQUFPLEdBQVcsTUFBWTtBQUN6RCxVQUFRLElBQUksTUFBTSxFQUFFLFdBQVcsRUFBRTtBQUNqQyxzQkFBb0IsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZDO0FBeUNPLElBQU0sTUFBTSxDQUNmLEtBQ0EsR0FDQSxNQUN1QjtBQUN2QixRQUFNLFlBQWlDLENBQUM7QUFDeEMsUUFBTSxRQUFvQixHQUFHLFNBQVMsWUFBWTtBQUNsRCxNQUFJO0FBRUosU0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFFcEMsVUFBTSxVQUFVLENBQUMsUUFBZ0I7QUFDN0IsbUJBQWEsS0FBSztBQUNsQixZQUFNLE9BQU8sV0FBVyxPQUFPLE9BQU8sTUFBTSxPQUFPLEVBQUUsSUFBSSxPQUFLLEVBQUUsS0FBSztBQUNyRSxjQUFRLE1BQU0sTUFBTTtBQUNwQixnQkFBVSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7QUFBQSxJQUNoQztBQUVBLFVBQU0sUUFBUSxDQUFDLFVBQWtCO0FBQzdCLFlBQU0sT0FBTyxNQUFNO0FBQ25CLFlBQU0sUUFBUSxJQUFJLElBQUk7QUFBQSxRQUNsQixTQUFTO0FBQUEsUUFDVDtBQUFBLE1BQ0o7QUFFQSxhQUFPLENBQUMsTUFBNkI7QUFDakMsY0FBTSxRQUFRLElBQUksRUFBRSxVQUFVO0FBQzlCLGNBQU0sT0FBTyxNQUFNO0FBQ2YsaUJBQU8sTUFBTSxRQUFRLElBQUk7QUFFekIsY0FBSSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUUsV0FBVyxHQUFHO0FBQUUsb0JBQVEsaUJBQWlCO0FBQUEsVUFBRztBQUFBLFFBQy9FO0FBQ0EsVUFBRTtBQUFBLFVBQ0UsQ0FBQyxNQUFNO0FBQUUsa0JBQU0sT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLEVBQUU7QUFBRyxpQkFBSztBQUFBLFVBQUc7QUFBQSxVQUMzRCxDQUFDLE1BQU07QUFDSCxrQkFBTSxRQUFRLGlCQUFpQixDQUFDO0FBRWhDLGtCQUFNLE9BQU8sT0FBTyxLQUFLLEVBQUMsT0FBTyxTQUFTLE1BQU0sQ0FBQztBQUFHLGlCQUFLO0FBQUEsVUFBRztBQUFBLFFBQ3BFO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFDQSxVQUFNLE9BQU8sSUFBSSxpQkFBaUIsSUFBSTtBQUN0QyxVQUFNLG9CQUFvQixDQUFDLFNBQWlCLFVBQW9CO0FBQzVELFVBQUksSUFBSSxnQkFBZ0IsQ0FBQyxPQUFPO0FBQUUsWUFBSSxhQUFhLEtBQUs7QUFBQSxNQUFHO0FBQzNELFVBQUksWUFBWSxHQUFHO0FBQ2YsZ0JBQVEsMkJBQTJCO0FBQUEsTUFDdkMsT0FBTztBQUNILGdCQUFRLFdBQVcsTUFBTTtBQUFFLDRCQUFrQixVQUFVLElBQUk7QUFBQSxRQUFHLEdBQUcsSUFBSTtBQUFBLE1BQ3pFO0FBQUEsSUFDSjtBQUNBLFlBQVEsV0FBVyxNQUFNO0FBQUUsd0JBQWtCLElBQUksU0FBUyxJQUFJO0FBQUEsSUFBRyxHQUFHLENBQUM7QUFFckUsVUFBTSxXQUFXLENBQUMsVUFBa0I7QUFDaEMsWUFBTSxJQUFTLENBQUM7QUFDaEIsUUFBRSxVQUFVLElBQUksUUFBYyxDQUFDLEdBQUcsTUFBTTtBQUVwQyxZQUFJLElBQUksa0JBQWlCO0FBQ3JCLGdCQUFNLE1BQU07QUFDWixjQUFJLENBQUMsTUFBTTtBQUFFLGdCQUFJLENBQUM7QUFBRyxrQkFBTSxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQUEsVUFBRTtBQUFBLFFBQzdDO0FBQ0EsY0FBTSxjQUFjLENBQUMsR0FBWSxXQUFvQjtBQUFFLGNBQUksR0FBRztBQUFFLGNBQUU7QUFBQSxVQUFHLE9BQU87QUFBRSxjQUFFLFVBQVUsaUJBQWlCO0FBQUEsVUFBRztBQUFBLFFBQUU7QUFDaEgsY0FBTSxrQkFBa0IsSUFBSSxNQUFpQjtBQUN6QyxnQkFBTSxPQUFPLENBQUM7QUFDZCxtQkFBUyxJQUFJLEdBQUcsTUFBTSxFQUFFLFFBQVEsSUFBSSxLQUFNLEtBQUs7QUFDdkMsZ0JBQUksQ0FBQyxFQUFFLENBQUM7QUFBRyxtQkFBSyxLQUFLLFlBQVksSUFBSSxDQUFDLFNBQVM7QUFBQSxVQUN2RDtBQUNBLGNBQUksS0FBSyxTQUFTO0FBQUcsY0FBRSxLQUFLLEtBQUssS0FBSyxDQUFDO0FBQ3ZDLFlBQUU7QUFBQSxRQUNOO0FBRUEsY0FBTSxvQkFBb0IsQ0FBQyxHQUFPLHFCQUF1QztBQUNyRSxjQUFJLGtCQUFrQjtBQUNsQixnQkFBSSw0QkFBNEIsUUFBUTtBQUNwQyxrQkFBSSxFQUFFLFNBQVMsRUFBRSxNQUFNLGdCQUFnQjtBQUFHLGtCQUFFO0FBQUE7QUFDdkMsa0JBQUU7QUFBQSxrQkFDSCxPQUFPLDJDQUEyQyxnQkFBZ0I7QUFBQSxrQkFDbEUsV0FBVztBQUFBLGdCQUNmLENBQUM7QUFBQSxZQUNMLE9BQU87QUFDSCxrQkFBSTtBQUNBLGlDQUFpQixDQUFDO0FBQ2xCLGtCQUFFO0FBQUEsY0FDTixTQUFTQyxJQUFHO0FBQ1Isa0JBQUU7QUFBQSxrQkFDRSxTQUFTO0FBQUEsa0JBQ1QsYUFBYUE7QUFBQSxnQkFDakIsQ0FBQztBQUFBLGNBQ0w7QUFBQSxZQVdKO0FBQUEsVUFDSjtBQUNLLGNBQUU7QUFBQSxRQUNYO0FBRUEsVUFBRSxVQUFVO0FBQ1osVUFBRSxPQUFPLE1BQU07QUFBRSxZQUFFO0FBQUcsZ0JBQU0sT0FBTyxLQUFLLEtBQUssS0FBSztBQUFBLFFBQUU7QUFDcEQsVUFBRSxPQUFPO0FBQ1QsVUFBRSxjQUFjO0FBQ2hCLFVBQUUsa0JBQWtCO0FBQ3BCLFVBQUUsbUJBQW1CLENBQUNDLElBQWMscUJBQXVDO0FBQ3ZFLGNBQUk7QUFDQSxZQUFBQSxHQUFFO0FBQ0YsY0FBRSxvQkFBb0I7QUFBQSxVQUMxQixTQUFTLEdBQUU7QUFDUCw4QkFBa0IsR0FBRyxnQkFBZ0I7QUFBQSxVQUN6QztBQUFBLFFBQ0o7QUFDQSxVQUFFLHlCQUF5QixDQUFDQSxJQUF1QixxQkFBcUQ7QUFDcEcsZ0JBQU0sSUFBSUEsR0FBRTtBQUNaLGlCQUFPLEVBQUU7QUFBQSxZQUNMLE1BQU0sRUFBRSwrQkFBK0Isa0JBQWtCLFNBQVMsQ0FBQyxFQUFFO0FBQUEsWUFDckUsQ0FBQyxNQUFXO0FBQ1I7QUFDQSxnQ0FBa0IsR0FBRyxnQkFBZ0I7QUFBQSxZQUN6QztBQUFBLFVBQUM7QUFBQSxRQUNUO0FBRUEsVUFBRSwyQkFBMkIsQ0FBQyxNQUFvQixFQUFFLEtBQU0sR0FBRyxDQUFFO0FBRS9ELFVBQUUsb0JBQW9CLENBQUksR0FBTSxHQUFNLFdBQXFCO0FBQ3ZELDBCQUFZLGtCQUFBQyxTQUFNLEdBQUcsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHO0FBQUEsSUFBd0IsS0FBSyxVQUFVLENBQUMsQ0FBQztBQUFBLElBQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxFQUFFO0FBQUEsUUFDdEg7QUFBQSxNQUNKLENBQUM7QUFFRCxZQUFNLEdBQUcsS0FBSyxFQUFFLEVBQUUsRUFBRSxPQUFPO0FBQzNCLGFBQU87QUFBQSxJQUNYO0FBRUEsVUFBTSxVQUFVLENBQUMsR0FBaUIsVUFBbUI7QUFFakQsWUFBTSxRQUFTLElBQUksTUFBTSxFQUFHO0FBQzVCLGFBQU8sTUFBTSxRQUFRLFFBQVEsTUFBTyxTQUFTLENBQUMsRUFBRSxDQUFDO0FBQUEsSUFDckQ7QUFFQTtBQUFBLE1BQ0ksRUFBRTtBQUFBLFFBQ0U7QUFBQSxRQUFTO0FBQUEsUUFBVTtBQUFBLFFBQ25CLE1BQU0sQ0FBQyxNQUFjLFNBQVMsQ0FBQyxFQUFFLEtBQUs7QUFBQSxRQUN0QyxTQUFTLENBQUMsTUFBTTtBQUFFLG9CQUFVLEtBQUssQ0FBQztBQUFBLFFBQUc7QUFBQSxNQUN6QyxDQUFDO0FBQUEsTUFBRztBQUFBLElBQ1I7QUFBQSxFQUNKLENBQUM7QUFFTDs7O0FFL1ZPLElBQU0sZUFBZSxDQUFJLE1BQWtCLElBQXdCLENBQUMsTUFBMEI7QUFDakcsUUFBTSxFQUFFLGVBQWUsZUFBYyxJQUFJLFdBQVcsQ0FBQztBQUVyRCxRQUFNLFFBQTRCLENBQUM7QUFDbkMsTUFBSSxTQUdvQjtBQUN4QixNQUFJO0FBRUosUUFBTSxNQUFNLEtBQUssUUFBUTtBQUFBLElBQ3JCLE1BQU0sQ0FBQyxNQUFNO0FBQ1QsVUFBSSxTQUFTO0FBQ1QsWUFBSSxLQUFLLE9BQU07QUFDWCxrQkFBUSxDQUFDLEVBQUUsS0FBSztBQUNoQixtQkFBUztBQUFBLFFBQ2IsV0FBVyxXQUFXLEdBQUc7QUFDckIsa0JBQVEsQ0FBQyxFQUFFLEVBQUUsS0FBSztBQUFBLFFBQ3RCLFdBQVcsV0FBVyxHQUFHO0FBQ3JCLGtCQUFRLENBQUMsRUFBRSxFQUFFLEtBQUs7QUFBQSxRQUN0QjtBQUNBLGtCQUFVO0FBQUEsTUFDZCxPQUFPO0FBQ0gsY0FBTSxLQUFLLENBQUM7QUFDWixZQUFJLE1BQU0sU0FBUztBQUFnQixjQUFJLE9BQU87QUFBQSxNQUNsRDtBQUFBLElBQ0o7QUFBQSxFQUNKLENBQUM7QUFFRCxTQUFPLENBQXVCLFFBQTZEO0FBRXZGLFFBQUksT0FBTyxPQUFNO0FBQ2IsVUFBSSxZQUFZO0FBQ2hCLGFBQU87QUFBQSxJQUNYO0FBRUEsUUFBSSxNQUFNLFVBQVUsR0FBRTtBQUNsQixVQUFJLFVBQVUsVUFBUztBQUNuQixZQUFJLE9BQU87QUFDWCxpQkFBUztBQUFBLE1BQ2I7QUFBQSxJQUNKLFdBQVcsTUFBTSxTQUFTLEdBQUU7QUFDeEIsWUFBTSxJQUFJLE1BQU0sTUFBTTtBQUN0QixVQUFJLE1BQU0sU0FBUyxlQUFjO0FBQzdCLFlBQUksT0FBTztBQUNYLGlCQUFTO0FBQUEsTUFDYjtBQUNBLFVBQUksS0FBSztBQUFPLGVBQU87QUFBQSxlQUNkLFdBQVc7QUFBRyxlQUFPLEVBQUU7QUFBQTtBQUMzQixjQUFNLEVBQUU7QUFBQSxJQUNqQjtBQUVBLFFBQUksVUFBVTtBQUFVLGFBQU87QUFFL0IsV0FBTyxJQUFJLFFBQVcsQ0FBQyxHQUFFLE1BQU07QUFDM0IsZ0JBQVUsQ0FBQyxHQUFFLENBQUM7QUFBQSxJQUNsQixDQUFDO0FBQUEsRUFFTDtBQUNKO0FBNkVPLElBQU0sNEJBQTRCLENBQUksUUFBMkIsTUFBa0M7QUFTdEcsVUFBUSxJQUFJLG1EQUFtRDtBQUUvRCxNQUFJLE9BQXNDO0FBQzFDLE1BQUksVUFBVTtBQUNkLE1BQUksU0FBUztBQUNiLE1BQUksUUFBc0IsUUFBUSxRQUFRLE1BQVM7QUFFbkQsTUFBSSxTQVNFO0FBRU4sTUFBSSxJQUFJLFFBQVEsUUFBUSxJQUFJO0FBRTVCLE1BQUk7QUFFSixRQUFNQyxPQUFNLFlBQVk7QUFDcEIsUUFBSSxDQUFDLFdBQVcsUUFBUSxFQUFFLFNBQVMsTUFBTTtBQUFHO0FBQzVDLGFBQVM7QUFJVCxXQUFPLFdBQVcsYUFBYSxVQUFVLEVBQUUsYUFBWTtBQUNuRCxZQUFNLEtBQUssZUFBZSxPQUFPLE1BQVMsQ0FBQztBQUMzQyxpQkFBVztBQUVYLFVBQUksRUFBRSxnQkFBZTtBQUNqQixnQkFBUSxNQUFNLEtBQU0sWUFBWTtBQUM1QixnQkFBTSxNQUFNLE1BQU07QUFFbEIscUJBQVc7QUFFWCxjQUFJLE9BQU8sT0FBTTtBQUViLHFCQUFTO0FBQUEsVUFDYjtBQUNBLGVBQU0sS0FBSyxHQUFHO0FBQ2Qsa0JBQVE7QUFBQSxRQUNaLENBQUM7QUFBQSxNQUNMLE9BQU87QUFDSCxXQUFHLEtBQUssQ0FBQyxRQUFRO0FBQ2IscUJBQVc7QUFFWCxjQUFJLE9BQU87QUFBTyxxQkFBUztBQUFBO0FBQ3RCLGlCQUFNLEtBQUssR0FBRztBQUNuQixjQUFJLFdBQVcsS0FBSztBQUNoQixpQkFBTSxLQUFLLEtBQUs7QUFDcEIsa0JBQVE7QUFBQSxRQUNaLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSjtBQUNBLFFBQUksV0FBVztBQUFXLGVBQVM7QUFBQTtBQUM5QixlQUFTO0FBQUEsRUFFbEI7QUFFQSxZQUFVLE1BQU07QUFFWixRQUFJO0FBQVE7QUFFWixRQUFJLENBQUMsVUFBVSxXQUFXLFFBQVEsRUFBRSxTQUFTLE1BQU07QUFBRztBQUd0RCxRQUFJLFVBQVUsRUFBRSxhQUFZO0FBRXhCLFVBQUksVUFBVTtBQUFtQixRQUFBQSxLQUFJO0FBQUEsSUFDekM7QUFBQSxFQUNKO0FBR0EsUUFBTSxVQUFpQyxDQUFDLFVBQVU7QUFFOUMsUUFBSTtBQUFNLFlBQU0sTUFBTSw2QkFBNkI7QUFFbkQsV0FBTztBQUVQLFdBQU8sQ0FBQyxXQUFnQztBQUNwQyxVQUFJLFVBQVUsU0FBUztBQUNuQixZQUFJLFVBQVU7QUFBVyxtQkFBUztBQUFBLGlCQUN6QixVQUFVLFVBQVU7QUFDekIsbUJBQVM7QUFDVCxrQkFBUTtBQUFBLFFBQ1o7QUFBQSxNQUNKO0FBQ0EsVUFBSSxVQUFVO0FBQVMsaUJBQVM7QUFDaEMsVUFBSSxVQUFVLGNBQWE7QUFDdkIsaUJBQVM7QUFDVCxlQUFPLEtBQUs7QUFBQSxNQUNoQjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBRUEsU0FBTztBQUFBLElBQ0g7QUFBQSxFQUNKO0FBQ0o7QUFFTyxJQUFNLG1CQUFtQixDQUFPLFFBQzNCQyxNQUNBLE1BQ1I7QUFBQSxFQUNJLDBCQUEwQixRQUFRLFFBQVFBLElBQUcsR0FBRyxDQUFDO0FBQUEsRUFDakQ7QUFBQSxJQUFFLFlBQVksRUFBRSxjQUFjO0FBQUE7QUFBQSxFQUM5QjtBQUNKOzs7QVIzUEosSUFBTUMsU0FBUSxDQUFDLE9BQWUsSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBRTNELElBQU0seUJBQXlCLENBQUksTUFBMEI7QUFDaEUsTUFBSSxnQkFBNEQ7QUFDaEUsTUFBSSxZQUFZO0FBQ2hCLE1BQUksT0FBd0M7QUFDNUMsUUFBTSxPQUFPLE1BQU0sY0FBYyxhQUFhO0FBQzlDLFFBQU0sUUFBUSxNQUFNO0FBQ2hCLG9CQUFnQixZQUFZLE1BQU07QUFDOUIsWUFBTSxJQUFJLEVBQUUsTUFBTTtBQUNsQixVQUFJLEtBQUssUUFBVztBQUNoQixhQUFNLEtBQUssS0FBSztBQUNoQixhQUFLO0FBQUEsTUFDVCxPQUFPO0FBQ0gsYUFBTSxLQUFLLEVBQUMsT0FBTyxFQUFDLENBQUM7QUFBQSxNQUN6QjtBQUFBLElBQ0osR0FBRyxFQUFFO0FBQUEsRUFDVDtBQUVBLFFBQU0sVUFBb0MsQ0FBQyxVQUFVO0FBQ2pELFFBQUk7QUFBVyxZQUFNLE1BQU0sR0FBRztBQUM5QixXQUFPO0FBQ1AsZ0JBQVk7QUFDWixXQUFPLENBQUMsV0FBbUM7QUFDdkMsVUFBSSxVQUFVO0FBQVMsY0FBTTtBQUM3QixVQUFJLFVBQVU7QUFBUyxhQUFLO0FBQzVCLFVBQUksVUFBVTtBQUFjLGFBQUs7QUFBQSxJQUNyQztBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQUEsSUFDSDtBQUFBLEVBQ0o7QUFDSjtBQUVPLElBQU0sWUFBWSxDQUFJLFFBQWdDLFVBQTBDO0FBQ25HLFFBQU0sV0FBVyxjQUFjLE1BQU0sS0FBSztBQUMxQyxTQUFRLE9BQU8sUUFBZ0I7QUFDM0IsVUFBTSxTQUFTO0FBQ2YsV0FBTyxPQUFPLEdBQUc7QUFBQSxFQUNyQjtBQUNKO0FBRUEsZ0JBQWdCO0FBQUEsRUFDZCxlQUFlO0FBQUEsRUFDZixXQUFZO0FBQ2QsR0FBRyxPQUFPLE1BQU07QUFFWixNQUFJLFFBQTJEO0FBQUEsSUFFdkQsMEJBQTBCLE9BQU8sTUFBTTtBQUNuQyxZQUFNLGNBQWMsdUJBQXVCLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQztBQUNsRCxZQUFNLGNBQWMsYUFBYSxXQUFXO0FBQzVDLFFBQUU7QUFBQSxRQUNFLENBQUMsR0FBRSxHQUFFLENBQUM7QUFBQSxRQUNOLE1BQVUsYUFBYSxXQUFXO0FBQUEsTUFDdEM7QUFBQSxJQUNKO0FBQUEsSUFJQSxjQUFjLE9BQU8sTUFBTTtBQUN2QixVQUFJLFVBQWMsZUFBZSxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUMsRUFBRTtBQUMxQyxVQUFJLFVBQWMsZUFBZSxDQUFDLEtBQUssS0FBSyxHQUFHLENBQUMsRUFBRTtBQUNsRCxZQUFNLFNBQWEsUUFBUSxDQUFDLEdBQUcsU0FBUyxPQUFPO0FBQy9DLFFBQUU7QUFBQSxRQUNFLENBQUMsQ0FBQyxHQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7QUFBQSxRQUMzQixNQUFVLGFBQWEsTUFBTTtBQUFBLE1BQ2pDO0FBQ0EsUUFBRSxLQUFLLDJCQUEyQjtBQUFBLElBQ3RDO0FBQUEsSUFFQSwwQkFBMEIsT0FBTyxNQUFNO0FBQ3ZDLFVBQUksU0FBYSxlQUFlLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQyxFQUFFO0FBQ3pDLGVBQVMsVUFBVSxRQUFRLEVBQUU7QUFDN0IsZUFBYSxhQUFhLE1BQU07QUFDaEMsUUFBRTtBQUFBLFFBQ0UsQ0FBQyxHQUFFLEdBQUUsQ0FBQztBQUFBLFFBQ04sTUFBVSxhQUFhLE1BQU07QUFBQSxNQUNqQztBQUFBLElBQ0o7QUFBQSxJQUVBLHNCQUFzQixPQUFPLE1BQU07QUFDL0IsVUFBSSxTQUFhLGVBQWUsQ0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsQ0FBQyxFQUFFO0FBQzdDLGVBQVMsVUFBVSxRQUFRLEVBQUU7QUFDN0IsZUFBYSxhQUFhLFFBQVEsRUFBRSxZQUFZLEVBQUMsZUFBZSxHQUFHLGdCQUFnQixFQUFFLEVBQUMsQ0FBQztBQUN2RixlQUFTLFVBQVUsUUFBUSxFQUFFO0FBQzdCLFFBQUU7QUFBQSxRQUNFLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDO0FBQUEsUUFDVixNQUFVLGFBQWEsTUFBTTtBQUFBLE1BQ2pDO0FBQUEsSUFDSjtBQUFBLElBRUEsdUJBQXVCLE9BQU8sTUFBTTtBQUNoQyxZQUFNLFNBQVksV0FBVyxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFDcEMsUUFBRTtBQUFBLFFBQ0UsQ0FBQyxHQUFFLEdBQUUsQ0FBQztBQUFBLFFBQ0gsU0FBUyxPQUFPLElBQUk7QUFBQSxNQUMzQjtBQUFBLElBQ0o7QUFBQTtBQUFBLElBSUEsOEJBQThCLE9BQU8sTUFBTTtBQUN2QyxZQUFNLFNBQVksV0FBVyxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFDcEMsWUFBTSxTQUFZLElBQUksT0FBTyxNQUFNLENBQUMsTUFBTSxJQUFJLENBQUM7QUFDL0MsUUFBRTtBQUFBLFFBQ0UsQ0FBQyxHQUFFLEdBQUUsQ0FBQztBQUFBLFFBQ0gsU0FBUyxNQUFNO0FBQUEsTUFDdEI7QUFBQSxJQUNKO0FBQUE7QUFBQSxJQUdJLHNCQUFzQixPQUFPLE1BQU07QUFDbkMsWUFBTSxTQUFhLGVBQWUsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxDQUFDO0FBQ3pDLFFBQUU7QUFBQSxRQUNFLENBQUMsR0FBRSxHQUFFLENBQUM7QUFBQSxRQUNOLE1BQVUsYUFBYSxPQUFPLElBQUk7QUFBQSxNQUN0QztBQUFBLElBQ0o7QUFBQSxJQUVBLHVCQUF1QixPQUFPLE1BQU07QUFDaEMsWUFBTSxTQUFhLGVBQWUsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFHLEVBQUMsTUFBTSxNQUFLLENBQUM7QUFDeEQsYUFBTyxLQUFLLEdBQUUsR0FBRSxDQUFDO0FBQ2pCLGFBQU8sS0FBSztBQUNaLFFBQUU7QUFBQSxRQUNFLENBQUMsR0FBRSxHQUFFLEdBQUcsR0FBRSxHQUFFLENBQUM7QUFBQSxRQUNiLE1BQVUsYUFBYSxPQUFPLElBQUk7QUFBQSxNQUN0QztBQUFBLElBQ0o7QUFBQSxJQUVBLG9DQUFvQyxPQUFPLE1BQU07QUFDN0MsWUFBTSxTQUFhLGVBQWUsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFHLEVBQUMsTUFBTSxNQUFLLENBQUM7QUFDeEQsWUFBTSxTQUFhLFFBQVEsT0FBTyxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDMUQsYUFBTyxLQUFLLEdBQUUsR0FBRSxDQUFDO0FBQ2pCLGFBQU8sS0FBSztBQUNaLFFBQUU7QUFBQSxRQUNFLENBQUMsR0FBRSxHQUFFLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFBQSxRQUNqQixNQUFVLGFBQWEsTUFBTTtBQUFBLE1BQ2pDO0FBQUEsSUFDSjtBQUFBO0FBQUEsSUFHQSxrQkFBa0IsT0FBTyxNQUFNO0FBQzNCLFFBQUUsWUFBWSxJQUFJO0FBQ2xCLFlBQU0sS0FBSyxFQUFFLFNBQVMsbUJBQW1CO0FBQ3pDLFlBQU0sS0FBSyxFQUFFLFNBQVMsbUJBQW1CO0FBQ3pDLFlBQU0sU0FBYSxlQUFlLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQztBQUV6QyxZQUFNLFNBQWEsUUFBUSxPQUFPLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUMxRCxZQUFNLElBQVEsZ0JBQWdCLFFBQVEsRUFBQyxTQUFTLEtBQUksQ0FBQztBQUVyRCxZQUFNLEtBQUssRUFBRSxPQUFPO0FBQ3BCLFlBQU0sS0FBSyxFQUFFLE9BQU87QUFFcEIsWUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLE1BQU0sUUFBUSxJQUFJO0FBQUEsUUFDM0IsYUFBYSxFQUFFO0FBQUEsUUFDZixhQUFhLEVBQUU7QUFBQSxNQUN2QixDQUFDO0FBQ0QsU0FBRyxrQkFBbUIsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFHLEVBQUU7QUFDakMsU0FBRyxrQkFBbUIsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxHQUFHLEVBQUU7QUFBQSxJQUNyQztBQUFBLElBR0Esa0JBQWtCLE9BQU8sTUFBTTtBQUMzQixZQUFNLFVBQWMsZUFBZSxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFDMUMsWUFBTSxVQUFjLGVBQWUsQ0FBQyxDQUFDO0FBQ3JDLFlBQU0sVUFBYyxlQUFlLENBQUMsR0FBRSxHQUFFLENBQUMsQ0FBQztBQUMxQyxZQUFNLElBQVEsVUFBVSxFQUFDLFNBQVMsQ0FBQyxRQUFRLE1BQU0sUUFBUSxNQUFNLFFBQVEsSUFBSSxFQUFDLENBQUM7QUFDN0UsUUFBRTtBQUFBLFFBQ0UsTUFBVSxhQUFhLEVBQUUsSUFBSTtBQUFBLFFBQzdCLENBQUMsR0FBRSxHQUFFLEdBQUcsR0FBRSxHQUFFLENBQUM7QUFBQSxNQUNqQjtBQUFBLElBQ0o7QUFBQSxJQUVDLG1CQUFtQixPQUFPLE1BQU07QUFDN0IsWUFBTSxTQUFhLGNBQWtCLGVBQWUsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDO0FBQ3BFLFFBQUU7QUFBQSxRQUNFLE1BQVUsYUFBYSxNQUFNO0FBQUEsUUFDOUIsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDYjtBQUFBLElBQ0o7QUFBQSxJQUVBLHVCQUF1QixPQUFPLE1BQU07QUFDaEMsWUFBTSxVQUFjLGVBQWUsQ0FBQyxHQUFFLEdBQUUsQ0FBQyxDQUFDO0FBQzFDLFlBQU0sVUFBYyxlQUFlLENBQUMsQ0FBQztBQUNyQyxZQUFNLFVBQWMsZUFBZSxDQUFDLEdBQUUsR0FBRSxDQUFDLENBQUM7QUFDMUMsWUFBTSxJQUFRLFVBQVUsRUFBQyxTQUFTLENBQUMsUUFBUSxJQUFJLEdBQUcsTUFBTSxNQUFLLENBQUM7QUFFOUQsaUJBQVcsTUFBTTtBQUNULFVBQUUsS0FBSyxRQUFRLE1BQU0sUUFBUSxJQUFJO0FBQ2pDLFVBQUUsS0FBSztBQUFBLE1BQ2YsR0FBRyxHQUFHO0FBRU4sUUFBRTtBQUFBLFFBQ0UsTUFBVSxhQUFhLEVBQUUsSUFBSTtBQUFBLFFBQzdCLENBQUMsR0FBRSxHQUFFLEdBQUcsR0FBRSxHQUFFLENBQUM7QUFBQSxNQUNqQjtBQUFBLElBQ0o7QUFBQSxJQUVJLHdCQUF3QixPQUFPLE1BQU07QUFDckMsUUFBRSxZQUFZLElBQUk7QUFDbEIsWUFBTSxZQUFZLEVBQUUsU0FBUyxXQUFXO0FBQ3hDLFlBQU0sY0FBYyxFQUFFLFNBQVMsYUFBYTtBQUU1QyxZQUFNLElBQUksQ0FBQyxtQkFDUDtBQUFBLFFBQ1EsZUFBZSxDQUFDLElBQUcsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsQ0FBQyxFQUFFO0FBQUEsUUFDdkMsT0FBTyxNQUFNO0FBQ1QsZ0JBQU1BLE9BQU0sSUFBSSxFQUFFO0FBQ2xCLGlCQUFPO0FBQUEsUUFDWDtBQUFBLFFBQ0EsRUFBQyxnQkFBZ0IsYUFBYSxHQUFFO0FBQUEsTUFDeEM7QUFNSixrQkFBWTtBQUFBLFFBQ1IsQ0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxFQUFFO0FBQUEsUUFDckIsTUFBVSxhQUFhLEVBQUUsS0FBSyxDQUFDO0FBQUEsTUFDbkM7QUFFQSxnQkFBVTtBQUFBLFFBQ04sQ0FBQyxJQUFHLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxDQUFDO0FBQUEsUUFDckIsTUFBVSxhQUFhLEVBQUUsSUFBSSxDQUFDO0FBQUEsTUFDbEM7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUlBLFFBQU0sUUFBUTtBQUFBLElBQ1YsT0FBTyxRQUFRLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFFLENBQUMsTUFBTSxFQUFFLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQ3pEO0FBRUEsSUFBRSxLQUFLLHNDQUFzQztBQUM3QyxJQUFFLEtBQUssa0RBQWtEO0FBQ3pELElBQUUsS0FBSyxrQ0FBa0M7QUFFN0MsQ0FBQyxFQUFFLEtBQUssUUFBUSxLQUFLLFFBQVEsR0FBRzsiLAogICJuYW1lcyI6IFsiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAicmVxdWlyZV9pbXBsZW1lbnRhdGlvbiIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJjb25jYXR0eSIsICJzbGljeSIsICJFbXB0eSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJ1bmRlZmluZWQiLCAiZG9FdmFsIiwgInN0cmluZ1RvUGF0aCIsICJnZXRCYXNlSW50cmluc2ljIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImhhc1Byb3BlcnR5RGVzY3JpcHRvcnMiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAibWFwIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImFwcGx5QmluZCIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJyZXF1aXJlX2ltcGxlbWVudGF0aW9uIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgIm1hcCIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJmdW5jdGlvbnNIYXZlTmFtZXMiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAicmVxdWlyZV9pbXBsZW1lbnRhdGlvbiIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJyZXF1aXJlX3BvbHlmaWxsIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgInJlcXVpcmVfc2hpbSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJyZXF1aXJlX2ltcGxlbWVudGF0aW9uIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgInJlcXVpcmVfcG9seWZpbGwiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAicmVxdWlyZV9zaGltIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgInJlcXVpcmVfc2hhbXMiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAidHJ5U3RyaW5nT2JqZWN0IiwgImV4cG9ydHMiLCAibW9kdWxlIiwgInRyeU51bWJlck9iamVjdCIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJmb3JFYWNoQXJyYXkiLCAiZm9yRWFjaFN0cmluZyIsICJmb3JFYWNoT2JqZWN0IiwgImZvckVhY2giLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAibWFwIiwgIm1hcCIsICJtYXAiLCAibyIsICJydW4iLCAiZSIsICJmIiwgImVxdWFsIiwgInJ1biIsICJtYXAiLCAic2xlZXAiXQp9Cg==
