export type MaybePromise<T> = T | Promise<T>

export type Resolve<T> = (r:T) => void
export type Reject = (e:any) => void

export type ResolveReject<T> = {
    resolve: Resolve<T>,
    reject: Reject,
}

export type ResolveRejectArray<R> = [ Resolve<R>, Reject ]

export const call_to_resolve = <T>(f: () => T, rra: ResolveRejectArray<T>) => {
    const [r,j] = rra
    try {
        r(f())
    } catch (e) {
        j(e)
    }
}

export const call_to_resolve_async = async <T>(f: () => Promise<T>, rra: ResolveRejectArray<T>) => {
    const [r,j] = rra
    try {
        r( await f())
    } catch (e) {
        j(e)
    }
}
