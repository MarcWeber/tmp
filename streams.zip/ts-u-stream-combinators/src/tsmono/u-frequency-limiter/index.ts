// usage:
// const getToken = createLimiter(() => 100)
// while (true); { await getToken(); ..}
export type GetToken = () => Promise<void>

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

export const createLimiter = (ms_fun: () => number): () => Promise<void> => {
    let last: undefined | number = undefined
    // returns getToken() function to be awaited for
    return async (): Promise<void> => {
        const wait = ms_fun()
        const n = (new Date).getTime()
        if (!last){
            last = n
            return; // first run
        }
        const sleep_ms = wait - (n - last)
        if (sleep_ms > 0) await sleep(sleep_ms)
        last = n + sleep_ms
        return 
    }
}

// createRandomLimiter(200, 2000) random interval between 200 and 2000 ms
export const createRandomLimiter = (ms: [ number, number]) => createLimiter(() => ms[0] + (ms[1] - ms[0]) * Math.random())
