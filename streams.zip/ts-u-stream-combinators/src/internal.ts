import { S_end, t_end } from "./symbols";
import { MaybePromise, ResolveRejectArray } from "u-promise";

export type ValueErrorEnd<T> = { value: T } | { error: any } | t_end

export const vee_to_p_handler = <T>(v: ValueErrorEnd<T>, p_handlers: ResolveRejectArray<T | t_end>) => {
    if (v === S_end)
        p_handlers[0](S_end) 
    else if ('value' in v)
        p_handlers[0](v.value) 
    else p_handlers[1](v.error)
}

export const vee_to_value = <T>(v: ValueErrorEnd<T>): T | t_end => {
    if (v === S_end)
        return S_end
    else if ('value' in v)
        return v.value
    else throw v.error
}

export const promise_to_vee = async <T>(p: MaybePromise<T | t_end>): Promise<ValueErrorEnd<T>> => {
    try {
        const v = await p
        if (v === S_end) return S_end
        return { value: v }
    } catch (e) {
        return {error: e}
    }
}

export type HighLow = { high_watermark: number, low_watermark: number }
export type HighLowOrWatermark = 
      { watermarks?: number | HighLow}

export const watermarks = (hl: HighLowOrWatermark): HighLow => {
    const w = hl.watermarks
    if (!w) return { low_watermark: 20, high_watermark: 100 }
    return (typeof w == 'number') ? { low_watermark: w, high_watermark: w * 10 } : w
}
