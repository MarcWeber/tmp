import { aps_map, AsyncPullStream } from "../pull/async"
import { AddSink, PushSourceApiSignal, PushSourcePush} from "../push"
import { MaybePromise, ResolveRejectArray } from "u-promise"
import { S_disconnect, S_ending, S_pause, S_paused, S_running, S_start, S_end, t_end, S_pausing, S_paused_internal } from "../symbols"
import { HighLowOrWatermark, promise_to_vee, ValueErrorEnd, watermarks } from "/internal"
import { PullStream } from "/pull"

export const push_to_pull = <T>(push: AddSink<T>, o: HighLowOrWatermark = {}): AsyncPullStream<T> => {
    const { low_watermark, high_watermark} = watermarks(o)

    const items: ValueErrorEnd<T>[] = []
    let status: 
        typeof S_running
        | typeof S_ending
        | typeof S_paused = S_paused
    let waiting: undefined | ResolveRejectArray<T | t_end>

    const api = push.addSink({
        push: (t) => {
            if (waiting) {
                if (t == S_end){
                    waiting[0](S_end)
                    status = S_ending
                } else if ("value" in t) {
                    waiting[0](t.value)
                } else if ("error" in t) {
                    waiting[1](t.error)
                }
                waiting = undefined
            } else {
                items.push(t)
                if (items.length > high_watermark) api(S_pause)
            }
        }
    })

    return <O extends T | t_end >(end?: O): MaybePromise<O extends t_end ? any : T | t_end> => {

        if (end == S_end){
            api(S_disconnect)
            return S_end
        }

        if (items.length == 0){
            if (status == S_paused){
                api(S_start)
                status = S_running
            }
        } else if (items.length > 0){
            const x = items.shift()!
            if (items.length < low_watermark){
                api(S_start)
                status = S_running
            }
            if (x == S_end) return S_end
            else if ('value' in x) return x.value
            else throw x.error
        }

        if (status == S_ending) return S_end

        return new Promise<T>((r,j) => {
            waiting = [r,j]
        })

    }
}

export const pull_to_push = <T>(stream: AsyncPullStream<T>) => {
    // not tested very well yet
    // see aps_buffered i
    // run can only be interrupted at await.
    // so pausing can be resumed without interrupting run
    // if it didn't quit the loop yet

    let sink: PushSourcePush<T> | undefined = undefined

    let status: 
        typeof S_paused
        | typeof S_pausing
        | typeof S_ending // ended
        | typeof S_running
        = S_paused

    let p = Promise.resolve(null)

    const run = async () => {
        if ([S_running, S_ending].includes(status)) return
        status = S_running
        while (status === S_running){
            try {
                // you can only start if sink is assigned
                const v = await promise_to_vee(stream())
                sink!.push(v)
                if (v == S_end){
                    status = S_ending
                    break
                }
            } catch (e) {
                // TODO what should happen if sink causes an error?
                // It's not really the responsibility of this code
                console.log(e);
            }
        }
        if (status = S_pausing) status = S_paused
    }

    const addSink: AddSink<T>["addSink"] = (_sink) => {

        if (sink) throw Error('only one sink can be added!')

        sink = _sink

        return (signal: PushSourceApiSignal) => {
            if (signal == S_start) {
                if (status == S_pausing) status = S_running
                else run()
            }
            if (signal == S_pause) status = S_pausing
            if (signal == S_disconnect){
                status = S_ending
                stream(S_end)
            }
        }
    }

    return {
        addSink
    }
}


export type pull_to_push_concurrently = 
{ concurrency: number, preserve_order: boolean }

// usage:
// See map_concurrently or
// push_to_pull(pull_to_push_concurrently(stream, {concurrency: 20, preserve_order: true}))
// preserve_order=true: results will always be returned in order (might be slower because one long running item can block all)
// preserve_order=false: if one run takes long (eg timeout) the others continue feeding the stream
//
// TODO: 
// concurrency=1: special case should behave like pull_to_push and preserve_order doesn't matter
export const pull_to_push_concurrently = <T>(stream: AsyncPullStream<T>,o : pull_to_push_concurrently) => {
    // this could push S_end multiple times beacuse promises get started before the S_end might be recieved !
    // not tested very well yet
    //
    // TODO: some of the aps_* stream function require the returned promises 
    // to be awaited for thus will not play well along with this
    // Whose responsibility is this ?
    //
    // I guess this requires many test cases because wrong order ending etc there are many cases
    console.log(`warning pull_to_push_concurrently not well tested`);

    let sink: PushSourcePush<T> | undefined = undefined
    let running = 0
    let ending = false // any returned S_end
    let order: Promise<any> = Promise.resolve(undefined)

    let status: typeof S_pausing
        | typeof S_ending // disconnect
        | typeof S_running
        | typeof S_paused_internal

        // external wish to pause
        | typeof S_paused 
        | typeof S_pausing 

        = S_paused

    let p = Promise.resolve(null)

    let restart: () => void

    const run = async () => {
        if ([S_running, S_ending].includes(status)) return
        status = S_running

        //console.log({ status, running, concurrency: o.concurrency });

        while (status === S_running && running < o.concurrency){
            const p_ = promise_to_vee(stream(undefined))
            running += 1
            // console.log(`running ${running}`);
            if (o.preserve_order){
                order = order.then( async () => {
                    const res = await p_
                    // console.log(`res ${res.toString()} ${JSON.stringify(res)} ${status.toString()}`);
                    running -= 1
                    // console.log(`running ${running}`);
                    if (res == S_end){
                        // console.log("ENDING and pushing it!");
                        ending = true
                    }
                    sink!.push(res)
                    restart()
                })
            } else {
                p_.then((res) => {
                    running -= 1
                    // console.log(`running ${running}`);
                    if (res == S_end) ending = true
                    else sink!.push(res)
                    if (running == 0 && ending)
                        sink!.push(S_end)
                    restart()
                })
            }
        }
        if (status === S_pausing) status = S_paused
        else status = S_paused_internal
        // console.log(`running ended ${status.toString()}`);
    }

    restart = () => {
        // console.log("restarting1");
        if (ending) return
        // console.log("restarting2");
        if ([S_paused, S_pausing, S_ending].includes(status)) return
        // console.log("restarting3");
        // console.log({running, concurrency: o.concurrency, status});
        if (running < o.concurrency){
            // console.log("restarting4");
            if (status == S_paused_internal) run()
        }
    }


    const addSink: AddSink<T>["addSink"] = (_sink) => {

        if (sink) throw Error('only one sink can be added!')

        sink = _sink

        return (signal: PushSourceApiSignal) => {
            if (signal == S_start) {
                if (status == S_pausing) status = S_running
                else if (status == S_paused) {
                    status = S_paused_internal
                    restart()
                }
            }
            if (signal == S_pause) status = S_pausing
            if (signal == S_disconnect){
                status = S_ending
                stream(S_end)
            }
        }
    }

    return {
        addSink
    }
}

export const map_concurrently = <I, O>(stream: AsyncPullStream<I>, 
            map: (item: I) => Promise<O>,
            o: pull_to_push_concurrently & HighLowOrWatermark) =>
    push_to_pull(
        pull_to_push_concurrently(aps_map(stream, map), o), 
        { watermarks: o.watermarks ?? 0 /* will accept pushin anyway, default to don't requset more than required */ 
        }
    )
