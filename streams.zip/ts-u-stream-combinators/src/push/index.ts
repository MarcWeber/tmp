import { ValueErrorEnd } from "/internal"
import { PullStream} from "/pull"
import { AsyncPullStream } from "/pull/async"
import { S_disconnect, S_pause, S_start, S_end, t_end } from "/symbols"
import { MaybePromise, ResolveRejectArray } from "u-promise"

export type PushSourceApiSignal = 
    typeof S_start /* resume */
    | typeof S_pause
    | typeof S_disconnect

export type PushSourceAPI = (signal: PushSourceApiSignal ) => void

export type AddSink<T> = {
    addSink(sink: PushSourcePush<T>): PushSourceAPI
}
export type PushFun<T> = (t: ValueErrorEnd<T>) => void
export type PushSourcePush<T> = { push: PushFun<T> }
export type PushStream<T> = PushSourcePush<T> & AddSink<T>
