import { _to_iter, PullStream } from "./"
import { MaybePromise, ResolveRejectArray } from "u-promise"
import { t_end, S_end } from "../symbols"
import { HighLowOrWatermark, promise_to_vee, ValueErrorEnd, vee_to_p_handler, vee_to_value, watermarks } from "../internal"

export type AsyncPullStream<T> = <O extends undefined | t_end >(o?: O) => MaybePromise<O extends t_end ? any : T | t_end>

// would class be a better interface ? (new FromArray([]).push().end()
export type from_array_options = { done?: boolean }

export const aps_from_array = <T>(buffer: T[] = [], o: from_array_options = {}) => {
    let ending: boolean = false
    let _buffer: undefined | T[] = buffer
    let p_handlers: undefined | ResolveRejectArray<T | t_end> = undefined
    let done = o.done ?? true

    let complete = false

    const push = (...i: T[]) => {
        if (p_handlers){
            p_handlers[0](i.shift())
            p_handlers = undefined
        }
        buffer.push(...i)
    }
    const next: AsyncPullStream<T> = async () => new Promise((r,j) => {
        if (!_buffer){
            return S_end // end
        }
        if (_buffer.length == 0){
            if (p_handlers) throw Error('p_handlers set, called iterator without waiting for previous result')
            if (done) r(S_end)
            else p_handlers = [r,j]
        } else {
            r(_buffer.shift()!)
        }
    })
    const end = () => { 
        if (!_buffer) return
        ending = true;
        if (_buffer.length == 0) _buffer = undefined
        if (p_handlers) p_handlers[0](S_end)
    }

    return {
        push, // you can push, append replace whatever you want
        end,
        next,
        done: () => done = true
    }
}
export const aps_map = <A, B>(i: AsyncPullStream<A>, map: (a:A) => MaybePromise<B>): AsyncPullStream<B> => async (e) => {
    if (e == S_end) {
        await i(S_end)
        return S_end
    }
    const v = await i()
    return v == S_end ? S_end : await map(v)
}

export const aps_filter = <T>(i: PullStream<T>, filter: (a:T) => MaybePromise<boolean>): AsyncPullStream<T> => async (e) => {
    if (e == S_end){
        await i(S_end)
        return S_end
    }
    let v = await i()
    if (v == S_end) return S_end
    while (v !== undefined && ! await filter(v)){
        v = await i()
        if (v == S_end)
        return S_end
    }
    return v
}

export const aps_to_iter = <T>(i: AsyncPullStream<T>) => ({
        [Symbol.asyncIterator]: () => ({
            next: async () => _to_iter( await i(undefined))
        })
})

export const aps_to_array = async <T>(i: AsyncPullStream<T>): Promise<T[]> => {
    const r: T[] = []
    for await (const v of aps_to_iter(i)) {
        r.push(v)
    }
    return r
}

// ended by source returning "end" -> will be passed to all
// ended by end() -> will S_end "end" to all consumers once asked
export const aps_multiplexer = <T>(s: AsyncPullStream<T>, o: { autoend: boolean } = { autoend: true}) => {

    let _complete = false
    let _ending = false

    const sources: Array< undefined | {
        waiting: ResolveRejectArray<T> | undefined
    }> = []

    const end = () => {
        _ending = true
        s(S_end)
    }

    const try_end = () => {
        if (!sources.find((x) => x) && o.autoend){
            // all sources gone, ..
            end()
        }
    }

    const try_fill = async () => {
        if (_complete) {
        } else {
            if (!sources.find((x) => x && !x.waiting)){
                 // all waiting
                const f = await s().then(
                    (v) => (x: ResolveRejectArray<T>) => x[0](v),
                    (v) => (x: ResolveRejectArray<T>) => x[1](v)
                )
                for (let v of sources) {
                    if (v) {
                        f(v.waiting!) 
                        v.waiting = undefined
                    }
                }
            }
        }
    }

    const complete = () => {
        _complete = true
        try_fill()
    }

    return {
        end,
        complete, // starts asking if all targets started asking
        source: () => {
            const id = sources.length
            sources.push({ waiting: undefined })
            const stream = (<O extends T | t_end>(o?: O): MaybePromise<O extends t_end ? t_end : T | t_end> => {
                if (o == S_end){
                    sources[id] = undefined
                    try_end()
                }
                if (_ending) return S_end

                if (sources[id]?.waiting) throw Error('you failed awaiting previous Promise')
                return new Promise((r,j) => {
                    sources[id]!.waiting = [r,j]
                    try_fill()
                })
            }) as AsyncPullStream<T>
            return stream
        }
    }
}


export type aps_QueOptions<T> = {
    done?: boolean
    streams: AsyncPullStream<T>[]
}

export const aps_queue = <T>(o: aps_QueOptions<T>) => {
    const streams = o.streams
    let  done = o.done ?? true
    let p_handlers: undefined | [any, any] = undefined
    let trying_next: Promise<any> | undefined = undefined

    const try_next = async () => {
        while (true){
            if (streams.length == 0){
                if (done){
                    p_handlers![0](S_end)
                    p_handlers = undefined
                }
                return 
            }
            try {
                const v = await streams[0]()
                if (v == S_end){
                    streams.shift()
                } else {
                    p_handlers![0](v)
                    p_handlers = undefined
                    return
                }
            } catch (e) {
                p_handlers![1](e)
                p_handlers = undefined
                return
            }
        }
    }

    const push = async (..._streams: AsyncPullStream<T>[]) => {
        if (trying_next) await trying_next
        streams.push(..._streams)
        if (p_handlers){
            trying_next = try_next()
        }
    }

    const next = (async (end) => {
        if (end == S_end){
            for (let s of streams) {
                s(S_end)
            }
        }
        if (p_handlers) throw Error('p_handlers set, called iterator without waiting for previous result')
        const p = new Promise((r,j) => p_handlers = [r,j])
        trying_next = try_next()
        return p

    }) as AsyncPullStream<T>

    return {
        push,
        next,
        done: () => { done = true; }
    }
}


export const aps_items_from_array = <T>(stream: AsyncPullStream<T[]>): AsyncPullStream<T> => {

    let array: T[] = []

    return (async (end?: t_end) => {

        if (end == S_end){
            stream(S_end)
            return S_end
        }

        while (array.length == 0){
            const v = await stream()
            if (v == S_end){
                return S_end
            }
            array = v
        }
        return array.shift()!
    })
}

// basically this is   pull_to_push and push_to_pull (push_to_pull contains buffering because it has to start/stop 
// the source stream
export const aps_buffered = <T>(stream: AsyncPullStream<T>, o: HighLowOrWatermark = {}): AsyncPullStream<T> => {
    const { low_watermark, high_watermark} = watermarks(o)

    const buffer: ValueErrorEnd<T>[] = []
    let p_handlers: undefined | ResolveRejectArray<T | t_end> = undefined

    let running = false
    const run = async () => {
        if (running) return 
        running = true
        try {
            while ( buffer.length < high_watermark){
                const v = await promise_to_vee(stream())
                if (p_handlers) { vee_to_p_handler(v, p_handlers); p_handlers = undefined; }
                else buffer.push(v)
                if (v == S_end) break
            }
        } finally {
            running = false
        }
    }

    return (async (end?: t_end) => {

        if (end == S_end){
            stream(S_end)
            return S_end
        }

        if (buffer.length > 0){
            const r = buffer.shift()!
            if (buffer.length < low_watermark)
                run()
            return vee_to_value(r)
        } else {
            const p = new Promise<T>((r,j) => { p_handlers = [r,j] })
            run()
            return p
        }
    }) as AsyncPullStream<T>
}

export type aps_zip_o = {
    end_on_first_end?: boolean // defaults to true
}

// zip values of one or more streams as [v1,v2]
export const aps_zip = <T extends AsyncPullStream<unknown>[]>(o: aps_zip_o, ...streams: T): AsyncPullStream<{ [K in keyof T]: T[K] extends (infer U)[] ? U : never }> => {

    const end_all = () => Promise.all(streams.map((x) => x(S_end)))
    const c = streams.length

    return (async (end?: t_end) => {

        // TODO would be nice if we added hints which stream caused an an issue
        const values = await Promise.all(streams.map((x) => x()))

        const count_ends = values.filter((x) => x === S_end).length

        if (count_ends > 0 && (o.end_on_first_end ?? true)){
            end_all() // TODO await or let go ?
            return S_end
        } else if (count_ends == c) {
            end_all() // TODO await or let go ?
            return S_end
        }

        return values

    }) as AsyncPullStream<T>
}

// chunk count items into an array
export const aps_partition = <T>(stream: AsyncPullStream<T>, count: number): AsyncPullStream<T[]> => {
    let ending = false
    return (async (end?: t_end) => {
        if (end) return stream(S_end)
        if (ending) return S_end
        const a: T[] = []
        for (var i = 0; i < count ; i++) {
           const v = await stream()
           if (v == S_end){
               ending = true
               break;
           } else a.push(v)
        }
        return a
    })
}


export type aps_concurrent_opts = {
    preserve_order: boolean,
    concurrency: number
}

// aps_onend(stream, () => { .. })
export const aps_onend = <T>(stream: AsyncPullStream<T>, onEnd: () => void): AsyncPullStream<T> => {
    let ended = false
    const e = () => { ended = true; onEnd() }
    return async (end?: t_end) => {
        const s = stream(end) // end stream before e() in case e() throws
        if (end){ e(); }
        if (await s == S_end) e()
        return s
    }
}
