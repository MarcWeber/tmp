export type Progress = {done: number, total: number} | undefined
export type ProgressWithValue<T> = { progress?: Progress, value: T }
