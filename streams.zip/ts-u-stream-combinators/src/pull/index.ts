// just pass simple values
// no progress information

import { t_end, S_end } from "../symbols"

export const eofi = Symbol('end-of-function-iterator')

export type PullStream<T> = <O extends undefined | t_end >(o?: O) => O extends t_end ? t_end : T | t_end

export const from_array = <T>(buffer: T[] = []) => {
    // doesn't allow waiting for items to be pushed,
    // use ./async's version instead
    const push = (...i: T[]) => buffer.push(...i)
    const next: PullStream<T> = ( (end) => {
        if ( end == S_end) return S_end
        return ((buffer.length == 0) ? S_end : buffer.shift()!)
    }) as PullStream<T>
    return {
        push, // you can push, append replace whatever you want
        next
    }
}

export const map = <A,B>(i: PullStream<A>, map: (a:A) => B): PullStream<B> => (e) => {
    if (e == S_end) return i(S_end)
    else {
        const v = i(e)
        return (v === S_end) ? S_end : map(v)
    }
}


export const filter = <T>(i: PullStream<T>, filter: (a:T) => boolean): PullStream<T> => (e) => {
    let v = i(e)
    while (v !== S_end && !filter(v)){
        v = i(e)
    }
    return v
}

export const _to_iter = <T>(x: T) => ({ done:x === S_end , value: x as Exclude<T, undefined | t_end> })

export const to_iter = <T>(i: PullStream<T>) => {
    return {
        [Symbol.iterator]: () => ({
            next: () => _to_iter(i(undefined))
        })
    }
}

export const to_array = <T>(i: PullStream<T>): T[] => {
    const r: T[] = []
    while (true){
        const v = i()
        if (v == S_end) break
        else r.push(v)
    }
    for (const v of to_iter(i)) {
        r.push(v)
    }
    return r
}
