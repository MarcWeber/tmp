export const S_end = Symbol("end")
export type t_end = typeof S_end

export const S_running = Symbol("running")
export const S_ending = Symbol("ending")
export const S_paused = Symbol("paused")
export const S_pausing = Symbol("pausing")

export const S_pause = Symbol("pause")
export const S_start = Symbol("start")
export const S_disconnect = Symbol("disconnect")

// sink wants to pause
export const S_paused_internal = Symbol('paused_external')
