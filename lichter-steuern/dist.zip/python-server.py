import sys, os, logging, re
from aiohttp import web, ClientSession

"""
Liest verzeichnis/index.html und mp3 dateien
forwarded /http(s)/.... requests
pip install aiohttp
"""

async def make_app(static_dir):
    app = web.Application()
    s = ClientSession()

    @web.middleware
    async def proxy(request, handler):
        path = request.path.lstrip('/')
        if re.match(r'^https?/', path):
            url = path.replace('/', '://', 1)
            if request.query_string: url += f"?{request.query_string}"
            request.app.loop.create_task(s.get(url, timeout=5))
            return web.Response(status=200)
        return await handler(request)

    app.middlewares.append(proxy)
    app.router.add_get('/', lambda request: web.FileResponse(os.path.join(static_dir, 'index.html')))
    app.router.add_static('/', static_dir, show_index=True)
    app.on_cleanup.append(lambda a: s.close())
    return app

if __name__ == '__main__':
    print("Nutzung: python-server.py 8080 Verzeichnis")

    port       = int(sys.argv[1])
    target_dir = sys.argv[2]

    web.run_app(make_app(target_dir), port=port)
