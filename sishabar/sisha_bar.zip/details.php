<?php 
include 'data.php'; 
$type = $_GET['type'] ?? '';
$id = $_GET['id'] ?? '';
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Details - Cozy Shisha Bar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="overflow: auto; padding: 50px;">
    <a href="index.php" class="btn">< Zurück</a>
    <div class="card" style="margin: 50px auto; max-width: 800px;">
        <?php if($type == 'drink' && isset($getraenke[$id])): $d = $getraenke[$id]; ?>
            <h1 class="gold-title"><?php echo $d['titel']; ?></h1>
            <img src="<?php echo $d['bild']; ?>" width="100%">
            <p><?php echo $d['beschreibung']; ?></p>
            <p><strong>Preis:</strong> <?php echo $d['preis']; ?></p>
            <p><strong>Inhaltsstoffe:</strong> <?php echo $d['inhalt']; ?></p>
        <?php elseif($type == 'all'): ?>
            <h1 class="gold-title">Vollständige Karte</h1>
            <?php foreach($getraenke as $d): ?>
                <div style="margin-bottom:20px; border-bottom:1px solid var(--gold)">
                    <h3><?php echo $d['titel']; ?> - <?php echo $d['preis']; ?></h3>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
