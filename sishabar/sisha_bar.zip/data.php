<?php
$getraenke = [
    "blue_lagoon" => [
        "titel" => "Blue Lagoon Shisha Mix",
        "beschreibung" => "Ein erfrischender Mix mit Blaubeere und Minze.",
        "preis" => "14.50€",
        "inhalt" => "Tabak, Glycerin, Aroma, Menthol",
        "bild" => "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=800"
    ],
    "oriental_tea" => [
        "titel" => "Marokkanische Minze",
        "beschreibung" => "Frisch aufgebrühter Tee mit Honig.",
        "preis" => "5.50€",
        "inhalt" => "Frische Minze, Grüner Tee, Rohrzucker",
        "bild" => "https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=800"
    ],
    "golden_cocktail" => [
        "titel" => "Golden Sunset",
        "beschreibung" => "Exotischer Cocktail mit Blattgold-Optik.",
        "preis" => "12.00€",
        "inhalt" => "Ananas, Maracuja, Limette, Grenadine",
        "bild" => "https://images.unsplash.com/photo-1536935338788-846bb9981813?q=80&w=800"
    ]
];

$events = [
    ["titel" => "Arabian Night", "datum" => "Jeden Freitag", "text" => "Bauchtanz & Live DJ"],
    ["titel" => "Ladies Night", "datum" => "Mittwoch", "text" => "Shisha für Ladies zum halben Preis"],
    ["titel" => "Deep House", "datum" => "Samstag", "text" => "Chillige Beats den ganzen Abend"]
];
?>
