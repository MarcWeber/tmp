<?php include 'data.php'; ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Cozy Shisha Bar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <!--  <section> -->
    <!--      <video autoplay muted loop class="video-bg"> -->
    <!--          <source src="https://www.w3schools.com/howto/rain.mp4" type="video/mp4"> -->
    <!--      </video> -->
    <!--      <h1 class="gold-title">Cozy Shisha Bar</h1> -->
    <!--      <p class="glitter-text">Exklusive Momente in Gold & Blau</p> -->
    <!--  </section> -->

  <section class="hero-slider">
      <div class="slide" style="background-image: url('/assets/upscayl_jpg_high-fidelity-4x_2x/6.jpg');"></div>
      <div class="slide" style="background-image: url('/assets/upscayl_jpg_high-fidelity-4x_2x/2.jpg');"></div>
      <div class="slide" style="background-image: url('/assets/upscayl_jpg_high-fidelity-4x_2x/3.jpg');"></div>

      <div class="hero-content reveal-left">
          <h1 class="gold-title">Cozy Shisha Bar</h1>
          <p class="glitter-text">Exklusive Momente in Gold & Blau</p>
      </div>

  </section>


    <section>
        <h2 style="color:var(--gold)">Unsere Highlights</h2>
        <div class="card" id="menu-slider">
            <?php $i = 0; foreach($getraenke as $id => $item): ?>
                <div class="slider-item <?php echo $i === 0 ? 'active' : ''; ?>">
                    <img src="<?php echo $item['bild']; ?>" width="100" style="border-radius:50%">
                    <h3><?php echo $item['titel']; ?></h3>
                    <p><?php echo $item['beschreibung']; ?></p>
                    <a href="details.php?type=drink&id=<?php echo $id; ?>" class="btn">Details</a>
                </div>
            <?php $i++; endforeach; ?>
            <br>
            <button onclick="nextSlide('menu-slider')" class="btn">Nächstes</button>
            <a href="details.php?type=all" class="btn" style="border-color:var(--blue); color:white">Alle Getränke</a>
        </div>
    </section>

    <section style="background: url('https://images.unsplash.com/photo-1542332213-9b5a5a3fab35?q=80&w=1200') center/cover;">
        <div style="background: rgba(0,0,0,0.6); padding: 20px;">
            <h2 class="glitter-text">Entspannung pur in jeder Wolke.</h2>
        </div>
    </section>

    <section>
        <h2 style="color:var(--gold)">Kommende Events</h2>
        <div class="card">
            <?php foreach($events as $event): ?>
                <div style="margin-bottom: 15px; border-bottom: 1px dashed var(--beige)">
                    <strong class="gold-text"><?php echo $event['datum']; ?></strong>: <?php echo $event['titel']; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<script>
function nextSlide(id) {
    const slides = document.querySelectorAll('#' + id + ' .slider-item');
    let activeIndex = Array.from(slides).findIndex(s => s.classList.contains('active'));
    slides[activeIndex].classList.remove('active');
    let nextIndex = (activeIndex + 1) % slides.length;
    slides[nextIndex].classList.add('active');
}
</script>
</body>
</html>
