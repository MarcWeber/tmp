<?php
/**
 * Plugin Name: Blogs mit Filter [Customizable]
 * Description: Filtert Posts nach Jahr und Typ (Kategorie). Shortcode-Name ist einstellbar.
 * Version: 1.1
 * Author: Gemini
 */

if (!defined('ABSPATH')) exit;

// 1. EINSTELLUNGEN (SETTINGS API)
// ----------------------------------------------------------------
function cfl_register_settings() {
    add_option('cfl_initial_posts', '5');
    add_option('cfl_preview_chars', '100');
    add_option('cfl_shortcode_tag', 'FILTER'); // Default Tag
    
    register_setting('cfl_options_group', 'cfl_initial_posts');
    register_setting('cfl_options_group', 'cfl_preview_chars');
    register_setting('cfl_options_group', 'cfl_shortcode_tag');
}
add_action('admin_init', 'cfl_register_settings');

function cfl_register_options_page() {
    add_options_page('Filter Plugin Einstellungen', 'Filter Plugin', 'manage_options', 'cfl', 'cfl_options_page_html');
}
add_action('admin_menu', 'cfl_register_options_page');

function cfl_options_page_html() {
    $current_tag = get_option('cfl_shortcode_tag', 'FILTER');
    ?>
    <div class="wrap">
        <h1>Filter Plugin Einstellungen</h1>
        <form method="post" action="options.php">
            <?php settings_fields('cfl_options_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Shortcode Name:</th>
                    <td>
                        <input type="text" name="cfl_shortcode_tag" value="<?php echo esc_attr($current_tag); ?>" />
                        <p class="description">Standard ist <code>FILTER</code>. Nutzung: <code>[<?php echo esc_html($current_tag); ?>]</code></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Anzahl initialer Posts:</th>
                    <td><input type="number" name="cfl_initial_posts" value="<?php echo esc_attr(get_option('cfl_initial_posts')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Anzahl Buchstaben (Vorschau):</th>
                    <td><input type="number" name="cfl_preview_chars" value="<?php echo esc_attr(get_option('cfl_preview_chars')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// 2. HELPER: POST RENDERING (Unchanged)
// ----------------------------------------------------------------
function cfl_render_single_post($post_id, $char_limit) {
    $post = get_post($post_id);
    $title = get_the_title($post_id);
    $categories = get_the_category($post_id);
    $type_name = !empty($categories) ? $categories[0]->name : 'Allgemein';
    $content = strip_shortcodes($post->post_content);
    $content_html = apply_filters('the_content', $content);
    $content_text = wp_strip_all_tags($content_html);
    
    if (strlen($content_text) > $char_limit) {
        $content_text = mb_substr($content_text, 0, $char_limit) . '...';
    }

    $permalink = get_permalink($post_id);
    
    ob_start();
    ?>
    <div class="cfl-post-item" style="border:1px solid #ddd; padding:15px; margin-bottom:15px;">
        <div class="cfl-header" style="display:flex; justify-content:space-between; border-bottom:1px solid #eee; margin-bottom:10px; padding-bottom:5px;">
            <h3 style="margin:0;"><?php echo esc_html($title); ?></h3>
            <span class="cfl-type" style="font-weight:bold; color:#666;"><?php echo esc_html($type_name); ?></span>
        </div>
        <div class="cfl-body"><?php echo esc_html($content_text); ?></div>
        <div class="cfl-footer" style="margin-top:10px; display:flex; gap:10px; align-items:center;">
            <a href="<?php echo esc_url($permalink); ?>" class="cfl-more-link">Mehr</a>
            <button class="cfl-pdf-btn" onclick="window.print()" style="padding:5px 10px; cursor:pointer;">PDF</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// 3. SHORTCODE HANDLER
// ----------------------------------------------------------------
function cfl_shortcode_handler($atts) {
    $selected_year = isset($_GET['year']) ? intval($_GET['year']) : '';
    $selected_type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
    $posts_per_page = get_option('cfl_initial_posts', 5);
    $char_limit = get_option('cfl_preview_chars', 100);

    $categories = get_categories();
    global $wpdb;
    $years = $wpdb->get_col("SELECT DISTINCT YEAR(post_date) FROM $wpdb->posts WHERE post_status = 'publish' ORDER BY post_date DESC");

    ob_start();
    ?>
    <div class="cfl-container">
        <form id="cfl-filter-form" onsubmit="return false;">
            <select name="year" id="cfl-year">
                <option value="">Alle Jahre</option>
                <?php foreach($years as $y): ?>
                    <option value="<?php echo $y; ?>" <?php selected($selected_year, $y); ?>><?php echo $y; ?></option>
                <?php endforeach; ?>
            </select>

            <select name="type" id="cfl-type">
                <option value="">Alle Typen</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat->slug; ?>" <?php selected($selected_type, $cat->slug); ?>><?php echo $cat->name; ?></option>
                <?php endforeach; ?>
            </select>
        </form>

        <div id="cfl-posts-wrapper" style="margin-top:20px;">
            <?php
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => $posts_per_page,
                'paged' => 1,
                'post_status' => 'publish'
            );

            if ($selected_year) $args['date_query'] = array(array('year' => $selected_year));
            if ($selected_type) $args['category_name'] = $selected_type;

            $query = new WP_Query($args);
            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    echo cfl_render_single_post(get_the_ID(), $char_limit);
                }
            } else {
                echo '<p>Keine Beiträge gefunden.</p>';
            }
            $max_pages = $query->max_num_pages;
            wp_reset_postdata();
            ?>
        </div>

        <?php if ($max_pages > 1): ?>
            <button id="cfl-load-more" data-page="1" data-max="<?php echo $max_pages; ?>" 
                    data-year="<?php echo esc_attr($selected_year); ?>" 
                    data-type="<?php echo esc_attr($selected_type); ?>"
                    style="width:100%; padding:10px; margin-top:20px;">
                [ mehr laden ]
            </button>
        <?php endif; ?>
    </div>

    <script>
        // Filter logic
        function updateFilters() {
            const url = new URL(window.location.href);
            const params = new URLSearchParams(url.search);
            const year = document.getElementById('cfl-year').value;
            const type = document.getElementById('cfl-type').value;
            if (year) params.set('year', year); else params.delete('year');
            if (type) params.set('type', type); else params.delete('type');
            window.location.search = params.toString();
        }
        document.getElementById('cfl-year').addEventListener('change', updateFilters);
        document.getElementById('cfl-type').addEventListener('change', updateFilters);

        // AJAX Load More
        const loadMoreBtn = document.getElementById('cfl-load-more');
        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', function() {
                const btn = this;
                const page = parseInt(btn.getAttribute('data-page'));
                const nextPage = page + 1;
                const formData = new FormData();
                formData.append('action', 'cfl_load_more');
                formData.append('page', nextPage);
                formData.append('year', btn.getAttribute('data-year'));
                formData.append('type', btn.getAttribute('data-type'));

                btn.innerText = 'Lade...';
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', { method: 'POST', body: formData })
                .then(r => r.text())
                .then(html => {
                    document.getElementById('cfl-posts-wrapper').insertAdjacentHTML('beforeend', html);
                    btn.setAttribute('data-page', nextPage);
                    btn.innerText = '[ mehr laden ]';
                    if (nextPage >= parseInt(btn.getAttribute('data-max'))) btn.style.display = 'none';
                });
            });
        }
    </script>
    <?php
    return ob_get_clean();
}

// 4. DYNAMIC SHORTCODE REGISTRATION
// ----------------------------------------------------------------
function cfl_init_shortcode() {
    $tag = get_option('cfl_shortcode_tag', 'FILTER');
    // Ensure tag is not empty to avoid errors
    if (empty($tag)) $tag = 'FILTER';
    add_shortcode($tag, 'cfl_shortcode_handler');
}
add_action('init', 'cfl_init_shortcode');

// AJAX handler remains same
function cfl_ajax_load_more() {
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $year = isset($_POST['year']) ? intval($_POST['year']) : '';
    $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';
    $posts_per_page = get_option('cfl_initial_posts', 5);
    $char_limit = get_option('cfl_preview_chars', 100);

    $args = array('post_type' => 'post', 'posts_per_page' => $posts_per_page, 'paged' => $page, 'post_status' => 'publish');
    if ($year) $args['date_query'] = array(array('year' => $year));
    if ($type) $args['category_name'] = $type;

    $query = new WP_Query($args);
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            echo cfl_render_single_post(get_the_ID(), $char_limit);
        }
    }
    wp_die();
}
add_action('wp_ajax_cfl_load_more', 'cfl_ajax_load_more');
add_action('wp_ajax_nopriv_cfl_load_more', 'cfl_ajax_load_more');
