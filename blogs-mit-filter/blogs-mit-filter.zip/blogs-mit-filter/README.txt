.zip Datei installieren in Wordpress als Plugin

Eine Seite auwählen.
Dort [FILTER] eintragen. Dann sollten Blog Posts erscheinen.


Einstellungen:
Wie viele Einträge geladen werden sollen
Wie viele Buchstaben angezeigt werden
Das Trigger-Wort [FILTER] als default
