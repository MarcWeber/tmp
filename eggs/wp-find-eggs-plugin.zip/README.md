# WP Find Eggs

Easter egg hunt plugin for WordPress. Visitors find hidden eggs on your pages and get a discount code when they find them all.

## Installation

1. Upload `wp-find-eggs-plugin/` to `/wp-content/plugins/`
2. Activate in WordPress admin
3. Configure at Settings → Find Eggs

## Configuration

| Setting | Description |
|---------|-------------|
| Discount Code | Code shown when all eggs are found |
| Egg URLs | Image URLs (one per line), or use defaults |
| Allow Pages | Regex patterns for pages with eggs |
| Disallow Pages | Regex patterns for pages without eggs |
| Eggs to Find | How many eggs to collect |
| Egg Appearance | Position and chance per egg |
| Session Suffix | Change to reset for all users |

## Egg Appearance

Format: `type:chance` (one per line)

Types:
- `static` - Visible in viewport (always in view)
- `anywhere` - Random position anywhere on page (may be visible)
- `require-scrolling` - Outside viewport (must scroll to find)

Example:
```
static:100
anywhere:100
require-scrolling:100
```

## Placeholders

Use these in popup messages:
- `FOUND` - Current egg count
- `TO_BE_FOUND` - Total eggs to find  
- `CODE` - The discount code

## Files

- `wp-find-eggs.php` - Main plugin file
- `assets/easter-eggs.js` - Frontend JavaScript  
- `assets/ei*.jpg` - Default egg images
- `tests/test.js` - Puppeteer test (run from repo root)
