<?php
/**
 * Plugin Name: WP Find Eggs
 * Description: Easter egg hunt - find eggs, get a discount code!
 * Version: 1.4.0
 */

if (!defined('ABSPATH')) exit;

class WP_Find_Eggs {
    private $defaults = [
        'discount_code' => 'OSTERN2026',
        'egg_urls' => '',
        'allow_pages' => '.*',
        'disallow_pages' => '',
        'eggs_to_find' => 3,
        'session_suffix' => 'v5',
        'egg_appearance' => "static:100\nanywhere:100\nstatic:100",
        'motivational_popup' => "Du hast <strong>[[FOUND]]</strong> von <strong>[[TO_BE_FOUND]]</strong> Eiern gefunden!",
        'discount_popup' => "Herzlichen Glückwunsch!\n[[CODE]]",
        'info_incomplete' => '',
        'info_completed' => ''
    ];

    public function __construct() {
        $saved = get_option('wp_find_eggs_options', []);
        $this->options = array_merge($this->defaults, $saved);
        $this->migrate_placeholders();
        add_action('admin_menu', fn() => add_options_page('Find Eggs', 'Find Eggs', 'manage_options', 'wp_find_eggs', [$this, 'settings_page']));
        add_action('admin_init', fn() => register_setting('wp_find_eggs', 'wp_find_eggs_options'));
        add_action('wp_footer', [$this, 'inject']);
    }

    private function migrate_placeholders() {
        $map = ['motivational_popup', 'discount_popup', 'info_incomplete', 'info_completed'];
        foreach ($map as $key) {
            if (isset($this->options[$key])) {
                $this->options[$key] = preg_replace('/(?!\[\[)TO_BE_FOUND(?!\]\])/', '[[TO_BE_FOUND]]', $this->options[$key]);
                $this->options[$key] = preg_replace('/(?!\[\[)FOUND(?!\]\])/', '[[FOUND]]', $this->options[$key]);
                $this->options[$key] = preg_replace('/(?!\[\[)CODE(?!\]\])/', '[[CODE]]', $this->options[$key]);
            }
        }
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $home = get_option('home');
        $plg_url = $home . '/wp-content/plugins/' . basename(__DIR__);
        $o = $this->options;
        ?>
        <div class="wrap">
            <h1>Find Eggs Settings</h1>
            
            <h2>Platzhalter</h2>
            <table class="widefat" style="max-width:600px">
                <tr><th>Platzhalter</th><th>Beschreibung</th></tr>
                <tr><td><code>FOUND</code></td><td>Anzahl gefundener Eier</td></tr>
                <tr><td><code>TO_BE_FOUND</code></td><td>Gesamtzahl zu findender Eier</td></tr>
                <tr><td><code>CODE</code></td><td>Der Rabatt-Code</td></tr>
            </table>
            
            <h2 style="margin-top:20px">Egg Appearance Format</h2>
            <table class="widefat" style="max-width:600px">
                <tr><th>Format</th><th>Beschreibung</th></tr>
                <tr><td><code>static:50</code></td><td>Sichtbar (fixed), 50% Chance</td></tr>
                <tr><td><code>anywhere:100</code></td><td>Beliebige Position auf der Seite (random), 100% Chance</td></tr>
                <tr><td><code>require-scrolling:100</code></td><td>Position außerhalb Viewport (Scrollen nötig), 100% Chance</td></tr>
                <tr><td colspan="2"><em>Eine Zeile pro Ei</em></td></tr>
            </table>
            
            <h2 style="margin-top:20px">Page Filtering (Regex)</h2>
            <table class="widefat" style="max-width:600px">
                <tr><th>Feld</th><th>Beschreibung</th></tr>
                <tr><td>Erlaubte Seiten</td><td>Regex für Seiten MIT Eggs (leer = alle)</td></tr>
                <tr><td>Verbotene Seiten</td><td>Regex für Seiten OHNE Eggs</td></tr>
                <tr><td colspan="2"><em>Eine Regex pro Zeile. Beispiel: <code>/kategorie/, /angebot/</code></em></td></tr>
            </table>
            
            <form method="post" action="options.php" style="margin-top:20px">
                <?php settings_fields('wp_find_eggs'); ?>
                <table class="form-table">
                    <tr><th scope="row">Rabatt-Code</th><td><input type="text" name="wp_find_eggs_options[discount_code]" value="<?php echo esc_attr($o['discount_code']); ?>" class="regular-text"></td></tr>
                    <tr><th scope="row">Egg URLs (eine pro Zeile)</th><td><textarea name="wp_find_eggs_options[egg_urls]" rows="3" class="large-text code"><?php echo esc_textarea($o['egg_urls']); ?></textarea></td></tr>
                    <tr><th scope="row">Erlaubte Seiten (Regex)</th><td><textarea name="wp_find_eggs_options[allow_pages]" rows="2" class="large-text code"><?php echo esc_textarea($o['allow_pages']); ?></textarea></td></tr>
                    <tr><th scope="row">Verbotene Seiten (Regex)</th><td><textarea name="wp_find_eggs_options[disallow_pages]" rows="2" class="large-text code"><?php echo esc_textarea($o['disallow_pages']); ?></textarea></td></tr>
                    <tr><th scope="row">Eier zu finden</th><td><input type="number" name="wp_find_eggs_options[eggs_to_find]" value="<?php echo (int)$o['eggs_to_find']; ?>" min="1" max="20"></td></tr>
                    <tr><th scope="row">Egg Appearance<br><small>(type:chance, one per line)</small></th><td><textarea name="wp_find_eggs_options[egg_appearance]" rows="4" class="large-text code"><?php echo esc_textarea($o['egg_appearance']); ?></textarea></td></tr>
                    <tr><th scope="row">Session Suffix<br><small>(Ändern = Neustart)</small></th><td><input type="text" name="wp_find_eggs_options[session_suffix]" value="<?php echo esc_attr($o['session_suffix']); ?>" class="regular-text"></td></tr>
                    <tr><th scope="row">Motivations-Popup</th><td><textarea name="wp_find_eggs_options[motivational_popup]" rows="3" class="large-text code"><?php echo esc_textarea($o['motivational_popup']); ?></textarea></td></tr>
                    <tr><th scope="row">Rabatt-Popup</th><td><textarea name="wp_find_eggs_options[discount_popup]" rows="3" class="large-text code"><?php echo esc_textarea($o['discount_popup']); ?></textarea></td></tr>
                    <tr><th scope="row">Info Incomplete<br><small>(Optional - 0/X Eier)</small></th><td><textarea name="wp_find_eggs_options[info_incomplete]" rows="3" class="large-text code"><?php echo esc_textarea($o['info_incomplete']); ?></textarea></td></tr>
                    <tr><th scope="row">Info Completed<br><small>(Optional - 3/3 Eier)</small></th><td><textarea name="wp_find_eggs_options[info_completed]" rows="3" class="large-text code"><?php echo esc_textarea($o['info_completed']); ?></textarea></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
            
            <hr>
            <h2>Default Egg URLs</h2>
            <p><?php echo esc_html($plg_url); ?>/assets/ei1.jpg<br><?php echo esc_html($plg_url); ?>/assets/ei2.jpg<br><?php echo esc_html($plg_url); ?>/assets/ei3.jpg</p>
            <img src="<?php echo esc_url($plg_url); ?>/assets/ei1.jpg" style="width:60px">
            <img src="<?php echo esc_url($plg_url); ?>/assets/ei2.jpg" style="width:60px">
            <img src="<?php echo esc_url($plg_url); ?>/assets/ei3.jpg" style="width:60px">
        </div>
        <?php
    }

    private function is_allowed() {
        if (is_admin() || strpos($_SERVER['REQUEST_URI'], '/wp-admin/') !== false) return false;
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $o = $this->options;
        if (!empty($o['disallow_pages'])) {
            foreach (explode("\n", $o['disallow_pages']) as $p) {
                if ($p = trim($p)) @preg_match("/$p/", $path) and $path = '';
            }
        }
        if (!empty($o['allow_pages'])) {
            foreach (explode("\n", $o['allow_pages']) as $p) {
                if ($p = trim($p) and @preg_match("/$p/", $path)) return true;
            }
            return false;
        }
        return true;
    }

    private function parse_appearance($str) {
        $result = [];
        foreach (explode("\n", $str) as $item) {
            $item = trim($item);
            if (preg_match('/^(\w+):(\d+)$/', $item, $m)) {
                $result[] = ['type' => $m[1], 'chance' => (int)$m[2]];
            }
        }
        return $result ?: [['type' => 'static', 'chance' => 100]];
    }

    public function inject() {
        if (!$this->is_allowed()) return;
        $o = $this->options;
        $urls = array_filter(array_map('trim', explode("\n", $o['egg_urls'])));
        if (!$urls) {
            $plg = plugin_dir_url(__FILE__);
            $urls = [$plg . 'assets/ei1.jpg', $plg . 'assets/ei2.jpg', $plg . 'assets/ei3.jpg'];
        }
        $config = json_encode([
            'urls' => $urls,
            'target' => (int)$o['eggs_to_find'],
            'mPopup' => $o['motivational_popup'],
            'rPopup' => $o['discount_popup'],
            'infoIncomplete' => $o['info_incomplete'] ?? $o['info_popup'] ?? '',
            'infoCompleted' => $o['info_completed'] ?? '',
            'rCode' => $o['discount_code'],
            'sessionSuffix' => $o['session_suffix'],
            'appearances' => $this->parse_appearance($o['egg_appearance'])
        ]);
        ?>
        <style>
            .wp-egg{width:60px;height:70px;cursor:pointer;z-index:999999;animation:bounce 2s infinite}
            .wp-egg:hover{transform:scale(1.2)}
            @keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-15px)}}
            .wp-popup{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;padding:30px;border-radius:15px;box-shadow:0 10px 40px rgba(0,0,0,.3);z-index:1000001;text-align:center;max-width:450px}
            .wp-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:1000000}
            .wp-btn{padding:10px 25px;border:none;border-radius:5px;cursor:pointer;font-size:14px;margin:5px;font-weight:bold}
            .wp-close{background:#2271b1;color:#fff}.wp-copy{background:#198754;color:#fff}
            .wp-counter{position:fixed;bottom:20px;right:20px;background:linear-gradient(135deg,#ff6b6b,#ff8e53);color:#fff;padding:15px 25px;border-radius:30px;font-weight:bold;z-index:999998;font-size:16px}
        </style>
        <div id="wp-counter" class="wp-counter" style="display:none">0 / <?php echo (int)$o['eggs_to_find']; ?> 🥚</div>
        <script><?php echo file_get_contents(__DIR__ . '/assets/easter-eggs.js'); ?>wpEierInit(<?php echo $config; ?>);})();</script>
        <?php
    }
}

new WP_Find_Eggs();
