(function(){
    var cfg, count = 0, shown = false;

    function sk() { return 'wpe_' + cfg.sessionSuffix; }

    function load() {
        try {
            var d = localStorage.getItem(sk());
            if (d) {
                var p = JSON.parse(d);
                if (p.s !== cfg.sessionSuffix) return {f:0, c:false};
                return p;
            }
        } catch(e) {}
        return {f:0, c:false};
    }

    function save(d) {
        try { localStorage.setItem(sk(), JSON.stringify(d)); } catch(e) {}
    }

    function listenForChanges() {
        window.addEventListener('storage', function(e) {
            if (e.key === sk() && e.newValue) {
                try {
                    var p = JSON.parse(e.newValue);
                    count = p.f;
                    shown = p.c;
                    updateCounter();
                } catch(err) {}
            }
        });
    }

    function rp(str) {
        return str.replace(/\[\[FOUND\]\]/g, count).replace(/\[\[TO_BE_FOUND\]\]/g, cfg.target).replace(/\[\[CODE\]\]/g, cfg.rCode).replace(/\n/g, '<br>');
    }

    function updateCounter() {
        var el = document.getElementById('wp-counter');
        if (el) { 
            el.textContent = count + ' / ' + cfg.target + ' 🥚'; 
            el.style.display = 'block';
            el.style.cursor = 'pointer';
            el.onclick = function() {
                if (count >= cfg.target && cfg.infoCompleted) showDiscount();
                else if (cfg.infoIncomplete) {
                    var ov = document.createElement('div');
                    ov.className = 'wp-overlay';
                    var po = document.createElement('div');
                    po.className = 'wp-popup';
                    po.innerHTML = '<div style="font-size:40px">🥚</div><div style="font-size:18px;margin:15px 0">' + rp(cfg.infoIncomplete) + '</div><button class="wp-btn wp-close">Weiter!</button>';
                    document.body.appendChild(ov);
                    document.body.appendChild(po);
                    po.querySelector('.wp-close').onclick = function() { po.remove(); ov.remove(); };
                    ov.onclick = function() { po.remove(); ov.remove(); };
                }
            };
        }
    }

    function getAppearance(idx) {
        return cfg.appearances[idx] || {type: 'static', chance: 100};
    }

    function makeEgg() {
        if (shown || !cfg.urls.length) return;
        var app = getAppearance(count);
        if (Math.random() > app.chance / 100) return;
        var img = document.createElement('img');
        img.src = cfg.urls[Math.floor(Math.random() * cfg.urls.length)];
        img.className = 'wp-egg';
        if (app.type === 'static') {
            img.style.position = 'fixed';
            img.style.left = (Math.random() * (window.innerWidth - 120) + 20) + 'px';
            img.style.top = (Math.random() * (window.innerHeight - 170) + 50) + 'px';
        } else if (app.type === 'require-scrolling') {
            var pageH = Math.max(document.body.scrollHeight, window.innerHeight * 2);
            img.style.position = 'absolute';
            img.style.left = (Math.random() * (window.innerWidth - 100)) + 'px';
            img.style.top = (window.innerHeight + Math.random() * (pageH - window.innerHeight - 100)) + 'px';
        } else {
            var pageW = Math.max(document.body.scrollWidth, window.innerWidth);
            var pageH = Math.max(document.body.scrollHeight, window.innerHeight * 2);
            img.style.position = 'absolute';
            img.style.left = (Math.random() * (pageW - 100)) + 'px';
            img.style.top = (Math.random() * pageH) + 'px';
        }
        img.addEventListener('click', function() {
            img.remove();
            count++;
            save({f: count, c: shown, s: cfg.sessionSuffix});
            updateCounter();
            count >= cfg.target ? showDiscount() : showMotivational();
            setTimeout(makeEgg, 2000);
        });
        document.body.appendChild(img);
    }

    function showMotivational() {
        var ov = document.createElement('div');
        ov.className = 'wp-overlay';
        var po = document.createElement('div');
        po.className = 'wp-popup';
        po.innerHTML = '<div style="font-size:40px">🥚</div><div style="font-size:18px;margin:15px 0">' + rp(cfg.mPopup) + '</div><button class="wp-btn wp-close">Weiter!</button>';
        document.body.appendChild(ov);
        document.body.appendChild(po);
        po.querySelector('.wp-close').onclick = function() { po.remove(); ov.remove(); };
        ov.onclick = function() { po.remove(); ov.remove(); };
    }

    function showDiscount() {
        var ov = document.createElement('div');
        ov.className = 'wp-overlay';
        var po = document.createElement('div');
        po.className = 'wp-popup';
        if (cfg.infoCompleted) {
            po.innerHTML = '<div style="font-size:40px">🥚</div><div style="font-size:18px;margin:15px 0">' + rp(cfg.infoCompleted) + '</div><button class="wp-btn wp-close">Weiter!</button>';
        } else {
            po.innerHTML = '<div style="font-size:50px">🎉</div><div style="font-size:18px;margin:15px 0">' + rp(cfg.rPopup) + '</div><button class="wp-btn wp-copy">Kopieren!</button><button class="wp-btn wp-close">Schließen</button>';
            po.querySelector('.wp-copy').onclick = function() { navigator.clipboard.writeText(cfg.rCode).then(function() { alert('Kopiert!'); }).catch(function() { prompt('Code:', cfg.rCode); }); };
        }
        document.body.appendChild(ov);
        document.body.appendChild(po);
        po.querySelector('.wp-close').onclick = function() { po.remove(); ov.remove(); };
        ov.onclick = function() { po.remove(); ov.remove(); };
        shown = true;
        save({f: count, c: shown, s: cfg.sessionSuffix});
    }

    window.wpEierInit = function(config) {
        cfg = config;
        var s = load();
        count = s.f;
        shown = s.c;
        updateCounter();
        listenForChanges();
        if (!shown && cfg.urls.length) makeEgg();
    };
